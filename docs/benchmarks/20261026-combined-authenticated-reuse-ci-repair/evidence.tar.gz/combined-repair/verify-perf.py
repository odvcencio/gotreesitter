import json, subprocess
from pathlib import Path
root='/candidate'
def git(*args):
 return subprocess.check_output(['git','-C',root,*args])
def paths(*args):
 return {p for p in git(args[0],'-z',*args[1:]).decode().split('\0') if p}
m=json.loads(Path('/controls/combined-repair/perf.json').read_text())['Replace']
assert git('rev-parse','HEAD').decode().strip() == 'f546fceea6edb77843dba0f7009d4f7ff73a893a'
changed=paths('diff','--name-only','HEAD','--','*.go') | paths('ls-files','--others','--exclude-standard','--','*.go')
actual={k[len('/baseline/'):] for k in m if k.startswith('/baseline/') and k != '/baseline/authenticated_reuse_benchmark_private_test.go'}
assert actual == changed, (sorted(actual-changed), sorted(changed-actual))
for name in changed:
 source=m['/baseline/'+name]
 try:
  expected=git('show','HEAD:'+name)
 except subprocess.CalledProcessError:
  assert source == '', name
 else:
  assert source == '/controls/combined-repair/v28-baseline/'+name, name
  assert Path(source).read_bytes()==expected, name
manifest=Path('/controls/combined-repair/source.sha256').read_text().splitlines()
pinned={line.split('  ',1)[1] for line in manifest}
files=paths('ls-files','-co','--exclude-standard')
current={p for p in files if (p.endswith('.go') or p.startswith('cmd/v1layout/api/')) and Path(root,p).is_file()}
assert current == pinned, (sorted(current-pinned), sorted(pinned-current))
print('exact source set and baseline overlay match published V28 blobs')
