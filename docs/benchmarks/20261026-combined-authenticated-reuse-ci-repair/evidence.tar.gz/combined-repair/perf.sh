set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly -overlay=/controls/combined-repair/perf.json' GTS_ADMISSION_CANDIDATE=0
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
check() {
 sha256sum --quiet -c /controls/combined-repair/source.sha256
 sha256sum --quiet -c /controls/combined-repair/perf-controls.sha256
 python3 /controls/combined-repair/verify-perf.py
}
trap 'check > /evidence/guard-after.log 2>&1' EXIT
check > /evidence/guard-before.log 2>&1
python3 - <<'GATE'
import json
from pathlib import Path
summary = json.loads(Path('/controls/out-combined-repair-counters/summary.json').read_text())
assert summary['languages'] == 206 and summary['routes_per_language'] == 2
assert summary['ledger_exports_byte_identical'] and summary['work_and_reuse_direction_passed']
assert summary['changes'] == []
GATE
bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/before.txt --output /evidence/after.txt --runs 20 --seed-start 1 --benchtime 750ms --bench-regex '^BenchmarkGTSAuthenticatedReuse$' --require-benchmarks 'BenchmarkGTSAuthenticatedReuse/BenchmarkGoParseFullDFA,BenchmarkGTSAuthenticatedReuse/BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGTSAuthenticatedReuse/BenchmarkGoParseIncrementalNoEditDFA,BenchmarkGTSAuthenticatedReuse/Report137KiBFull,BenchmarkGTSAuthenticatedReuse/Report137KiBEdit,BenchmarkGTSAuthenticatedReuse/Report137KiBEditProfiled' --lock-path /runtime/tmp/gts-repair-perf.lock > /evidence/randomized.log 2>&1
