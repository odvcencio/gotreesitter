//go:build gts_parsercorephase0 || gts_workcount || gts_diag

package gotreesitter

import "github.com/odvcencio/gotreesitter/internal/incr"

type trustedGoReuseShadowEvent struct {
	parser *Parser
	source []byte
	old, candidate, fresh *Tree
	wouldCertify, smallMode, bypassed bool
}

type legacyShadowObserver struct { call func(trustedGoReuseShadowEvent) }
var trustedGoReuseShadowObserver legacyShadowObserver

func (o *legacyShadowObserver) Lock() { incr.ReuseObserver.Lock() }
func (o *legacyShadowObserver) Unlock() {
	fn := o.call
	if fn == nil { incr.ReuseObserver.Call = nil } else {
		incr.ReuseObserver.Call = func(e incr.ReuseObservation) {
			p, _ := e.Parser.(*Parser)
			old, _ := e.Old.(*Tree)
			candidate, _ := e.Candidate.(*Tree)
			fresh, _ := e.Fresh.(*Tree)
			fn(trustedGoReuseShadowEvent{p,e.Source,old,candidate,fresh,e.WouldCertify,e.SmallMode,e.Bypassed})
		}
	}
	incr.ReuseObserver.Unlock()
}
