package gotreesitter

import "fmt"
func W5StrictStateMismatch(a,b *Tree, lang *Language) string {
 if !incrementalTreesStructurallyEqual(a,b,lang) {return "public structure differs"}
 var walk func(*Node,*Node,string) string
 walk=func(x,y *Node,path string) string {
  if x==nil||y==nil {if x!=y{return path+": nil mismatch"};return ""}
  if x.symbol!=y.symbol || x.parseState!=y.parseState || x.preGotoState!=y.preGotoState || x.dynamicPrecedence!=y.dynamicPrecedence || x.ChildCount()!=y.ChildCount() {return fmt.Sprintf("%s span=%d..%d symbol=%d/%d state=%d/%d pre=%d/%d precedence=%d/%d children=%d/%d",path,x.StartByte(),x.EndByte(),x.symbol,y.symbol,x.parseState,y.parseState,x.preGotoState,y.preGotoState,x.dynamicPrecedence,y.dynamicPrecedence,x.ChildCount(),y.ChildCount())}
  for i:=0;i<x.ChildCount();i++ {if m:=walk(x.Child(i),y.Child(i),fmt.Sprintf("%s/%d",path,i));m!="" {return m}}
  return ""
 }
 return walk(a.RootNode(),b.RootNode(),"root")
}
