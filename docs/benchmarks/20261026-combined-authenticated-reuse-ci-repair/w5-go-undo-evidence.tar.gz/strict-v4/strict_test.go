package gotreesitter_test
import (
 "crypto/sha256"
 "fmt"
 "os"
 "testing"
 gts "github.com/odvcencio/gotreesitter"
 "github.com/odvcencio/gotreesitter/grammars"
)
func TestW5GoStrictUndo(t *testing.T) {
 src,err:=os.ReadFile("/controls/w5-ci/fixtures/go");if err!=nil {t.Fatal(err)}
 if fmt.Sprintf("%x",sha256.Sum256(src))!="ff2f811d29a56303bad96c3c7cff1a83814a974503a51cee918a314a96eb476e" {t.Fatal("fixture drift")}
 lang:=grammars.GoLanguage(); var point gts.Point;for _,c:=range src[:2959] {if c=='\n'{point.Row++;point.Column=0}else{point.Column++}}
 for _,profiled:=range []bool{false,true} {t.Run(fmt.Sprintf("profiled=%t",profiled),func(t *testing.T){
  p:=gts.NewParser(lang); old,err:=p.Parse(src);if err!=nil {t.Fatal(err)}; defer func(){old.Release()}(); current:=src
  for i,b:=range []byte{'Z','E'} {next:=append([]byte(nil),current...);next[2959]=b;end:=point;end.Column++;old.Edit(gts.InputEdit{StartByte:2959,OldEndByte:2960,NewEndByte:2960,StartPoint:point,OldEndPoint:end,NewEndPoint:end});fmt.Printf("W5_STRICT_START profiled=%t step=%d\n",profiled,i)
   var tree *gts.Tree;if profiled {tree,_,err=p.ParseIncrementalProfiled(next,old)}else{tree,err=p.ParseIncremental(next,old)};if err!=nil {t.Fatal(err)}
   fresh,err:=gts.NewParser(lang).Parse(next);if err!=nil{t.Fatal(err)};if reason:=gts.W5StrictStateMismatch(tree,fresh,lang);reason!="" {t.Errorf("step %d strict mismatch: %s",i,reason)};fresh.Release();old.Release();old=tree;current=next
  }
 })}
}
