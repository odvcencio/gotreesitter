package gotreesitter_test

import (
 "crypto/sha256"
 "fmt"
 "os"
 "testing"
 gts "github.com/odvcencio/gotreesitter"
 "github.com/odvcencio/gotreesitter/grammars"
)
func TestW5GoUndoReplay(t *testing.T) {
 src,err:=os.ReadFile("/controls/w5-ci/fixtures/go"); if err!=nil {t.Fatal(err)}
 if fmt.Sprintf("%x",sha256.Sum256(src))!="ff2f811d29a56303bad96c3c7cff1a83814a974503a51cee918a314a96eb476e" || len(src)!=140026 || src[2959]!='E' {t.Fatal("fixture drift")}
 p:=gts.NewParser(grammars.GoLanguage()); old,err:=p.Parse(src);if err!=nil {t.Fatal(err)}
 var point gts.Point;for _,c:=range src[:2959] {if c=='\n' {point.Row++;point.Column=0}else{point.Column++}}
 for i,b:=range []byte{'Z','E'} { fmt.Printf("W5_STEP_START %d\n",i); next:=append([]byte(nil),src...); next[2959]=b; end:=point;end.Column++;old.Edit(gts.InputEdit{StartByte:2959,OldEndByte:2960,NewEndByte:2960,StartPoint:point,OldEndPoint:end,NewEndPoint:end});tree,profile,err:=p.ParseIncrementalProfiled(next,old);if err!=nil{t.Fatal(err)};fmt.Printf("W5_REPLAY step=%d reuse=%d bytes=%d nodes=%d tokens=%d stacks=%d stop=%s\n",i,profile.ReusedSubtrees,profile.ReusedBytes,profile.NewNodesAllocated,profile.TokensConsumed,profile.MaxStacksSeen,tree.ParseRuntime().StopReason);old.Release();old=tree;src=next };old.Release()
}
