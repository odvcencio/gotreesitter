#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOMAXPROCS=1 GOWORK=off GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
go env GOOS GOARCH > /evidence/platform.txt
if [[ "$(go env GOARCH)" != arm64 ]]; then exit 30; fi
cd /candidate
go test -c -tags gts_parsercorephase0 -o /evidence/root.test . > /evidence/build.log 2>&1
GTS_ADMISSION_CANDIDATE=1 GTS_BENCHMARK_SEED=149501 GTS_WARM_CPU_PATH=/evidence/go-lr.cpu /evidence/root.test -test.run '^$' -test.bench '^BenchmarkCompactThroughputGo$/^grammargen_lr$' -test.benchtime=5s -test.count=1 -test.cpu=1 -test.benchmem -test.timeout=5m > /evidence/go-lr.log 2>&1
GTS_ADMISSION_CANDIDATE=1 GTS_BENCHMARK_SEED=149502 GTS_WARM_CPU_PATH=/evidence/yaml-ordinary.cpu /evidence/root.test -test.run '^$' -test.bench '^BenchmarkCompactThroughputYAML$/^r4_ordinary$' -test.benchtime=5s -test.count=1 -test.cpu=1 -test.benchmem -test.timeout=5m > /evidence/yaml-ordinary.log 2>&1
GTS_ADMISSION_CANDIDATE=1 GTS_BENCHMARK_SEED=149503 GTS_WARM_CPU_PATH=/evidence/yaml-owned.cpu /evidence/root.test -test.run '^$' -test.bench '^BenchmarkCompactThroughputYAML$/^r4_owned$' -test.benchtime=5s -test.count=1 -test.cpu=1 -test.benchmem -test.timeout=5m > /evidence/yaml-owned.log 2>&1
printf 'complete\n' > /evidence/complete.txt
