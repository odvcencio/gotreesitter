from pathlib import Path
import fcntl, hashlib, json, os, re, shutil, subprocess

base = Path('/Users/georgevillavicencio/.local/state/gotreesitter-compute/20261021-arm64-native-fields')
lab = base / 'warm-runtime-profiles-v1'
original = base / 'primitive-dfa-state-source-v1'
source = lab / 'source'
os.environ['PATH'] = '/Applications/Docker.app/Contents/Resources/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def manifest(root):
    return {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob('*.go')) if p.is_file()}

def checkout():
    p = '/Users/georgevillavicencio/Projects/gotreesitter'
    return {'head': subprocess.check_output(['git', '-C', p, 'rev-parse', 'HEAD'], text=True).strip(),
            'status': subprocess.check_output(['git', '-C', p, 'status', '--porcelain=v1'], text=True)}

with open('/Users/georgevillavicencio/.local/state/gotreesitter-compute/compute.lock', 'a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    assert (base / 'paged-read-history-v3/paired-perf/exit.txt').read_text().strip() == '0', 'paired timing must finish first'
    before = manifest(original)
    assert before == json.loads((base / 'compact-full-cpu-v1/before.json').read_text())['source_go']
    user_before = checkout()
    scope = json.loads((lab / 'scope.json').read_text())
    rel = 'benchmark_admission_candidate_route_test.go'
    assert before[rel] == scope['harness_before_sha256']
    assert digest(lab / 'benchmark-warm-profile.go.txt') == scope['harness_after_sha256']
    shutil.copytree(original, source, copy_function=os.link)
    temporary = source / (rel + '.gts-tmp')
    temporary.write_bytes((lab / 'benchmark-warm-profile.go.txt').read_bytes())
    temporary.replace(source / rel)
    modified = manifest(source)
    assert [key for key in before if before[key] != modified[key]] == [rel]
    (lab / 'before.json').write_text(json.dumps({'source_go': before, 'profile_source_go': modified,
        'checkout': user_before}, sort_keys=True) + '\n')
    docker = '/usr/local/bin/docker'
    name = 'gts-warm-runtime-profiles-native-20261022-v1'
    image = 'golang@sha256:3b4a11519ad929d1e1d261a12cff056f0c85b735253d7d861346b9c6f8b36437'
    args = [docker, 'run', '--platform', 'linux/arm64', '--name', name, '--network', 'none', '--memory', '4g',
            '--memory-swap', '4g', '--cpus', '2', '--cpuset-cpus', '2,3', '--pids-limit', '256',
            '-e', 'GOMAXPROCS=1', '-e', 'GOMEMLIMIT=3GiB', '-e', 'GOCACHE=/go-build',
            '-v', str(base / 'inactive-scanner-trials-v1/go-build') + ':/go-build',
            '-v', str(source) + ':/candidate:ro', '-v', str(lab) + ':/evidence',
            image, 'bash', '/evidence/run.sh']
    (lab / 'command.json').write_text(json.dumps(args, indent=2) + '\n')
    with (lab / 'container.log').open('wb') as log:
        result = subprocess.run(args, stdout=log, stderr=subprocess.STDOUT, timeout=900)
    inspection = json.loads(subprocess.check_output([docker, 'inspect', name], text=True))[0]
    (lab / 'inspect.json').write_text(json.dumps(inspection, indent=2) + '\n')
    subprocess.run([docker, 'rm', name], stdout=subprocess.DEVNULL, check=True)
    audit = {'exit_code': result.returncode, 'original_unchanged': before == manifest(original),
        'profile_source_unchanged': modified == manifest(source), 'checkout_unchanged': user_before == checkout(),
        'state': inspection['State'], 'platform': 'native linux/arm64', 'warmup_parses': 11,
        'parser_construction_excluded': True, 'manual_GC': False, 'performance_comparison': False}
    assert result.returncode == 0 and not inspection['State']['OOMKilled']
    for label, benchmark in [('go-lr', 'BenchmarkCompactThroughputGo/grammargen_lr'),
                             ('yaml-ordinary', 'BenchmarkCompactThroughputYAML/r4_ordinary'),
                             ('yaml-owned', 'BenchmarkCompactThroughputYAML/r4_owned')]:
        text = (lab / (label + '.log')).read_text()
        assert len(re.findall(r'^' + re.escape(benchmark) + r'\s+\d+\s+', text, re.M)) == 1
        assert re.search(r'^PASS$', text, re.M) and 'FAIL' not in text
        receipt = json.loads((lab / (label + '.cpu.json')).read_text())
        assert receipt['benchmark'] == benchmark and receipt['iterations'] > 1 and receipt['warmup_parses'] == 11
        assert (lab / (label + '.cpu')).stat().st_size > 500
    assert audit['original_unchanged'] and audit['profile_source_unchanged'] and audit['checkout_unchanged']
    (lab / 'parent-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
    (lab / 'exit.txt').write_text('0\n')
