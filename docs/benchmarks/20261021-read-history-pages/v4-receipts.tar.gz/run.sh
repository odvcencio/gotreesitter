#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOMAXPROCS=1 GOWORK=off GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
cd /baseline
go test ./internal/incr -count=1 -timeout=5m -v > /evidence/baseline-incr.log 2>&1
go test ./internal/incr -overlay=/evidence/retention-overlay.json -run '^TestReadHistoryRetains64KiBFlatPrefix$' -count=1 -v > /evidence/baseline-retention-regression.log 2>&1
cd /rejected
if go test ./internal/incr -overlay=/evidence/retention-overlay.json -run '^TestReadHistoryRetains64KiBFlatPrefix$' -count=1 -v > /evidence/rejected-retention-regression.log 2>&1; then
 exit 41
else
 regression_code=$?
 printf '%s\n' "$regression_code" > /evidence/rejected-retention-exit.txt
 if [[ "$regression_code" != 1 ]] || ! grep -Fq '64 KiB history retains 65680 bytes, want 65600' /evidence/rejected-retention-regression.log; then exit 42; fi
fi
cd /overflow-rejected
if go test ./internal/incr -overlay=/evidence/overflow-rejected-overlay.json -run '^TestReadWordPagesRejectOverflowBeforeBudgetCharge$' -count=1 -v > /evidence/rejected-overflow-regression.log 2>&1; then
 exit 43
else
 regression_code=$?
 printf '%s\n' "$regression_code" > /evidence/rejected-overflow-exit.txt
 if [[ "$regression_code" != 1 ]] || ! grep -Fq 'overflowing storage reached budget charging' /evidence/rejected-overflow-regression.log; then exit 44; fi
fi
cd /candidate
go test ./internal/incr -count=1 -timeout=5m -v > /evidence/candidate-incr.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test -c -overlay=/evidence/header-overlay.json ./internal/incr -o /evidence/incr386.test > /evidence/386-build.log 2>&1
go test -race ./internal/incr -count=1 -timeout=5m -v > /evidence/candidate-incr-race.log 2>&1
go test -c -tags gts_parsercorephase0 -o /evidence/root.test . > /evidence/root-build.log 2>&1
for route in 0 1; do
 for lang in go yaml; do
  GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /evidence/root.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/invariant-${route}-${lang}.log" 2>&1
 done
done
go build -tags gts_parsercorephase0 -o /evidence/perfcounterledger ./cmd/perfcounterledger > /evidence/counter-build.log 2>&1
/evidence/perfcounterledger --write --output /evidence/candidate-ledger.json > /evidence/counter.log 2>&1
printf 'complete\n' > /evidence/complete.txt
