from pathlib import Path
import fcntl, hashlib, json, os, re, subprocess

base = Path('/Users/georgevillavicencio/.local/state/gotreesitter-compute/20261021-arm64-native-fields')
prototype = base / 'paged-read-history-v4'
lab = prototype / 'full-gates'
source = prototype / 'source'
baseline = base / 'primitive-dfa-state-source-v1'
deps = base / 'locked-c-oracle-amd64-v1'
docker = '/usr/local/bin/docker'
image = 'golang@sha256:3b4a11519ad929d1e1d261a12cff056f0c85b735253d7d861346b9c6f8b36437'
os.environ['PATH'] = '/Applications/Docker.app/Contents/Resources/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def manifest(root):
    return {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob('*.go')) if p.is_file()}

def checkout():
    path = '/Users/georgevillavicencio/Projects/gotreesitter'
    return {'head': subprocess.check_output(['git', '-C', path, 'rev-parse', 'HEAD'], text=True).strip(),
            'status': subprocess.check_output(['git', '-C', path, 'status', '--porcelain=v1'], text=True)}

def run_container(phase, platform, extra):
    evidence = lab / phase
    evidence.mkdir()
    name = 'gts-paged-reads-v4-' + phase + '-20261022'
    args = [docker, 'run', '--platform', platform, '--name', name, '--network', 'none',
            '--memory', '4g', '--memory-swap', '4g', '--cpus', '2', '--cpuset-cpus', '2,3', '--pids-limit', '256',
            '-e', 'GOMAXPROCS=1', '-e', 'GOMEMLIMIT=3GiB', '-v', str(source) + ':/candidate:ro',
            '-v', str(prototype) + ':/prototype:ro', '-v', str(lab) + ':/controls:ro',
            '-v', str(evidence) + ':/evidence'] + extra + [image, 'bash', '/controls/' + phase + '.sh']
    (evidence / 'command.json').write_text(json.dumps(args, indent=2) + '\n')
    with (evidence / 'container.log').open('wb') as log:
        result = subprocess.run(args, stdout=log, stderr=subprocess.STDOUT, timeout=7200)
    inspection = json.loads(subprocess.check_output([docker, 'inspect', name], text=True))[0]
    (evidence / 'inspect.json').write_text(json.dumps(inspection, indent=2) + '\n')
    subprocess.run([docker, 'rm', name], stdout=subprocess.DEVNULL, check=True)
    (evidence / 'exit.txt').write_text(str(result.returncode) + '\n')
    assert result.returncode == 0 and not inspection['State']['OOMKilled'], (phase, result.returncode)
    return inspection['State']

with open('/Users/georgevillavicencio/.local/state/gotreesitter-compute/compute.lock', 'a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    assert (prototype / 'exit.txt').read_text().strip() == '0'
    counter = json.loads((lab / 'counter-equality.json').read_text())
    assert counter['passed'] and counter['rows'] == 412
    assert digest(prototype / 'candidate-ledger.json') == counter['candidate_sha256']
    expected = json.loads((prototype / 'before.json').read_text())
    before, baseline_before, user_before = manifest(source), manifest(baseline), checkout()
    assert before == expected['candidate_go'] and baseline_before == expected['baseline_go']
    assert len(before) == 3544
    binary = prototype / 'root.test'
    binary_before = digest(binary)
    with binary.open('rb') as stream:
        header = stream.read(20)
    assert header[:4] == b'\x7fELF' and int.from_bytes(header[18:20], 'little') == 183
    dependencies = json.loads((base / 'ordered-receipt-v3-cgo-v1/dependency-manifest.json').read_text())
    assert all(digest(deps / key) == info['sha256'] for key, info in dependencies.items())
    languages = (base / 'ordered-receipt-v3-full-gates-v1/languages.txt').read_text()
    assert len(languages.splitlines()) == 206
    (lab / 'languages.txt').write_text(languages)
    (lab / 'before.json').write_text(json.dumps({'source_go': before, 'baseline_go': baseline_before,
        'checkout': user_before, 'binary_sha256': binary_before}, sort_keys=True) + '\n')

    c_state = run_container('cgo', 'linux/amd64', [
        '-e', 'CGO_ENABLED=1', '-e', 'GOPROXY=off', '-e', 'GOCACHE=/go-build', '-e', 'GOMODCACHE=/go-mod',
        '-e', 'GTS_PARITY_C_REF_BUILD_CACHE=/c-cache', '-v', str(deps / 'go-build') + ':/go-build',
        '-v', str(deps / 'go-mod') + ':/go-mod', '-v', str(deps / 'c-cache') + ':/c-cache:ro'])
    checks = 0
    for language in languages.splitlines():
        for route in (0, 1):
            text = (lab / 'cgo' / ('c-%d-%s.log' % (route, language))).read_text()
            assert text.rstrip().endswith('PASS') and '--- FAIL:' not in text and '--- SKIP:' not in text
            for suite in ['TestParityFreshParse', 'TestParityIncrementalParse', 'TestParityHasNoErrors']:
                assert len(re.findall(r'^    --- PASS: ' + suite + '/' + re.escape(language) + r' ', text, re.M)) == 1
                checks += 1
    assert checks == 1236

    native_state = run_container('native', 'linux/arm64', [
        '-e', 'GOCACHE=/go-build', '-v', str(base / 'inactive-scanner-trials-v1/go-build') + ':/go-build'])
    for language in languages.splitlines():
        for route in (0, 1):
            text = (lab / 'native' / ('invariant-%d-%s.log' % (route, language))).read_text()
            assert text.rstrip().endswith('PASS') and '--- FAIL:' not in text and '--- SKIP:' not in text
            assert 'session_steps=72 no_edit_allocs=0' in text
    unit_counts = {}
    for name in ['memory-contracts.log', 'race.log']:
        text = (lab / 'native' / name).read_text()
        assert re.search(r'^PASS$', text, re.M) and '--- FAIL:' not in text and '--- SKIP:' not in text and 'DATA RACE' not in text
        unit_counts[name] = len(re.findall(r'^--- PASS: Test', text, re.M))
    assert unit_counts['memory-contracts.log'] == 20

    audit = {'passed': True, 'source_unchanged': before == manifest(source),
        'baseline_unchanged': baseline_before == manifest(baseline), 'checkout_unchanged': user_before == checkout(),
        'binary_unchanged': binary_before == digest(binary),
        'dependency_inputs_unchanged': all(digest(deps / key) == info['sha256'] for key, info in dependencies.items()),
        'locked_C_checks': checks, 'invariant_sessions': 412, 'edit_steps': 29664, 'no_edit_allocations': 0,
        'memory_contracts': 20, 'root_race_cases': unit_counts['race.log'],
        'cgo_platform': 'linux/amd64 emulated on Mac; correctness only', 'native_platform': 'linux/arm64',
        'cgo_state': c_state, 'native_state': native_state, 'large_file_RSS_qualified': False, 'timing_claim': False}
    assert all(audit[key] for key in ['source_unchanged', 'baseline_unchanged', 'checkout_unchanged', 'binary_unchanged', 'dependency_inputs_unchanged'])
    (lab / 'gate-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
    (lab / 'exit.txt').write_text('0\n')
