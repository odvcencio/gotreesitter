from pathlib import Path
import json,os,fcntl,subprocess,hashlib,shutil,sys
base=Path('/Users/georgevillavicencio/.local/state/gotreesitter-compute/20261021-arm64-native-fields')
lab=base/'paged-read-history-v3';baseline=base/'primitive-dfa-state-source-v1';source=lab/'source'
os.environ['PATH']='/Applications/Docker.app/Contents/Resources/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin'
def manifest(root):return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*.go')) if p.is_file()}
def checkout():
 p=Path('/Users/georgevillavicencio/Projects/gotreesitter')
 return {'head':subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',str(p),'status','--porcelain=v1'],text=True)}
name='gts-paged-read-history-20261022-v3';docker='/usr/local/bin/docker';image='golang@sha256:3b4a11519ad929d1e1d261a12cff056f0c85b735253d7d861346b9c6f8b36437'
with open('/Users/georgevillavicencio/.local/state/gotreesitter-compute/compute.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 prior=base/'ordered-receipt-v3-paired-perf-v1';assert (prior/'exit.txt').read_text().strip()=='0','paired timing must be terminal first'
 rejected=base/'paged-read-history-v2/source';rejected_before=manifest(rejected)
 before=manifest(baseline);expected=json.loads((base/'compact-full-cpu-v1/before.json').read_text())['source_go'];assert before==expected;user_before=checkout()
 shutil.copytree(baseline,source,copy_function=os.link)
 scope=json.loads((lab/'scope.json').read_text())
 for rel,sha in scope['files'].items():
  data=(lab/'delta'/rel).read_bytes();assert hashlib.sha256(data).hexdigest()==sha
  p=source/rel;p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.gts-tmp');tmp.write_bytes(data);tmp.replace(p)
 candidate=manifest(source);assert len(candidate)==3544
 delta=[key for key in set(before)|set(candidate) if before.get(key)!=candidate.get(key)];assert set(delta)==set(scope['files'])
 (lab/'before.json').write_text(json.dumps({'baseline_go':before,'candidate_go':candidate,'checkout':user_before},sort_keys=True))
 args=[docker,'run','--platform','linux/arm64','--name',name,'--network','none','--memory','4g','--memory-swap','4g','--cpus','2','--cpuset-cpus','2,3','--pids-limit','256','-e','GOMAXPROCS=1','-e','GOMEMLIMIT=3GiB','-e','GOCACHE=/go-build','-v',str(base/'inactive-scanner-trials-v1/go-build')+':/go-build','-v',str(baseline)+':/baseline:ro','-v',str(source)+':/candidate:ro','-v',str(rejected)+':/rejected:ro','-v',str(lab)+':/evidence',image,'bash','/evidence/run.sh']
 (lab/'command.json').write_text(json.dumps(args,indent=2))
 with (lab/'container.log').open('wb') as log:result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=3600)
 inspection=json.loads(subprocess.check_output([docker,'inspect',name],text=True))[0];(lab/'inspect.json').write_text(json.dumps(inspection,indent=2))
 audit={'exit_code':result.returncode,'baseline_unchanged':before==manifest(baseline),'candidate_unchanged':candidate==manifest(source),'rejected_unchanged':rejected_before==manifest(rejected),'source_go_files':len(candidate),'checkout_unchanged':user_before==checkout(),'container_state':inspection['State'],'timing_claim':False}
 (lab/'parent-audit.json').write_text(json.dumps(audit,indent=2))
 subprocess.run([docker,'rm',name],stdout=subprocess.DEVNULL,check=True)
 (lab/'exit.txt').write_text(str(result.returncode)+chr(10))

 if result.returncode==0:
  assert all(audit[k] for k in ['baseline_unchanged','candidate_unchanged','rejected_unchanged','checkout_unchanged']) and not inspection['State']['OOMKilled']
  old=json.loads((base/'paged-read-history-v2/candidate-ledger.json').read_text());new=json.loads((lab/'candidate-ledger.json').read_text())
  assert old==new and len(new['rows'])==412
  following=lab/'full-gates'
  (following/'counter-equality.json').write_text(json.dumps({'passed':True,'rows':412,'json_values_equal':True,'candidate_sha256':hashlib.sha256((lab/'candidate-ledger.json').read_bytes()).hexdigest(),'baseline':'fully equal paged-v2 and qualified primitive-DFA ledgers'},indent=2)+'\n')
  with (following/'worker.log').open('wb') as log:child=subprocess.Popen([sys.executable,str(following/'worker.py')],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  (following/'launch.json').write_text(json.dumps({'pid':child.pid,'worker':'full-gates/worker.py'},indent=2)+'\n')
