#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOMAXPROCS=1 GOWORK=off GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
cd /candidate
for role in baseline candidate; do
 overlay=()
 if [[ "$role" == candidate ]]; then overlay=(-overlay=/evidence/production-overlay.json); fi
 go test -c -tags gts_parsercorephase0 "${overlay[@]}" -o "/evidence/${role}.test" . > "/evidence/${role}-build.log" 2>&1
 "/evidence/${role}.test" -test.run '^TestCompactReuseDependency' -test.count=1 -test.v -test.timeout=5m > "/evidence/${role}-unit.log" 2>&1
 for route in 0 1; do
  for lang in go yaml; do
   GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" "/evidence/${role}.test" -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/${role}-invariant-${route}-${lang}.log" 2>&1
  done
 done
 go test -c -tags gts_parsercorephase0 -overlay="/evidence/${role}-overlay.json" -o "/evidence/${role}-geometry.test" . > "/evidence/${role}-geometry-build.log" 2>&1
 "/evidence/${role}-geometry.test" -test.run '^TestReceiptPublicationGeometryGo$' -test.count=1 -test.v -test.timeout=10m > "/evidence/${role}-geometry.log" 2>&1
done
go build -tags gts_parsercorephase0 -overlay=/evidence/production-overlay.json -o /evidence/perfcounterledger ./cmd/perfcounterledger > /evidence/counter-build.log 2>&1
/evidence/perfcounterledger --write --output /evidence/selected-ledger-candidate.json > /evidence/counter.log 2>&1
printf 'complete\n' > /evidence/complete.txt
