#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOMAXPROCS=1 GOWORK=off GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
go env GOOS GOARCH CGO_ENABLED > /evidence/platform.txt
cc --version > /evidence/c-compiler.txt
command -v cc > /evidence/c-compiler-path.txt
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -overlay=/evidence/oracle-overlay.json -o /evidence/cgo.test . > /evidence/build.log 2>&1
for lang in go yaml; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GTS_PARITY_MODE=exhaustive /evidence/cgo.test -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${lang}$" -test.count=1 -test.v -test.timeout=5m > "/evidence/preflight-${route}-${lang}.log" 2>&1
 done
done
while IFS= read -r lang; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GTS_PARITY_MODE=exhaustive /evidence/cgo.test -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${lang}$" -test.count=1 -test.v -test.timeout=5m > "/evidence/c-${route}-${lang}.log" 2>&1
 done
done < /evidence/languages.txt
printf 'complete\n' > /evidence/complete.txt
