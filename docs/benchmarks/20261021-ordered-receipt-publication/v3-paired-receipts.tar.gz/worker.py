from pathlib import Path
import json,os,fcntl,subprocess,hashlib,shutil
base=Path('/Users/georgevillavicencio/.local/state/gotreesitter-compute/20261021-arm64-native-fields')
lab=base/'ordered-receipt-v3-paired-perf-v1';source=base/'primitive-dfa-state-source-v1';prototype=base/'ordered-receipt-publication-v3';full=base/'ordered-receipt-v3-full-gates-v1';oracle=base/'ordered-receipt-v3-cgo-v1'
os.environ['PATH']='/Applications/Docker.app/Contents/Resources/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin'
docker='/usr/local/bin/docker';name='gts-ordered-receipts-native-pairs-20261021-v3';image='golang@sha256:3b4a11519ad929d1e1d261a12cff056f0c85b735253d7d861346b9c6f8b36437'
def manifest(path):return {str(p.relative_to(path)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(path.rglob('*.go')) if p.is_file()}
def checkout():
 p=Path('/Users/georgevillavicencio/Projects/gotreesitter')
 return {'head':subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',str(p),'status','--porcelain=v1'],text=True)}
def replace(path,content):
 temp=path.with_name(path.name+'.gts-tmp');temp.write_bytes(content);temp.replace(path)
with open('/Users/georgevillavicencio/.local/state/gotreesitter-compute/compute.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 assert json.loads((full/'gate-audit.json').read_text())['passed'],'full gates not audited'
 assert json.loads((oracle/'gate-audit.json').read_text())['locked_C_checks']==1236
 scope=json.loads((lab/'scope.json').read_text());protohash=hashlib.sha256((prototype/'candidate-publication.go.txt').read_bytes()).hexdigest();assert protohash==scope['runtime_prototype_sha256']
 before=manifest(source);expected=json.loads((base/'compact-full-cpu-v1/before.json').read_text())['source_go'];assert before==expected
 user_before=checkout()
 for role in ['baseline','candidate']:
  directory=lab/role
  shutil.copytree(source,directory,copy_function=os.link)
  replace(directory/'benchmark_admission_candidate_route_test.go',(lab/'benchmark-wrapper.go.txt').read_bytes())
  replace(directory/'parsercore_phase0_reuse_dependency_test.go',(lab/'overflow-regression.go.txt').read_bytes())
  if role=='candidate': replace(directory/'parsercore_phase0_reuse_dependency.go',(prototype/'candidate-publication.go.txt').read_bytes())
 b=manifest(lab/'baseline');c=manifest(lab/'candidate');changed=[key for key in b if b[key]!=c[key]];assert changed==['parsercore_phase0_reuse_dependency.go'],changed
 assert len(b)==len(c)==3542
 (lab/'before.json').write_text(json.dumps({'source_go':before,'baseline_go':b,'candidate_go':c,'checkout':user_before,'prototype_sha256':protohash},sort_keys=True))
 with (lab/'image-pull.log').open('wb') as log:subprocess.run([docker,'pull','--platform','linux/arm64',image],stdout=log,stderr=subprocess.STDOUT,timeout=900,check=True)
 args=[docker,'run','--platform','linux/arm64','--name',name,'--network','none','--memory','4g','--memory-swap','4g','--cpus','2','--cpuset-cpus','2,3','--pids-limit','256','-e','GOMAXPROCS=1','-e','GOMEMLIMIT=3GiB','-e','GOCACHE=/go-build','-v',str(base/'inactive-scanner-trials-v1/go-build')+':/go-build','-v',str(lab/'baseline')+':/baseline:ro','-v',str(lab/'candidate')+':/candidate:ro','-v',str(lab)+':/evidence',image,'bash','/evidence/run.sh']
 (lab/'command.json').write_text(json.dumps(args,indent=2))
 with (lab/'container.log').open('wb') as log:result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=7200)
 inspection=json.loads(subprocess.check_output([docker,'inspect',name],text=True))[0];(lab/'inspect.json').write_text(json.dumps(inspection,indent=2))
 audit={'exit_code':result.returncode,'source_unchanged':before==manifest(source),'source_go_files':len(before),'baseline_unchanged':b==manifest(lab/'baseline'),'candidate_unchanged':c==manifest(lab/'candidate'),'checkout_unchanged':user_before==checkout(),'prototype_unchanged':protohash==hashlib.sha256((prototype/'candidate-publication.go.txt').read_bytes()).hexdigest(),'container_state':inspection['State'],'platform':'native linux/arm64 Docker on M1 Max; explicit platform and Go architecture guard'}
 (lab/'parent-audit.json').write_text(json.dumps(audit,indent=2))
 subprocess.run([docker,'rm',name],stdout=subprocess.DEVNULL,check=True)
 (lab/'exit.txt').write_text(str(result.returncode)+chr(10))
