#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOMAXPROCS=1 GOWORK=off GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
export GTS_ADMISSION_CANDIDATE=1 GOT_BENCH_FUNC_COUNT=500
go version > /evidence/go-version.txt
go env GOOS GOARCH > /evidence/platform.txt
if [[ "$(go env GOARCH)" != arm64 ]]; then exit 30; fi
cd /candidate
for role in baseline candidate; do
 cd "/${role}"
 go test -c -tags gts_parsercorephase0 -o "/evidence/${role}.test" . > "/evidence/${role}-build.log" 2>&1
 "/evidence/${role}.test" -test.run '^TestCompactReuseDependency' -test.count=1 -test.v -test.timeout=5m > "/evidence/${role}-unit.log" 2>&1
done
cd /candidate
go test -c -tags gts_parsercorephase0 -overlay=/evidence/rejected-overlay.json -o /evidence/rejected-v1.test . > /evidence/rejected-build.log 2>&1
set +e
/evidence/rejected-v1.test -test.run '^TestCompactReuseDependencyPublicationOverflowSlab$' -test.count=1 -test.v -test.timeout=5m > /evidence/rejected-regression.log 2>&1
rejected_code=$?
set -e
printf '%s\n' "$rejected_code" > /evidence/rejected-regression-exit.txt
if [[ "$rejected_code" != 2 ]] || ! grep -Fq 'index out of range' /evidence/rejected-regression.log; then exit 31; fi
bash /evidence/randomized-benchmarks.sh --output /evidence/go-after.txt --baseline-root /baseline --baseline-output /evidence/go-before.txt --lock-path /evidence/benchmark.lock --runs 20 --seed-start 142001 --benchtime 750ms --tags gts_parsercorephase0 --bench-regex '^BenchmarkOrderedReceiptsGo$' --require-benchmarks 'BenchmarkOrderedReceiptsGo/full_dfa,BenchmarkOrderedReceiptsGo/full_dfa_3500,BenchmarkOrderedReceiptsGo/single_byte_edit_dfa,BenchmarkOrderedReceiptsGo/no_edit_dfa,BenchmarkOrderedReceiptsGo/fresh_one_mib,BenchmarkOrderedReceiptsGo/query_compile,BenchmarkOrderedReceiptsGo/grammargen_lr' > /evidence/go-runner.log 2>&1
bash /evidence/randomized-benchmarks.sh --output /evidence/yaml-after.txt --baseline-root /baseline --baseline-output /evidence/yaml-before.txt --lock-path /evidence/benchmark.lock --runs 20 --seed-start 143001 --benchtime 750ms --tags gts_parsercorephase0 --bench-regex '^BenchmarkCompactThroughputYAML$' --require-benchmarks 'BenchmarkCompactThroughputYAML/r4_legacy,BenchmarkCompactThroughputYAML/r4_ordinary,BenchmarkCompactThroughputYAML/r4_owned,BenchmarkCompactThroughputYAML/eof8k_legacy,BenchmarkCompactThroughputYAML/eof8k_ordinary,BenchmarkCompactThroughputYAML/eof8k_owned' > /evidence/yaml-runner.log 2>&1
printf 'complete\n' > /evidence/complete.txt
