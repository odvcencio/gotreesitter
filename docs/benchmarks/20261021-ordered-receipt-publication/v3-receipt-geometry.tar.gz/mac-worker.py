from pathlib import Path
import json,os,fcntl,subprocess,hashlib,sys
base=Path('/Users/georgevillavicencio/.local/state/gotreesitter-compute/20261021-arm64-native-fields')
lab=base/'ordered-receipt-publication-v3';source=base/'primitive-dfa-state-source-v1'
os.environ['PATH']='/Applications/Docker.app/Contents/Resources/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin'
def manifest():return {str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.rglob('*.go')) if p.is_file()}
def checkout():
 p=Path('/Users/georgevillavicencio/Projects/gotreesitter')
 return {'head':subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',str(p),'status','--porcelain=v1'],text=True)}
name='gts-ordered-receipt-publication-20261021-v3';docker='/usr/local/bin/docker'
with open('/Users/georgevillavicencio/.local/state/gotreesitter-compute/compute.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 before=manifest();linux_expected=json.loads((lab/'source-before.json').read_text());user_before=checkout()
 expected=json.loads((base/'compact-full-cpu-v1/before.json').read_text())['source_go']
 assert before==expected and len(before)==3542, 'source differs from qualified Mac profile source'
 deltas={key:{'linux':linux_expected.get(key),'mac':before.get(key)} for key in set(linux_expected)|set(before) if linux_expected.get(key)!=before.get(key)}
 assert set(deltas)=={'benchmark_recurring_parse_test.go','incremental_test.go','work_count_diagnostic_test.go'}, deltas
 (lab/'source-closure-deltas.json').write_text(json.dumps(deltas,indent=2))
 scope=json.loads((lab/'scope.json').read_text())
 assert before[scope['runtime_file']]==scope['runtime_before_sha256'], 'runtime source identity changed'
 assert all(before[rel]==info['original_sha256'] for rel,info in scope['diagnostic_overlays'].items()), 'overlaid source identity changed'
 assert all(hashlib.sha256((lab/info['overlay_file']).read_bytes()).hexdigest()==info['overlay_sha256'] for info in scope['diagnostic_overlays'].values())
 (lab/'before.json').write_text(json.dumps({'source_go':before,'checkout':user_before},sort_keys=True))
 args=[docker,'run','--platform','linux/arm64','--name',name,'--network','none','--memory','4g','--memory-swap','4g','--cpus','2','--cpuset-cpus','2,3','--pids-limit','256','-e','GOMAXPROCS=1','-e','GOMEMLIMIT=3GiB','-e','GOCACHE=/go-build','-v',str(base/'inactive-scanner-trials-v1/go-build')+':/go-build','-v',str(source)+':/candidate:ro','-v',str(lab)+':/evidence','golang@sha256:3b4a11519ad929d1e1d261a12cff056f0c85b735253d7d861346b9c6f8b36437','bash','/evidence/run.sh']
 (lab/'command.json').write_text(json.dumps(args,indent=2))
 with (lab/'container.log').open('wb') as log:result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=3600)
 inspection=json.loads(subprocess.check_output([docker,'inspect',name],text=True))[0]
 (lab/'inspect.json').write_text(json.dumps(inspection,indent=2))
 after=manifest();user_after=checkout()
 audit={'exit_code':result.returncode,'source_unchanged':before==after,'source_matches_qualified_mac':before==expected,'linux_source_closure_deltas':deltas,'source_go_files':len(before),'checkout_unchanged':user_before==user_after,'container_state':inspection['State'],'comparison_claim':False,'purpose':'ordered publication: before/after unit, D8, full receipt digest and deterministic counter checks; no timing claim'}
 (lab/'parent-audit.json').write_text(json.dumps(audit,indent=2))
 subprocess.run([docker,'rm',name],stdout=subprocess.DEVNULL,check=True)
 (lab/'exit.txt').write_text(str(result.returncode)+'\n')
