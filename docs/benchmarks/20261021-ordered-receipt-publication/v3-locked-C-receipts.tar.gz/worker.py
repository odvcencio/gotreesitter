from pathlib import Path
import json,os,fcntl,subprocess,hashlib,re,sys
base=Path('/Users/georgevillavicencio/.local/state/gotreesitter-compute/20261021-arm64-native-fields')
lab=base/'ordered-receipt-v3-cgo-v1';source=base/'primitive-dfa-state-source-v1';prototype=base/'ordered-receipt-publication-v3'
deps_root=base/'locked-c-oracle-amd64-v1'
os.environ['PATH']='/Applications/Docker.app/Contents/Resources/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin'
docker='/usr/local/bin/docker';name='gts-ordered-receipts-cgo-amd64-20261021-v3';image='golang@sha256:3b4a11519ad929d1e1d261a12cff056f0c85b735253d7d861346b9c6f8b36437'
def source_manifest():return {str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.rglob('*.go')) if p.is_file()}
def checkout():
 p=Path('/Users/georgevillavicencio/Projects/gotreesitter')
 return {'head':subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',str(p),'status','--porcelain=v1'],text=True)}
with open('/Users/georgevillavicencio/.local/state/gotreesitter-compute/compute.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 assert (prototype/'exit.txt').read_text().strip()=='0','prototype focused gates did not pass'
 pin=json.loads((lab/'prototype-pin.json').read_text())
 assert hashlib.sha256((prototype/'candidate-publication.go.txt').read_bytes()).hexdigest()==pin['sha256']
 before=source_manifest();expected=json.loads((base/'compact-full-cpu-v1/before.json').read_text())['source_go'];assert before==expected
 user_before=checkout();deps=json.loads((lab/'dependency-manifest.json').read_text())
 assert all(hashlib.sha256((deps_root/key).read_bytes()).hexdigest()==info['sha256'] for key,info in deps.items())
 (lab/'before.json').write_text(json.dumps({'source_go':before,'checkout':user_before,'prototype_pin':pin},sort_keys=True))
 with (lab/'image-pull.log').open('wb') as log:
  pull=subprocess.run([docker,'pull','--platform','linux/amd64',image],stdout=log,stderr=subprocess.STDOUT,timeout=900)
 assert pull.returncode==0,'pinned amd64 image pull failed'
 args=[docker,'run','--platform','linux/amd64','--name',name,'--network','none','--memory','4g','--memory-swap','4g','--cpus','2','--cpuset-cpus','2,3','--pids-limit','256','-e','GOMAXPROCS=1','-e','GOMEMLIMIT=3GiB','-e','CGO_ENABLED=1','-e','GOPROXY=off','-e','GOCACHE=/go-build','-e','GOMODCACHE=/go-mod','-e','GTS_PARITY_C_REF_BUILD_CACHE=/c-cache','-v',str(deps_root/'go-build')+':/go-build','-v',str(deps_root/'go-mod')+':/go-mod','-v',str(deps_root/'c-cache')+':/c-cache:ro','-v',str(source)+':/candidate:ro','-v',str(prototype)+':/prototype:ro','-v',str(lab)+':/evidence',image,'bash','/evidence/run.sh']
 (lab/'command.json').write_text(json.dumps(args,indent=2))
 with (lab/'container.log').open('wb') as log:result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=7200)
 inspection=json.loads(subprocess.check_output([docker,'inspect',name],text=True))[0]
 (lab/'inspect.json').write_text(json.dumps(inspection,indent=2))
 audit={'exit_code':result.returncode,'source_unchanged':before==source_manifest(),'source_go_files':len(before),'checkout_unchanged':user_before==checkout(),'dependency_inputs_unchanged':all(hashlib.sha256((deps_root/key).read_bytes()).hexdigest()==info['sha256'] for key,info in deps.items()),'prototype_unchanged':hashlib.sha256((prototype/'candidate-publication.go.txt').read_bytes()).hexdigest()==pin['sha256'],'container_state':inspection['State'],'platform':'linux/amd64 emulated on Mac; correctness only','timing_claim':False}
 (lab/'parent-audit.json').write_text(json.dumps(audit,indent=2))
 subprocess.run([docker,'rm',name],stdout=subprocess.DEVNULL,check=True)
 (lab/'exit.txt').write_text(str(result.returncode)+chr(10))

 if result.returncode==0:
  assert all(audit[k] for k in ['source_unchanged','checkout_unchanged','dependency_inputs_unchanged','prototype_unchanged']) and not inspection['State']['OOMKilled']
  languages=(lab/'languages.txt').read_text().splitlines();assert len(languages)==206
  checks=0
  for lang in languages:
   for route in (0,1):
    text=(lab/('c-%d-%s.log'%(route,lang))).read_text()
    assert text.rstrip().endswith('PASS') and '--- FAIL:' not in text and '--- SKIP:' not in text
    for suite in ['TestParityFreshParse','TestParityIncrementalParse','TestParityHasNoErrors']:
     assert len(re.findall(r'^    --- PASS: '+suite+'/'+re.escape(lang)+r' ',text,re.M))==1
     checks+=1
  assert checks==1236
  (lab/'gate-audit.json').write_text(json.dumps({'passed':True,'locked_C_checks':checks,'languages':206,'routes':2,'source_unchanged':True,'cache_unchanged':True,'prototype_unchanged':True,'platform':'linux/amd64 emulated; correctness only'},indent=2)+chr(10))
  following=base/'ordered-receipt-v3-full-gates-v1'
  with (following/'worker.log').open('wb') as log:child=subprocess.Popen([sys.executable,str(following/'worker.py')],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  (following/'worker.pid').write_text(str(child.pid)+chr(10))
