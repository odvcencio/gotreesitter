from pathlib import Path
import json,os,fcntl,subprocess,hashlib,re,sys
base=Path('/Users/georgevillavicencio/.local/state/gotreesitter-compute/20261021-arm64-native-fields')
lab=base/'ordered-receipt-v3-full-gates-v1';source=base/'primitive-dfa-state-source-v1';prototype=base/'ordered-receipt-publication-v3';oracle=base/'ordered-receipt-v3-cgo-v1'
os.environ['PATH']='/Applications/Docker.app/Contents/Resources/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin'
def manifest():return {str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.rglob('*.go')) if p.is_file()}
def checkout():
 p=Path('/Users/georgevillavicencio/Projects/gotreesitter')
 return {'head':subprocess.check_output(['git','-C',str(p),'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',str(p),'status','--porcelain=v1'],text=True)}
name='gts-ordered-receipts-full-gates-20261021-v3';docker='/usr/local/bin/docker';image='golang@sha256:3b4a11519ad929d1e1d261a12cff056f0c85b735253d7d861346b9c6f8b36437'
with open('/Users/georgevillavicencio/.local/state/gotreesitter-compute/compute.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 gate=json.loads((oracle/'gate-audit.json').read_text());assert gate['passed'] and gate['locked_C_checks']==1236
 assert (prototype/'exit.txt').read_text().strip()=='0'
 proto_scope=json.loads((prototype/'scope.json').read_text());protohash=hashlib.sha256((prototype/'candidate-publication.go.txt').read_bytes()).hexdigest();assert protohash==proto_scope['runtime_after_sha256']
 binary=prototype/'candidate.test';bh=hashlib.sha256(binary.read_bytes()).hexdigest();header=binary.open('rb').read(20);assert header[:4]==b'ELF' and int.from_bytes(header[18:20],'little')==183
 before=manifest();expected=json.loads((base/'compact-full-cpu-v1/before.json').read_text())['source_go'];assert before==expected;user_before=checkout()
 (lab/'before.json').write_text(json.dumps({'source_go':before,'checkout':user_before,'binary_sha256':bh,'prototype_sha256':protohash},sort_keys=True))
 with (lab/'image-pull.log').open('wb') as log:
  subprocess.run([docker,'pull','--platform','linux/arm64',image],stdout=log,stderr=subprocess.STDOUT,timeout=900,check=True)
 args=[docker,'run','--platform','linux/arm64','--name',name,'--network','none','--memory','4g','--memory-swap','4g','--cpus','2','--cpuset-cpus','2,3','--pids-limit','256','-e','GOMAXPROCS=1','-e','GOMEMLIMIT=3GiB','-e','GOCACHE=/go-build','-v',str(base/'inactive-scanner-trials-v1/go-build')+':/go-build','-v',str(source)+':/candidate:ro','-v',str(prototype)+':/qualified:ro','-v',str(lab)+':/evidence',image,'bash','/evidence/run.sh']
 (lab/'command.json').write_text(json.dumps(args,indent=2))
 with (lab/'container.log').open('wb') as log:result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=7200)
 inspection=json.loads(subprocess.check_output([docker,'inspect',name],text=True))[0];(lab/'inspect.json').write_text(json.dumps(inspection,indent=2))
 audit={'exit_code':result.returncode,'source_unchanged':before==manifest(),'source_go_files':len(before),'checkout_unchanged':user_before==checkout(),'binary_unchanged':bh==hashlib.sha256(binary.read_bytes()).hexdigest(),'prototype_unchanged':protohash==hashlib.sha256((prototype/'candidate-publication.go.txt').read_bytes()).hexdigest(),'container_state':inspection['State'],'platform':'native linux/arm64 Docker on M1 Max','timing_claim':False}
 (lab/'parent-audit.json').write_text(json.dumps(audit,indent=2))
 subprocess.run([docker,'rm',name],stdout=subprocess.DEVNULL,check=True)
 (lab/'exit.txt').write_text(str(result.returncode)+chr(10))

 if result.returncode==0:
  assert all(audit[k] for k in ['source_unchanged','checkout_unchanged','binary_unchanged','prototype_unchanged']) and not inspection['State']['OOMKilled']
  languages=(lab/'languages.txt').read_text().splitlines();assert len(languages)==206
  for lang in languages:
   for route in (0,1):
    text=(lab/('invariant-%d-%s.log'%(route,lang))).read_text()
    assert text.rstrip().endswith('PASS') and '--- FAIL:' not in text and '--- SKIP:' not in text and 'session_steps=72 no_edit_allocs=0' in text
  counts={}
  for name in ['memory-contracts.log','race.log']:
   text=(lab/name).read_text();assert re.search(r'^PASS$',text,re.M) and '--- FAIL:' not in text and '--- SKIP:' not in text and 'DATA RACE' not in text
   counts[name]=len(re.findall(r'^--- PASS: Test',text,re.M))
  assert counts['memory-contracts.log']==20 and counts['race.log']==27,counts
  (lab/'gate-audit.json').write_text(json.dumps({'passed':True,'sessions':412,'edit_steps':29664,'no_edit_allocations':0,'memory_contracts':20,'race_cases':27,'source_unchanged':True,'prototype_unchanged':True,'platform':'native linux/arm64'},indent=2)+chr(10))
  following=base/'ordered-receipt-v3-paired-perf-v1'
  with (following/'worker.log').open('wb') as log:child=subprocess.Popen([sys.executable,str(following/'worker.py')],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  (following/'worker.pid').write_text(str(child.pid)+chr(10))
