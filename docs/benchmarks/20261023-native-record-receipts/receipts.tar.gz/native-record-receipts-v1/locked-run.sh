set -uo pipefail
date -u +%FT%T.%NZ > /evidence/workload-start.txt
bash /controls/run.sh
status=$?
printf "%s\n" "$status" > /evidence/workload-exit.txt
date -u +%FT%T.%NZ > /evidence/workload-end.txt
exit "$status"
