#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/overlay.json'
test -f /lab/focused-complete.txt
test -f /lab/counter-gate.json
python3 -c 'import json; assert json.load(open("/lab/counter-gate.json"))["passed"]'
cd /candidate
go test -c -tags gts_parsercorephase0 -o /evidence/root.test . > /evidence/build.log 2>&1
GTS_STORAGE_CASE=yaml /evidence/root.test -test.run '^TestAcceptedStorageCensus$' -test.count=1 -test.v -test.timeout=8m > /evidence/yaml.log 2>&1
printf 'complete\n' > /evidence/complete.txt
