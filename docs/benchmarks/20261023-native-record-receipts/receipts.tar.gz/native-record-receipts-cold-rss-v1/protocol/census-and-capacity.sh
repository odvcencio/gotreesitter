#!/usr/bin/env bash
set -euo pipefail
bash /evidence/run-census-and-analyze.sh
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -buildvcs=false -overlay=/evidence/capacity/overlay.json'
cd /candidate
go test -c -tags gts_parsercorephase0 -o /evidence/capacity/root.test . > /evidence/capacity/build.log 2>&1
GTS_STORAGE_CASE=yaml /evidence/capacity/root.test -test.run '^TestAcceptedStorageCensus$' -test.count=1 -test.v -test.timeout=8m > /evidence/capacity/yaml.log 2>&1
printf 'complete\n' > /evidence/capacity/complete.txt
