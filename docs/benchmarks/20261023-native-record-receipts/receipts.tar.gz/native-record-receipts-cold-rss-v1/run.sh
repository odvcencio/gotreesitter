set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
python3 /controls/source_hashes.py > /evidence/source-before.json
python3 - <<'CHECK'
from pathlib import Path
import json,hashlib
p=Path('/qualified');assert (p/'complete.txt').exists()
assert json.loads((p/'source-before.json').read_text())==json.loads((p/'source-after-final.json').read_text())==json.loads(Path('/evidence/source-before.json').read_text())
files=list((p/'counter-deltas').glob('*.json'));assert len(files)==206 and all(json.loads(f.read_text())['passed'] for f in files)
for role in ['baseline','candidate']:
 text=(p/(role+'-large-go-C.log')).read_text();assert '--- FAIL:' not in text and text.count('warmed 1 MiB Go: exact symbols, fields, spans, points, flags, and deep digest')==6
Path('/evidence/reused-qualification-receipt.json').write_text(json.dumps({'identical_source_manifests':True,'completed_ledger_exports':206,'large_C_comparisons_reused':12,'scope':'Verified completed source-identical correctness; not repeated in RSS job.'},indent=2)+'\n')
CHECK
mkdir /evidence/probes
for role in baseline candidate; do
 cd "/$role"
 go test -c -overlay=/controls/overlay.json -tags gts_parsercorephase0 -o "/evidence/probes/$role-rss-root.test" . > "/evidence/probes/$role-build.log" 2>&1
done
cp /controls/rss-wrapper.go.txt /evidence/rss-wrapper.go
go build -o /evidence/rsswrap /evidence/rss-wrapper.go > /evidence/rss-wrapper-build.log 2>&1
for role in baseline candidate; do
 cd "/$role"
 for name in go yaml_ordinary yaml_owned; do
  GTS_RSS_EXPECT_ORDINARY_COMPACT=1 /evidence/rsswrap "/evidence/probes/$role-standalone-$name.rss" "/evidence/probes/$role-rss-root.test" -test.run "^TestCompactLineageRSS$/^${name}$" -test.count=1 -test.v -test.timeout=5m > "/evidence/probes/$role-standalone-$name.log" 2>&1
 done
done
python3 /controls/protocol/rss/repeat_rss.py > /evidence/rss-run.log 2>&1
printf 'complete\n' > /evidence/complete.txt
