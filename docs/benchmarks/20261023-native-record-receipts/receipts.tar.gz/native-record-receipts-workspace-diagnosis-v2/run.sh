set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false' CGO_ENABLED=0
python3 /controls/source_hashes.py > /evidence/source-before.json
for role in baseline candidate; do
 cd "/$role"
 go test -c -tags gts_parsercorephase0 -overlay=/controls/overlay.json -o "/evidence/$role-probe.test" . > "/evidence/$role-build.log" 2>&1
 GTS_BENCHMARK_SEED=194001 GTS_ADMISSION_CANDIDATE=1 "/evidence/$role-probe.test" -test.run '^$' -test.bench '^BenchmarkCompactThroughputGo$/^(full_dfa|grammargen_lr|fresh_one_mib|query_compile)$' -test.benchtime=1x -test.count=1 -test.timeout=5m > "/evidence/$role-workspace.log" 2>&1
done
printf 'Diagnostic storage census only; instrumented single iterations are not timing or allocation comparison evidence.\n' > /evidence/scope.txt
printf 'complete\n' > /evidence/complete.txt
