set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly -modfile=/controls/oracle0271-module-bind-v3/go.mod -overlay=/controls/raw-summary-output-v1/oracle0271-qualification-v1/composed-v1/overlay.c027.json'
git config --global --add safe.directory /candidate
cd /candidate
finish(){
 cd /candidate
 sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-after.log 2>&1
 sha256sum --quiet -c /controls/raw-summary-c027-v4/controls.sha256 > /evidence/controls-after.log 2>&1
 sha256sum --quiet -c /controls/oracle0271/checksums.container.sha256 > /evidence/oracle-after.log 2>&1
 sha256sum --quiet -c /controls/oracle0271-module-bind-v3/checksums.container.sha256 > /evidence/binding-after.log 2>&1
 python3 /controls/oracle0271-module-bind-v3/verify-inputs.py > /evidence/staged-after.json
}
trap finish EXIT
sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/raw-summary-c027-v4/controls.sha256 > /evidence/controls-before.log 2>&1
sha256sum --quiet -c /controls/oracle0271/checksums.container.sha256 > /evidence/oracle-before.log 2>&1
sha256sum --quiet -c /controls/oracle0271-module-bind-v3/checksums.container.sha256 > /evidence/binding-before.log 2>&1
python3 /controls/oracle0271-module-bind-v3/verify-inputs.py > /evidence/staged-before.json
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/raw-summary-c027-v4
mkdir -p "$scratch"
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o "$scratch/cgo.test" . > /evidence/cgo-build.log 2>&1
"$scratch/cgo.test" -test.run '^TestCOracle0271HeaderAndLinkProbe$' -test.count=1 -test.v -test.timeout=2m > /evidence/runtime-probe.log 2>&1
"$scratch/cgo.test" -test.run '^TestRawSummaryOrdinaryLockedC$' -test.count=1 -test.v -test.timeout=5m > /evidence/ordinary-cgo.log 2>&1
sha256sum "$scratch/cgo.test" > /evidence/binary.sha256
