set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/raw-summary-root-v2/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/raw-summary-root-v2/controls.sha256 > /evidence/controls-before.log 2>&1
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/raw-summary-root-v2
mkdir -p "$scratch"
overlay=/controls/raw-summary-output-v1/lease-root/publication-accounting-v2/overlay.tests.json
go test -c -overlay="$overlay" -tags gts_parsercorephase0 -o "$scratch/root.test" . > /evidence/root-build.log 2>&1
"$scratch/root.test" -test.run '^TestRawSummaryOrdinaryPublicParity$' -test.count=1 -test.v -test.timeout=4m > /evidence/ordinary-root.log 2>&1
cd /candidate/cgo_harness
go test -c -overlay=/controls/raw-summary-output-v1/lease-root/publication-accounting-v2/overlay.cgo.tests.json -tags treesitter_c_parity,gts_parsercorephase0 -o "$scratch/cgo.test" . > /evidence/cgo-build.log 2>&1
"$scratch/cgo.test" -test.run '^TestRawSummaryOrdinaryLockedC$' -test.count=1 -test.v -test.timeout=4m > /evidence/ordinary-cgo.log 2>&1
sha256sum "$scratch/root.test" "$scratch/cgo.test" > /evidence/binary.sha256
