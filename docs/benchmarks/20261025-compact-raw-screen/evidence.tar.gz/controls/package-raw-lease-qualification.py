#!/usr/bin/env python3
"""Freeze one terminal owned raw-output correctness bucket; never run workloads."""
from pathlib import Path
import argparse
import gzip
import io
import json
import runpy
import subprocess
import tarfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--decision-file", type=Path, required=True, help="root-authored JSON with nonempty decision and rationale")
    parser.add_argument("--destination", type=Path, default=Path("docs/benchmarks/20261025-raw-lease-qualification"))
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    checkout = root.parents[2]
    destination = args.destination if args.destination.is_absolute() else checkout / args.destination
    decision = json.loads(args.decision_file.read_text())
    assert isinstance(decision.get("decision"), str) and decision["decision"].strip()
    assert isinstance(decision.get("rationale"), str) and decision["rationale"].strip()
    variants = ["raw-summary-history-v1", "raw-summary-history-v2", "raw-summary-history-transfer-v3", "raw-summary-core-v1", "raw-summary-core-reference-v1", "raw-summary-root-v2", "raw-summary-root-debug-v3", "raw-summary-ordinary-repair-v4", "raw-summary-public-lifetime-v4", "raw-summary-linear-v5"]
    # Never snapshot a live stage. A failed historical/linear stage is retained
    # as failed, not silently dropped or promoted into the green qualification.
    for variant in variants:
        finished = root / "out" / variant / "finished.json"
        assert finished.is_file() and isinstance(json.loads(finished.read_text())["exit_code"], int), variant
    template = root / "raw-summary-output-v1/qualification-package-v1/validate-evidence.py.txt"
    validator = runpy.run_path(str(template))
    sha = validator["sha"]
    files = {}

    def add(path, name):
        assert path.is_file() and name not in files, (path, name)
        files[name] = path.read_bytes()

    def add_tree(path, prefix, outputs=False):
        assert path.is_dir(), path
        for entry in sorted(path.rglob("*")):
            if not entry.is_file() or "__pycache__" in entry.parts or entry.suffix == ".pyc":
                continue
            if outputs and entry.suffix not in (".json", ".log", ".txt", ".stderr", ".sha256"):
                continue
            assert entry.suffix not in (".test", ".exe", ".prof", ".pb"), entry
            add(entry, prefix + str(entry.relative_to(path)))

    # Exact source versions only: later sibling files are not swept into this
    # receipt merely because an author added them below an existing directory.
    frozen_controls = root / "raw-summary-output-v1/qualification-package-v1/frozen-controls.json"
    control_rows = json.loads(frozen_controls.read_text())["files"]
    for relative, expected in sorted(control_rows.items()):
        assert sha((root / relative).read_bytes()) == expected, relative
        add(root / relative, "controls/" + relative)
    for variant in variants:
        add_tree(root / "out" / variant, "outputs/" + variant + "/", outputs=True)
    add(frozen_controls, "controls/raw-summary-output-v1/qualification-package-v1/frozen-controls.json")
    add(Path(__file__).resolve(), "controls/package-raw-lease-qualification.py")
    add(template, "controls/raw-summary-output-v1/qualification-package-v1/validate-evidence.py.txt")
    verified = validator["validate_payloads"](files)
    frozen = json.loads(files["controls/raw-summary-output-v1/lease-root/frozen-inputs.json"])
    qualified_map = "controls/raw-summary-output-v1/ordinary-repair-v4/overlay.runtime.json"
    linear_map = "controls/raw-summary-output-v1/lease-root/linear-core-v4/overlay.runtime.json"
    summary = {
        "schema": "gts-owned-raw-output-correctness-qualification/v1",
        "root_decision": decision,
        "actual_correctness": verified,
        "historical_explanation": {
            "history-v1": "Initial test expected a known end=0 lookahead, but unchanged canonical lookup intentionally abstains at zero. V2 corrects only that expectation; both original failed packed/wide records are preserved.",
            "root-v2/root-debug-v3": "Both ordinary activation witnesses failed; debug recorded only aborted status after 4/7 raw records, not the original refusal reason. The separate repair and certified-external fixtures address Go automatic-semicolon payloads using the existing quiescent certificate, retain checkpointed/uncertified refusals, and preserve refusal/transfer status until reset/new valid session.",
            "linear-v5": "Its own terminal result controls qualification. A nonzero stage remains archived as a failed experiment; later unexecuted selectors confer no qualification.",
        },
        "scope": "Actual ordinary primary500 and real R4 Go output under pinned repository C025 plus bounded public API, source-authority, memory and race controls. The initial formation algorithm remains unsuitable for performance claims; a green linear follow-up alone would still need actual formation work, full C/D8/counters/memory and randomized timing qualification.",
        "runtime_promoted": False,
        "global_or_language_default_changed": False,
        "timing_claim": False,
        "C027_claim": False,
        "YAML_checkpoint_lease_claim": False,
        "fleet_claim": False,
        "graduation_claim": False,
        "merges_to_main_held": True,
    }
    identities = {
        "schema": "gts-owned-raw-output-source-identities/v1",
        "source_base_head": frozen["base_head"],
        "packaged_at_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=checkout, text=True).strip(),
        "canonical_source_manifest_sha256": sha(files["controls/sealed-reduction-perf-v1/source.sha256"]),
        "qualified_C025_v4_runtime_map_sha256": sha(files[qualified_map]),
        "linear_v5_runtime_map_sha256": sha(files[linear_map]),
        "linear_v5_qualified": verified["linear_v5"]["qualified"],
        "ordinary_Go_artifact_sha256": "9ad1f8d7d0f2b9aa32c61bd8295b56177caabb0ae2fb8dd4617559ee0f71fed4",
        "C_oracle_scope": {"version": "0.25.1", "runtime_commit": "f5afe475deb7c0bae6407fb776c76824f717bb61", "Go_grammar_commit": "2346a3ab1bb3857b48b29d779a1ef9799a248cd7", "Go_grammar_artifact_sha256": "f17d674be6e3e7a0edb521defa31d3174c877b01414fd758a4988673423573f7", "new_C027_binding_not_included": True},
        "archived_controls_sha256": {name: sha(data) for name, data in sorted(files.items()) if name.startswith("controls/")},
        "binary_receipts": [name for name in sorted(files) if name.endswith("/binary.sha256")],
        "binary_payloads_included": False,
        "caches_credentials_private_CSV_Enforce_payloads_included": False,
    }
    names = ["evidence.tar.gz", "contents.json.gz", "source-identities.json", "verification.json", "summary.json", "validate-evidence.py", "SHA256SUMS"]
    assert not any((destination / name).exists() for name in names), "refusing to overwrite a frozen receipt"
    destination.mkdir(parents=True, exist_ok=True)
    for name, value in (("summary.json", summary), ("verification.json", verified), ("source-identities.json", identities)):
        (destination / name).write_text(json.dumps(value, indent=2) + "\n")
    (destination / "validate-evidence.py").write_bytes(template.read_bytes())
    index = []
    with (destination / "evidence.tar.gz").open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w") as archive:
                for name, data in sorted(files.items()):
                    member = tarfile.TarInfo(name)
                    member.size, member.mode, member.mtime = len(data), 0o644, 0
                    archive.addfile(member, io.BytesIO(data))
                    index.append({"path": name, "bytes": len(data), "sha256": sha(data)})
    with (destination / "contents.json.gz").open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
            compressed.write((json.dumps(index, indent=2) + "\n").encode())
    (destination / "SHA256SUMS").write_text("".join(f"{sha((destination / name).read_bytes())}  {name}\n" for name in names[:-1]))
    print(json.dumps({"destination": str(destination), "members": len(files), "archive_sha256": sha((destination / "evidence.tar.gz").read_bytes()), "linear_v5_qualified": verified["linear_v5"]["qualified"], "next": "Root writes README and runs public validate-evidence.py. README remains outside artifact checksums."}, indent=2))


if __name__ == "__main__":
    main()
