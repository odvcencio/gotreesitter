set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/raw-summary-root-debug-v3/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/raw-summary-root-debug-v3/controls.sha256 > /evidence/controls-before.log 2>&1
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/raw-summary-root-debug-v3
mkdir -p "$scratch"
overlay=/controls/raw-summary-output-v1/root-qualification-v1/debug-v3/overlay.tests.json
go test -c -overlay="$overlay" -tags gts_parsercorephase0 -o "$scratch/root.test" . > /evidence/root-build.log 2>&1
"$scratch/root.test" -test.run '^TestRawSummaryOrdinaryPublicParity$' -test.count=1 -test.v -test.timeout=4m > /evidence/ordinary-root.log 2>&1
