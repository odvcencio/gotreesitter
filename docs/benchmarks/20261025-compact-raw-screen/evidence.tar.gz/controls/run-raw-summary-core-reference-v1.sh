set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/raw-summary-core-reference-v1/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/raw-summary-core-reference-v1/controls.sha256 > /evidence/controls-before.log 2>&1
overlay=/controls/raw-summary-output-v1/lease-core/overlay.tests.json
go test -overlay="$overlay" -tags gts_parsercorephase0 -run '^Test(Native|Selected|RawSummary|SingleVersion|DirectReduction)' -count=1 -v -timeout=3m ./internal/parsercorephase0 > /evidence/core-release.log 2>&1
go test -overlay="$overlay" -tags gts_parsercorephase0,gts_workcount -run '^Test(Native|Selected|RawSummary|SingleVersion|DirectReduction)' -count=1 -v -timeout=3m ./internal/parsercorephase0 > /evidence/core-workcount.log 2>&1
go test -race -overlay="$overlay" -tags gts_parsercorephase0 -run '^Test(Native|Selected|RawSummary|SingleVersion|DirectReduction)' -count=1 -v -timeout=3m ./internal/parsercorephase0 > /evidence/core-race.log 2>&1
