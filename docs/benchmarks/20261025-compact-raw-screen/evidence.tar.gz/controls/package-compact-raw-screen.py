#!/usr/bin/env python3
"""Freeze the terminal compact raw-output screen; no workloads and no source sweep."""
from pathlib import Path
import argparse, gzip, io, json, runpy, subprocess, tarfile


def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--decision-file',type=Path,required=True,help='explicit root-authored JSON: decision and rationale')
 parser.add_argument('--destination',type=Path,default=Path('docs/benchmarks/20261025-compact-raw-screen'))
 args=parser.parse_args();root=Path(__file__).resolve().parent;checkout=root.parents[2];prior=root.parent/'go-reuse-20261025'
 dest=args.destination if args.destination.is_absolute() else checkout/args.destination
 decision=json.loads(args.decision_file.read_text());assert isinstance(decision.get('decision'),str) and decision['decision'].strip();assert isinstance(decision.get('rationale'),str) and decision['rationale'].strip()
 package=root/'raw-summary-output-v1/screen-package-v1';template=package/'validate-evidence.py.txt';v=runpy.run_path(str(template));sha=v['sha']
 old=v['OLD_VARIANTS'];new=list(v['GREEN']);variants=old+['raw-summary-c027-v4']+new+[v['PERF'],'raw-summary-profile-v6']
 # All output stages are fixed by name; never freeze a live or missing stage.
 for name in variants:
  finished=root/'out'/name/'finished.json';assert finished.is_file() and type(json.loads(finished.read_text())['exit_code'])==int,name
 for name in new+[v['PERF'],'raw-summary-profile-v6']:assert json.loads((root/'out'/name/'finished.json').read_text())['exit_code']==0,name
 assert (root/'out'/v['PERF']/'completed.txt').is_file() and (root/'out'/v['PERF']/'validated-summary.json').is_file()
 files={}
 def add(path,name):
  assert path.is_file() and name not in files,(path,name);files[name]=path.read_bytes()
 # Exact allowlists were captured before terminal timing. Later source files,
 # YAML extensions, and live experiments cannot enter this archive implicitly.
 for manifest in ('frozen-controls.json','profile-controls.json'):
  rows=json.loads((package/manifest).read_text())['files']
  for name,row in rows.items():
   source=(root if row['root']=='main' else prior)/row['relative'];data=source.read_bytes()
   assert len(data)==row['bytes'] and sha(data)==row['sha256'],name
   if name in files:assert files[name]==data
   else:files[name]=data
  add(package/manifest,'controls/raw-summary-output-v1/screen-package-v1/'+manifest)
 # Only fixed terminal output folders are swept, never control/source folders.
 # Profiles are included solely as attribution; binaries/caches are excluded.
 allowed={'.json','.log','.txt','.stderr','.sha256','.cpu','.mem'}
 for name in variants:
  for source in sorted((root/'out'/name).rglob('*')):
   if source.is_file() and source.suffix in allowed and '__pycache__' not in source.parts:
    add(source,'outputs/'+name+'/'+str(source.relative_to(root/'out'/name)))
 add(template,v['TEMPLATE']);add(Path(__file__).resolve(),'controls/package-compact-raw-screen.py')
 verified=v['validate_payloads'](files)
 sourceindex='controls/raw-summary-perf-compact-v6/source.sha256'
 identities={'schema':'gts-compact-raw-screen-source-identities/v1','packaged_at_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=checkout,text=True).strip(),'source_census_sha256':sha(files[sourceindex]),'source_census_entries':len(files[sourceindex].splitlines()),'runtime_map_sha256':sha(files[v['RUNTIME']]),'runtime_targets':25,'ordinary_Go_artifact_sha256':'9ad1f8d7d0f2b9aa32c61bd8295b56177caabb0ae2fb8dd4617559ee0f71fed4','C025_runtime_commit':'f5afe475deb7c0bae6407fb776c76824f717bb61','C027_runtime_commit':v['C027'],'C027_scope':'Only actual default parse/close API on unchanged primary500 and real R4 sources; private frozen v0.25.0 binding adapter. No adoption or general API compatibility.','frozen_control_manifest_sha256':sha(files[v['FROZEN']]),'archived_controls_sha256':{n:sha(d) for n,d in sorted(files.items()) if n.startswith('controls/')},'binary_hash_receipts':[n for n in sorted(files) if n.endswith('binary.sha256')],'binaries_or_dependency_caches_included':False,'private_CSV_Enforce_or_credentials_included':False}
 summary={'schema':'gts-compact-raw-screen/v1','root_decision':decision,'actual_screen':verified,'scope':'Independent held compact raw-output variant. Ordinary primary500 and real R4 Go actual lease, strict C025/C027 default API; existing Go/YAML C and four D8 sessions; five real-source formation/read work controls; public lifetime/race; standard60pair performance; four attribution profiles.','historical_failures_preserved':['end0 expectation in packed/wide history control','ordinary activation aborted: ASI/status repair followed','linear1024 unchanged byte-cap failure','C027 readonly nested mount infrastructure exit125'],'pending_qualification':v['PENDING'],'runtime_promoted':False,'default_or_dependency_changed':False,'graduation_claim':False,'merges_to_main_held':True}
 names=['evidence.tar.gz','contents.json.gz','source-identities.json','verification.json','summary.json','validate-evidence.py','SHA256SUMS'];assert not any((dest/n).exists() for n in names),'refusing overwrite'
 dest.mkdir(parents=True,exist_ok=True)
 for name,value in [('summary.json',summary),('verification.json',verified),('source-identities.json',identities)]: (dest/name).write_text(json.dumps(value,indent=2)+'\n')
 (dest/'validate-evidence.py').write_bytes(template.read_bytes());index=[]
 with (dest/'evidence.tar.gz').open('wb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
   with tarfile.open(fileobj=zipped,mode='w') as archive:
    for name,data in sorted(files.items()):
     member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;member.mtime=0;archive.addfile(member,io.BytesIO(data));index.append({'path':name,'bytes':len(data),'sha256':sha(data)})
 with (dest/'contents.json.gz').open('wb') as raw:
  with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:zipped.write((json.dumps(index,indent=2)+'\n').encode())
 (dest/'SHA256SUMS').write_text(''.join(f'{sha((dest/n).read_bytes())}  {n}\n' for n in names[:-1]))
 print(json.dumps({'destination':str(dest),'members':len(files),'archive_sha256':sha((dest/'evidence.tar.gz').read_bytes()),'decision':decision,'next':'Root writes README outside artifact hashes and executes the public Python validator; no workload is run by packaging.'},indent=2))

if __name__=='__main__':main()
