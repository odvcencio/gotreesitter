set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/raw-summary-history-v2/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/raw-summary-history-v2/controls.sha256 > /evidence/controls-before.log 2>&1
overlay=/controls/raw-summary-output-v1/root-qualification-v1/immutable-history-v2/overlay.tests.json
go test -overlay="$overlay" -count=1 -v -timeout=3m ./internal/incr > /evidence/incr-all.log 2>&1
go test -race -overlay="$overlay" -run '^TestRawSummaryImmutableHistory' -count=1 -v -timeout=3m ./internal/incr > /evidence/incr-race.log 2>&1
