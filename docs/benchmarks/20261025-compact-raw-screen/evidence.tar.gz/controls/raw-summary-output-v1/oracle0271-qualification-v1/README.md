# Raw output against the already-qualified private C 0.27.1 oracle

Prepared only. Reuse the exact source/binding adapter from public receipt commit `66cd77478b8e79323cb843a2523489830cc9af19`. This recipe adds no binding, C source or compatibility shim. It keeps new raw-output runtime/test files and the full strict tree comparator byte-for-byte. Only the previously qualified two GoNext runtime identity constants change for the C027 arm; the unrelated query-known-note overlay is excluded.

After the same frozen raw map passes `TestRawSummaryOrdinaryLockedC` under the repository C025 oracle, compose a new ignored map:

```sh
python3 harness_out/docker/go-ci-blockers-20261025/raw-summary-output-v1/oracle0271-qualification-v1/compose.py --raw-map FROZEN-RAW-TEST-MAP --c025-log SUCCESSFUL-C025-ORDINARY-LOG --output harness_out/docker/go-ci-blockers-20261025/raw-summary-output-v1/oracle0271-qualification-v1/composed-v1
```

`recipe.json` lists exact readonly Docker submounts, build flags, two selectors and before/after authentication commands. Keep the ordinary `/controls` mount at the current evidence root and overlay its four prior-oracle subdirectories with the existing prior readonly directories. The same original binding is also bound at `/oracle-binding`; the existing module cache remains readonly at `/go-mod`. The second bind avoids Go1.26's module-cache overlay restriction. Preserve the staged `.go` backing basenames: the earlier `.go.txt` cgo attempt failed before tests.

From `/candidate/cgo_harness`, build with `-modfile=/controls/oracle0271-module-bind-v3/go.mod` and the composed overlay. Run the new C027 header/link probe, then the unchanged new ordinary raw-output test. Both original primary500 and real R4 fixtures must execute both reference/lease arms with full strict C equality and genuine lease ownership checked before traversal. Capture new binary hashes and complete results. The prior bounded preflight and prior fleet smoke are provenance, not proof for this new publisher.

The v0.25 binding's frozen private adapter rejects removed deprecated timeout/cancellation methods explicitly. These tests use the supported default parse API. Passing this selection does not establish general binding compatibility, adopt C027, switch a dependency/default, qualify the fleet/platform/performance or complete Go graduation. Main merges remain held.
