#!/usr/bin/env python3
"""Compose already-qualified C027 controls with one frozen, C025-passing raw map."""
from pathlib import Path
import argparse
import hashlib
import json
import re


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-map", type=Path, required=True)
    parser.add_argument("--c025-log", type=Path, required=True, help="successful same-map TestRawSummaryOrdinaryLockedC log")
    parser.add_argument("--output", type=Path, required=True, help="new ignored control directory; no overwrite")
    args = parser.parse_args()
    own = Path(__file__).resolve().parent
    controls = own.parents[1]
    checkout = controls.parents[2]
    prior = checkout / "harness_out/docker/go-reuse-20261025"
    recipe = json.loads((own / "recipe.json").read_text())
    for name, expected in recipe["frozen_prior_control_sha256"].items():
        assert sha(prior / name) == expected, name
    for name, expected in recipe["canonical_source_sha256"].items():
        assert sha(checkout / name) == expected, name
    for name, expected in recipe["raw_qualification_source_sha256"].items():
        assert sha(controls / name) == expected, name
    log = args.c025_log.read_text()
    assert len(re.findall(r"^--- PASS: TestRawSummaryOrdinaryLockedC\b", log, re.M)) == 1
    assert len(re.findall(r"^\s*--- PASS:", log, re.M)) == 7
    assert not re.search(r"--- (FAIL|SKIP):|^FAIL\b|panic:|WARNING: DATA RACE", log, re.M)
    for fixture in ("primary500", "real-r4"):
        for arm in ("false", "true"):
            assert f"--- PASS: TestRawSummaryOrdinaryLockedC/{fixture}/lease={arm} " in log
    raw = json.loads(args.raw_map.read_text())["Replace"]
    for suffix in ("ordinary_cgo_test.go.txt", "cgo_export.go.txt"):
        expected = "/controls/raw-summary-output-v1/root-qualification-v1/" + suffix
        assert sum(value == expected for value in raw.values()) == 1, suffix
    comparator = "/candidate/cgo_harness/parity_swift_condition_field_regression_test.go"
    assert comparator not in raw, "strict all-axis comparator must stay canonical"
    frozen = json.loads((prior / "oracle0271-module-bind-v3/overlay.json").read_text())["Replace"]
    assert len(frozen) == 15
    # Only the two previously qualified GoNext runtime identity constants are
    # needed by this test. Its grammar/source/digest/pass assertions are intact.
    metadata_target = "/candidate/cgo_harness/go_next_live_probe_test.go"
    old = (checkout / "cgo_harness/go_next_live_probe_test.go").read_bytes()
    new = (prior / "oracle0271-go-pins-v4/go_next_live_probe_test.go.txt").read_bytes()
    restored = new
    for before, after in recipe["GoNext_identity_only_replacements"]:
        assert restored.count(after.encode()) == 1
        restored = restored.replace(after.encode(), before.encode(), 1)
    assert restored == old, "GoNext overlay differs beyond the two qualified identity constants"
    frozen[metadata_target] = "/controls/oracle0271-go-pins-v4/go_next_live_probe_test.go.txt"
    merged = dict(raw)
    for target, backing in frozen.items():
        assert target not in merged or merged[target] == backing, (target, merged.get(target), backing)
        merged[target] = backing
    assert "/candidate/cgo_harness/parity_query_semantics_test.go" not in frozen
    # Preserve every source byte from the C025-passing raw lease/test map.
    assert all(merged[key] == value for key, value in raw.items())
    args.output.mkdir(parents=True, exist_ok=False)
    overlay = args.output / "overlay.c027.json"
    overlay.write_text(json.dumps({"Replace": merged}, indent=2) + "\n")
    receipt = {
        "status": "composed only; no build or execution",
        "raw_c025_map_sha256": sha(args.raw_map),
        "raw_c025_selected_log_sha256": sha(args.c025_log),
        "raw_c025_selected_pass_records": 7,
        "new_raw_map_entries_unchanged": len(raw),
        "reused_C027_binding_entries": 15,
        "added_GoNext_metadata_entries": 1,
        "changed_GoNext_constants": 2,
        "query_known_metadata_changes": 0,
        "strict_comparator_unchanged": True,
        "C027_runtime_commit": "10eb5ac119eec9cb4267a8e035066473983f5f3a",
        "composed_map_sha256": sha(overlay),
        "raw_test_sources_and_inputs_unchanged": True,
        "oracle_adopted": False,
        "fleet_or_graduation_claim": False,
    }
    (args.output / "composition.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
