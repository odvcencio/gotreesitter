#!/usr/bin/env bash
set -euo pipefail
# Parent supplies a fully frozen runtime+existing-test map. No runtime source
# is selected by these controls, so a failed representation is not qualified
# merely by composing these two extra test-only files.
: "${RAW_SUMMARY_BASE_MAP:?path to frozen complete map}"
: "${RAW_SUMMARY_OUTPUT_MAP:?path for composed test map}"
python3 /controls/raw-summary-output-v1/ordinary-work-proof-v1/compose.py "$RAW_SUMMARY_BASE_MAP" "$RAW_SUMMARY_OUTPUT_MAP"
cd /candidate
for fixture in primary32 primary128 primary512 primary1024 real-r4; do
  GOMAXPROCS=1 go test -overlay="$RAW_SUMMARY_OUTPUT_MAP" -tags 'gts_parsercorephase0 gts_workcount' -count=1 -v -run "^TestRawSummaryOrdinaryFormationAndReadWork$/${fixture}$" .
done
