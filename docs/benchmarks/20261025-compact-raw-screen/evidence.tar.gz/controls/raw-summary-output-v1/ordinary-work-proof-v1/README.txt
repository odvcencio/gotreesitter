Untimed ordinary-entry formation/read-work control only. No runtime changes.

The external test calls the unchanged benchmark factory for 32/128/512/1024
functions and reads the unchanged 2047-byte real R4 source. Each source and the
9ad1f8d7 grammar identity are asserted. Before RootNode or any public walk it
requires the genuine raw lease, no SelectedStore, Core raw records zero, and
one allocated arena node. Formation, raw/context/public counts, and local read
work are recorded before traversal, after full digest/state/field/parent API
traversal against the old publisher, then after the same warm traversal.
Formation must remain immutable. Warm traversal must add no projection work,
contexts, nodes, or backing bytes. RAW_SUMMARY_ORDINARY_WORK JSON logs retain
all formation fields separately from read-plan fields, raw counts and public
visited edge counts. There is no copied expected work total or invented tight
formation multiplier. Scaling is evaluated from all four authenticated rows.

compose.py adds exactly two test targets to a parent-supplied complete map and
fails on overlaps. commands.sh runs one process per fixture under workcount.
The previously failed linear-v3 release cap run is preserved and is not
qualified by this control. Use only a separately frozen representation chosen
by the parent. No builds, tests, Docker or timing executed by this author.
