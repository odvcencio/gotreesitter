#!/usr/bin/env python3
"""Compose test-only controls with a separately frozen full runtime/test map."""
import argparse, hashlib, json
from pathlib import Path
parser = argparse.ArgumentParser()
parser.add_argument("base_map", type=Path)
parser.add_argument("output_map", type=Path)
args = parser.parse_args()
here = Path(__file__).resolve().parent
manifest = json.loads((here / "manifest.json").read_text())
for name, expected in manifest["backings"].items():
    actual = hashlib.sha256((here / name).read_bytes()).hexdigest()
    if actual != expected:
        raise SystemExit("frozen backing changed: " + name)
base = json.loads(args.base_map.read_text())
own = json.loads((here / "overlay.own.json").read_text())
for target, backing in own["Replace"].items():
    if target in base["Replace"]:
        raise SystemExit("own map target overlap: " + target)
    base["Replace"][target] = backing
args.output_map.write_text(json.dumps(base, sort_keys=True, indent=2) + "\n")
print(json.dumps({"base_sha256": hashlib.sha256(args.base_map.read_bytes()).hexdigest(),
                  "output_sha256": hashlib.sha256(args.output_map.read_bytes()).hexdigest(),
                  "runtime_changes": 0, "new_test_targets": len(own["Replace"])}, sort_keys=True))
