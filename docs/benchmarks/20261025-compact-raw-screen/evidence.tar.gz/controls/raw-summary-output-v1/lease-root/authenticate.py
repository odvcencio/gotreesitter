#!/usr/bin/env python3
import argparse,hashlib,json,pathlib,sys
p=argparse.ArgumentParser();p.add_argument('--root',default='/candidate');p.add_argument('--controls',default=str(pathlib.Path(__file__).resolve().parents[2]));a=p.parse_args();d=pathlib.Path(__file__).resolve().parent;m=json.loads((d/'frozen-inputs.json').read_text());root=pathlib.Path(a.root);controls=pathlib.Path(a.controls)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for row in m['files']:
 source=root/row['target'];actual=sha(source) if source.exists() else None
 if actual!=row['base_sha256']:sys.exit('base drift: '+row['target'])
 if sha(controls/row['backing'])!=row['sha256']:sys.exit('backing drift: '+row['backing'])
for name,want in m['maps'].items():
 if sha(d/name)!=want:sys.exit('map drift: '+name)
print(json.dumps({'authenticated':len(m['files']),'status':'identities match; no execution claim'},sort_keys=True))
