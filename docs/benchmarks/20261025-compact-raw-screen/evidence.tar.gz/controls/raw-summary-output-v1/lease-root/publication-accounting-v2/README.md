# Publication census correction

Frozen mechanical correction over lease-root V1: every publication allocation reservation now includes current arena volume and any detached backing not yet billed through that arena, with overflow checks. Other runtime/test assertions unchanged; memory test map uses the independently corrected full-capacity page census. Original V1 remains frozen.

This remains a semantic correctness prototype. Formation prefix revisits bar timing/standard qualification until composable CoreV2. No execution/performance/promotion/graduation claim is made by these controls.
