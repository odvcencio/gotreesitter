Frozen complete root composition over unchanged publication accounting-v2.
Core uses lease-core-compact-layout-v4 complete runtime/tests, not an additive
partial patch. Root/incr runtime targets are byte-identical to linear-core-v4.
Tests retain memory-v2, source authority, borrowed/immutable history, existing
ordinary public/Copy/C tests, all original Core assertions, the new compact
Core controls, and the ordinary five-source work proof. No prior frozen file
was changed. This composition contains no new Go source bytes.

Maps:
  overlay.runtime.json       Full runtime only.
  overlay.tests.json         Runtime + full internal/root and work controls.
  overlay.cgo.tests.json     Above + unchanged regular C export/strict C test.
Each also has a .host.json counterpart. /candidate and /controls are container
mounts; /controls points to go-ci-blockers-20261025, not this leaf directory.

Initial selectors (root executes, not author):
  Core release: ^Test(Native|Selected|RawSummary|DirectReduction|SingleVersion)
  Core work/race: ^TestRawSummary
  Root: ^TestRawSummaryOrdinaryPublicParity$
  C: ^TestRawSummaryOrdinaryLockedC$
  Workcount: ^TestRawSummaryOrdinaryFormationAndReadWork$
The full lifetime/memory/source controls remain in map, selectable separately.
No timing is qualified by map assembly. All failed linear1024 inputs/output
remain immutable; byte/node limits and tests are not loosened.
