Private attribution/RSS controls; no runtime changes or author execution.

Candidate runtime is exactly compact-core-v5/overlay.runtime.json SHA256
25e9017c7210eb13766ebdd8f5bd9dd63b9c1bc31d12cf3023416ff786dd837c.
The baseline has only two new test controls, with no experimental runtime.
C027 grammar/oracle identity overlays are excluded. Canonical primary and R4
benchmark functions remain untouched; CPU uses BenchmarkGoParseFullDFA (500)
and BenchmarkAdmissionR4Compact (original Go R4 factory). Per-arm entry tests
require complete clean source_file and one compact route/no fallback. Candidate
entry additionally requires real raw lease, Core raw0, arena1 before public
inspection. Profiles are attribution only, not randomized speed evidence.

The large source is exactly 1 MiB: unchanged makeGoBenchmarkSource(24901),
followed by39newline bytes. SHA256
53acce07ec05e32f46d5875067647efc2179d0ded714ac90b65bce56f443181d.
A separate candidate process compares experimental OFF/ON full public digest,
then exact state/fields/parent metadata and all existing cold-receipt assertions.
Both RootOnly observations run once in fresh processes under /usr/bin/time -v,
read no child or query, and include normal source/grammar/parser startup.
The full verifier's process/RSS must never be reported as RootOnly. No cap,
node-limit, byte-budget, memory-threshold or completeness assertion is relaxed.
If the large source declines or truncates, controls fail and preserve reason;
this is not evidence of activation or qualified RSS at 1MiB.

Container mounts are /candidate /baseline /controls /evidence /runtime. Root
owns Docker serialization and resource limits. Run with:
  bash /controls/raw-summary-profile-rss-v1/run.sh profile
  bash /controls/raw-summary-profile-rss-v1/run.sh rss
or all for both. Binaries stay in shared runtime scratch, SHA remains evidence.
No output/publication change, timing claim, promotion or graduation is implied.
