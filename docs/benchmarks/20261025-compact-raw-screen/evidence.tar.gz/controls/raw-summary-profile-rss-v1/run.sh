#!/usr/bin/env bash
set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
export GOMAXPROCS=1 GTS_ADMISSION_CANDIDATE=1 GTS_ADMISSION_REAL_CORPUS_LANGS=go
export GOT_BENCH_FUNC_COUNT=500
unset GOT_STATS
stage=${1:-all}
case "$stage" in all|profile|rss) ;; *) echo 'select all, profile or rss' >&2; exit 2;; esac
cd /candidate
finish() {
  cd /candidate
  sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-after.log 2>&1
  sha256sum --quiet -c /controls/raw-summary-profile-rss-v1/controls.sha256 > /evidence/controls-after.log 2>&1
}
trap finish EXIT
sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/raw-summary-profile-rss-v1/controls.sha256 > /evidence/controls-before.log 2>&1
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/raw-summary-profile-rss-v1
mkdir -p "$scratch"
for arm in baseline candidate; do
  cd "/$arm"
  git config --global --add safe.directory "/$arm"
  go test -c -overlay="/controls/raw-summary-profile-rss-v1/overlay.$arm.json" -tags gts_parsercorephase0 -o "$scratch/$arm.test" . > "/evidence/$arm-build.log" 2>&1
  sha256sum "$scratch/$arm.test" > "/evidence/$arm-binary.sha256"
  for fixture in primary500 real-r4; do
    GTS_RAW_SUMMARY_SCREEN_ARM="$arm" GTS_RAW_SUMMARY_SCREEN_FIXTURE="$fixture" "$scratch/$arm.test" -test.run '^TestRawSummaryProfileEntry$' -test.count=1 -test.v -test.timeout=4m > "/evidence/$arm-$fixture-entry.log" 2>&1
  done
done
if [[ "$stage" == all || "$stage" == profile ]]; then
  for fixture in primary500 real-r4; do
    if [[ "$fixture" == primary500 ]]; then selector='^BenchmarkGoParseFullDFA$'; else selector='^BenchmarkAdmissionR4Compact$'; fi
    for arm in baseline candidate; do
      cd "/$arm"
      GTS_RAW_SUMMARY_SCREEN_ARM="$arm" /usr/bin/time -v "$scratch/$arm.test" -test.run '^$' -test.bench "$selector" -test.benchtime=5s -test.count=1 -test.benchmem -test.cpuprofile="/evidence/$arm-$fixture.cpu" -test.memprofile="/evidence/$arm-$fixture.mem" > "/evidence/$arm-$fixture-profile.log" 2> "/evidence/$arm-$fixture-time.txt"
      go tool pprof -top -nodecount=50 "$scratch/$arm.test" "/evidence/$arm-$fixture.cpu" > "/evidence/$arm-$fixture-top.txt" 2>&1
      go tool pprof -top -cum -nodecount=70 "$scratch/$arm.test" "/evidence/$arm-$fixture.cpu" > "/evidence/$arm-$fixture-cum.txt" 2>&1
    done
  done
fi
if [[ "$stage" == all || "$stage" == rss ]]; then
  # Full verifier uses its own process; its RSS is not a RootOnly observation.
  cd /candidate
  GTS_RAW_SUMMARY_SCREEN_ARM=candidate "$scratch/candidate.test" -test.run '^TestRawSummaryLargeCompleteAndParity$' -test.count=1 -test.v -test.timeout=10m > /evidence/large-full-parity.log 2>&1
  for arm in baseline candidate; do
    cd "/$arm"
    GTS_RAW_SUMMARY_SCREEN_ARM="$arm" /usr/bin/time -v "$scratch/$arm.test" -test.run '^TestRawSummaryLargeRootOnlyRSS$' -test.count=1 -test.v -test.timeout=10m > "/evidence/$arm-large-root-only.log" 2> "/evidence/$arm-large-root-only-time.txt"
  done
fi
