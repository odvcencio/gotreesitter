# Compact raw-lease standard timing controls

Prepared only; runtime-only frozen compact-core-v5 versus canonical dd7d1d1 (Go/bin/module bytes unchanged from the qualified source). Both arms use the identical sealed-screen benchmark wrapper and unchanged randomized runner:20 matched seeds,750ms,count1,benchmem,GOMAXPROCS1. Primary Go trio, ordinary Go R4 and ordinary YAML R4 run as separate cohorts:60pairs/120processes. No work/debug tags or activation instrumentation.

Parent-owned launch:

```sh
python3 harness_out/docker/go-ci-blockers-20261025/raw-summary-perf-compact-v6/worker.py
python3 harness_out/docker/go-ci-blockers-20261025/raw-summary-perf-compact-v6/validate.py
```

The worker waits for the existing shared workload lock. The gate requires completed validated Core/API/C025, five-source actual work/warm0, C027, semantic/C/report/D8/counter and new public-race evidence. It independently recomputes all actual ledger changes and blocks any work rise, reuse fall, unknown metric or metadata change. There is no approval override, and Go-assignment approval does not authorize another counter change. Beneficial changes are recorded. Source/control hashes are checked before and after.

The unchanged result validator requires all60matched pairs, identical child order, expected routes1/fallback0, noedit0 and complete metrics; it emits benchstat, paired ratios and ratios of medians. Failures/timeouts remain visible with no automatic retry or sample deletion. This screen alone gives no fleet/RSS/platform/graduation/promotion or merge permission. YAML stays an ordinary candidate control without scanner ownership activation.
