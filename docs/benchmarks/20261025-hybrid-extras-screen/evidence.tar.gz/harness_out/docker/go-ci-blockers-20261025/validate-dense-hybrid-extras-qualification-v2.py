from pathlib import Path
import copy,json,re
root=Path(__file__).resolve().parent
out=root/'out/dense-hybrid-extras-qualification-v2'
assert json.loads((out/'finished.json').read_text())['exit_code']==0
assert (out/'completed.txt').is_file()
counts={}
for name,want in [('core.log',24),('region-boundaries.log',10),('lifetime.log',4),('memory.log',15),('go-cgo.log',10),('yaml-cgo.log',8)]:
 text=(out/name).read_text()
 assert not re.search(r'--- (FAIL|SKIP):|^panic:|^fatal error:',text,re.M),name
 counts[name]=len(re.findall(r'^--- PASS:',text,re.M))
 assert counts[name]==want,(name,counts[name])
for name in ['source-before.log','source-after.log','controls-before.log','controls-after.log']:
 assert (out/name).read_text()==''
for lang in ['go','yaml']:
 for route in ['0','1']:
  text=(out/f'invariants-{lang}-{route}.log').read_text()
  assert f'language={lang}' in text and 'session_steps=72 no_edit_allocs=0' in text
  assert re.search(r'^--- PASS: TestV1InvariantGateR4EditSession ',text,re.M)
  assert not re.search(r'--- (FAIL|SKIP):',text)
rows={m:[json.loads(x.split('ENTRY_WORK ',1)[1]) for x in (out/f'entry-{m}.log').read_text().splitlines() if 'ENTRY_WORK ' in x] for m in ['off','on']}
assert len(rows['off'])==len(rows['on'])==8
assert len({(r['fixture'],r['entry'],r['candidate']) for r in rows['on']})==8
differences=[];memory=[]
for aa,bb in zip(rows['off'],rows['on']):
 a,b=copy.deepcopy(aa),copy.deepcopy(bb)
 key={k:a[k] for k in ['fixture','entry','candidate']}
 assert all(a[k]==b[k] for k in key)
 oa,ob=a.pop('dense_private_observations'),b.pop('dense_private_observations')
 if a['candidate']:
  assert len(oa)==len(ob)==1
  x,y=copy.deepcopy(oa[0]),copy.deepcopy(ob[0])
  x.pop('Dense');y.pop('Dense')
  for dim in ['CoreNodes','CoreLinks']:
   before,after=x.pop(dim),y.pop(dim);assert after<before
  before,after=x.pop('IdleDenseBytes'),y.pop('IdleDenseBytes')
  assert before==0 and 0<after<=16384
  assert x['CoreWork'].keys()==y['CoreWork'].keys()
  for k in x['CoreWork']:
   before,after=x['CoreWork'][k],y['CoreWork'][k]
   if before!=after:
    assert k=='GraphLinkAdditionsProxy' and after<before
    differences.append(dict(key,area='CoreWork',name=k,before=before,after=after))
  x['CoreWork'].pop('GraphLinkAdditionsProxy');y['CoreWork'].pop('GraphLinkAdditionsProxy')
  assert x==y,('changed provenance/scanner/dependency/scheduler receipt',key)
  for dim in ['last_idle_core_footprint_bytes','last_idle_core_nodes']:
   before,after=a['publication'].pop(dim),b['publication'].pop(dim)
   assert after<before
   memory.append(dict(key,name=dim,before=before,after=after))
  before=a['publication']['last_idle_core_work'].pop('GraphLinkAdditionsProxy')
  after=b['publication']['last_idle_core_work'].pop('GraphLinkAdditionsProxy')
  assert after<before
 else:assert oa==ob
 assert a==b,('changed ordinary public/runtime/work receipt',key)
assert len(differences)==4
m=re.search(r'DENSE_PROMOTION_BUDGET_DIAGNOSTICS \{Regions:(\d+) Checks:(\d+) Fallbacks:(\d+) Refreshes:(\d+)\}',(out/'lifetime.log').read_text())
assert m and int(m[2])>int(m[1])>0 and int(m[3])==0
q=root/'out/dense-hybrid-extras-counters-v2'
assert json.loads((q/'finished.json').read_text())['exit_code']==0
for name in ['source-before.log','source-after.log','controls-before.log','controls-after.log']:
 assert (q/name).read_text()==''
for lang in ['go','yaml']:
 for route in ['default','candidate']:
  name=f'{route}-{lang}.json'
  assert json.loads((q/name).read_text())==json.loads((root/'out/packed-snapshot-budget-final/ledger'/name).read_text()),name
  assert (q/f'{route}-{lang}.stderr').read_text()==''
ordinary={}
for language in ['go','yaml']:
 text=(out/f'extras-ordinary-{language}.log').read_text()
 assert not re.search(r'--- (FAIL|SKIP):|panic:',text)
 assert len(re.findall(r'^--- PASS: TestDenseHybridExtrasOrdinaryWorkReceipt ',text,re.M))==1
 r=[json.loads(x.split('DENSE_EXTRAS_ORDINARY ',1)[1]) for x in text.splitlines() if 'DENSE_EXTRAS_ORDINARY ' in x]
 assert len(r)==2 and [x['enabled'] for x in r]==[False,True]
 a,b=r
 for key in ['grammar','source_sha256','source_bytes','digest','payload_scanner','dependencies','scheduler_work','no_edit_allocations']:assert a[key]==b[key],(language,key)
 assert a['no_edit_allocations']==0
 x,y=dict(a['core_work']),dict(b['core_work'])
 before,after=x.pop('GraphLinkAdditionsProxy'),y.pop('GraphLinkAdditionsProxy')
 assert x==y and after<before
 ordinary[language]={'graph_links_before':before,'graph_links_after':after,'dense':b['dense'],'other_receipts_work_equal':True,'no_edit_allocations':0}
summary={
 'pairs':8,'public_deep_digests_equal':True,'differences':differences,'receipt_differences':[],
 'memory_differences':memory,'budget_diagnostic_regions':int(m[1]),'budget_diagnostic_checks':int(m[2]),
 'budget_diagnostic_fallbacks':int(m[3]),'top_level_tests':counts,
 'Go_and_YAML_C_D8_passed':True,'extras_ordinary':ordinary,'invariant_sessions':4,'edit_steps':288,'no_edit_allocations':0,
 'ordinary_route_actual_ledger_rows_unchanged':4,'performance_claim':False,'private_prototype_promoted':False
}
(out/'entry-rows.json').write_text(json.dumps(rows,indent=2)+'\n')
(out/'differential-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
