set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/dense-hybrid-extras-qualification-v1/controls.sha256 > /evidence/controls-before.log 2>&1
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/dense-hybrid-extras-counters-v1
mkdir -p "$scratch"
go build -overlay=/controls/dense-hybrid-extras-qualification-v1/overlay.container.json -tags gts_parsercorephase0 -o "$scratch/ledger" ./cmd/perfcounterledger > /evidence/build.log 2>&1
for language in go yaml; do
 for route in default candidate; do
  mode=0; if [[ "$route" = candidate ]]; then mode=1; fi
  GTS_ADMISSION_CANDIDATE=$mode "$scratch/ledger" --child-route "$route" --langs "$language" > "/evidence/$route-$language.json" 2> "/evidence/$route-$language.stderr"
 done
done
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1
sha256sum --quiet -c /controls/dense-hybrid-extras-qualification-v1/controls.sha256 > /evidence/controls-after.log 2>&1
sha256sum "$scratch/ledger" > /evidence/binary.sha256
