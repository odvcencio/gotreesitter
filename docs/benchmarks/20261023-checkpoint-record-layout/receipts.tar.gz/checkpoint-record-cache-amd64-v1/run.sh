set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
go env GOOS GOARCH > /evidence/platform.txt
[[ "$(go env GOARCH)" = amd64 ]]
for role in baseline candidate; do
 cd "/$role/cgo_harness"
 go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o "/evidence/$role-cgo.test" . > "/evidence/$role-cgo-build.log" 2>&1
 GTS_YAML_LARGE_PROBE=1 "/evidence/$role-cgo.test" -test.run '^TestCompactYAMLDocumentStreamLockedC$/^large_owned_documents$' -test.count=1 -test.v -test.timeout=5m > "/evidence/$role-large-owned-C.log" 2>&1
 grep -q -- '--- PASS: TestCompactYAMLDocumentStreamLockedC/large_owned_documents' "/evidence/$role-large-owned-C.log"
 cd "/$role"
 go test -c -overlay=/controls/overlay.json -tags gts_parsercorephase0 -o "/evidence/$role.test" . > "/evidence/$role-build.log" 2>&1
done
cp /controls/rss-wrapper.go.txt /evidence/rss-wrapper.go
go build -o /evidence/rsswrap /evidence/rss-wrapper.go > /evidence/rss-wrapper-build.log 2>&1
mkdir /evidence/rss
for seed in $(seq 164001 164020); do
 if (( seed % 2 )); then roles=(baseline candidate); modes=(ordinary owned); else roles=(candidate baseline); modes=(owned ordinary); fi
 for role in "${roles[@]}"; do
  cd "/$role"
  for mode in "${modes[@]}"; do
   GTS_CHECKPOINT_MEMORY_MODE="$mode" /evidence/rsswrap "/evidence/rss/$role-$mode-$seed.json" "/evidence/$role.test" -test.run '^$' -test.bench '^BenchmarkCheckpointYAMLMemory$' -test.benchtime=2x -test.count=1 -test.benchmem -test.shuffle="$seed" -test.timeout=5m > "/evidence/rss/$role-$mode-$seed.log" 2>&1
  done
 done
done
printf 'complete\n' > /evidence/complete.txt
