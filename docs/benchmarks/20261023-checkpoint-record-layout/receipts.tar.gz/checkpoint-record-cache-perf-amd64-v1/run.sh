set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 CGO_ENABLED=0 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
cd /candidate
bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-yaml.txt --output /evidence/candidate-yaml.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 165001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputYAML$' --require-benchmarks 'BenchmarkCompactThroughputYAML/r4_legacy,BenchmarkCompactThroughputYAML/eof8k_legacy,BenchmarkCompactThroughputYAML/r4_ordinary,BenchmarkCompactThroughputYAML/eof8k_ordinary,BenchmarkCompactThroughputYAML/r4_owned,BenchmarkCompactThroughputYAML/eof8k_owned' > /evidence/yaml-driver.log 2>&1
bash scripts/run_randomized_benchmarks.sh --primary-go-suite --baseline-root /baseline --baseline-output /evidence/baseline-go.txt --output /evidence/candidate-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 166001 --benchtime 750ms > /evidence/go-driver.log 2>&1
printf 'complete\n' > /evidence/complete.txt
