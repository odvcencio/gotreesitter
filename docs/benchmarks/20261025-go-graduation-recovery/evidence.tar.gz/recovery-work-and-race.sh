set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
for role in baseline missing; do
 overlay=()
 if [ "$role" = baseline ]; then overlay=(-overlay=/controls/baseline-profile-overlay.json); fi
 go build "${overlay[@]}" -tags gts_parsercorephase0,gts_workcount -o /runtime/tmp/gotreesitter-go-graduation/work-$role /controls/recovery-work-main.go > /evidence/work-$role-build.log 2>&1
 for assignment in 0 1; do
  GTS_PROBE_ASSIGNMENT=$assignment /runtime/tmp/gotreesitter-go-graduation/work-$role > /evidence/work-$role-$assignment.log 2>&1
 done
done
go test ./grammars/runtime -run '^Test(BuiltinGoMissingVersionTurnsRequireExactBlobIdentity|BuiltinRuntimeProfilesStayNarrow)$' -count=1 -v > /evidence/runtime-profile.log 2>&1
/runtime/tmp/gotreesitter-go-graduation/missing-root.test -test.run '^Test(CompactIncrementalExecution.*|CompactRecoveryMemoMemoryBudget|CompactAcceptanceReferenceAndRetainedArenasStayInMemoryBudget|CompactAcceptanceComparisonWorkspaceMemoryBudget|CompactAcceptanceChangedSourceKeepsRebuildBudget)$' -test.v -test.count=1 > /evidence/missing-memory.log 2>&1
/runtime/tmp/gotreesitter-go-graduation/missing-root.test -test.run '^Test(DiagnosticParserCoreSummaryAcceptsExactQueryCompile|DiagnosticParserCoreSeedMatchesImmutableLegacyGolden|NativeNodeViews.*|QuiescentNativeGo.*)$' -test.v -test.count=1 > /evidence/missing-publication.log 2>&1
go test -race -tags gts_parsercorephase0 -run '^Test(NativeNodeViewsConcurrentReads|CompactIncrementalExecutionLifetime)$' -count=1 -v . > /evidence/missing-race.log 2>&1
