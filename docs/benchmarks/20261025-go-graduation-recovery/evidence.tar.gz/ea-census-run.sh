set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOMODCACHE=/go-mod GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
bash /controls/ea-census/prepare.sh > /evidence/ea-prepare.log 2>&1
bash /controls/ea-census/run.sh > /evidence/ea-run.log 2>&1
