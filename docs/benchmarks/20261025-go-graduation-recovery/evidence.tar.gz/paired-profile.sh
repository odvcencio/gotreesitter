set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly -overlay=/controls/paired-profile-overlay.json'
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE=$route bash scripts/run_randomized_benchmarks.sh --output /evidence/profile-after-$route.txt --baseline-root /baseline --baseline-output /evidence/profile-before-$route.txt --lock-path /evidence/benchmark.lock --bench-regex '^BenchmarkGraduationGoSuite$' --require-benchmarks BenchmarkGraduationGoSuite/Full,BenchmarkGraduationGoSuite/Edit,BenchmarkGraduationGoSuite/NoEdit --runs 20 --seed-start 1 --benchtime 750ms > /evidence/profile-runner-$route.log 2>&1
done
