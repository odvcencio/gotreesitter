set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
sha256sum --quiet -c /controls/final-go-source.sha256 > /evidence/final-source-authentication.log 2>&1
git rev-parse HEAD > /evidence/final-tested-head.txt
git status --short > /evidence/final-tested-status.txt
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /runtime/tmp/gotreesitter-go-graduation/qualified-cgo.test . > /evidence/qualified-cgo-build.log 2>&1
/runtime/tmp/gotreesitter-go-graduation/qualified-cgo.test -test.run '^Test(Go(Compact|TokenInvariant|Unterminated|GeneratedNUL|NewMake|Cognociente|MalformedDeclaration|AssignmentTarget)|Stage6GoCompactCertification|CanonicalGoBenchmarkPreflight)' -test.v -test.count=1 > /evidence/qualified-go-cgo.log 2>&1
GTS_ADMISSION_REAL_CORPUS_LANGS=go /runtime/tmp/gotreesitter-go-graduation/qualified-cgo.test -test.run '^TestCompactR4StructuralLockedC$' -test.v -test.count=1 > /evidence/qualified-r4-cgo.log 2>&1
GTS_CANONICAL_GO_INCREMENTAL=1 GTS_ADMISSION_CANDIDATE=1 /runtime/tmp/gotreesitter-go-graduation/qualified-cgo.test -test.run '^TestCanonicalGoIncrementalParity/(unchanged_snapshot_identity|same_length_leaf_validation|token_class_change|same_line_length_change|early_newline|recovery_deletion)$' -test.v -test.count=1 > /evidence/qualified-canonical-go.log 2>&1
