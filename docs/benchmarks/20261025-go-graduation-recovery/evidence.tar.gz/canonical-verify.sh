set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate/cgo_harness
set +e
GTS_CANONICAL_GO_INCREMENTAL=1 GTS_ADMISSION_CANDIDATE=1 /runtime/tmp/gotreesitter-go-graduation/recovery-probe.test -test.run '^TestCanonicalGoIncrementalParity/same_length_leaf_validation$' -test.v -test.count=1 > /evidence/canonical-leaf-baseline.log 2>&1
printf '%s\n' "$?" > /evidence/canonical-leaf-baseline.exit
set -e
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /runtime/tmp/gotreesitter-go-graduation/canonical-cgo.test . > /evidence/canonical-cgo-build.log 2>&1
/runtime/tmp/gotreesitter-go-graduation/canonical-cgo.test -test.run '^TestCanonicalIncremental(Classification.*|ClosureStatus|ReceiptPathStaysInHarness)$' -test.v -test.count=1 > /evidence/canonical-classification.log 2>&1
GTS_CANONICAL_GO_INCREMENTAL=1 GTS_ADMISSION_CANDIDATE=1 /runtime/tmp/gotreesitter-go-graduation/canonical-cgo.test -test.run '^TestCanonicalGoIncrementalParity/(unchanged_snapshot_identity|same_length_leaf_validation|token_class_change|same_line_length_change|early_newline|recovery_deletion)$' -test.v -test.count=1 > /evidence/canonical-final-go.log 2>&1
GTS_CANONICAL_GO_INCREMENTAL=1 GTS_ADMISSION_CANDIDATE=1 /runtime/tmp/gotreesitter-go-graduation/canonical-cgo.test -test.run '^TestCanonicalGoIncrementalParity/(python_scanner_dedent)$' -test.v -test.count=1 > /evidence/canonical-final-python.log 2>&1
