set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
mkdir -p /runtime/tmp/gotreesitter-go-graduation
git config --global --add safe.directory /candidate
cd /candidate
go build -tags gts_parsercorephase0 -overlay=/controls/baseline-profile-overlay.json -o /runtime/tmp/gotreesitter-go-graduation/baseline-ledger ./cmd/perfcounterledger > /evidence/baseline-ledger-build.log 2>&1
go build -tags gts_parsercorephase0 -o /runtime/tmp/gotreesitter-go-graduation/missing-ledger ./cmd/perfcounterledger > /evidence/missing-ledger-build.log 2>&1
for route in default candidate; do
 GTS_ADMISSION_CANDIDATE=$([ "$route" = candidate ] && echo 1 || echo 0) /runtime/tmp/gotreesitter-go-graduation/baseline-ledger --child-route="$route" --langs go > /evidence/baseline-ledger-$route.json
 GTS_ADMISSION_CANDIDATE=$([ "$route" = candidate ] && echo 1 || echo 0) /runtime/tmp/gotreesitter-go-graduation/missing-ledger --child-route="$route" --langs go > /evidence/missing-ledger-$route.json
done
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /runtime/tmp/gotreesitter-go-graduation/missing-cgo.test . > /evidence/missing-cgo-build.log 2>&1
/runtime/tmp/gotreesitter-go-graduation/missing-cgo.test -test.run '^Test(Go(Compact|TokenInvariant|Unterminated|GeneratedNUL|NewMake|Cognociente137KiBTopEditLockedC|MalformedDeclarationPrefixLockedC)|Stage6GoCompactCertification|CanonicalGoBenchmarkPreflight)$' -test.v -test.count=1 > /evidence/missing-cgo.log 2>&1
cd /candidate
go test -c -tags gts_parsercorephase0 -o /runtime/tmp/gotreesitter-go-graduation/missing-root.test . > /evidence/missing-root-build.log 2>&1
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE=go /runtime/tmp/gotreesitter-go-graduation/missing-root.test -test.run '^TestV1InvariantGateR4EditSession$' -test.v -test.count=1 > /evidence/missing-invariant-$route.log 2>&1
done
