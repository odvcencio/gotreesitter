set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
mkdir -p /runtime/tmp/gotreesitter-go-graduation
git config --global --add safe.directory /candidate
cd /candidate/cgo_harness
go test -overlay=/controls/recovery-probe-overlay.json -c -tags treesitter_c_parity,gts_parsercorephase0 -o /runtime/tmp/gotreesitter-go-graduation/recovery-probe.test . > /evidence/recovery-probe-build.log 2>&1
set +e
/runtime/tmp/gotreesitter-go-graduation/recovery-probe.test -test.run '^TestGoGraduationRecoveryProbe$' -test.count=1 -test.v > /evidence/recovery-probe.log 2>&1
printf '%s
' "$?" > /evidence/recovery-probe.exit
GTS_RECOVERY_TRACE=1 /runtime/tmp/gotreesitter-go-graduation/recovery-probe.test -test.run '^TestGoGraduationRecoveryProbe/base/candidate=false$' -test.count=1 -test.v > /evidence/recovery-trace.log 2>&1
printf '%s
' "$?" > /evidence/recovery-trace.exit
