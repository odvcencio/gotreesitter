set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /runtime/tmp/gotreesitter-go-graduation/final-cgo.test . > /evidence/final-cgo-build.log 2>&1
/runtime/tmp/gotreesitter-go-graduation/final-cgo.test -test.run '^TestGo(MalformedDeclarationPrefixLockedC|AssignmentTargetEdits16SitesLockedC)$' -test.v -test.count=1 > /evidence/final-recovery-cgo.log 2>&1
GTS_CANONICAL_GO_INCREMENTAL=1 GTS_CANONICAL_INCREMENTAL_RECEIPT_OUT=/evidence/canonical-incremental.json /runtime/tmp/gotreesitter-go-graduation/final-cgo.test -test.run '^TestCanonicalGoIncrementalParity$' -test.v -test.count=1 > /evidence/canonical-incremental.log 2>&1
