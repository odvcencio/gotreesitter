set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate/cgo_harness
env -u GTS_CANONICAL_INCREMENTAL_RECEIPT_OUT GTS_CANONICAL_GO_INCREMENTAL=1 /runtime/tmp/gotreesitter-go-graduation/final-cgo.test -test.run '^TestCanonicalGoIncrementalParity$' -test.v -test.count=1 > /evidence/canonical-incremental-final.log 2>&1
go test -overlay=/controls/order-profile-overlay.json -c -tags treesitter_c_parity,gts_parsercorephase0 -o /runtime/tmp/gotreesitter-go-graduation/order-cgo.test . > /evidence/order-cgo-build.log 2>&1
/runtime/tmp/gotreesitter-go-graduation/order-cgo.test -test.run '^Test(Go(MalformedDeclarationPrefixLockedC|AssignmentTargetEdits16SitesLockedC|Compact.*|TokenInvariant.*|Cognociente137KiBTopEditLockedC)|Stage6GoCompactCertification)$' -test.v -test.count=1 > /evidence/order-cgo.log 2>&1
cd /candidate
go build -overlay=/controls/order-profile-overlay.json -tags gts_parsercorephase0 -o /runtime/tmp/gotreesitter-go-graduation/order-ledger ./cmd/perfcounterledger > /evidence/order-ledger-build.log 2>&1
for route in default candidate; do
 GTS_ADMISSION_CANDIDATE=$([ "$route" = candidate ] && echo 1 || echo 0) /runtime/tmp/gotreesitter-go-graduation/order-ledger --child-route="$route" --langs go > /evidence/order-ledger-$route.json
done
go build -overlay=/controls/order-profile-overlay.json -tags gts_parsercorephase0,gts_workcount -o /runtime/tmp/gotreesitter-go-graduation/work-order /controls/recovery-work-main.go > /evidence/work-order-build.log 2>&1
for assignment in 0 1; do
 GTS_PROBE_ASSIGNMENT=$assignment /runtime/tmp/gotreesitter-go-graduation/work-order > /evidence/work-order-$assignment.log 2>&1
done
