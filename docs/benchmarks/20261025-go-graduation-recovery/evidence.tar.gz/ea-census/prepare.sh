#!/usr/bin/env bash
set -euo pipefail
# Root owns the outer container resource cap and shared measurement lock.
# This script compiles only; it launches no benchmark or independent workload.
cd /candidate
controls=/controls/ea-census
out=${GTS_EA_RESULTS:-/evidence/ea-census-results}
binary=${GTS_EA_FROZEN_BIN:-/runtime/tmp/gotreesitter-ea-census/current-r4.test}
real_go=${GTS_EA_REAL_GO:-/usr/local/go/bin/go}
[[ "$out" = /* && "$binary" = /* ]] || { echo 'absolute results/binary paths required' >&2; exit 2; }
[[ ! -e "$out/ready.json" && ! -e "$binary" ]] || { echo 'refusing to overwrite a frozen census build' >&2; exit 2; }
mkdir -p "$out" "$(dirname "$binary")"
export GOWORK=off GOTOOLCHAIN=local
# Preserve VCS stamping; overlays change only the private benchmark control.
export GOFLAGS='-p=1 -mod=readonly'
"$real_go" version > "$out/go-version.txt"
"$real_go" env -json GOOS GOARCH GOVERSION CGO_ENABLED GOMODCACHE GOCACHE > "$out/go-env.json"
git --no-optional-locks rev-parse HEAD > "$out/build-head.txt"
git --no-optional-locks status --short > "$out/build-status.txt"
mkdir -p "$out/frozen-bin"
cp "$controls/bin/go" "$out/frozen-bin/go"
chmod 0555 "$out/frozen-bin/go"
cp /candidate/scripts/run_randomized_benchmarks.sh "$out/frozen-randomized-benchmarks.sh"
cmp /candidate/scripts/run_randomized_benchmarks.sh "$out/frozen-randomized-benchmarks.sh"
"$real_go" list -deps -test -json -tags gts_parsercorephase0 -overlay="$controls/overlay.json" . > "$out/packages-before.json" 2> "$out/packages-before.stderr"
"$real_go" run "$controls/source-manifest.go" -packages "$out/packages-before.json" -overlay "$controls/overlay.json" -inputs "$controls/input-identities.json" -controls "$controls" -output "$out/source-before.json" > "$out/source-before.log" 2>&1
"$real_go" test -c -tags gts_parsercorephase0 -overlay="$controls/overlay.json" -o "$binary" . > "$out/build.log" 2>&1
"$real_go" list -deps -test -json -tags gts_parsercorephase0 -overlay="$controls/overlay.json" . > "$out/packages-after.json" 2> "$out/packages-after.stderr"
"$real_go" run "$controls/source-manifest.go" -packages "$out/packages-after.json" -overlay "$controls/overlay.json" -inputs "$controls/input-identities.json" -controls "$controls" -output "$out/source-after.json" > "$out/source-after.log" 2>&1
if ! cmp "$out/source-before.json" "$out/source-after.json" > "$out/source-stability.diff"; then
 echo 'source changed during build; binary is unqualified and ready.json is not written' >&2
 exit 1
fi
cmp "$controls/bin/go" "$out/frozen-bin/go"
cmp /candidate/scripts/run_randomized_benchmarks.sh "$out/frozen-randomized-benchmarks.sh"
# Snapshot package/corpus inputs and controls by hash, never copy local payloads.
cp "$controls/input-identities.json" "$out/input-identities.json"
cp "$controls/languages.txt" "$out/languages.txt"
sha256sum "$binary" | awk '{print $1}' > "$out/binary.sha256"
sha256sum "$out/frozen-bin/go" | awk '{print $1}' > "$out/shim.sha256"
sha256sum "$out/source-after.json" | awk '{print $1}' > "$out/source-manifest.sha256"
sha256sum "$out/frozen-randomized-benchmarks.sh" | awk '{print $1}' > "$out/runner.sha256"
chmod 0555 "$binary"
printf '{"schema":"gts-frozen-r4-census-ready/v1","scope":"diagnostic current legacy; no M1 baseline qualification","binary_sha256":"%s","source_manifest_sha256":"%s","runner_sha256":"%s","shim_sha256":"%s","languages":206}\n' "$(cat "$out/binary.sha256")" "$(cat "$out/source-manifest.sha256")" "$(cat "$out/runner.sha256")" "$(cat "$out/shim.sha256")" > "$out/ready.json"
