// Command source-manifest binds the prebuilt diagnostic test binary to every
// package source/embed input selected by go list, its overlay and runtime corpus.
package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

type sourceFile struct {
	LogicalPath string `json:"logical_path"`
	ContentPath string `json:"content_path"`
	Bytes       int    `json:"bytes"`
	SHA256      string `json:"sha256"`
}
type listedPackage struct {
	ImportPath, Dir                                                                                                                                                                 string
	GoFiles, CgoFiles, CFiles, CXXFiles, MFiles, HFiles, FFiles, SFiles, SwigFiles, SwigCXXFiles, SysoFiles, EmbedFiles, TestEmbedFiles, XTestEmbedFiles, TestGoFiles, XTestGoFiles []string
}

func main() {
	var packages, overlayPath, inputPath, controls, output string
	flag.StringVar(&packages, "packages", "", "go list -deps -test -json output")
	flag.StringVar(&overlayPath, "overlay", "", "exact source overlay")
	flag.StringVar(&inputPath, "inputs", "", "authenticated runtime inputs")
	flag.StringVar(&controls, "controls", "", "static census controls directory")
	flag.StringVar(&output, "output", "", "output manifest")
	flag.Parse()
	must := func(err error) {
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	}
	var overlay struct{ Replace map[string]string }
	data, err := os.ReadFile(overlayPath)
	must(err)
	must(json.Unmarshal(data, &overlay))
	files := map[string]sourceFile{}
	record := func(logical string) {
		logical = filepath.Clean(logical)
		path := logical
		if replacement, ok := overlay.Replace[logical]; ok {
			path = replacement
		}
		data, err := os.ReadFile(path)
		must(err)
		h := sha256.Sum256(data)
		value := sourceFile{logical, path, len(data), hex.EncodeToString(h[:])}
		if previous, ok := files[logical]; ok && previous != value {
			must(fmt.Errorf("source changed while manifesting %s", logical))
		}
		files[logical] = value
	}
	f, err := os.Open(packages)
	must(err)
	defer f.Close()
	decoder := json.NewDecoder(f)
	packageNames := map[string]bool{}
	var generatedPackages []string
	for {
		var p listedPackage
		err := decoder.Decode(&p)
		if err == io.EOF {
			break
		}
		must(err)
		if strings.HasSuffix(p.ImportPath, ".test") {
			// go test generates testmain; capture all actual package inputs instead of
			// depending on a temporary/cache pathname assigned to the generated glue.
			generatedPackages = append(generatedPackages, p.ImportPath)
			continue
		}
		packageNames[p.ImportPath] = true
		for _, group := range [][]string{p.GoFiles, p.CgoFiles, p.CFiles, p.CXXFiles, p.MFiles, p.HFiles, p.FFiles, p.SFiles, p.SwigFiles, p.SwigCXXFiles, p.SysoFiles, p.EmbedFiles, p.TestEmbedFiles, p.XTestEmbedFiles, p.TestGoFiles, p.XTestGoFiles} {
			for _, name := range group {
				path := name
				if !filepath.IsAbs(path) {
					path = filepath.Join(p.Dir, name)
				}
				record(path)
			}
		}
	}
	var inputs struct {
		Languages []struct {
			Language, Path, SHA256 string
			Bytes                  int
		}
	}
	data, err = os.ReadFile(inputPath)
	must(err)
	must(json.Unmarshal(data, &inputs))
	if len(inputs.Languages) != 206 {
		must(fmt.Errorf("runtime input count=%d want 206", len(inputs.Languages)))
	}
	seen := map[string]bool{}
	for _, r := range inputs.Languages {
		if seen[r.Language] {
			must(fmt.Errorf("duplicate runtime input %s", r.Language))
		}
		seen[r.Language] = true
		data, err := os.ReadFile(r.Path)
		must(err)
		h := sha256.Sum256(data)
		if len(data) != r.Bytes || hex.EncodeToString(h[:]) != r.SHA256 {
			must(fmt.Errorf("runtime input identity changed: %s", r.Language))
		}
		record(r.Path)
	}
	for _, path := range []string{"/candidate/go.mod", "/candidate/go.sum", "/candidate/scripts/run_randomized_benchmarks.sh", "/candidate/internal/benchfixtures/real_corpus.json"} {
		record(path)
	}
	record(filepath.Join(controls, "bin", "go"))
	entries, err := os.ReadDir(controls)
	must(err)
	for _, entry := range entries {
		if !entry.IsDir() {
			record(filepath.Join(controls, entry.Name()))
		}
	}
	ordered := make([]sourceFile, 0, len(files))
	for _, f := range files {
		ordered = append(ordered, f)
	}
	sort.Slice(ordered, func(i, j int) bool { return ordered[i].LogicalPath < ordered[j].LogicalPath })
	names := make([]string, 0, len(packageNames))
	for name := range packageNames {
		names = append(names, name)
	}
	sort.Strings(names)
	sort.Strings(generatedPackages)
	value := struct {
		Schema                    string       `json:"schema"`
		Scope                     string       `json:"scope"`
		Tags                      string       `json:"tags"`
		Packages                  []string     `json:"packages"`
		GeneratedTestMainPackages []string     `json:"generated_test_main_packages"`
		Files                     []sourceFile `json:"files"`
	}{"gts-frozen-r4-census-source/v1", "diagnostic current-runtime compact versus current-runtime legacy; M1 baseline unauthenticated", "gts_parsercorephase0", names, generatedPackages, ordered}
	data, err = json.MarshalIndent(value, "", "  ")
	must(err)
	data = append(data, '\n')
	must(os.WriteFile(output, data, 0644))
	fmt.Printf("source manifest: %d package variants, %d files, %d runtime inputs\n", len(names), len(ordered), len(inputs.Languages))
}
