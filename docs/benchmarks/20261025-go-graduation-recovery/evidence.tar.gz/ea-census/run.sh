#!/usr/bin/env bash
set -euo pipefail
# Invoke in the already isolated/serialized measurement container. No host
# flock is acquired here. The unchanged runner owns only its results-directory
# bookkeeping lock while root retains the outer shared measurement lock.
cd /candidate
out=${GTS_EA_RESULTS:-/evidence/ea-census-results}
binary=${GTS_EA_FROZEN_BIN:-/runtime/tmp/gotreesitter-ea-census/current-r4.test}
[[ -s "$out/ready.json" && -x "$binary" ]] || { echo 'prepare.sh must finish successfully first' >&2; exit 2; }
[[ ! -e "$out/census-started.json" ]] || { echo 'refusing to overwrite/restart an existing census' >&2; exit 2; }
[[ "$(sha256sum "$binary" | awk '{print $1}')" = "$(cat "$out/binary.sha256")" ]] || { echo 'frozen binary changed' >&2; exit 2; }
[[ "$(sha256sum "$out/frozen-randomized-benchmarks.sh" | awk '{print $1}')" = "$(cat "$out/runner.sha256")" ]] || { echo 'frozen randomized runner changed' >&2; exit 2; }
[[ "$(sha256sum "$out/source-after.json" | awk '{print $1}')" = "$(cat "$out/source-manifest.sha256")" ]] || { echo 'frozen source manifest changed' >&2; exit 2; }
[[ "$(sha256sum "$out/frozen-bin/go" | awk '{print $1}')" = "$(cat "$out/shim.sha256")" ]] || { echo 'frozen strict go shim changed' >&2; exit 2; }
export GTS_EA_RESULTS="$out" GTS_EA_FROZEN_BIN="$binary" GOMAXPROCS=1
export GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
export PATH="$out/frozen-bin:$PATH"
mapfile -t languages < "$out/languages.txt"
(( ${#languages[@]} == 206 )) || { echo 'expected all 206 languages' >&2; exit 2; }
# The parser override in each exact original benchmark selects its route.
unset GTS_ADMISSION_CANDIDATE
for variable in ${!GOT_@}; do
 [[ -z "${!variable}" ]] || { printf 'parser override %s must be unset\n' "$variable" >&2; exit 2; }
done
printf '{"schema":"gts-current-legacy-ea-census/v1","status":"started","languages":206,"seeds":20,"seed_start":1,"benchtime":"750ms","scope":"diagnostic current legacy; M1 baseline unauthenticated","started":"%s"}\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" > "$out/census-started.json"
mkdir -p "$out/languages" "$out/status" "$out/events"
failed=0
for language in "${languages[@]}"; do
 [[ "$language" =~ ^[a-z0-9_-]+$ ]] || { echo 'invalid language name' >&2; exit 2; }
 export GTS_ADMISSION_REAL_CORPUS_LANGS="$language"
 started=$(date -u '+%Y-%m-%dT%H:%M:%SZ')
 printf '{"language":"%s","status":"started","expected_seeds":20,"started":"%s"}\n' "$language" "$started" > "$out/status/$language.json"
 # The runner fails on an incomplete seed; retain that seed and count all
 # remaining seeds as unattempted, then continue to the next grammar.
 set +e
 bash "$out/frozen-randomized-benchmarks.sh" \
  --output "$out/languages/$language.txt" \
  --lock-path "$out/runner-bookkeeping.lock" \
  --runs 20 --seed-start 1 --benchtime 750ms \
  --tags gts_parsercorephase0 --package . \
  --bench-regex '^BenchmarkCompactGraduationR4$' \
  --require-benchmarks BenchmarkCompactGraduationR4/legacy,BenchmarkCompactGraduationR4/compact \
  > "$out/languages/$language.runner.log" 2>&1
 code=$?
 set -e
 ended=$(date -u '+%Y-%m-%dT%H:%M:%SZ')
 printf '{"language":"%s","status":"finished","expected_seeds":20,"started":"%s","ended":"%s","exit_code":%s}\n' "$language" "$started" "$ended" "$code" > "$out/status/$language.json"
 printf 'EA_CENSUS language=%s exit_code=%s\n' "$language" "$code"
 if (( code != 0 )); then failed=$((failed+1)); fi
done
binary_stable=false
if [[ "$(sha256sum "$binary" | awk '{print $1}')" = "$(cat "$out/binary.sha256")" ]]; then binary_stable=true; fi
printf '{"schema":"gts-current-legacy-ea-census/v1","status":"finished","attempted_languages":206,"failed_runner_count":%s,"binary_stable":%s,"ended":"%s"}\n' "$failed" "$binary_stable" "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" > "$out/census-finished.json"
[[ "$binary_stable" = true ]] || exit 1
(( failed == 0 ))
