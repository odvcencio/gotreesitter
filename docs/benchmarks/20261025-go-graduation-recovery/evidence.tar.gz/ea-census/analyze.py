#!/usr/bin/env python3
"""Audit every expected language/seed; summarize a current-legacy diagnostic.

Usage: python3 analyze.py RESULTS [--output PREFIX]
No language is silently removed. Partial seed data is retained as diagnostic
samples, but only complete 20-seed languages enter the explicitly partial fleet
statistics. An incomplete fleet can never pass the E-A distribution thresholds.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import statistics


def read_json(path):
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text())
    except (ValueError, OSError) as exc:
        return {"read_error": str(exc)}


def median(values):
    return statistics.median(values) if values else None


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def parse_rows(path):
    samples = {}
    orders = {}
    current_seed = None
    raw_orders = {}
    errors = []
    text = path.read_text(errors="replace") if path.is_file() else ""
    for line in text.splitlines():
        match = re.match(r"# seed: ([0-9]+); position: ([0-9]+)$", line)
        if match:
            current_seed = int(match[1])
        if line.startswith("# workload order: ") and current_seed is not None:
            raw_orders.setdefault(current_seed, []).append(line.split(": ", 1)[1].split(","))
        fields = line.split()
        if not fields or not fields[0].startswith("BenchmarkCompactGraduationR4/"):
            continue
        # Ignore the test binary's unterminated benchmark-name preamble until
        # a complete numeric benchmark result appears.
        if len(fields) < 4 or not fields[1].isdigit():
            continue
        match = re.fullmatch(r"BenchmarkCompactGraduationR4/(legacy|compact)(?:-[0-9]+)?", fields[0])
        if not match:
            errors.append("unknown benchmark row: " + fields[0])
            continue
        if current_seed is None:
            errors.append("benchmark result without explicit process seed")
            continue
        metrics = {}
        try:
            for i in range(2, len(fields) - 1, 2):
                metrics[fields[i + 1]] = float(fields[i])
        except ValueError:
            errors.append(f"seed {current_seed}: nonnumeric metric")
            continue
        route = match[1]
        rows = samples.setdefault(current_seed, {}).setdefault(route, [])
        rows.append({"iterations": int(fields[1]), "metrics": metrics})
        orders.setdefault(current_seed, []).append(fields[0].removesuffix("-1"))
    expected_names = {"BenchmarkCompactGraduationR4/legacy", "BenchmarkCompactGraduationR4/compact"}
    for seed, order in orders.items():
        declared = raw_orders.get(seed, [])
        if len(order) != 2 or set(order) != expected_names:
            errors.append(f"seed {seed}: incomplete/duplicated child execution order {order}")
        if declared != [order]:
            errors.append(f"seed {seed}: explicit runner order missing or differs: {declared} / {order}")
    return samples, orders, errors, "# status: complete" in text


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("results", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    results = args.results
    prefix = args.output or results / "analysis"
    identities = read_json(results / "input-identities.json")
    if not identities or len(identities.get("languages", [])) != 206:
        raise SystemExit("expected the frozen 206-language input-identities.json")
    expected = identities["languages"]
    if len({row["language"] for row in expected}) != 206:
        raise SystemExit("duplicate language identity")
    ready = read_json(results / "ready.json")
    source_manifest = read_json(results / "source-after.json")
    finished = read_json(results / "census-finished.json")
    provenance_errors = []
    if not ready or ready.get("schema") != "gts-frozen-r4-census-ready/v1":
        provenance_errors.append("frozen build ready receipt missing/invalid")
    elif digest(results / "source-after.json") != ready.get("source_manifest_sha256"):
        provenance_errors.append("source manifest hash differs from build receipt")
    if not source_manifest or not source_manifest.get("files"):
        provenance_errors.append("compiled source/runtime-input manifest missing")
    if not finished or finished.get("attempted_languages") != 206 or not finished.get("binary_stable"):
        provenance_errors.append("all-language final state or stable-binary proof missing")
    if ready and digest(results / "frozen-randomized-benchmarks.sh") != ready.get("runner_sha256"):
        provenance_errors.append("unchanged randomized runner snapshot does not authenticate")
    if ready and digest(results / "frozen-bin/go") != ready.get("shim_sha256"):
        provenance_errors.append("frozen strict go shim does not authenticate")

    rows = []
    for identity in expected:
        language = identity["language"]
        status = read_json(results / "status" / (language + ".json"))
        samples, orders, errors, raw_complete = parse_rows(results / "languages" / (language + ".txt"))
        events = {seed: read_json(results / "events" / language / f"seed-{seed}.json") for seed in range(1, 21)}
        if any(seed not in range(1, 21) for seed in samples):
            errors.append("unexpected seed in raw timing data")
        valid = []
        pairs = []
        missing_or_invalid = []
        for seed in range(1, 21):
            pair = samples.get(seed, {})
            event = events[seed]
            valid_pair = event and event.get("status") == "finished" and event.get("exit_code") == 0
            for route in ("legacy", "compact"):
                values = pair.get(route, [])
                valid_pair = valid_pair and len(values) == 1 and values[0]["iterations"] > 0
                if len(values) == 1:
                    metrics = values[0]["metrics"]
                    valid_pair = valid_pair and all(k in metrics for k in ("ns/op", "B/op", "allocs/op", "compact-routes/op", "compact-fallbacks/op")) and all(math.isfinite(metrics[k]) and metrics[k] >= 0 for k in ("ns/op", "B/op", "allocs/op")) and metrics.get("ns/op", 0) > 0
            if not valid_pair:
                missing_or_invalid.append(seed)
                continue
            legacy = pair["legacy"][0]["metrics"]
            compact = pair["compact"][0]["metrics"]
            # Original route benchmarks force legacy off: any compact activity
            # on that side is a control failure, not a favorable ratio.
            if legacy["compact-routes/op"] != 0 or legacy["compact-fallbacks/op"] != 0:
                errors.append(f"seed {seed}: legacy route entered candidate execution")
                missing_or_invalid.append(seed)
                continue
            valid.append(seed)
            pairs.append({"seed": seed, "legacy": legacy, "compact": compact, "compact_over_legacy": compact["ns/op"] / legacy["ns/op"], "child_order": orders.get(seed, [])})
        complete = len(valid) == 20 and not errors and raw_complete and status and status.get("status") == "finished" and status.get("exit_code") == 0
        failed_events = [v for v in events.values() if v and (v.get("status") != "finished" or v.get("exit_code") != 0)]
        if complete:
            classification = "complete"
        elif failed_events or (status and status.get("status") == "finished" and status.get("exit_code") != 0) or errors:
            classification = "failed"
        else:
            classification = "incomplete"
        legacy_times = [p["legacy"]["ns/op"] for p in pairs]
        compact_times = [p["compact"]["ns/op"] for p in pairs]
        paired_median = median([p["compact_over_legacy"] for p in pairs])
        medians_ratio = median(compact_times) / median(legacy_times) if pairs else None
        rows.append({
            "language": language, "identity": identity, "status": classification,
            "complete_pair_count": len(pairs), "missing_or_invalid_seeds": missing_or_invalid,
            "runner_status": status, "process_events": [v for v in events.values() if v],
            "failed_or_interrupted_processes": len(failed_events),
            "timeout_or_kill_processes": sum(bool(v.get("timeout_or_kill")) for v in failed_events),
            "errors": errors, "legacy_ns_median": median(legacy_times), "compact_ns_median": median(compact_times),
            "paired_ratio_median": paired_median, "ratio_of_time_medians": medians_ratio,
            "compact_routes_per_op_median": median([p["compact"]["compact-routes/op"] for p in pairs]),
            "compact_fallbacks_per_op_median": median([p["compact"]["compact-fallbacks/op"] for p in pairs]),
            "pairs": pairs,
        })
    complete_rows = [r for r in rows if r["status"] == "complete"]
    failed = [r["language"] for r in rows if r["status"] == "failed"]
    incomplete = [r["language"] for r in rows if r["status"] == "incomplete"]
    ratios = [r["paired_ratio_median"] for r in complete_rows]
    other_ratios = [r["ratio_of_time_medians"] for r in complete_rows]
    partial = len(complete_rows) != 206
    thresholds = bool(ratios) and median(ratios) <= 1.0 and max(ratios) <= 1.15
    analysis = {
        "schema": "gts-current-legacy-ea-census-analysis/v1",
        "scope": "diagnostic current-runtime comparison; not authenticated frozen M1 legacy or E-A graduation qualification",
        "language_count": 206, "complete_language_count": len(complete_rows),
        "failed_language_count": len(failed), "incomplete_language_count": len(incomplete),
        "failed_languages": failed, "incomplete_languages": incomplete,
        "failure_or_incomplete_count": len(failed) + len(incomplete),
        "provenance_errors": provenance_errors,
        "fleet_statistics_are_partial": partial,
        "fleet_median_of_paired_ratio_medians": median(ratios),
        "fleet_worst_paired_ratio_median": max(ratios) if ratios else None,
        "fleet_median_of_ratios_of_medians": median(other_ratios),
        "fleet_worst_ratio_of_medians": max(other_ratios) if other_ratios else None,
        "complete_current_runtime_distribution_meets_numeric_thresholds": not partial and not provenance_errors and thresholds,
        "M1_baseline_authenticated": False, "graduation_qualified": False,
        "worst_complete_languages": [{k: r[k] for k in ("language", "paired_ratio_median", "ratio_of_time_medians", "compact_routes_per_op_median", "compact_fallbacks_per_op_median")} for r in sorted(complete_rows, key=lambda r: r["paired_ratio_median"], reverse=True)[:30]],
        "languages": rows,
    }
    prefix.parent.mkdir(parents=True, exist_ok=True)
    prefix.with_suffix(".json").write_text(json.dumps(analysis, indent=2) + "\n")
    lines = ["# Current-runtime E-A route census diagnostic", "", "This compares the frozen current runtime's compact and legacy routes. The M1 graduation baseline is unauthenticated. No graduation pass is asserted.", "", f"Expected languages: 206; complete: {len(complete_rows)}; failed: {len(failed)}; incomplete: {len(incomplete)}.", f"Fleet numbers are {'PARTIAL and cannot qualify E-A' if partial else 'complete for this current-runtime diagnostic only'}.", ""]
    for key in ("fleet_median_of_paired_ratio_medians", "fleet_worst_paired_ratio_median", "fleet_median_of_ratios_of_medians", "fleet_worst_ratio_of_medians"):
        lines.append(f"- {key}: {analysis[key]}")
    if provenance_errors:
        lines += ["", "Provenance failures: " + "; ".join(provenance_errors)]
    lines += ["", "| Language | Status | Pairs | Paired ratio median | Ratio of medians | Compact routes/op | Fallbacks/op |", "|---|---|---:|---:|---:|---:|---:|"]
    for row in sorted(rows, key=lambda r: (r["status"] != "complete", -(r["paired_ratio_median"] or 0), r["language"])):
        def fmt(value):
            return "—" if value is None else f"{value:.6f}"
        lines.append(f"| {row['language']} | {row['status']} | {row['complete_pair_count']} | {fmt(row['paired_ratio_median'])} | {fmt(row['ratio_of_time_medians'])} | {fmt(row['compact_routes_per_op_median'])} | {fmt(row['compact_fallbacks_per_op_median'])} |")
    prefix.with_suffix(".md").write_text("\n".join(lines) + "\n")
    print(json.dumps({k: analysis[k] for k in ("complete_language_count", "failed_language_count", "incomplete_language_count", "fleet_median_of_paired_ratio_medians", "fleet_worst_paired_ratio_median", "provenance_errors")}, indent=2))


if __name__ == "__main__":
    main()
