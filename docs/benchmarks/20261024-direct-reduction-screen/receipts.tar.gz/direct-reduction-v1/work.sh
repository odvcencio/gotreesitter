set -euo pipefail
mkdir -p /evidence/work
for role in baseline candidate; do
 cd "/$role"
 go test -c -overlay=/controls/work-overlay.json -tags gts_parsercorephase0,gts_workcount -o "/evidence/work/$role.test" . > "/evidence/work/$role-build.log" 2>&1
done
while IFS= read -r lang; do
 for role in baseline candidate; do
  cd "/$role"
  GTS_WORK_LANGUAGE="$lang" "/evidence/work/$role.test" -test.run '^TestDirectReductionWork$' -test.count=1 -test.timeout=5m > "/evidence/work/$role-$lang.log" 2>&1
 done
done < /controls/languages.txt
python3 /controls/compare-work.py
