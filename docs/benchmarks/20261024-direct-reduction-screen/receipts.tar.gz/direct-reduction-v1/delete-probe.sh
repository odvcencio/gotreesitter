set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
mkdir -p /evidence/delete-probe
cd /candidate/cgo_harness
GOFLAGS='-p=1 -mod=readonly -overlay=/controls/delete-probe-overlay.json' go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/delete-probe/probe.test . > /evidence/delete-probe/build.log 2>&1
set +e
/evidence/delete-probe/probe.test -test.run '^TestDirectReductionGoDeleteReductionProbe$' -test.count=1 -test.v -test.timeout=2m > /evidence/delete-probe/probe.log 2>&1
result=$?
printf '%s\n' "$result" > /evidence/delete-probe/parity-exit.txt
exit 0
