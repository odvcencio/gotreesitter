set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -overlay=/controls/source-overlay.json'
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
python3 /controls/source_hashes.py > /evidence/source-before-resume.json
cmp /evidence/source-before.json /evidence/source-before-resume.json
cd /candidate
for role in baseline candidate; do
 cd "/$role"
 go build -tags gts_parsercorephase0 -o "/evidence/$role-ledger" ./cmd/perfcounterledger > "/evidence/$role-ledger-build.log" 2>&1
done
cd /candidate
mkdir -p /evidence/ledger /evidence/counter-deltas
while IFS= read -r lang; do
 /evidence/baseline-ledger --langs "$lang" > "/evidence/ledger/baseline-$lang.json" 2> "/evidence/ledger/baseline-$lang.log"
 /evidence/candidate-ledger --langs "$lang" > "/evidence/ledger/candidate-$lang.json" 2> "/evidence/ledger/candidate-$lang.log"
 python3 /controls/compare-ledger.py "/evidence/ledger/baseline-$lang.json" "/evidence/ledger/candidate-$lang.json" "/evidence/counter-deltas/$lang.json" > "/evidence/counter-deltas/$lang.log"
 printf 'ledger\t%s\n' "$lang" >> /evidence/progress.tsv
done < /controls/languages.txt
printf 'correctness-and-ledger-complete\n' > /evidence/correctness-complete.txt
export CGO_ENABLED=0
bash /controls/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-yaml.txt --output /evidence/candidate-yaml.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 240001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputYAML$' --require-benchmarks 'BenchmarkCompactThroughputYAML/r4_legacy,BenchmarkCompactThroughputYAML/eof8k_legacy,BenchmarkCompactThroughputYAML/r4_ordinary,BenchmarkCompactThroughputYAML/eof8k_ordinary,BenchmarkCompactThroughputYAML/r4_owned,BenchmarkCompactThroughputYAML/eof8k_owned' > /evidence/yaml-driver.log 2>&1
cp /controls/benchmark_primary_overlay.go.txt /evidence/prepare-primary.go
go run /evidence/prepare-primary.go /controls/benchmark_primary_go_suite.go.txt /evidence/primary-overlay.json /baseline /candidate > /evidence/primary-hashes.txt
python3 - <<'PRIMARY'
from pathlib import Path
import json
p=Path('/evidence/primary-overlay.json');d=json.loads(p.read_text());d['Replace'].update(json.loads(Path('/controls/source-overlay.json').read_text())['Replace']);p.write_text(json.dumps(d,indent=2)+'\n');p.chmod(0o644)
for value in d['Replace'].values():
 f=Path(value)
 if str(f).startswith('/evidence/'):f.chmod(0o644)
PRIMARY
GOFLAGS='-p=1 -mod=readonly -overlay=/evidence/primary-overlay.json' bash /controls/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-go.txt --output /evidence/candidate-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 241001 --benchtime 750ms --bench-regex '^BenchmarkGTSSeededPrimary$' --require-benchmarks 'BenchmarkGTSSeededPrimary/BenchmarkGoParseFullDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalNoEditDFA' > /evidence/go-driver.log 2>&1
GOFLAGS='-p=1 -mod=readonly -overlay=/controls/benchmark-overlay.json' GTS_ADMISSION_CANDIDATE=1 bash /controls/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-compact-go.txt --output /evidence/candidate-compact-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 242001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputGo$' --require-benchmarks 'BenchmarkCompactThroughputGo/full_dfa,BenchmarkCompactThroughputGo/single_byte_edit_dfa,BenchmarkCompactThroughputGo/no_edit_dfa,BenchmarkCompactThroughputGo/fresh_one_mib,BenchmarkCompactThroughputGo/query_compile,BenchmarkCompactThroughputGo/grammargen_lr' > /evidence/compact-go-driver.log 2>&1

python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'complete\n' > /evidence/complete.txt
