set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -overlay=/controls/comparison-overlay.json'
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build CGO_ENABLED=1
cd /candidate/cgo_harness
for lang in go yaml; do
 seed=243001; if [[ "$lang" == yaml ]]; then seed=244001; fi
 GTS_COMPARE_LANGUAGE="$lang" bash /controls/run_randomized_benchmarks.sh --tags treesitter_c_parity,gts_parsercorephase0 --bench-regex '^BenchmarkDirectReductionVsC$' --runs 20 --seed-start "$seed" --benchtime 750ms --output "/evidence/C-$lang.txt" --lock-path /evidence/C.lock > "/evidence/C-$lang-driver.log" 2>&1
done

cd /candidate
GTS_BENCHMARK_SEED=245001 GTS_ADMISSION_CANDIDATE=1 /evidence/candidate.test -test.run '^$' -test.bench '^BenchmarkCompactThroughputGo$/^(full_dfa|grammargen_lr)$' -test.benchtime=5s -test.count=1 -test.cpuprofile=/evidence/go-cpu.pprof -test.timeout=5m > /evidence/go-profile.log 2>&1
GTS_BENCHMARK_SEED=245002 /evidence/candidate.test -test.run '^$' -test.bench '^BenchmarkCompactThroughputYAML$/^eof8k_ordinary$' -test.benchtime=5s -test.count=1 -test.cpuprofile=/evidence/yaml-cpu.pprof -test.timeout=5m > /evidence/yaml-profile.log 2>&1
go tool pprof -top -nodecount=45 /evidence/candidate.test /evidence/go-cpu.pprof > /evidence/go-cpu-top.txt
go tool pprof -top -nodecount=45 /evidence/candidate.test /evidence/yaml-cpu.pprof > /evidence/yaml-cpu-top.txt

go tool pprof -traces /evidence/candidate.test /evidence/go-cpu.pprof > /evidence/go-cpu-traces.txt
go tool pprof -traces /evidence/candidate.test /evidence/yaml-cpu.pprof > /evidence/yaml-cpu-traces.txt
