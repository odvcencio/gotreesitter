#!/usr/bin/env bash
set -euo pipefail
if [[ ! -f /evidence/work/complete.txt ]]; then bash /controls/work.sh > /evidence/work-driver.log 2>&1; fi
exec bash /controls/run_randomized_benchmarks_original.sh "$@"
