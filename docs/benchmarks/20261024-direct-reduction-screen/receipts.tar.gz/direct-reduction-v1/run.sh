set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -overlay=/controls/source-overlay.json'
git config --global --add safe.directory /candidate
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
python3 /controls/source_hashes.py > /evidence/source-before.json
python3 - <<'PIN'
from pathlib import Path
import json
actual=json.loads(Path('/evidence/source-before.json').read_text());expected=json.loads(Path('/controls/expected-source.json').read_text());assert actual==expected
PIN
printf 'baseline 6fe1f7c1a05af777223024d96d960007f8bd7fd3; candidate direct deterministic reduction kernel\n' > /evidence/revision.txt
for role in baseline candidate; do
 cd "/$role"
 go test -tags gts_parsercorephase0 ./internal/parsercorephase0 -count=1 -timeout=6m > "/evidence/$role-core-unit.log" 2>&1
 go test -tags gts_parsercorephase0,gts_parsercorephase0a,gts_eof_recovery_shadow ./internal/parsercorephase0 -count=1 -timeout=6m > "/evidence/$role-core-shadow.log" 2>&1
done
cd /candidate
go test -race -tags gts_parsercorephase0 ./internal/parsercorephase0 -count=1 -timeout=6m > /evidence/core-race.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test -tags gts_parsercorephase0 ./internal/parsercorephase0 -count=1 -timeout=6m > /evidence/core-386.log 2>&1
go test ./internal/incr -count=1 -timeout=3m > /evidence/incr-unit.log 2>&1
go test -race ./internal/incr -count=1 -timeout=3m > /evidence/incr-race.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/incr -count=1 -timeout=3m > /evidence/incr-386.log 2>&1
python3 /controls/source_patch.py > /evidence/source.patch
go version > /evidence/go-version.txt
go test -c -tags gts_parsercorephase0 -o /evidence/candidate.test . > /evidence/root-build.log 2>&1
/evidence/candidate.test -test.run '^Test(DirectReduction.*|QuiescentNative.*|NativeProjection.*|CompactReuseDependency.*|CompactLegacyRead.*|CompactLegacyProjection.*)$' -test.count=1 -test.v -test.timeout=5m > /evidence/root-unit.log 2>&1
go test -race -tags gts_parsercorephase0 -run '^Test(DirectReduction.*|QuiescentNative.*|NativeProjection.*|CompactReuseDependency.*|CompactLegacyRead.*|CompactLegacyProjection.*)$' -count=1 -timeout=8m . > /evidence/root-race.log 2>&1
/evidence/candidate.test -test.run '^Test(CompactAcceptance(ChangedSourceKeepsRebuildBudget|CachedPublicationStopControl)|CompactMemoryBudgetDetectsGrowthAfterSmallPoll|CompactAcceptance.*(MemoryBudget|RetentionBound)|CompactArenaReserve.*(Budget|RetentionCap)|CompactExternalScannerCheckpointCopyMemoryBudget|CompactRecoveryMemoMemoryBudget|CompactBorrowedMaterializationProjectionMemoryBudget|G18RefSetSchedulerMemoryBudgetAccounting|RuntimeMemoryBudget.*|RuntimeMemoryHardCeilingStillStopsParse|ParseMemoryHardCeiling.*)$' -test.count=1 -test.v -test.timeout=8m > /evidence/memory.log 2>&1
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/candidate-cgo.test . > /evidence/cgo-build.log 2>&1
mkdir -p /evidence/invariants /evidence/cgo
cd /candidate
bash /controls/work.sh > /evidence/work-driver.log 2>&1
while IFS= read -r lang; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /evidence/candidate.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/invariants/$route-$lang.log" 2>&1
  printf 'invariant\t%s\t%s\n' "$lang" "$route" >> /evidence/progress.tsv
 done
done < /controls/languages.txt
cd /candidate/cgo_harness
while IFS= read -r lang; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GTS_PARITY_MODE=exhaustive /evidence/candidate-cgo.test -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${lang}$" -test.count=1 -test.v -test.timeout=5m > "/evidence/cgo/$route-$lang.log" 2>&1
  printf 'C\t%s\t%s\n' "$lang" "$route" >> /evidence/progress.tsv
 done
done < /controls/languages.txt
cd /candidate/cgo_harness
GTS_YAML_LARGE_PROBE=1 /evidence/candidate-cgo.test -test.run '^Test(YAMLOwnedGrammarLockedCParity|CompactYAMLDocumentStreamLockedC|YAMLRecoveredMappingQuotesLockedC|YAMLEOFRecoverWrapCompactRoute|YAMLEOFRecoverWrapUnfinishedMappingDeclinesCompact|YAMLOneBytePrintableEOFAdmissionMatchesLockedC)$' -test.count=1 -test.v -test.timeout=8m > /evidence/yaml-owned-cgo.log 2>&1
cd /candidate
cd /candidate/cgo_harness
mkdir /evidence/cogno
go test -c -overlay=/controls/cogno-overlay.json -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/cogno/probe.test . > /evidence/cogno/build.log 2>&1
for route in production candidate; do
 for api in plain profiled; do
  for edit in insert replace delete; do
   label="$route-$api-$edit"
   if /evidence/cogno/probe.test -test.run "^TestGoCognociente137KiBTopEditLockedC$/^$route$/^$api$/^$edit$" -test.v -test.count=1 -test.timeout=5m > "/evidence/cogno/$label.log" 2>&1; then code=0; else code=$?; fi
   printf '%s\t%s\n' "$label" "$code" >> /evidence/cogno/status.tsv
   if [[ "$edit" != delete && "$code" != 0 ]]; then exit "$code"; fi
  done
 done
done
python3 - <<'COGNO'
from pathlib import Path
p=Path('/evidence/cogno');rows=(p/'status.tsv').read_text().splitlines();assert len(rows)==12
for row in rows:
 name,code=row.split('\t');text=(p/(name+'.log')).read_text();assert 'D8 incremental/fresh Go and incremental/fresh C agree independently:' in text
 if name.endswith('-delete'):
  assert code=='1' and 'Path:/source_file/function_declaration[2]/block[4]/ERROR[1] Category:shape GoValue:children=1 CValue:children=2' in text
 else:assert code=='0' and 'independent fresh Go versus fresh C: exact symbols, fields, spans, points, flags' in text
COGNO
cd /candidate
for role in baseline candidate; do
 cd "/$role/cgo_harness"
 go test -c -overlay=/controls/cgo-overlay.json -tags treesitter_c_parity,gts_parsercorephase0 -o "/evidence/$role-large-cgo.test" . > "/evidence/$role-large-cgo-build.log" 2>&1
 "/evidence/$role-large-cgo.test" -test.run '^TestWarmCapacityLargeGoLockedC$' -test.v -test.count=1 -test.timeout=5m > "/evidence/$role-large-go-C.log" 2>&1
done
cd /candidate
for role in baseline candidate; do
 cd "/$role"
 go build -tags gts_parsercorephase0 -o "/evidence/$role-ledger" ./cmd/perfcounterledger > "/evidence/$role-ledger-build.log" 2>&1
done
cd /candidate
mkdir -p /evidence/ledger /evidence/counter-deltas
while IFS= read -r lang; do
 /evidence/baseline-ledger --langs "$lang" > "/evidence/ledger/baseline-$lang.json" 2> "/evidence/ledger/baseline-$lang.log"
 /evidence/candidate-ledger --langs "$lang" > "/evidence/ledger/candidate-$lang.json" 2> "/evidence/ledger/candidate-$lang.log"
 python3 /controls/compare-ledger.py "/evidence/ledger/baseline-$lang.json" "/evidence/ledger/candidate-$lang.json" "/evidence/counter-deltas/$lang.json" > "/evidence/counter-deltas/$lang.log"
 printf 'ledger\t%s\n' "$lang" >> /evidence/progress.tsv
done < /controls/languages.txt
printf 'correctness-and-ledger-complete\n' > /evidence/correctness-complete.txt
export CGO_ENABLED=0
bash /controls/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-yaml.txt --output /evidence/candidate-yaml.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 240001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputYAML$' --require-benchmarks 'BenchmarkCompactThroughputYAML/r4_legacy,BenchmarkCompactThroughputYAML/eof8k_legacy,BenchmarkCompactThroughputYAML/r4_ordinary,BenchmarkCompactThroughputYAML/eof8k_ordinary,BenchmarkCompactThroughputYAML/r4_owned,BenchmarkCompactThroughputYAML/eof8k_owned' > /evidence/yaml-driver.log 2>&1
cp /controls/benchmark_primary_overlay.go.txt /evidence/prepare-primary.go
go run /evidence/prepare-primary.go /controls/benchmark_primary_go_suite.go.txt /evidence/primary-overlay.json /baseline /candidate > /evidence/primary-hashes.txt
python3 - <<'PRIMARY'
from pathlib import Path
import json
p=Path('/evidence/primary-overlay.json');d=json.loads(p.read_text());d['Replace'].update(json.loads(Path('/controls/source-overlay.json').read_text())['Replace']);p.write_text(json.dumps(d,indent=2)+'\n');p.chmod(0o644)
for value in d['Replace'].values():
 f=Path(value)
 if str(f).startswith('/evidence/'):f.chmod(0o644)
PRIMARY
GOFLAGS='-p=1 -mod=readonly -overlay=/evidence/primary-overlay.json' bash /controls/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-go.txt --output /evidence/candidate-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 241001 --benchtime 750ms --bench-regex '^BenchmarkGTSSeededPrimary$' --require-benchmarks 'BenchmarkGTSSeededPrimary/BenchmarkGoParseFullDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalNoEditDFA' > /evidence/go-driver.log 2>&1
GOFLAGS='-p=1 -mod=readonly -overlay=/controls/benchmark-overlay.json' GTS_ADMISSION_CANDIDATE=1 bash /controls/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-compact-go.txt --output /evidence/candidate-compact-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 242001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputGo$' --require-benchmarks 'BenchmarkCompactThroughputGo/full_dfa,BenchmarkCompactThroughputGo/single_byte_edit_dfa,BenchmarkCompactThroughputGo/no_edit_dfa,BenchmarkCompactThroughputGo/fresh_one_mib,BenchmarkCompactThroughputGo/query_compile,BenchmarkCompactThroughputGo/grammargen_lr' > /evidence/compact-go-driver.log 2>&1

python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'complete\n' > /evidence/complete.txt
