//go:build cgo && treesitter_c_parity && gts_parsercorephase0

package cgoharness

/*
#cgo CFLAGS: -I/go-mod/github.com/tree-sitter/go-tree-sitter@v0.25.0/include -O2 -std=c11
#include <tree_sitter/api.h>
#include <stdlib.h>

static uint64_t direct_native_walk(TSNode node) {
 TSTreeCursor cursor=ts_tree_cursor_new(node);
 uint64_t total=0;
 for (;;) {
  TSNode current=ts_tree_cursor_current_node(&cursor);
  total+=(uint64_t)ts_node_start_byte(current)+ts_node_end_byte(current)+ts_node_child_count(current);
  if (ts_tree_cursor_goto_first_child(&cursor)) continue;
  while (!ts_tree_cursor_goto_next_sibling(&cursor)) {
   if (!ts_tree_cursor_goto_parent(&cursor)) {ts_tree_cursor_delete(&cursor);return total;}
  }
 }
}
static int direct_native_run(TSParser *parser, const char *source, uint32_t length, uint64_t count, int consume, uint64_t expected) {
 for (uint64_t i=0;i<count;i++) {
  TSTree *tree=ts_parser_parse_string(parser,NULL,source,length);
  if (!tree) return 1;
  TSNode root=ts_tree_root_node(tree);
  if (ts_node_is_null(root)||ts_node_start_byte(root)!=0||ts_node_end_byte(root)!=length||ts_node_has_error(root)) {ts_tree_delete(tree);return 2;}
  if (consume && direct_native_walk(root)!=expected) {ts_tree_delete(tree);return 3;}
  ts_tree_delete(tree);
 }
 return 0;
}
*/
import "C"
import (
	"fmt"
	sitter "github.com/tree-sitter/go-tree-sitter"
	"unsafe"
)

type directNativeC struct {
	parser *C.TSParser
	source unsafe.Pointer
	length C.uint32_t
}

func newDirectNativeC(lang *sitter.Language, source []byte) (*directNativeC, error) {
	p := C.ts_parser_new()
	if p == nil {
		return nil, fmt.Errorf("native C parser allocation")
	}
	if !bool(C.ts_parser_set_language(p, (*C.TSLanguage)(unsafe.Pointer(lang.Inner)))) {
		C.ts_parser_delete(p)
		return nil, fmt.Errorf("native C language mismatch")
	}
	return &directNativeC{p, C.CBytes(source), C.uint32_t(len(source))}, nil
}
func (p *directNativeC) close() { C.ts_parser_delete(p.parser); C.free(p.source) }
func (p *directNativeC) run(n int, consume bool, want uint64) error {
	c := C.int(0)
	if consume {
		c = 1
	}
	code := C.direct_native_run(p.parser, (*C.char)(p.source), p.length, C.uint64_t(n), c, C.uint64_t(want))
	if code != 0 {
		return fmt.Errorf("native C parse/coverage/checksum failure: %d", int(code))
	}
	return nil
}
