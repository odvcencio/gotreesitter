set -u
date -u +'%Y-%m-%dT%H:%M:%S.%NZ' > /evidence/resume-started.txt
bash /controls/resume-run-v4.sh
result=$?
python3 /controls/source_hashes.py > /evidence/source-after-resume-final.json
if ! cmp /evidence/source-before.json /evidence/source-after-resume-final.json; then result=125; fi
date -u +'%Y-%m-%dT%H:%M:%S.%NZ' > /evidence/resume-finished.txt
printf '%s\n' "$result" > /evidence/resume-exit-code.txt
exit "$result"
