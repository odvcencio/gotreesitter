from pathlib import Path
import collections,gzip,hashlib,io,json,subprocess,tarfile,shutil
repo=Path('/home/draco/work/gotreesitter');run=repo/'harness_out/docker/direct-reduction-v1';p=run/'out-v4'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert (p/'complete.txt').exists() and (p/'resume-exit-code.txt').read_text().strip()=='0'
assert (p/'C-exit.txt').read_text().strip()=='0'
source=json.loads((p/'source-before.json').read_text())
for name in ['source-after-final.json','source-after-resume-final.json','C-source-before.json','C-source-after.json']:assert source==json.loads((p/name).read_text())
counts=dict(collections.Counter(x.split('\t')[0] for x in (p/'progress.tsv').read_text().splitlines()));assert counts=={'invariant':412,'C':412,'ledger':206}
for f in (p/'counter-deltas').glob('*.json'):
 d=json.loads(f.read_text());assert d['passed'] and not d['changes'] and not d['route_metadata_changes']
for name in ['invariants','cgo']:
 logs=list((p/name).glob('*.log'));assert len(logs)==412
 for f in logs:assert '--- FAIL:' not in f.read_text() and '--- SKIP:' not in f.read_text() and f.read_text().rstrip().endswith('PASS')
work=json.loads((p/'work/comparison.json').read_text());assert work=={'rows':824,'changes':[],'adverse':[]}
perf=json.loads((p/'independent-analysis.json').read_text());assert perf['valid_rows_per_role']==300 and not perf['ratchet_failures'] and perf['all_timed_work_and_route_metrics_exact']
creport=json.loads((p/'C-analysis.json').read_text());assert all(d['timing_rows']==320 for d in creport['languages'].values())
review=json.loads((run/'source-review.json').read_text());patch=(p/'runtime-source.patch').read_bytes();assert sha(patch)==review['patch_sha256']
for change in review['source_changes']:assert sha((run/'candidate-files'/change['path']).read_bytes())==change['after']==source['candidate'][change['path']]
assert (run/'run_randomized_benchmarks_original.sh').read_bytes()==(repo/'scripts/run_randomized_benchmarks.sh').read_bytes()
for row in (p/'cogno/status.tsv').read_text().splitlines():
 name,code=row.split('\t');s=(p/'cogno'/(name+'.log')).read_text();assert 'D8 incremental/fresh Go and incremental/fresh C agree independently:' in s
 if name.endswith('-delete'):assert code=='1' and 'Path:/source_file/function_declaration[2]/block[4]/ERROR[1] Category:shape GoValue:children=1 CValue:children=2' in s
 else:assert code=='0'
for role in ['baseline','candidate']:assert (p/(role+'-large-go-C.log')).read_text().count('warmed 1 MiB Go: exact symbols, fields, spans, points, flags, and deep digest')==6
for n in ['qualification-resume','comparison-native']:
 d=json.loads((p/(n+'-container-audit.json')).read_text());assert d['state']['ExitCode']==0 and not d['state']['OOMKilled']
entries={}
files=[f for f in run.iterdir() if f.is_file() and f.name!='v4-reference.patch']+list((run/'candidate-files').rglob('*'))+list(p.rglob('*'))
for f in sorted(files):
 if not f.is_file() or f.suffix not in {'.json','.log','.txt','.tsv','.rss','.py','.sh','.go','.patch','.pprof','.sha256'}:continue
 if any(x in f.name for x in ['private','inspect','buckley']):continue
 entries[run.name+'/'+str(f.relative_to(run))]=f.read_bytes()
for overlay in ['source-overlay.json','benchmark-overlay.json','cgo-overlay.json','cogno-overlay.json','comparison-overlay.json','work-overlay.json']:
 for replacement in json.loads((run/overlay).read_text())['Replace'].values():
  if replacement.startswith('/controls/'):assert run.name+'/'+replacement.removeprefix('/controls/') in entries,replacement
manifest={n:{'bytes':len(b),'sha256':sha(b)} for n,b in entries.items()};entries['members.json']=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
out=repo/'docs/benchmarks/20261024-direct-reduction-screen';out.mkdir(exist_ok=True);archive=out/'receipts.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for n,b in sorted(entries.items()):
    i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;tar.addfile(i,io.BytesIO(b))
with tarfile.open(archive) as tar:
 assert len(tar.getmembers())==len(entries)
 for m in tar.getmembers():
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  if m.name!='members.json':assert sha(tar.extractfile(m).read())==manifest[m.name]['sha256']
receipt={'status':'unpromoted experiment; gains too small for requested architectural target','source':review,'fleet':{**counts,'standard_C_checks':1236,'edit_steps':29664,'no_edit_allocations':0,'memory_checks':20,'larger_Go_C_checks':12},'strict_counter_changes':[],'whole_operation_counters':work,'profile_attribution':json.loads((p/'profile-attribution.json').read_text()),'reduced_delete_probe':{'small_witness_bytes':31,'report_prefix_bytes':114,'failed_parity_cases':4,'status':'unresolved; Go emits one error run over := while C emits colon then equal'},'source_overlay_backings_complete':True,'performance':perf,'C_comparison':creport,'Cogno':{'report_comment_id':6311551850,'D8_checks':12,'clean_C_checks':8,'unchanged_malformed_delete_C_failures':4},'limitations':['No new RSS qualification; runtime not promoted.','Linux amd64 Docker only; no ARM64, native Windows or Darwin timing.','Comparison baseline is the stacked branch HEAD, not main.','Native C loop uses the locked static runtime and shared grammar in the cgo binary; not the standalone static publication protocol.','No merge, graduation, allowlist change or counter exception.'],'archive':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':sha(archive.read_bytes())}}
(out/'qualification.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n');(out/'source.patch.gz').write_bytes(gzip.compress(patch,mtime=0))
for suite in ['go','compact-go','yaml']:shutil.copyfile(p/('benchstat-'+suite+'.txt'),out/('benchstat-'+suite+'.txt'))
for name in ['go-cpu-top.txt','yaml-cpu-top.txt','C-analysis.json','profile-attribution.json']:shutil.copyfile(p/name,out/name)
(run/'artifact-verification.json').write_text(json.dumps({'archive_members_verified':len(entries),'all_hashes_match':True,'source_patch_sha256':sha(patch),'archive':receipt['archive']},indent=2)+'\n')
print(json.dumps(receipt['archive']))
