set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly'
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
cd /candidate
go test -tags gts_parsercorephase0 ./internal/parsercorephase0 -count=1 -timeout=6m > /evidence/core-unit.log 2>&1
go test -c -tags gts_parsercorephase0 -o /evidence/candidate.test . > /evidence/root-build.log 2>&1
/evidence/candidate.test -test.run '^Test(QuiescentNative.*|NativeProjection.*|CompactReuseDependency.*|CompactLegacyRead.*|CompactLegacyProjection.*|Compact.*Reduction.*|.*Corridor.*)$' -test.count=1 -test.v -test.timeout=6m > /evidence/root-unit.log 2>&1
