set -euo pipefail
test -f /evidence/complete.txt
date -u +'%Y-%m-%dT%H:%M:%S.%NZ' > /evidence/C-started.txt
python3 /controls/source_hashes.py > /evidence/C-source-before.json
cmp /evidence/source-before.json /evidence/C-source-before.json
sha256sum /controls/comparison.go.txt /controls/comparison-native.go /controls/comparison-overlay.json /controls/comparison.sh > /evidence/C-controls-before.sha256
result=0
bash /controls/comparison.sh || result=$?
python3 /controls/source_hashes.py > /evidence/C-source-after.json
cmp /evidence/C-source-before.json /evidence/C-source-after.json || result=125
sha256sum /controls/comparison.go.txt /controls/comparison-native.go /controls/comparison-overlay.json /controls/comparison.sh > /evidence/C-controls-after.sha256
cmp /evidence/C-controls-before.sha256 /evidence/C-controls-after.sha256 || result=125
printf '%s\n' "$result" > /evidence/C-exit.txt
date -u +'%Y-%m-%dT%H:%M:%S.%NZ' > /evidence/C-finished.txt
exit "$result"
