from pathlib import Path
import collections,json,re
p=Path(__file__).parent/'out-v4'; report={}
for lang in ['go','yaml']:
 samples=[];current=None
 for line in (p/f'{lang}-cpu-traces.txt').read_text().splitlines():
  m=re.match(r'^\s+([\d.]+)(ns|us|ms|s)\s+(.+)$',line)
  if m:
   if current:samples.append(current)
   current=[float(m[1])*{'s':1,'ms':.001,'us':.000001,'ns':.000000001}[m[2]],[m[3]]]
  elif line.startswith('-------------') or line.startswith('-----------+'):
   if current:samples.append(current);current=None
  elif current and line.startswith('             '):current[1].append(line.strip())
 if current:samples.append(current)
 phases=collections.defaultdict(float);excluded=0;total=0
 for weight,stack in samples:
  total+=weight
  # Exclude language load/setup and benchmarks unrelated to actual parsing.
  if not any('(*Parser).Parse' in f or '(*Parser).parse' in f for f in stack):excluded+=weight;continue
  joined='\n'.join(stack)
  if '(*Core).StreamNativeProjection' in joined or 'publishNativeProjectionReads' in joined or 'nativeStreamSink' in joined:phase='native output projection and reads'
  elif '.elect' in joined:
   phase='token production inside election' if '(*dfaTokenSource).Next' in joined else 'election outside token production'
  elif '.applyGenericReduction' in joined or '.corridorDirectReduction' in joined or '.TryReduceDirectOwned' in joined:phase='reduction construction and publication'
  elif '.applyGenericShifts' in joined or '.corridorDirectShift' in joined:phase='shift construction and publication'
  else:phase='other parse work'
  phases[phase]+=weight
 measured=sum(phases.values())
 report[lang]={'profile_seconds':round(total,6),'parse_seconds':round(measured,6),'excluded_setup_and_other_seconds':round(excluded,6),'disjoint_parse_percent':{k:round(v/measured*100,2) for k,v in sorted(phases.items())}}
(p/'profile-attribution.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
