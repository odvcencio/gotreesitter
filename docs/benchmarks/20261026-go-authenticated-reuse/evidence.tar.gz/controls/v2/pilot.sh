set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly -overlay=/controls/v2/perf.json' GTS_ADMISSION_CANDIDATE=0
sha256sum --quiet -c /controls/source.sha256
sha256sum --quiet -c /controls/controls.sha256
sha256sum --quiet -c /controls/perf/controls.sha256
sha256sum /controls/v2/{language.go,runtime.json,perf.json} > /evidence/v2.sha256
cd /candidate
bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/before.txt --output /evidence/after.txt --runs 4 --seed-start 21 --benchtime 750ms --bench-regex '^BenchmarkGTSAuthenticatedReuse$' --require-benchmarks 'BenchmarkGTSAuthenticatedReuse/BenchmarkGoParseFullDFA,BenchmarkGTSAuthenticatedReuse/BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGTSAuthenticatedReuse/BenchmarkGoParseIncrementalNoEditDFA,BenchmarkGTSAuthenticatedReuse/Report137KiBFull,BenchmarkGTSAuthenticatedReuse/Report137KiBEdit,BenchmarkGTSAuthenticatedReuse/Report137KiBEditProfiled' --lock-path /runtime/tmp/gotreesitter-go-authenticated-reuse-v2-pilot.lock > /evidence/randomized.log 2>&1
sha256sum --quiet -c /controls/source.sha256
sha256sum --quiet -c /controls/controls.sha256
sha256sum --quiet -c /controls/perf/controls.sha256
sha256sum --quiet -c /evidence/v2.sha256
