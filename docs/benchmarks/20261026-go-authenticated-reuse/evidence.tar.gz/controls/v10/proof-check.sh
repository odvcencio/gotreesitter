set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly' GTS_ADMISSION_CANDIDATE=0
sha256sum --quiet -c /controls/source.sha256
sha256sum --quiet -c /controls/controls.sha256
sha256sum /controls/v9/token_invariant_lexical_proof.go /controls/v10/{probe_into_private_test.go,runtime.json,tests.json,perf.json} > /evidence/v10.sha256
cd /candidate
go test -overlay=/controls/v10/tests.json -tags gts_parsercorephase0 -run '^Test(PrimitiveProbeIntoContract|TokenInvariantPrimitive|TokenInvariantWhitespace|TokenInvariantKeyword|PrimitiveProof|TokenInvariantLookahead|TokenInvariant.*(Go|Python|TypeScript)|ForestTreeIncrementalEdit(CSS|SCSS)|YAMLIncrementalEditScalar)' -count=1 -v -timeout=8m . > /evidence/proof-tests.log 2>&1
for arm in baseline candidate; do
 cd "/$arm"
 extra=(); if [[ "$arm" == candidate ]]; then extra=(-overlay=/controls/v10/runtime.json); fi
 go build "${extra[@]}" -tags gts_parsercorephase0,gts_workcount -o "/runtime/tmp/gts-v10-$arm-work" /prior-controls/recovery-work-main.go
 for assignment in 0 1; do GTS_PROBE_ASSIGNMENT=$assignment "/runtime/tmp/gts-v10-$arm-work" > "/evidence/$arm-work-$assignment.log" 2>&1; done
done
sha256sum --quiet -c /controls/source.sha256
sha256sum --quiet -c /controls/controls.sha256
sha256sum --quiet -c /evidence/v10.sha256
