#!/usr/bin/env python3
"""Freeze candidate overlay mappings and hash their source inputs for the gate."""
import hashlib
import json
from pathlib import Path
import sys

root = Path('/controls')
tests, c027, out = map(Path, sys.argv[1:4])
base = json.loads(tests.read_text())['Replace']
extras = json.loads((root / 'extended/overlay.tests.json').read_text())['Replace']
for key in ('/candidate/authenticated_lifecycle_private_test.go', '/candidate/authenticated_lifecycle_external_test.go'):
    base[key] = extras[key]
authority = json.loads((root / 'review-v3/overlay.tests.json').read_text())['Replace']
for key in ('/candidate/language_copy_private_test.go', '/candidate/language_copy_external_private_test.go'):
    base[key] = authority[key]
combined = json.loads(c027.read_text())['Replace']
combined.update(base)
out.mkdir(parents=True, exist_ok=False)
for name, mapping in [('tests.json', base), ('c027.json', combined)]:
    (out/name).write_text(json.dumps({'Replace': mapping}, indent=2) + '\n')
paths = sorted(set(base.values()) | set(combined.values()))
records = []
for name in paths:
    p = Path(name)
    if not p.is_file():
        raise SystemExit(f'missing overlay input: {name}')
    records.append(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {name}')
(out/'inputs.sha256').write_text('\n'.join(records)+'\n')
