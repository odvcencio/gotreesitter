#!/usr/bin/env bash
set -euo pipefail
q=/home/draco/work/gotreesitter/harness_out/docker/go-authenticated-reuse-20261026
prior=/home/draco/work/gotreesitter/harness_out/docker/go-reuse-20261025
dep=/home/draco/.local/state/gotreesitter-evidence/20261021-runtime-rss-architecture/compact-link-storage-v1/main-cgo-v1/dependencies
stage=${1:?stage}; shift
case "$stage" in setup) runner=setup.sh;; race|oracle) runner=race-oracle.sh;; focused|fleet) runner=run.sh;; *) exit 2;; esac
flock /tmp/gotreesitter-compact-storage-docker.lock docker run --rm --network none --memory 4g --memory-swap 4g --cpus 1 --cpuset-cpus 6 --pids-limit 512 \
 -e GOMAXPROCS=1 -e GOMEMLIMIT=3GiB -e GOPROXY=off -e GOMODCACHE=/go-mod -e CGO_ENABLED=1 \
 -e GTS_FINAL_OVERLAY=/evidence/frozen-v2/tests.json -e GTS_FINAL_C027_OVERLAY=/evidence/frozen-v2/c027.json -e GTS_FINAL_INPUTS=/evidence/frozen-v2/inputs.sha256 -e GTS_FINAL_OUT=/evidence \
 -v /home/draco/work/gotreesitter:/candidate:ro -v /home/draco/work/gotreesitter:/baseline:ro -v "$q:/controls:ro" -v "$q/final-correctness/out:/evidence" -v /home/draco/work/.runtime:/runtime \
 -v "$dep/go-mod:/go-mod:ro" -v "$dep/c-cache:/c-cache:ro" -v "$dep/go-mod/github.com/tree-sitter/go-tree-sitter@v0.25.0:/oracle-binding:ro" \
 -v "$prior/oracle0271:/controls/oracle0271:ro" -v "$prior/oracle0271-module-bind-v3:/controls/oracle0271-module-bind-v3:ro" -v "$prior/oracle0271-go-pins-v4:/controls/oracle0271-go-pins-v4:ro" \
 golang@sha256:116d58cbd88c1297624acc6e967a060012422bacf9930927e23fb719189c6f36 \
 timeout --foreground --kill-after=10s 32m bash "/controls/final-correctness/$runner" "$stage" "$@"
