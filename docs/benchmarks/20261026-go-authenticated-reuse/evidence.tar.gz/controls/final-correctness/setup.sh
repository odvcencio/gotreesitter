#!/usr/bin/env bash
set -euo pipefail
python3 /controls/final-correctness/freeze.py /controls/v11/tests.json /controls/extended/overlay.c027.json /evidence/frozen-v2
bash /controls/final-correctness/run.sh build
