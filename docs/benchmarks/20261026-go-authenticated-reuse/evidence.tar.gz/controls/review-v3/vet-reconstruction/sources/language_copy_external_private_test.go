//go:build gts_parsercorephase0 || gts_workcount || gts_diag

package gotreesitter_test

import (
	"testing"

	gts "github.com/odvcencio/gotreesitter"
	"github.com/odvcencio/gotreesitter/grammars"
)

func TestLanguageCopyDoesNotAuthenticate(t *testing.T) {
	gts.RunLanguageCopyDoesNotAuthenticate(t, grammars.GoLanguage())
}
