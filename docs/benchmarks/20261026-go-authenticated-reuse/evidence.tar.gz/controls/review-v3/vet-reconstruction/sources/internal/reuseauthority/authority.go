// Package reuseauthority binds a certified runtime profile to its language instance.
package reuseauthority

// Grant is created only by the internal certified profile loader. The owner
// reference does not keep a language alive beyond its own lifecycle.
type Grant struct{ owner any }

func New(owner any) *Grant {
	return &Grant{owner: owner}
}

func (g *Grant) Matches(owner any) bool { return g != nil && g.owner == owner }
