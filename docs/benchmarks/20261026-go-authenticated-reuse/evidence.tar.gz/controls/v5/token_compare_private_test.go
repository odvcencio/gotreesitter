package gotreesitter

import (
	"reflect"
	"testing"
)

func TestPrimitiveTokenComparisonFieldCoverage(t *testing.T) {
	if n := reflect.TypeOf(Token{}).NumField(); n != 14 {
		t.Fatalf("Token has %d fields; update comparison coverage", n)
	}
	cases := []struct {
		name   string
		change func(*Token)
		equal  bool
	}{
		{"text", func(t *Token) { t.Text = "x" }, true},
		{"start", func(t *Token) { t.StartByte = 1 }, false},
		{"end", func(t *Token) { t.EndByte = 1 }, false},
		{"start point", func(t *Token) { t.StartPoint.Row = 1 }, false},
		{"end point", func(t *Token) { t.EndPoint.Column = 1 }, false},
		{"lookahead", func(t *Token) { t.lexerLookaheadEndByte = 1 }, true},
		{"missing reference", func(t *Token) { t.missingStackRef = 1 }, false},
		{"scanner start", func(t *Token) { t.ExternalScannerStartByte = 1 }, false},
		{"skipped prefix", func(t *Token) { t.lexerSkippedPrefixStart = 1 }, false},
		{"symbol", func(t *Token) { t.Symbol = 1 }, false},
		{"missing", func(t *Token) { t.Missing = true }, false},
		{"no lookahead", func(t *Token) { t.NoLookahead = true }, false},
		{"external", func(t *Token) { t.ExternalScannerToken = true }, false},
		{"flags", func(t *Token) { t.lexFlags = 1 }, false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			var a, b Token
			tc.change(&b)
			if got := tokenInvariantPrimitiveTokensEqual(a, b); got != tc.equal {
				t.Fatalf("got %t want %t", got, tc.equal)
			}
		})
	}
}
