set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
sha256sum --quiet -c /controls/source.sha256
sha256sum --quiet -c /controls/controls.sha256
sha256sum --quiet -c /controls/v11/inputs.sha256
scratch=/runtime/tmp/gts-authenticated-reuse-v11-counters
mkdir -p "$scratch"
for arm in baseline candidate; do
 cd "/$arm"
 extra=(); if [[ "$arm" == candidate ]]; then extra=(-overlay=/controls/v11/runtime.json); fi
 go build "${extra[@]}" -tags gts_parsercorephase0 -o "$scratch/$arm-ledger" ./cmd/perfcounterledger
 for lang in go yaml; do
  for route in default candidate; do
   mode=0; if [[ "$route" == candidate ]]; then mode=1; fi
   GTS_ADMISSION_CANDIDATE=$mode "$scratch/$arm-ledger" --child-route "$route" --langs "$lang" > "/evidence/$arm-$lang-$route.json" 2> "/evidence/$arm-$lang-$route.stderr"
  done
 done
 go build "${extra[@]}" -tags gts_parsercorephase0,gts_workcount -o "$scratch/$arm-work" /prior-controls/recovery-work-main.go
 for assignment in 0 1; do GTS_PROBE_ASSIGNMENT=$assignment "$scratch/$arm-work" > "/evidence/$arm-work-$assignment.log" 2>&1; done
done
python3 /controls/v11/summarize-counters.py
sha256sum "$scratch/"* > /evidence/binary.sha256
sha256sum --quiet -c /controls/source.sha256
sha256sum --quiet -c /controls/controls.sha256
sha256sum --quiet -c /controls/v11/inputs.sha256
