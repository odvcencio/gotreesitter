set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOMAXPROCS=1
sha256sum --quiet -c /controls/source.sha256
sha256sum --quiet -c /controls/controls.sha256
sha256sum --quiet -c /controls/v11/inputs.sha256
sha256sum --quiet -c /controls/out-v11-counters/binary.sha256
mkdir -p /evidence/records /evidence/diffs
python3 - <<'PY' > /evidence/languages.txt
import json
p='/baseline/internal/benchfixtures/real_corpus.json'
names=sorted({e['language'] for e in json.load(open(p))['entries'] if e['role']=='sample'})
assert len(names)==206
print('\n'.join(names))
PY
scratch=/runtime/tmp/gts-authenticated-reuse-v11-counters
fail=0
while IFS= read -r lang; do
 for route in default candidate; do
  mode=0; if [[ "$route" == candidate ]]; then mode=1; fi
  for arm in baseline candidate; do
   cd "/$arm"
   if ! GTS_ADMISSION_CANDIDATE=$mode timeout --foreground --kill-after=5s 45s "$scratch/$arm-ledger" --child-route "$route" --langs "$lang" > "/evidence/records/$lang-$route-$arm.json" 2> "/evidence/records/$lang-$route-$arm.stderr"; then
    echo "$lang $route $arm FAILED"; fail=1
   fi
  done
  if ! cmp -s "/evidence/records/$lang-$route-baseline.json" "/evidence/records/$lang-$route-candidate.json"; then
   diff -u "/evidence/records/$lang-$route-baseline.json" "/evidence/records/$lang-$route-candidate.json" > "/evidence/diffs/$lang-$route.diff" || true
   echo "$lang $route DIFF"; fail=1
  fi
 done
 echo "$lang complete"
done < /evidence/languages.txt
sha256sum --quiet -c /controls/source.sha256
sha256sum --quiet -c /controls/controls.sha256
sha256sum --quiet -c /controls/v11/inputs.sha256
sha256sum --quiet -c /controls/out-v11-counters/binary.sha256
if ((fail)); then exit 1; fi
python3 - <<'PY'
import json
from pathlib import Path
Path('/evidence/summary.json').write_text(json.dumps({'languages':206,'routes_per_language':2,'baseline_candidate_ledgers_byte_identical':True,'separate_process_per_language_route_arm':True},indent=2)+'\n')
PY
