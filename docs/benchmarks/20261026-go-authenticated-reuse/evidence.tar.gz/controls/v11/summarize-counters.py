import json
from pathlib import Path
q=Path('/controls'); p=Path('/evidence')
for lang in ('go','yaml'):
 for route in ('default','candidate'):
  assert (p/f'baseline-{lang}-{route}.json').read_bytes()==(p/f'candidate-{lang}-{route}.json').read_bytes(),(lang,route)

def records(path):
 return [json.loads(line[5:]) for line in path.read_text().splitlines() if line.startswith('WORK ')]
for assignment in (0,1):
 for arm, previous in (('baseline','before'),('candidate','after')):
  now=records(p/f'{arm}-work-{assignment}.log'); old=records(q/f'out-v1/{previous}-work-{assignment}.log')
  assert len(now)==len(old)==12,(arm,assignment,len(now),len(old))
  assert all(a['work']==b['work'] and a['selected']==b['selected'] for a,b in zip(now,old)),(arm,assignment)
summary={'complete_operations_per_arm':24,'work_and_selected_reuse_match_frozen_v1':True,'four_ledger_exports_equal':True,'ratchet_basis':'V1 counter-summary.json; same baseline and candidate work and selected reuse'}
(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
