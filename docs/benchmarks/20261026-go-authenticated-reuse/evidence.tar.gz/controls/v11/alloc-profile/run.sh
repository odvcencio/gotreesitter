set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GTS_ADMISSION_CANDIDATE=0 GTS_BENCHMARK_SEED=1
sha256sum --quiet -c /controls/source.sha256
sha256sum --quiet -c /controls/controls.sha256
sha256sum --quiet -c /controls/v11/inputs.sha256
sha256sum --quiet -c /controls/out-v11-perf/binary.sha256
scratch=/runtime/tmp/gotreesitter-go-authenticated-reuse-v11-perf-20261026
for arm in baseline candidate; do
 cd "/$arm"
 "$scratch/$arm.test" -test.run '^$' -test.bench '^BenchmarkGTSAuthenticatedReuse$/^Report137KiBFull$' -test.count=1 -test.benchtime=10s -test.memprofile="/evidence/$arm.pprof" -test.memprofilerate=1 > "/evidence/$arm.log" 2>&1
 go tool pprof -top -alloc_space -nodecount=25 "$scratch/$arm.test" "/evidence/$arm.pprof" > "/evidence/$arm-alloc-space.txt" 2>&1
 go tool pprof -top -alloc_objects -nodecount=25 "$scratch/$arm.test" "/evidence/$arm.pprof" > "/evidence/$arm-alloc-objects.txt" 2>&1
done
sha256sum --quiet -c /controls/source.sha256
sha256sum --quiet -c /controls/controls.sha256
sha256sum --quiet -c /controls/v11/inputs.sha256
sha256sum --quiet -c /controls/out-v11-perf/binary.sha256
