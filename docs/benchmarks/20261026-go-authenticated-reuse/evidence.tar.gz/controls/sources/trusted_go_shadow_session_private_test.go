//go:build gts_parsercorephase0 || gts_workcount || gts_diag

package gotreesitter

import (
	"bytes"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"testing"
)

func trustedGoSessionPoint(source []byte, offset int) Point {
	var point Point
	for _, b := range source[:offset] {
		if b == '\n' {
			point.Row++
			point.Column = 0
		} else {
			point.Column++
		}
	}
	return point
}

// This is deliberately an absolute comparison to an independent fresh tree,
// including the native internal state plane. No capability-off or historical
// compact-origin comparator substitutes for the native certificate proof.
func trustedGoSessionEqual(t *testing.T, language *Language, got, fresh *Tree) {
	t.Helper()
	if got == nil || fresh == nil || got.rawParseStopReason() != fresh.rawParseStopReason() || !incrementalTreesStructurallyEqual(got, fresh, language) {
		t.Fatal("clean session differs from independent fresh structure/stop")
	}
	type pair struct{ a, b *Node }
	stack := []pair{{got.RootNode(), fresh.RootNode()}}
	for len(stack) != 0 {
		q := stack[len(stack)-1]
		stack = stack[:len(stack)-1]
		if q.a.ParseState() != q.b.ParseState() || q.a.PreGotoState() != q.b.PreGotoState() || q.a.dynamicPrecedence != q.b.dynamicPrecedence {
			t.Fatalf("clean session state/precedence differs at %s[%d..%d]", q.a.Type(language), q.a.StartByte(), q.a.EndByte())
		}
		for i := 0; i < q.a.ChildCount(); i++ {
			stack = append(stack, pair{q.a.Child(i), q.b.Child(i)})
		}
	}
}

type trustedGoSessionRow struct {
	API             string
	Step            int
	Function        int
	Kind            string
	EditByte        int
	BeforeBytes     int
	AfterBytes      int
	BeforeSourceSHA string
	AfterSourceSHA  string
	ProducerKey     uint16
	VerifierEvents  int
	BypassEvents    int
	WouldCertify    int
	NotWouldCertify int
	SharedTopLevel  int
	ReusedSubtrees  uint64
	ReusedBytes     uint64
	FreshVerified   bool
	BypassCertified bool
	NoEditAllocs    float64
}

// Called only from a qualification _test.go bridge. Both APIs use separate
// native old-tree chains with the exact original source, rather than copying a
// native result or quietly promoting a compact producer into this contract.
func RunTrustedGoReuseShadowCleanSession(t *testing.T, language *Language) {
	var builder bytes.Buffer
	builder.WriteString("package main\n\nimport \"fmt\"\n\n")
	functions := 0
	for ; builder.Len() < 137*1024; functions++ {
		fmt.Fprintf(&builder, "func f%d(a int, b int) int {\n\tx := a + b\n\tfmt.Println(\"f%d\", x)\n\treturn x\n}\n\n", functions, functions)
	}
	source := builder.Bytes()
	if len(source) != 140368 || functions != 1760 || fmt.Sprintf("%x", sha256.Sum256(source)) != "5434575bb249338937331c3756e10dcec34237d107f523ea315996fb6de0ef8f" {
		t.Fatal("original session source changed")
	}
	if language.SmallSourceReuseShadowArtifact == ([32]byte{}) {
		t.Fatal("exact Go artifact lacks shadow capability")
	}
	// Spread the edits across the entire original source, including its first
	// and last functions. The four full phases grow/grow/shrink/shrink every
	// identifier. Four final pairs bring the chain to 72 edits and restore the
	// exact original source. Every operation changes the input length by one.
	sites := [...]int{0, 117, 235, 352, 469, 587, 704, 821, 939, 1056, 1173, 1291, 1408, 1525, 1643, 1759}
	type operation struct {
		site int
		grow bool
	}
	operations := make([]operation, 0, 72)
	for phase := 0; phase < 4; phase++ {
		for i := range sites {
			operations = append(operations, operation{site: i, grow: phase < 2})
		}
	}
	for _, grow := range []bool{true, false} {
		for _, i := range []int{0, 5, 10, 15} {
			operations = append(operations, operation{site: i, grow: grow})
		}
	}
	if len(operations) != 72 {
		t.Fatal("session operation count changed")
	}
	for _, api := range []string{"plain", "profiled"} {
		t.Run(api, func(t *testing.T) {
			parser := NewParser(language)
			parser.SetAdmissionCandidateRoute(false)
			old, err := parser.Parse(source)
			if err != nil || old == nil || old.RootNode().HasError() || old.compactMaterialized || old.arena == nil || old.arena.legacyReuseReads.DefaultProducerSchedule(len(source)) == 0 {
				t.Fatalf("session did not obtain an actual default native producer: %v", err)
			}
			defer func() { old.Release() }()
			current := source
			lengths := [len(sites)]int{}
			for i := range lengths {
				lengths[i] = 1
			}
			var row *trustedGoSessionRow
			var currentAfter []byte
			var currentOld *Tree
			var oldTop map[*Node]struct{}
			totalEvents, totalWould, totalShared := 0, 0, 0
			trustedGoReuseShadowObserver.Lock()
			if trustedGoReuseShadowObserver.call != nil {
				trustedGoReuseShadowObserver.Unlock()
				t.Fatal("another test owns the shadow observer")
			}
			trustedGoReuseShadowObserver.call = func(event trustedGoReuseShadowEvent) {
				if event.parser != parser {
					return
				}
				releaseWitness := authenticatedIndependentWitness(t, &event)
				defer releaseWitness()
				if row == nil || event.old != currentOld || !bytes.Equal(event.source, currentAfter) {
					t.Fatal("shadow event is not bound to the actual current edit")
				}
				if event.bypassed {
					row.BypassEvents++
				} else {
					row.VerifierEvents++
				}
				if event.wouldCertify {
					if !event.smallMode || row.ProducerKey == 0 {
						t.Fatal("would-certify lacks actual native producer/small-mode authority")
					}
					row.WouldCertify++
					trustedGoSessionEqual(t, language, event.candidate, event.fresh)
				} else {
					row.NotWouldCertify++
				}
				if event.candidate != nil {
					root := event.candidate.RootNode()
					for i := 0; i < root.ChildCount(); i++ {
						if _, reused := oldTop[root.Child(i)]; reused {
							row.SharedTopLevel++
						}
					}
				}
			}
			trustedGoReuseShadowObserver.Unlock()
			defer func() {
				trustedGoReuseShadowObserver.Lock()
				trustedGoReuseShadowObserver.call = nil
				trustedGoReuseShadowObserver.Unlock()
			}()
			for step, op := range operations {
				prefix := []byte(fmt.Sprintf("func f%d(a int, b int) int {\n\t", sites[op.site]))
				start := bytes.Index(current, prefix)
				if start < 0 {
					t.Fatalf("step%d function missing", step)
				}
				at := start + len(prefix)
				want := append(bytes.Repeat([]byte{'x'}, lengths[op.site]), []byte(" := a + b\n")...)
				if !bytes.HasPrefix(current[at:], want) {
					t.Fatalf("step%d identifier site changed", step)
				}
				oldEnd, newEnd := at, at+1
				kind := "grow"
				var after []byte
				if op.grow {
					after = append(append(append([]byte(nil), current[:at]...), 'x'), current[at:]...)
					lengths[op.site]++
				} else {
					if lengths[op.site] < 2 {
						t.Fatal("shrink would remove whole identifier")
					}
					oldEnd, newEnd, kind = at+1, at, "shrink"
					after = append(append([]byte(nil), current[:at]...), current[at+1:]...)
					lengths[op.site]--
				}
				if len(after) == len(current) || bytes.Equal(after, current) {
					t.Fatal("session used unchanged/same-width input")
				}
				edit := InputEdit{StartByte: uint32(at), OldEndByte: uint32(oldEnd), NewEndByte: uint32(newEnd), StartPoint: trustedGoSessionPoint(current, at), OldEndPoint: trustedGoSessionPoint(current, oldEnd), NewEndPoint: trustedGoSessionPoint(after, newEnd)}
				row = &trustedGoSessionRow{API: api, Step: step, Function: sites[op.site], Kind: kind, EditByte: at, BeforeBytes: len(current), AfterBytes: len(after), BeforeSourceSHA: fmt.Sprintf("%x", sha256.Sum256(current)), AfterSourceSHA: fmt.Sprintf("%x", sha256.Sum256(after))}
				if old.arena != nil {
					row.ProducerKey = old.arena.legacyReuseReads.DefaultProducerSchedule(len(current))
				}
				old.Edit(edit)
				oldTop = make(map[*Node]struct{}, old.RootNode().ChildCount())
				for i := 0; i < old.RootNode().ChildCount(); i++ {
					oldTop[old.RootNode().Child(i)] = struct{}{}
				}
				currentAfter, currentOld = after, old
				var result *Tree
				var parseErr error
				if api == "profiled" {
					var profile IncrementalParseProfile
					result, profile, parseErr = parser.ParseIncrementalProfiled(after, old)
					row.ReusedSubtrees, row.ReusedBytes = profile.ReusedSubtrees, profile.ReusedBytes
				} else {
					result, parseErr = parser.ParseIncremental(after, old)
				}
				old.Release()
				old = result
				if parseErr != nil || result == nil || result.RootNode().HasError() {
					t.Fatalf("step%d parse: %v", step, parseErr)
				}
				row.FreshVerified, row.BypassCertified = result.incrementalFreshVerified(), result.hasCertifiedIncrementalReuse()
				if row.FreshVerified || !row.BypassCertified || row.BypassEvents != 1 || row.VerifierEvents != 0 {
					t.Fatalf("step%d did not use exactly one authenticated bypass without a verifier: %+v", step, *row)
				}
				freshParser := NewParser(language)
				freshParser.SetAdmissionCandidateRoute(false)
				fresh, freshErr := freshParser.Parse(after)
				if freshErr != nil || fresh == nil {
					t.Fatalf("step%d independent fresh: %v", step, freshErr)
				}
				trustedGoSessionEqual(t, language, result, fresh)
				fresh.Release()
				seenBeforeNoEdit := row.VerifierEvents + row.BypassEvents
				row.NoEditAllocs = testing.AllocsPerRun(3, func() {
					var next *Tree
					var e error
					if api == "profiled" {
						next, _, e = parser.ParseIncrementalProfiled(after, result)
					} else {
						next, e = parser.ParseIncremental(after, result)
					}
					if e != nil || next == nil {
						panic("session no-edit failed")
					}
					next.Release()
				})
				if row.NoEditAllocs != 0 || row.VerifierEvents+row.BypassEvents != seenBeforeNoEdit {
					t.Fatalf("step%d no-edit allocations/events=%g/%d", step, row.NoEditAllocs, row.VerifierEvents+row.BypassEvents-seenBeforeNoEdit)
				}
				totalEvents += row.VerifierEvents
				totalWould += row.WouldCertify
				totalShared += row.SharedTopLevel
				if api == "profiled" && (row.ReusedSubtrees == 0 || row.ReusedBytes == 0) {
					t.Fatalf("step%d profiled edit did not actually reuse: %+v", step, *row)
				}
				data, jsonErr := json.Marshal(row)
				if jsonErr != nil {
					t.Fatal(jsonErr)
				}
				t.Logf("TRUSTED_GO_SESSION_STEP %s", data)
				current = after
			}
			if totalWould != 72 || totalEvents != 0 || totalShared == 0 {
				t.Fatalf("session lacks actual activation/reuse: events=%d would=%d shared_top=%d", totalEvents, totalWould, totalShared)
			}
			if !bytes.Equal(current, source) {
				t.Fatal("72-edit chain did not restore original source")
			}
			t.Logf("TRUSTED_GO_SESSION_SUMMARY api=%s steps=72 functions=16 initial_bytes=%d final_bytes=%d final_sha256=%x verifier_events=%d would_certify=%d shared_top_level=%d noedit_allocs=0", api, len(source), len(current), sha256.Sum256(current), totalEvents, totalWould, totalShared)
		})
	}
}
