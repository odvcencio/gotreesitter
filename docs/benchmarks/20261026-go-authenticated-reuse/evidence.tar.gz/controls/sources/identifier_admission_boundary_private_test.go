//go:build gts_parsercorephase0 || gts_workcount || gts_diag

package gotreesitter

import (
	"bytes"
	"fmt"
	"testing"
)

func RunIdentifierAdmissionBoundaryCases(t *testing.T, language *Language) {
	var builder bytes.Buffer
	builder.WriteString("package main\n\nimport \"fmt\"\n\n")
	for i := 0; builder.Len() < 137*1024; i++ {
		fmt.Fprintf(&builder, "func f%d(a int, b int) int {\n\tx := a + b\n\tfmt.Println(\"f%d\", x)\n\treturn x\n}\n\n", i, i)
	}
	source := builder.Bytes()
	if len(source) != 140368 || source[57] != 'x' {
		t.Fatal("original source changed")
	}
	for _, tc := range []struct {
		name, replacement string
		start, removed    int
		small             bool
	}{
		{"identifier-prefix", "y", 57, 0, true},
		{"identifier-replace", "y", 57, 1, true},
		{"identifier-suffix", "y", 58, 0, true},
		{"keyword", "var", 57, 1, false},
		{"remove-token", "", 57, 1, false},
		{"punctuation", ":", 57, 0, false},
		{"newline", "\n", 57, 0, false},
		{"space", " ", 57, 0, false},
		{"unicode", "α", 57, 0, false},
		{"split-token", "x /* retained */ y", 57, 1, false},
		{"literal-text", "m", 23, 0, false},
		{"oversized-identifier", string(bytes.Repeat([]byte{'x'}, 257)), 57, 0, false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			parser := NewParser(language)
			parser.SetAdmissionCandidateRoute(false)
			old, err := parser.Parse(source)
			if err != nil || old == nil {
				t.Fatalf("old: %v", err)
			}
			defer old.Release()
			if old.arena == nil || old.arena.legacyReuseReads.DefaultProducerSchedule(len(source)) == 0 {
				t.Fatal("old producer is not authenticated")
			}
			end := tc.start + tc.removed
			after := append(append(append([]byte{}, source[:tc.start]...), tc.replacement...), source[end:]...)
			edit := InputEdit{StartByte: uint32(tc.start), OldEndByte: uint32(end), NewEndByte: uint32(tc.start + len(tc.replacement)), StartPoint: trustedGoSessionPoint(source, tc.start), OldEndPoint: trustedGoSessionPoint(source, end), NewEndPoint: trustedGoSessionPoint(after, tc.start+len(tc.replacement))}
			old.Edit(edit)
			events, small, would, bypasses := 0, 0, 0, 0
			trustedGoReuseShadowObserver.Lock()
			trustedGoReuseShadowObserver.call = func(event trustedGoReuseShadowEvent) {
				if event.parser != parser {
					return
				}
				releaseWitness := authenticatedIndependentWitness(t, &event)
				defer releaseWitness()
				events++
				if event.bypassed {
					bypasses++
				}
				if event.smallMode {
					small++
				}
				if event.wouldCertify {
					would++
					trustedGoSessionEqual(t, language, event.candidate, event.fresh)
				}
			}
			trustedGoReuseShadowObserver.Unlock()
			defer func() {
				trustedGoReuseShadowObserver.Lock()
				trustedGoReuseShadowObserver.call = nil
				trustedGoReuseShadowObserver.Unlock()
			}()
			next, _, err := parser.ParseIncrementalProfiled(after, old)
			if err != nil || next == nil {
				t.Fatalf("edited: %v", err)
			}
			defer next.Release()
			freshParser := NewParser(language)
			freshParser.SetAdmissionCandidateRoute(false)
			fresh, err := freshParser.Parse(after)
			if err != nil || fresh == nil {
				t.Fatalf("fresh: %v", err)
			}
			defer fresh.Release()
			if !incrementalTreesStructurallyEqual(next, fresh, language) || next.rawParseStopReason() != fresh.rawParseStopReason() {
				t.Fatal("returned result differs from fresh")
			}
			if events == 0 || (tc.small && (bypasses != 1 || !next.hasCertifiedIncrementalReuse() || next.incrementalFreshVerified())) ||
				(!tc.small && (bypasses != 0 || next.hasCertifiedIncrementalReuse() || !next.incrementalFreshVerified())) {
				t.Fatalf("events=%d bypasses=%d certified=%v fresh=%v", events, bypasses, next.hasCertifiedIncrementalReuse(), next.incrementalFreshVerified())
			}
			if (small > 0) != tc.small || (!tc.small && would != 0) {
				t.Fatalf("small=%d would=%d want small=%v", small, would, tc.small)
			}
			t.Logf("case=%s verifier_events=%d bypass_events=%d small=%d certificates=%d independent_fresh_equal=true", tc.name, events-bypasses, bypasses, small, would)
		})
	}
}
