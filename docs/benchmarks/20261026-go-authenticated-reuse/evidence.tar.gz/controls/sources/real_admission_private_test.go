//go:build gts_parsercorephase0 || gts_workcount || gts_diag

package gotreesitter

import (
	"fmt"
	"os"
	"testing"
)

func RunIdentifierAdmissionRealSources(t *testing.T, language *Language) {
	for _, path := range []string{"internal/benchfixtures/testdata/real/go", "internal/incr/lookahead.go", "internal/benchfixtures/edit_session.go", "cmd/perfcounterledger/main.go"} {
		t.Run(path, func(t *testing.T) {
			source, err := os.ReadFile(path)
			if err != nil {
				t.Fatal(err)
			}
			parser := NewParser(language)
			parser.SetAdmissionCandidateRoute(false)
			probe, err := parser.Parse(source)
			if err != nil || probe == nil || probe.RootNode().HasError() {
				t.Fatalf("source did not parse cleanly: %v", err)
			}
			type span struct{ start, end uint32 }
			var sites []span
			stack := []*Node{probe.RootNode()}
			for len(stack) != 0 {
				n := stack[len(stack)-1]
				stack = stack[:len(stack)-1]
				if n.ChildCount() == 0 && n.symbol == language.KeywordCaptureToken && n.EndByte() > n.StartByte() && n.EndByte()-n.StartByte() < 255 {
					sites = append(sites, span{n.StartByte(), n.EndByte()})
				}
				for i := n.ChildCount() - 1; i >= 0; i-- {
					stack = append(stack, n.Child(i))
				}
			}
			probe.Release()
			if len(sites) == 0 {
				t.Fatal("no real identifier sites")
			}
			count, totalWould := min(9, len(sites)), 0
			for i := 0; i < count; i++ {
				site := sites[i*(len(sites)-1)/max(1, count-1)]
				for _, kind := range []string{"prefix", "suffix", "replace"} {
					t.Run(fmt.Sprintf("%d/%s", site.start, kind), func(t *testing.T) {
						old, err := parser.Parse(source)
						if err != nil || old == nil {
							t.Fatalf("old: %v", err)
						}
						defer old.Release()
						start, end := site.start, site.start
						if kind == "suffix" {
							start, end = site.end, site.end
						} else if kind == "replace" {
							end++
						}
						replacement := byte('z')
						if start < uint32(len(source)) && source[start] == replacement {
							replacement = 'q'
						}
						after := append(append(append([]byte{}, source[:start]...), replacement), source[end:]...)
						edit := InputEdit{StartByte: start, OldEndByte: end, NewEndByte: start + 1, StartPoint: trustedGoSessionPoint(source, int(start)), OldEndPoint: trustedGoSessionPoint(source, int(end)), NewEndPoint: trustedGoSessionPoint(after, int(start+1))}
						old.Edit(edit)
						events, would, bypasses := 0, 0, 0
						trustedGoReuseShadowObserver.Lock()
						trustedGoReuseShadowObserver.call = func(event trustedGoReuseShadowEvent) {
							if event.parser != parser {
								return
							}
							releaseWitness := authenticatedIndependentWitness(t, &event)
							defer releaseWitness()
							events++
							if event.bypassed {
								bypasses++
							}
							if event.wouldCertify {
								would++
								trustedGoSessionEqual(t, language, event.candidate, event.fresh)
							}
						}
						trustedGoReuseShadowObserver.Unlock()
						defer func() {
							trustedGoReuseShadowObserver.Lock()
							trustedGoReuseShadowObserver.call = nil
							trustedGoReuseShadowObserver.Unlock()
						}()
						result, _, err := parser.ParseIncrementalProfiled(after, old)
						if err != nil || result == nil {
							t.Fatalf("edited: %v", err)
						}
						defer result.Release()
						freshParser := NewParser(language)
						freshParser.SetAdmissionCandidateRoute(false)
						fresh, err := freshParser.Parse(after)
						if err != nil || fresh == nil {
							t.Fatalf("fresh: %v", err)
						}
						defer fresh.Release()
						if !incrementalTreesStructurallyEqual(result, fresh, language) || result.rawParseStopReason() != fresh.rawParseStopReason() {
							t.Fatal("returned result differs from fresh")
						}
						if (bypasses != 0 && (!result.hasCertifiedIncrementalReuse() || result.incrementalFreshVerified())) ||
							(bypasses == 0 && ((events != 0 && !result.incrementalFreshVerified()) || result.hasCertifiedIncrementalReuse())) {
							t.Fatalf("events=%d bypasses=%d fresh=%v certified=%v", events, bypasses, result.incrementalFreshVerified(), result.hasCertifiedIncrementalReuse())
						}
						totalWould += would
						t.Logf("real_source=%s byte=%d kind=%s verifier_events=%d bypass_events=%d certificates=%d", path, start, kind, events-bypasses, bypasses, would)
					})
				}
			}
			if totalWould == 0 {
				t.Fatal("real-source coverage never activated the candidate certificate")
			}
			t.Logf("REAL_ADMISSION_SUMMARY source=%s bytes=%d cases=%d would_certify=%d", path, len(source), count*3, totalWould)
		})
	}
}
