package incr

import "testing"

func TestIdentifierAdmissionBounds(t *testing.T) {
	for _, tc := range []struct {
		name, old, next string
		edit            TokenEdit
		start, end      uint32
		want            bool
	}{
		{"insert", " x ", " xx ", TokenEdit{Start: 1, OldEnd: 1, NewEnd: 2}, 1, 3, true},
		{"delete", " xx ", " x ", TokenEdit{Start: 1, OldEnd: 2, NewEnd: 1}, 1, 2, true},
		{"replace", " x ", " y ", TokenEdit{Start: 1, OldEnd: 2, NewEnd: 2}, 1, 2, true},
		{"punctuation", " x ", " :x ", TokenEdit{Start: 1, OldEnd: 1, NewEnd: 2}, 1, 3, false},
		{"newline", " x ", " x\n ", TokenEdit{Start: 2, OldEnd: 2, NewEnd: 3}, 1, 3, false},
		{"removed-token", " x ", "  ", TokenEdit{Start: 1, OldEnd: 2, NewEnd: 1}, 1, 1, false},
		{"prefix-changed", " x ", "!xx ", TokenEdit{Start: 1, OldEnd: 1, NewEnd: 2}, 1, 3, false},
		{"suffix-changed", " x ", " xx!", TokenEdit{Start: 1, OldEnd: 1, NewEnd: 2}, 1, 3, false},
		{"invalid-bounds", " x ", " xx ", TokenEdit{Start: 5, OldEnd: 5, NewEnd: 6}, 1, 3, false},
		{"digit-start", " x ", " 1x ", TokenEdit{Start: 1, OldEnd: 1, NewEnd: 2}, 1, 3, false},
		{"unicode", " x ", " éx ", TokenEdit{Start: 1, OldEnd: 1, NewEnd: 3}, 1, 4, false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			_, got := IdentifierEditBounds([]byte(tc.old), []byte(tc.next), tc.edit, tc.start, tc.end)
			if got != tc.want {
				t.Fatalf("admitted=%v want %v", got, tc.want)
			}
			_, _, _, got = IdentifierEditToken([]byte(tc.old), []byte(tc.next), tc.edit)
			if got != tc.want {
				t.Fatalf("source-token admission=%v want %v", got, tc.want)
			}
		})
	}
}

func TestIdentifierAdmissionOldEditNecessary(t *testing.T) {
	for _, old := range []string{" x ", " _xy2 ", " x,y ", " 1x ", " x\ny ", " xé "} {
		for start := 0; start <= len(old); start++ {
			for end := start; end <= len(old); end++ {
				for _, replacement := range []string{"", "a", "xy", "1", "_", " ", ":", "\n"} {
					edit := TokenEdit{Start: uint32(start), OldEnd: uint32(end), NewEnd: uint32(start + len(replacement))}
					next := old[:start] + replacement + old[end:]
					begin, oldEnd, _, admitted := IdentifierEditToken([]byte(old), []byte(next), edit)
					if !admitted {
						continue
					}
					before, after, possible := IdentifierEditOldToken([]byte(old), edit)
					if !possible || before != begin || after != oldEnd {
						t.Fatalf("admitted edit lacks old-source invalidation: %q [%d,%d) -> %q", old, start, end, replacement)
					}
				}
			}
		}
	}
	if _, _, ok := IdentifierEditOldToken([]byte("x, y"), TokenEdit{Start: 2, OldEnd: 2, NewEnd: 3}); ok {
		t.Fatal("padding insertion must retain the ordinary invalidation policy")
	}
}
