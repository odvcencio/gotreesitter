package incr

import "testing"

func TestIdentifierAdmissionNativeTransfer(t *testing.T) {
	for _, previous := range []uint16{0, 8195, 8196} {
		for _, current := range []uint16{0, 8195, 8196} {
			for _, complete := range []bool{false, true} {
				for _, covered := range []bool{false, true} {
					got := TransferNativeReuseProducer(previous, current, complete, covered)
					want := uint16(0)
					if previous != 0 && previous == current && complete && covered {
						want = current
					}
					if got != want {
						t.Fatalf("previous=%d current=%d complete=%v covered=%v grant=%d want=%d", previous, current, complete, covered, got, want)
					}
				}
			}
		}
	}
}
