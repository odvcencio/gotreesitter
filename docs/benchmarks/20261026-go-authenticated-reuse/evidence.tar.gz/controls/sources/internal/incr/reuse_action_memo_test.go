package incr

import "testing"

func TestIdentifierAdmissionActionMemoIsolation(t *testing.T) {
	var memo ReuseActionMemo
	if _, _, ok := memo.Lookup(0, 0); ok {
		t.Fatal("empty memo granted a hit")
	}
	memo.Store(65537, 2, true, true)
	for _, state := range []uint32{1, 65536, 65538} {
		if _, _, ok := memo.Lookup(state, 2); ok {
			t.Fatal("different state reused table facts")
		}
	}
	if _, _, ok := memo.Lookup(65537, 3); ok {
		t.Fatal("different symbol reused table facts")
	}
	if actions, reusable, ok := memo.Lookup(65537, 2); !ok || !actions || !reusable {
		t.Fatal("matching immutable facts were lost")
	}
	memo.Store(65537, 2, false, false)
	if actions, reusable, ok := memo.Lookup(65537, 2); !ok || actions || reusable {
		t.Fatal("negative facts were turned into positive authority")
	}
	memo = ReuseActionMemo{}
	if _, _, ok := memo.Lookup(65537, 2); ok {
		t.Fatal("a new parse inherited old table facts")
	}
}
