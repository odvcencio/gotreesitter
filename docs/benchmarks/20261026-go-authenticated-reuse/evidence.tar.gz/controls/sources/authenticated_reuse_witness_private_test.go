//go:build gts_parsercorephase0 || gts_workcount || gts_diag

package gotreesitter

import "testing"

// Independent comparison belongs to the test, outside the measured operation.
// A production bypass event never supplies a hidden fresh parse as its witness.
func authenticatedIndependentWitness(t *testing.T, event *trustedGoReuseShadowEvent) func() {
	t.Helper()
	if !event.bypassed {
		return func() {}
	}
	if event.fresh != nil || !event.candidate.hasCertifiedIncrementalReuse() || event.candidate.incrementalFreshVerified() || !event.smallMode {
		t.Fatal("bypass observation lacks a genuine unverified native certificate")
	}
	independent := NewParser(event.parser.language)
	independent.SetAdmissionCandidateRoute(false)
	fresh, err := independent.Parse(event.source)
	if err != nil || fresh == nil {
		t.Fatalf("independent bypass witness: %v", err)
	}
	event.fresh = fresh
	return fresh.Release
}
