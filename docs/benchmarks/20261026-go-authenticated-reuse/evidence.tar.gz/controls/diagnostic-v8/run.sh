set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly' GTS_ADMISSION_CANDIDATE=0 GTS_BENCHMARK_SEED=1
sha256sum --quiet -c /controls/source.sha256
sha256sum --quiet -c /controls/controls.sha256
sha256sum /controls/diagnostic-v8/{proof.go,overlay.json} > /evidence/input.sha256
for arm in baseline candidate; do
 cd "/$arm"
 go test -overlay=/controls/diagnostic-v8/overlay.json -tags gts_parsercorephase0 -run '^$' -bench '^BenchmarkGTSAuthenticatedReuse$/^BenchmarkGoParseIncrementalSingleByteEditDFA$' -benchtime=3x -count=1 . > "/evidence/$arm.log" 2>&1
done
sha256sum --quiet -c /controls/source.sha256
sha256sum --quiet -c /controls/controls.sha256
sha256sum --quiet -c /evidence/input.sha256
