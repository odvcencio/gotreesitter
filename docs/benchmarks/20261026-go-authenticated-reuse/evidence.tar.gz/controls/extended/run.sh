set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
finish(){
 sha256sum --quiet -c /controls/source.sha256 > /evidence/source-after.log 2>&1
 sha256sum --quiet -c /controls/controls.sha256 > /evidence/controls-after.log 2>&1
 sha256sum --quiet -c /controls/extended/controls.sha256 > /evidence/extended-after.log 2>&1
 sha256sum --quiet -c /controls/oracle0271/checksums.container.sha256 > /evidence/oracle-after.log 2>&1
 sha256sum --quiet -c /controls/oracle0271-module-bind-v3/checksums.container.sha256 > /evidence/binding-after.log 2>&1
 python3 /controls/oracle0271-module-bind-v3/verify-inputs.py > /evidence/staged-after.json
}
trap finish EXIT
sha256sum --quiet -c /controls/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/controls.sha256 > /evidence/controls-before.log 2>&1
sha256sum --quiet -c /controls/extended/controls.sha256 > /evidence/extended-before.log 2>&1
sha256sum --quiet -c /controls/oracle0271/checksums.container.sha256 > /evidence/oracle-before.log 2>&1
sha256sum --quiet -c /controls/oracle0271-module-bind-v3/checksums.container.sha256 > /evidence/binding-before.log 2>&1
python3 /controls/oracle0271-module-bind-v3/verify-inputs.py > /evidence/staged-before.json
scratch=/runtime/tmp/gotreesitter-go-authenticated-reuse-extended-20261026
mkdir -p "$scratch"
cd /candidate
go test -overlay=/controls/extended/overlay.tests.json -tags gts_parsercorephase0 -run '^TestAuthenticatedGoReuseLifecycle$' -count=1 -v -timeout=5m . > /evidence/lifecycle.log 2>&1
go test -race -overlay=/controls/extended/overlay.tests.json ./internal/incr -run '^Test(IdentifierAdmissionActionMemoIsolation|PrivateTrustedNativeReuseProducerTransfer)$' -count=1 -v -timeout=2m > /evidence/memo-race.log 2>&1
go test -race -c -overlay=/controls/extended/overlay.tests.json -tags gts_parsercorephase0 -o "$scratch/root-race.test" . > /evidence/race-build.log 2>&1
"$scratch/root-race.test" -test.run '^Test(TrustedGoReuseShadowOriginalProducer|IdentifierAdmissionActualBoundaryCases|IdentifierAdmissionRealSources|TrustedGoShadowActualDefaultProducerContext|AuthenticatedGoReuseLifecycle)$' -test.count=1 -test.v -test.timeout=10m > /evidence/race-go.log 2>&1
for api in plain profiled; do
 "$scratch/root-race.test" -test.run "^TestTrustedGoReuseShadowCleanEditSession$/$api$" -test.count=1 -test.v -test.timeout=8m > "/evidence/race-clean-$api.log" 2>&1
done
cd /candidate/cgo_harness
export GOFLAGS='-p=1 -mod=readonly -modfile=/controls/oracle0271-module-bind-v3/go.mod -overlay=/controls/extended/overlay.c027.json'
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o "$scratch/cgo.test" . > /evidence/cgo-build.log 2>&1
"$scratch/cgo.test" -test.run '^TestCOracle0271HeaderAndLinkProbe$' -test.count=1 -test.v -test.timeout=2m > /evidence/runtime-probe.log 2>&1
"$scratch/cgo.test" -test.run '^TestGo(Cognociente137KiBTopEditLockedC|MalformedDeclarationPrefixLockedC|AssignmentTargetEdits16SitesLockedC)$' -test.count=1 -test.v -test.timeout=12m > /evidence/locked-c027.log 2>&1
sha256sum "$scratch/root-race.test" "$scratch/cgo.test" > /evidence/binary.sha256
