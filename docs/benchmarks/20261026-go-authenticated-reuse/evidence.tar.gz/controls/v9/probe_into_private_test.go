package gotreesitter

import (
	"github.com/odvcencio/gotreesitter/internal/incr"
	"testing"
)

func TestPrimitiveProbeIntoContract(t *testing.T) {
	for _, src := range [][]byte{[]byte("12x"), []byte("z"), []byte("1é"), {0xff}, nil} {
		for _, scans := range []uint32{0, 1, 8} {
			for _, bytes := range []uint32{0, 1, 128} {
				for _, limit := range []uint32{0, 1, 8} {
					lang := primitiveProofDigitLanguage()
					d := newDFATokenSourceDirectWithCRecovery(NewLexer(lang.LexStates, src), lang, nil, nil, nil, nil, false)
					a, b := tokenInvariantPrimitiveBudget{bytes: bytes, scans: scans}, tokenInvariantPrimitiveBudget{bytes: bytes, scans: scans}
					want, ws, wa, wok := d.tokenInvariantProbeDFALimited(src, 0, Point{}, 0, &a, limit)
					got := Token{Symbol: 1}
					gs := incr.DFAProbeState{Position: 1}
					ga, gok := d.tokenInvariantProbeDFALimitedInto(src, 0, Point{}, 0, &b, limit, &got, &gs)
					if got != want || gs != ws || ga != wa || gok != wok || a != b {
						t.Fatalf("src=%x scans=%d bytes=%d limit=%d got=%+v/%+v/%t/%t/%+v want=%+v/%+v/%t/%t/%+v", src, scans, bytes, limit, got, gs, ga, gok, b, want, ws, wa, wok, a)
					}
					d.Close()
				}
			}
		}
	}
}
