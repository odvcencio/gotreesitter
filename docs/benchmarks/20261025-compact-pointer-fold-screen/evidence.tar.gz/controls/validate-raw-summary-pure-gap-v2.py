from pathlib import Path
import hashlib,json,re
r=Path(__file__).resolve().parent;o=r/'out'
def logs(new,old):
 p=o/new;template=json.loads((o/old/'validated-summary.json').read_text())
 assert json.loads((p/'finished.json').read_text())['exit_code']==0,new
 for n in ['source-before.log','source-after.log','controls-before.log','controls-after.log']:
  assert (p/n).read_text()=='',(new,n)
 for name,expected in template.items():
  if not name.endswith('.log'):continue
  text=(p/name).read_text();actual={'families':len(re.findall(r'^--- PASS:',text,re.M)),'pass_records':len(re.findall(r'^\s*--- PASS:',text,re.M))}
  assert actual==expected,(new,name,actual,expected)
  assert not re.search(r'--- (FAIL|SKIP):|^FAIL\b|WARNING: DATA RACE|panic:',text,re.M),(new,name)
 return p,template
p=o/'raw-summary-pure-gap-v2b';summary=json.loads((p/'validated-summary.json').read_text());text=(p/'ordinary-root.log').read_text()
assert text.count('lease:true')==4 and text.count('core_owned_raw_records:0')==4 and text.count('arena_nodes:1')==4
summary.update(public_ordinary_two_sources_genuine_lease=True,C025_original_two_sources_exact_both_arms=True,runtime_map_sha256='6f2d518d0051e520644a32cf2991ada86231cc7d40cc952109956428172070fe')
(p/'validated-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
p,t=logs('raw-summary-semantic-pure-gap-v2b','raw-summary-semantic-v6')
work={'tokens','new_nodes','max_live_versions','multi_version_token_share_ppm'};reuse={'reused_bytes','block_splices'}
def diff(a,b,path=''):
 assert type(a)==type(b),(path,'type')
 if isinstance(a,dict):
  assert a.keys()==b.keys(),(path,'schema')
  return [d for k in a for d in diff(a[k],b[k],path+'/'+k)]
 if isinstance(a,list):
  assert len(a)==len(b),(path,'rows')
  return [d for i in range(len(a)) for d in diff(a[i],b[i],path+'/'+str(i))]
 if a==b:return []
 k=path.rsplit('/',1)[-1];assert type(a)==int and a>=0 and b>=0,(path,a,b)
 if k in work: assert b<=a,(path,'work increased',a,b);direction='less_work'
 elif k in reuse: assert b>=a,(path,'reuse fell',a,b);direction='more_reuse'
 else:raise AssertionError((path,'unknown change',a,b))
 return [{'path':path.lstrip('/'),'before':a,'after':b,'direction':direction}]
rows=[]
for route in ['default','candidate']:
 for language in ['go','yaml']:
  name=f'{route}-{language}.json';a=json.loads((o/'packed-snapshot-budget-final/ledger'/name).read_text());b=json.loads((p/name).read_text());ds=diff(a,b)
  rows.append({'route':route,'language':language,'exact_equal':not ds,'approved_work_exception_used':False,'changes':ds})
  assert (p/f'{route}-{language}.stderr').read_text()==''
for language in ['go','yaml']:
 for route in [0,1]: assert 'session_steps=72 no_edit_allocs=0' in (p/f'invariants-{language}-{route}.log').read_text()
t['counter_rows']=rows;(p/'validated-summary.json').write_text(json.dumps(t,indent=2)+'\n')
p,t=logs('raw-summary-public-race-pure-gap-v2b','raw-summary-public-race-v6');t['runtime_map']='raw-summary-output-v1/pure-gap-fused-v2/overlay.runtime.json';(p/'validated-summary.json').write_text(json.dumps(t,indent=2)+'\n')
p,t=logs('raw-summary-c027-pure-gap-v2b','raw-summary-c027-compact-v6')
for name in ['oracle-before','oracle-after','binding-before','binding-after']: assert (p/f'{name}.log').read_text()==''
assert '"runtime_commit":"10eb5ac119eec9cb4267a8e035066473983f5f3a"' in (p/'runtime-probe.log').read_text()
(p/'validated-summary.json').write_text(json.dumps(t,indent=2)+'\n')
print(json.dumps({'pointer_fold_v2_gates_passed':True,'actual_counter_rows':rows,'merges_held':True}))
