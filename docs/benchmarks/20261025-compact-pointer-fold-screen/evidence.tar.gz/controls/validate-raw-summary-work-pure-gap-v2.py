from pathlib import Path
import json,re
r=Path(__file__).resolve().parent;o=r/'out';p=o/'raw-summary-work-pure-gap-v2b'
assert json.loads((p/'finished.json').read_text())['exit_code']==0
for n in ('source-before.log','source-after.log','controls-before.log','controls-after.log'): assert (p/n).read_text()==''
template=json.loads((o/'raw-summary-work-fused-v7/validated-summary.json').read_text());rows=[]
for fixture in ('primary32','primary128','primary512','primary1024','real-r4'):
 s=(p/f'work-{fixture}.log').read_text()
 assert len(re.findall(r'^--- PASS:',s,re.M))==1 and len(re.findall(r'^\s*--- PASS:',s,re.M))==2
 assert not re.search(r'--- (FAIL|SKIP):|^FAIL\b|WARNING: DATA RACE|panic:',s,re.M)
 actual=[json.loads(line.split('RAW_SUMMARY_ORDINARY_WORK ',1)[1]) for line in s.splitlines() if 'RAW_SUMMARY_ORDINARY_WORK ' in line]
 assert len(actual)==1;row=actual[0];old=next(x for x in template['sources'] if x['Fixture']==fixture)
 assert row==old,(fixture,'actual source/tree/storage/formation/read counter drift',row,old)
 rows.append(row)
result=dict(template);result['sources']=rows;result['runtime_map_sha256']='6f2d518d0051e520644a32cf2991ada86231cc7d40cc952109956428172070fe';result['equal_to_held_fused_v7']=True
(p/'validated-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'ordinary_sources':5,'all_source_tree_storage_formation_and_read_counters_equal':True,'warm_additional_work':0}))
