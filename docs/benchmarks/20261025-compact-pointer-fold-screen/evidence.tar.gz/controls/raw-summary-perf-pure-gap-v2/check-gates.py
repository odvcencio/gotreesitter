from pathlib import Path
import json,re,hashlib
r=Path(__file__).resolve().parents[1];out=r/'out'
def check(folder,logs):
 p=out/folder
 assert json.loads((p/'finished.json').read_text())['exit_code']==0,folder
 for n in ('source-before.log','source-after.log','controls-before.log','controls-after.log'):assert (p/n).read_text()=='',(folder,n)
 for n,(tops,records) in logs.items():
  s=(p/n).read_text()
  assert len(re.findall(r'^--- PASS:',s,re.M))==tops and len(re.findall(r'^\s*--- PASS:',s,re.M))==records,(folder,n)
  assert not re.search(r'--- (FAIL|SKIP):|^FAIL\b|WARNING: DATA RACE|panic:',s,re.M),(folder,n)
 return p,json.loads((p/'validated-summary.json').read_text())
p,compact=check('raw-summary-pure-gap-v2b',{'core-release.log':(83,173),'core-workcount.log':(19,34),'core-race.log':(19,34),'ordinary-root.log':(6,16),'ordinary-cgo.log':(1,7)})
assert compact['public_ordinary_two_sources_genuine_lease'] and compact['C025_original_two_sources_exact_both_arms']
p,work=check('raw-summary-work-pure-gap-v2b',{f'work-{n}.log':(1,2) for n in ('primary32','primary128','primary512','primary1024','real-r4')})
assert work['ordinary_lease_required'] and work['warm_additional_work']==0
assert len(work['sources'])==5 and {x['Fixture'] for x in work['sources']}=={'primary32','primary128','primary512','primary1024','real-r4'}
for x in work['sources']:
 rows=[json.loads(line.split('RAW_SUMMARY_ORDINARY_WORK ',1)[1]) for line in (p/f"work-{x['Fixture']}.log").read_text().splitlines() if 'RAW_SUMMARY_ORDINARY_WORK ' in line]
 assert rows==[x] and x['After']==x['Warm']
 assert x['Before']['RegisteredContexts']==x['Before']['ArenaNodes']==1 and x['Before']['Formation']==x['After']['Formation']
 assert x['Before']['Formation']['Contexts']>0 and x['Before']['Formation']['ComposedSummaries']>0
 assert x['Before']['Formation']['ExceptionalRefusals']==0
p,c027=check('raw-summary-c027-pure-gap-v2b',{'runtime-probe.log':(1,1),'ordinary-cgo.log':(1,7)})
assert c027['runtime_commit']=='10eb5ac119eec9cb4267a8e035066473983f5f3a' and c027['new_raw_both_original_sources_exact_C']
p,semantic=check('raw-summary-semantic-pure-gap-v2b',{'focused.log':(36,68),'go-public-api.log':(3,9),'go-cgo.log':(10,41),'go-report-cgo.log':(3,127),'yaml-cgo.log':(8,184),**{f'invariants-{n}-{route}.log':(1,1) for n in ('go','yaml') for route in (0,1)}})
assert semantic['D8_sessions']==4 and semantic['D8_steps']==288 and semantic['no_edit_allocations']==0 and semantic['adverse_counter_changes']==0
for n in ('go','yaml'):
 for route in (0,1):assert 'session_steps=72 no_edit_allocs=0' in (p/f'invariants-{n}-{route}.log').read_text()
work_keys={'tokens','new_nodes','max_live_versions','multi_version_token_share_ppm'};reuse_keys={'reused_bytes','block_splices'}
def differences(a,b,path=''):
 assert type(a)==type(b),(path,'schema/type changed')
 if isinstance(a,dict):
  assert a.keys()==b.keys(),(path,'schema changed')
  return [change for k in a for change in differences(a[k],b[k],f'{path}/{k}' if path else k)]
 if isinstance(a,list):
  assert len(a)==len(b),(path,'rows changed')
  return [change for i in range(len(a)) for change in differences(a[i],b[i],f'{path}/{i}' if path else str(i))]
 if a==b:return []
 key=path.rsplit('/',1)[-1]
 assert type(a)==int and a>=0 and b>=0,(path,'noncounter field changed',a,b)
 if key in work_keys:
  assert b<=a,(path,'WORK INCREASE: timing blocked pending separate adjudication',a,b)
  direction='less_work'
 elif key in reuse_keys:
  assert b>=a,(path,'REUSE DECREASE: timing blocked pending separate adjudication',a,b)
  direction='more_reuse'
 else:raise AssertionError((path,'unknown counter/metadata change',a,b))
 return [{'path':path,'before':a,'after':b,'direction':direction}]
rows=[]
for route in ('default','candidate'):
 for language in ('go','yaml'):
  name=f'{route}-{language}.json';before=json.loads((out/'packed-snapshot-budget-final/ledger'/name).read_text());after=json.loads((p/name).read_text())
  changes=differences(before,after)
  row={'route':route,'language':language,'exact_equal':not changes,'approved_work_exception_used':False,'changes':changes}
  assert row in semantic['counter_rows'],(name,'root comparison receipt differs')
  rows.append(row)
p,race=check('raw-summary-public-race-pure-gap-v2b',{'public-race.log':(5,13)})
print(json.dumps({'schema':'gts-raw-summary-compact-preperf/v1','selected_semantic_gates_passed':True,'actual_lease_sources':2,'C025_original_sources':2,'C027_original_sources':2,'real_source_work_fixtures':5,'warm_additional_work':0,'actual_counter_rows':rows,'counter_exceptions_used':False,'D8_sessions':4,'D8_steps':288,'no_edit_allocations':0,'public_race_families':5,'production_promoted':False,'fleet_qualified':False,'merges_held':True}))

p=out/'raw-summary-pure-gap-focused-v1'
assert json.loads((p/'finished.json').read_text())['exit_code']==0
for n in ('source-before.log','source-after.log','controls-before.log','controls-after.log'): assert (p/n).read_text()==''
for n in ('focused.log','workcount.log','race.log'):
 s=(p/n).read_text()
 assert len(re.findall(r'^--- PASS:',s,re.M))==12 and len(re.findall(r'^\s*--- PASS:',s,re.M))==71,(n,'focused coverage')
 assert not re.search(r'--- (FAIL|SKIP):|^FAIL\b|WARNING: DATA RACE|panic:',s,re.M),n

p=out/'raw-summary-pure-gap-refusals-v3'
assert json.loads((p/'finished.json').read_text())['exit_code']==0
for guard in ('source-before.log','source-after.log','controls-before.log','controls-after.log'):assert (p/guard).read_text()==''
for name in ('focused.log','workcount.log','race.log'):
 text=(p/name).read_text()
 assert len(re.findall(r'^--- PASS:',text,re.M))==1 and len(re.findall(r'^\s*--- PASS:',text,re.M))==9,(name,'refusal coverage')
 assert not re.search(r'--- (FAIL|SKIP):|^FAIL\b|WARNING: DATA RACE|panic:',text,re.M),name
