from pathlib import Path
import datetime,fcntl,json,subprocess
root=Path(__file__).resolve().parent
commands=json.loads((root/'commands.json').read_text())
with Path('/tmp/gotreesitter-compact-storage-docker.lock').open('a') as lock:
 print('pure-gap V2 exact-refusal correctness waiting for shared measurement lock',flush=True)
 fcntl.flock(lock,fcntl.LOCK_EX)
 print('pure-gap V2 exact-refusal correctness acquired shared measurement lock',flush=True)
 for task in commands:
  out=Path(task['output'])
  out.mkdir(parents=True,exist_ok=True)
  assert not (out/'started.json').exists(),'refusing to overwrite an earlier attempt'
  (out/'started.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'variant':task['variant']}))
  print('starting '+task['variant'],flush=True)
  try:
   with (out/'container.log').open('w') as log:r=subprocess.run(task['args'],stdout=log,stderr=subprocess.STDOUT,timeout=1300)
   code=r.returncode
  except subprocess.TimeoutExpired:
   name=task['args'][task['args'].index('--name')+1]
   subprocess.run(['docker','stop','--time','10',name],capture_output=True)
   code=124
  (out/'finished.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code}))
  print('finished '+task['variant']+' exit='+str(code),flush=True)
 print('pure-gap V2 exact-refusal correctness terminal; no timing or promotion',flush=True)
