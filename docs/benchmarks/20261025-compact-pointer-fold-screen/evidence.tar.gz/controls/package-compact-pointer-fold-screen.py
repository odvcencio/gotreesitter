from pathlib import Path
import gzip,hashlib,io,json,tarfile
r=Path(__file__).resolve().parent;repo=r.parents[2];d=repo/'docs/benchmarks/20261025-compact-pointer-fold-screen';d.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
inherited={}
for folder in ('20261025-compact-raw-screen','20261025-compact-construction-screen'):
 with tarfile.open(repo/'docs/benchmarks'/folder/'evidence.tar.gz') as t:
  for m in t:
   assert m.isfile();b=t.extractfile(m).read();assert m.name not in inherited;inherited[m.name]=b
files={}
def add(key,p):
 b=p.read_bytes()
 if key in inherited:assert inherited[key]==b,key;return
 if key in files:assert files[key]==b,key;return
 files[key]=b
def folder(rel,virtual):
 for p in sorted((r/rel).rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix in ('.py','.sh','.json','.sha256','.txt','.log'):
   add(virtual+'/'+p.relative_to(r/rel).as_posix(),p)
for name in ('pure-gap-fused-v1','pure-gap-fused-v2','pure-gap-refusal-proof-v3'):
 folder('raw-summary-output-v1/'+name,'controls/raw-summary-output-v1/'+name)
variants=[]
for version in ('v1','v2','v2b'):
 for prefix in ('raw-summary-pure-gap','raw-summary-work-pure-gap','raw-summary-semantic-pure-gap','raw-summary-public-race-pure-gap','raw-summary-c027-pure-gap','raw-summary-pure-gap-focused','raw-summary-pure-gap-gates'):
  variants.append(prefix+'-'+version)
variants+=['raw-summary-pure-gap-refusals-v3','raw-summary-perf-pure-gap-v1','raw-summary-perf-pure-gap-v2']
for name in variants:
 if (r/name).exists():folder(name,'controls/'+name)
 if (r/'out'/name).exists():folder('out/'+name,'outputs/'+name)
for name in ('validate-raw-summary-pure-gap-v1.py','validate-raw-summary-pure-gap-v2.py','validate-raw-summary-work-pure-gap-v2.py','package-compact-pointer-fold-screen.py'):
 add('controls/'+name,r/name)
# Follow only explicit checksum inputs, never a cache or repository tree.
done=set()
while True:
 pending=[(k,b) for k,b in files.items() if k not in done and Path(k).name=='controls.sha256']
 if not pending:break
 for key,b in pending:
  done.add(key)
  for line in b.decode().splitlines():
   digest,v=line.split('  ',1)
   if not v.startswith('/controls/'):continue
   k=v.lstrip('/')
   if k not in files and k not in inherited and v.startswith('/controls/out/'):k='outputs/'+v.removeprefix('/controls/out/')
   if k not in files and k not in inherited:
    p=r/v.removeprefix('/controls/');assert p.is_file(),(key,v);add(k,p)
   assert sha(files[k] if k in files else inherited[k])==digest,(key,v)
index=[{'path':k,'bytes':len(b),'sha256':sha(b)} for k,b in sorted(files.items())]
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.PAX_FORMAT) as t:
 for k,b in sorted(files.items()):
  i=tarfile.TarInfo(k);i.size=len(b);i.mode=0o644;i.mtime=0;t.addfile(i,io.BytesIO(b))
(d/'evidence.tar.gz').write_bytes(gzip.compress(buf.getvalue(),mtime=0));(d/'contents.json.gz').write_bytes(gzip.compress(json.dumps(index,indent=2).encode(),mtime=0))
perf=json.loads((r/'out/raw-summary-perf-pure-gap-v2/validated-summary.json').read_text());summary=dict(perf)
summary.update(runtime_map_sha256='6f2d518d0051e520644a32cf2991ada86231cc7d40cc952109956428172070fe',archive_members=len(files),base_evidence_archive_sha256=sha((repo/'docs/benchmarks/20261025-compact-raw-screen/evidence.tar.gz').read_bytes()),construction_archive_sha256=sha((repo/'docs/benchmarks/20261025-compact-construction-screen/evidence.tar.gz').read_bytes()),decision='hold: ordinary Go compact throughput regresses; no runtime promotion',V1_timing_executed=False,V1_refusal_formation_edges={'reference':0,'candidate':1},V2_refusal_formation_edges={'reference':0,'candidate':0},counter_exceptions_used=False,actual_counter_rows=json.loads((r/'out/raw-summary-semantic-pure-gap-v2b/validated-summary.json').read_text())['counter_rows'])
(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'members':len(files),'archive_bytes':(d/'evidence.tar.gz').stat().st_size,'archive_sha256':sha((d/'evidence.tar.gz').read_bytes())}))
