set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/raw-summary-public-race-pure-gap-v1/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/raw-summary-public-race-pure-gap-v1/controls.sha256 > /evidence/controls-before.log 2>&1
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/raw-summary-public-race-pure-gap-v1
mkdir -p "$scratch"
overlay=/controls/raw-summary-output-v1/pure-gap-fused-v1/overlay.tests.json
go test -race -overlay="$overlay" -tags gts_parsercorephase0 -run '^TestRawSummary(CopyOutlivesProducer|SavedSourceAuthorityRejectsEOFMutation|ImmutableLeaseSurvivesOtherResultAndProducerReuse|ReaderCacheCapacityIsChargedAndCopyIsIndependent|ConcurrentReadQueryCopyDuringOtherReleaseAndCoreReset)$' -count=1 -v -timeout=5m . > /evidence/public-race.log 2>&1
