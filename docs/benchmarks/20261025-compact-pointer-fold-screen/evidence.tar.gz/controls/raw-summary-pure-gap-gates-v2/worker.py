from pathlib import Path
import datetime,fcntl,json,subprocess
root=Path(__file__).resolve().parent
commands=json.loads((root/'commands.json').read_text())
with Path('/tmp/gotreesitter-compact-storage-docker.lock').open('a') as lock:
 print('Go pointer-fold qualification waiting for shared measurement lock',flush=True)
 fcntl.flock(lock,fcntl.LOCK_EX)
 print('Go pointer-fold qualification acquired shared measurement lock',flush=True)
 focused=root.parent/'out/raw-summary-pure-gap-focused-v2b'
 assert json.loads((focused/'finished.json').read_text())['exit_code']==0, 'focused V2 gate failed'
 for guard in ('source-before.log','source-after.log','controls-before.log','controls-after.log'):
  assert (focused/guard).read_text()=='',guard

 for task in commands:
  out=Path(task['output'])
  out.mkdir(parents=True,exist_ok=True)
  assert not (out/'started.json').exists(),'refusing to overwrite an earlier attempt'
  (out/'started.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'variant':task['variant']}))
  print('starting '+task['variant'],flush=True)
  try:
   with (out/'container.log').open('w') as log:r=subprocess.run(task['args'],stdout=log,stderr=subprocess.STDOUT,timeout=1300)
   code=r.returncode
  except subprocess.TimeoutExpired:
   name=task['args'][task['args'].index('--name')+1]
   subprocess.run(['docker','stop','--time','10',name],capture_output=True)
   code=124
  (out/'finished.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code}))
  print('finished '+task['variant']+' exit='+str(code),flush=True)
  if code != 0: raise SystemExit(code)
 print('Go pointer-fold qualification terminal; no verifier bypass or timing',flush=True)
