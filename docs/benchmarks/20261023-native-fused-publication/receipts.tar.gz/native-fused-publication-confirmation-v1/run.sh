set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly'
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
git config --global --add safe.directory /candidate
python3 /controls/source_hashes.py > /evidence/source-before.json
cmp /evidence/source-before.json /controls/expected-source.json
python3 - <<'RECEIPT'
from pathlib import Path
import json
p=Path('/qualified')
assert (p/'complete.txt').exists() and (p/'workload-exit-code.txt').read_text().strip()=='0'
assert json.loads((p/'source-before.json').read_text())==json.loads(Path('/evidence/source-before.json').read_text())
assert json.loads((p/'source-after-final.json').read_text())==json.loads(Path('/evidence/source-before.json').read_text())
for f in (p/'counter-deltas').glob('*.json'):
 d=json.loads(f.read_text());assert d['passed'] and not d['changes'] and not d['route_metadata_changes']
assert len(list((p/'counter-deltas').glob('*.json')))==206
RECEIPT
printf 'source-identical correctness and all 206 strict counter receipts verified before timing\n' > /evidence/correctness-complete.txt
cd /candidate
go version > /evidence/go-version.txt
export CGO_ENABLED=0
bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-yaml.txt --output /evidence/candidate-yaml.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 217001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputYAML$' --require-benchmarks 'BenchmarkCompactThroughputYAML/r4_legacy,BenchmarkCompactThroughputYAML/eof8k_legacy,BenchmarkCompactThroughputYAML/r4_ordinary,BenchmarkCompactThroughputYAML/eof8k_ordinary,BenchmarkCompactThroughputYAML/r4_owned,BenchmarkCompactThroughputYAML/eof8k_owned' > /evidence/yaml-driver.log 2>&1
bash scripts/run_randomized_benchmarks.sh --primary-go-suite --baseline-root /baseline --baseline-output /evidence/baseline-go.txt --output /evidence/candidate-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 218001 --benchtime 750ms > /evidence/go-driver.log 2>&1
GOFLAGS='-p=1 -mod=readonly -overlay=/controls/benchmark-overlay.json' GTS_ADMISSION_CANDIDATE=1 bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-compact-go.txt --output /evidence/candidate-compact-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 219001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputGo$' --require-benchmarks 'BenchmarkCompactThroughputGo/full_dfa,BenchmarkCompactThroughputGo/single_byte_edit_dfa,BenchmarkCompactThroughputGo/no_edit_dfa,BenchmarkCompactThroughputGo/fresh_one_mib,BenchmarkCompactThroughputGo/query_compile,BenchmarkCompactThroughputGo/grammargen_lr' > /evidence/compact-go-driver.log 2>&1
python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'complete\n' > /evidence/complete.txt
