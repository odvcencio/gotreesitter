from pathlib import Path
import re,json,statistics,subprocess,hashlib,sys
p=Path('/home/draco/work/gotreesitter/harness_out/docker/native-fused-publication-mac-v1/out')
report=Path('/home/draco/work/gotreesitter/harness_out/docker/native-fused-publication-mac-v1/out')
assert (p/'exit-code.txt').exists(), 'qualification has not finished'
assert (p/'correctness-complete.txt').exists(), 'correctness and counters did not finish'
assert (p/'platform.txt').read_text().splitlines()==['linux','arm64']
before=json.loads((p/'source-before.json').read_text());after=json.loads((p/'source-after.json').read_text());assert before==after

def parse(path,start,cells):
 text=path.read_text();assert text.rstrip().endswith('# status: complete')
 assert '# completed runs: 20' in text
 seeds={};seed=None
 for line in text.splitlines():
  match=re.match(r'# seed: (\d+); position: (\d+)$',line)
  if match:
   seed,pos=map(int,match.groups());assert seed not in seeds;seeds[seed]={'position':pos,'rows':{},'order':[]}
  elif line.startswith('Benchmark'):
   words=line.split();name=re.sub(r'-\d+$','',words[0]);assert seed is not None and name not in seeds[seed]['rows'];assert int(words[1])>0
   assert len(words[2:])%2==0
   metrics={words[i+1]:float(words[i]) for i in range(2,len(words),2)}
   assert all(m in metrics for m in ['ns/op','B/op','allocs/op']);seeds[seed]['rows'][name]=metrics;seeds[seed]['order'].append(name)
  elif line.startswith('# workload order: '):assert line.split(': ',1)[1].split(',')==seeds[seed]['order']
 assert set(seeds)==set(range(start,start+20));assert all(len(v['rows'])==cells for v in seeds.values())
 assert len({tuple(sorted(v['rows'])) for v in seeds.values()})==1
 return seeds
result={'scope':'Fused native publication traversal versus frozen native-record-receipts-v2; Linux ARM64 in Mac Docker; not native Darwin or main-based qualification.','suites':{},'ratchet_failures':[],'valid_rows_per_role':0}
for suite,start,cells in [('yaml',209001,6),('compact-go',210001,6)]:
 paths={role:p/f'{role}-{suite}.txt' for role in ['baseline','candidate']};data={k:parse(v,start,cells) for k,v in paths.items()};summary=[]
 for seed in range(start,start+20):
  b,c=data['baseline'][seed],data['candidate'][seed];assert b['order']==c['order'];assert b['position']==1+(seed-start)%2 and c['position']==2-(seed-start)%2
  for name in b['rows']:
   x,y=b['rows'][name],c['rows'][name];assert x.keys()==y.keys()
   for metric in x.keys()-{'ns/op','B/op','allocs/op','MB/s'}:assert y[metric]==x[metric],(suite,seed,name,metric,x[metric],y[metric])
   if 'no_edit' in name or 'NoEdit' in name:assert x['B/op']==x['allocs/op']==y['B/op']==y['allocs/op']==0
 for name in data['baseline'][start]['order']:
  med={r:{m:statistics.median(data[r][s]['rows'][name][m] for s in range(start,start+20)) for m in ['ns/op','B/op','allocs/op']} for r in data}
  ratios={m:med['candidate'][m]/med['baseline'][m] if med['baseline'][m] else (1 if med['candidate'][m]==0 else float('inf')) for m in med['baseline']};fail=[m for m,v in ratios.items() if v>1.1]
  summary.append({'benchmark':name,'medians':med,'ratios':ratios,'ratchet_failures':fail})
  if fail:result['ratchet_failures'].append({'suite':suite,'benchmark':name,'metrics':fail})
 result['suites'][suite]={'matched_orders':True,'alternating_roles':True,'seed_range':[start,start+19],'rows_per_role':20*cells,'source_files_sha256':{r:hashlib.sha256(f.read_bytes()).hexdigest() for r,f in paths.items()},'results':summary};result['valid_rows_per_role']+=20*cells
 with (report/f'benchstat-{suite}.txt').open('w') as out:subprocess.run(['/home/draco/go/bin/benchstat',paths['baseline'].name,paths['candidate'].name],cwd=p,stdout=out,check=True)
result['all_timed_work_and_route_metrics_exact']=True
result['workload_exit_code']=int((p/'exit-code.txt').read_text().strip())
result['all_qualification_stages_complete']=(p/'complete.txt').exists()
(report/'independent-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'valid_rows_per_role':result['valid_rows_per_role'],'ratchet_failures':result['ratchet_failures']}))
