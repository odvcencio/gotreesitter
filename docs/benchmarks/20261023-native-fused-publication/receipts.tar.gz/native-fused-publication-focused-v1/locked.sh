set -u
date -u > /evidence/workload-started.txt
bash /evidence/focused.sh
result=$?
printf '%s\n' "$result" > /evidence/exit-code.txt
date -u > /evidence/workload-finished.txt
exit "$result"
