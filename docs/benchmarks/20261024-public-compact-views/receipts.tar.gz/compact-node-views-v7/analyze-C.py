from pathlib import Path
import json,re,statistics,hashlib
p=Path(__file__).parent/'comparison'
assert (p/'C-exit.txt').read_text().strip()=='0'
result={'protocol':'20 seeds per language; shuffled fixture/consume groups, Go-C-C-Go within every group; warm parser; parse, validate and release included','C_transport':'native C loop; static locked runtime in cgo binary, locked -O2 grammar shared object; no per-parse or per-node Go-to-C crossing','C_memory_limit':'Go allocation metrics exclude native C allocation and are not comparable as total allocation','qualification_limit':'Not the standalone-static publication protocol or a graduation receipt','languages':{}}
for lang,start in [('go',243001),('yaml',244001)]:
 f=p/f'C-{lang}.txt';t=f.read_text();assert t.rstrip().endswith('# status: complete')
 rows={};orders={};seed=None
 for line in t.splitlines():
  m=re.match(r'# seed: (\d+); position: (\d+)$',line)
  if m:seed=int(m[1]);assert seed not in rows;rows[seed]={};orders[seed]=[]
  elif line.startswith('Benchmark'):
   w=line.split()
   if len(w)<4 or not w[1].isdigit():continue
   name=re.sub(r'-\d+$','',w[0]);assert name not in rows[seed];assert int(w[1])>0
   rows[seed][name]={w[i+1]:float(w[i]) for i in range(2,len(w),2)};orders[seed].append(name)
  elif line.startswith('# workload order: '):assert line.split(': ',1)[1].split(',')==orders[seed]
 assert set(rows)==set(range(start,start+20))
 summaries=[];groups=set()
 for seed,order in orders.items():
  assert len(order)==16
  for i in range(0,16,4):
   group=order[i].rsplit('/',1)[0];groups.add(group)
   assert order[i:i+4]==[group+'/'+x for x in ['go1','c1','c2','go2']]
 assert len(groups)==4
 for group in sorted(groups):
  go=[];c=[];paired=[]
  for seed in range(start,start+20):
   g=statistics.mean(rows[seed][group+'/'+x]['ns/op'] for x in ['go1','go2']);n=statistics.mean(rows[seed][group+'/'+x]['ns/op'] for x in ['c1','c2']);go.append(g);c.append(n);paired.append(g/n)
  summaries.append({'fixture_mode':group.split('/',1)[1],'cycles':20,'Go_ns_median':statistics.median(go),'C_ns_median':statistics.median(c),'Go_over_C_paired_ratio_median':statistics.median(paired),'paired_ratio_min':min(paired),'paired_ratio_max':max(paired)})
 result['languages'][lang]={'seed_range':[start,start+19],'timing_rows':sum(len(r) for r in rows.values()),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'results':summaries}
(p.parent/'C-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['languages'],indent=2))
