set -euo pipefail
export GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -overlay=/controls/comparison-overlay.json'
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build CGO_ENABLED=1
trap 'printf "%s\n" "$?" > /evidence/C-exit.txt' EXIT
[[ -f /gate/correctness-complete.txt ]]
git config --global --add safe.directory /candidate
cd /candidate/cgo_harness
for lang in go yaml; do
 seed=243001; if [[ "$lang" == yaml ]]; then seed=244001; fi
 GTS_COMPARE_LANGUAGE="$lang" bash /candidate/scripts/run_randomized_benchmarks.sh --tags treesitter_c_parity,gts_parsercorephase0,gts_compact_node_views --bench-regex '^BenchmarkPublicCompactVsC$' --runs 20 --seed-start "$seed" --benchtime 750ms --output "/evidence/C-$lang.txt" --lock-path /evidence/C.lock > "/evidence/C-$lang-driver.log" 2>&1
done
printf 'complete\n' > /evidence/complete.txt
