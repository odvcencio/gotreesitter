from pathlib import Path
import json,re,statistics
p=Path(__file__).resolve().parent;d=p/'extra'
assert (d/'exit.txt').read_text().strip()=='0' and (d/'complete.txt').exists()
for file in ['emergency.log','386.log']:
 text=(d/file).read_text();assert 'ok  ' in text and 'FAIL' not in text
lines=(d/'cogno/status.tsv').read_text().splitlines();assert len(lines)==12
known=[]
for line in lines:
 name,code=line.split('\t');text=(d/'cogno'/f'{name}.log').read_text()
 assert text.count('D8 incremental/fresh Go and incremental/fresh C agree independently:')==1
 if name.endswith('-delete'):
  assert code=='1' and '/source_file/function_declaration[2]/block[4]/ERROR[1]' in text
  known.append(name)
 else:assert code=='0' and '\nPASS\n' in text and '--- FAIL' not in text
out={'Cognociente':{'independent_fresh_agreements':12,'clean_C_passes':8,'known_delete_C_failures':known},'cold_allocations':{},'ratchet_failures':[]}
for language in ['go','yaml']:
 rows={role:[] for role in ['baseline','candidate']}
 for seed in range(1,21):
  for role in rows:
   text=(d/'cold'/f'{role}-{language}-{seed}.log').read_text();assert '\nPASS\n' in text
   matches=re.findall(r'COLD (\{.*\})',text);assert len(matches)==1
   rows[role].append(json.loads(matches[0]))
  assert rows['baseline'][-1]['SourceHash']==rows['candidate'][-1]['SourceHash']
 keys=['OpenBytes','EditBytes','TotalBytes','OpenAllocs','EditAllocs','TotalAllocs']
 med={role:{k:statistics.median(r[k] for r in values) for k in keys} for role,values in rows.items()}
 ratios={k:med['candidate'][k]/med['baseline'][k] for k in keys}
 out['cold_allocations'][language]={'pairs':20,'medians':med,'ratios':ratios}
 for key in ['TotalBytes','TotalAllocs']:
  if ratios[key]>1.1:out['ratchet_failures'].append({'language':language,'metric':key,'ratio':ratios[key]})
(p/'extra-analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
