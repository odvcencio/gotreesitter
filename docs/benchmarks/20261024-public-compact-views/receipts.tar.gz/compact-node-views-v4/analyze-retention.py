from pathlib import Path
import json,re,statistics
p=Path(__file__).resolve().parent;d=p/'extra'
assert (d/'complete.txt').exists() and (d/'exit.txt').read_text().strip()=='0'
result={'scope':'public trees after producing parser collection; peak RSS includes full-output preflight and validation','results':{},'ratchet_failures':[]}
for language in ['go','yaml']:
 for operation in ['root','walk']:
  rows={role:[] for role in ['baseline','candidate']}
  for seed in range(1,21):
   values={}
   for role in rows:
    label=f'{role}-{language}-{operation}-{seed}'
    text=(d/'heap'/f'{label}.log').read_text();assert '\nPASS\n' in text and '--- FAIL' not in text
    raw=re.findall(r'RETENTION (\{.*\})',text);assert len(raw)==1
    row=json.loads(raw[0]);row['retained_delta']=row['LiveHeap']-row['BeforeHeap'];row['released_delta']=row['ReleasedHeap']-row['BeforeHeap']
    assert row['retained_delta']>0 and abs(row['released_delta'])<1048576
    rss=(d/'heap'/f'{label}.rss').read_text();assert re.search(r'Exit status: 0',rss)
    row['max_rss_kib']=int(re.search(r'Maximum resident set size \(kbytes\): (\d+)',rss)[1])
    values[role]=row;rows[role].append(row)
   for k in ['SourceBytes','SourceHash','Digest']:assert values['baseline'][k]==values['candidate'][k],(language,operation,seed,k)
   assert abs(values['baseline']['Nodes']-values['candidate']['Nodes'])<=1
  keys=['retained_delta','released_delta','max_rss_kib','ArenaBytes','SourceBytes','Nodes']
  med={role:{k:statistics.median(row[k] for row in items) for k in keys} for role,items in rows.items()}
  ratios={k:med['candidate'][k]/med['baseline'][k] for k in ['retained_delta','max_rss_kib']}
  name=language+'-'+operation
  result['results'][name]={'pairs':20,'medians':med,'ratios':ratios,'source_sha256':bytes(rows['baseline'][0]['SourceHash']).hex(),'digest':rows['baseline'][0]['Digest']}
  if ratios['max_rss_kib']>1.1:result['ratchet_failures'].append({'case':name,'metric':'max_rss_kib','ratio':ratios['max_rss_kib']})
  if med['candidate']['max_rss_kib']*1024/med['candidate']['SourceBytes']>400:result['ratchet_failures'].append({'case':name,'metric':'400-bytes/source-byte'})
(p/'retention-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
