set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOFLAGS='-p=1 -mod=readonly -overlay=/controls/perf-overlay.json' GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/exit.txt' EXIT
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
for role in baseline candidate; do
 cd "/$role"
 go test -c -tags gts_parsercorephase0,gts_compact_node_views -o "/evidence/$role.test" . > "/evidence/$role-build.log" 2>&1
 for op in parse walk; do
  GTS_COMPARE_LANGUAGE=yaml GTS_BENCHMARK_SEED=259001 "/evidence/$role.test" -test.run '^$' -test.bench "^BenchmarkCompactPublicOutput$/^eof8k_$op$" -test.benchtime=5s -test.count=1 -test.cpuprofile="/evidence/$role-$op.cpu" > "/evidence/$role-$op.log" 2>&1
  go tool pprof -top -nodecount=50 "/evidence/$role.test" "/evidence/$role-$op.cpu" > "/evidence/$role-$op-top.txt"
 done
 done
printf 'complete\n' > /evidence/complete.txt
