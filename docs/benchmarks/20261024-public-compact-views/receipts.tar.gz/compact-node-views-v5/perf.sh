set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOFLAGS='-p=1 -mod=readonly -overlay=/controls/perf-overlay.json' GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/exit.txt; date -u +%FT%TZ > /evidence/finished.txt' EXIT
[[ -f /gate/correctness-complete.txt ]] || { echo 'correctness and counter qualification incomplete'; exit 2; }
date -u +%FT%TZ > /evidence/started.txt
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
for lang in go yaml; do
 GTS_COMPARE_LANGUAGE="$lang" bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output "/evidence/baseline-$lang.txt" --output "/evidence/candidate-$lang.txt" --runs 20 --seed-start 257001 --benchtime 750ms --tags gts_parsercorephase0,gts_compact_node_views --bench-regex '^BenchmarkCompactPublicOutput$' --lock-path /evidence/perf.lock > "/evidence/$lang-driver.log" 2>&1
done
cp /controls/benchmark_primary_overlay.go.txt /evidence/prepare-primary.go
go run /evidence/prepare-primary.go /controls/benchmark_primary_go_suite.go.txt /evidence/primary-overlay.json /baseline /candidate > /evidence/primary-hashes.txt
python3 - <<'PYSCRIPT'
from pathlib import Path
import json
p=Path('/evidence/primary-overlay.json');d=json.loads(p.read_text());d['Replace'].update(json.loads(Path('/controls/overlay.json').read_text())['Replace']);p.write_text(json.dumps(d,indent=2)+'\n')
PYSCRIPT
GOFLAGS='-p=1 -mod=readonly -overlay=/evidence/primary-overlay.json' GTS_ADMISSION_CANDIDATE=1 bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-primary.txt --output /evidence/candidate-primary.txt --runs 20 --seed-start 258001 --benchtime 750ms --tags gts_parsercorephase0,gts_compact_node_views --bench-regex '^BenchmarkGTSSeededPrimary$' --require-benchmarks 'BenchmarkGTSSeededPrimary/BenchmarkGoParseFullDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalNoEditDFA' --lock-path /evidence/perf.lock > /evidence/primary-driver.log 2>&1
GOFLAGS='-p=1 -mod=readonly -overlay=/evidence/primary-overlay.json' GTS_ADMISSION_CANDIDATE=0 bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-default-primary.txt --output /evidence/candidate-default-primary.txt --runs 20 --seed-start 258101 --benchtime 750ms --tags gts_parsercorephase0,gts_compact_node_views --bench-regex '^BenchmarkGTSSeededPrimary$' --require-benchmarks 'BenchmarkGTSSeededPrimary/BenchmarkGoParseFullDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalNoEditDFA' --lock-path /evidence/perf.lock > /evidence/default-primary-driver.log 2>&1
for lang in go yaml; do
 GOFLAGS='-p=1 -mod=readonly -overlay=/controls/legacy-read-overlay.json' GTS_COMPARE_LANGUAGE="$lang" bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output "/evidence/baseline-legacy-$lang.txt" --output "/evidence/candidate-legacy-$lang.txt" --runs 20 --seed-start 258201 --benchtime 750ms --tags gts_parsercorephase0,gts_compact_node_views --bench-regex '^BenchmarkCompactLegacyReadControls$' --lock-path /evidence/perf.lock > "/evidence/legacy-$lang-driver.log" 2>&1
 done
printf 'complete\n' > /evidence/complete.txt
