set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOFLAGS='-p=1 -mod=readonly -overlay=/controls/perf-overlay.json' GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/exit.txt' EXIT
[[ -f /gate/correctness-complete.txt ]]
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
for lang in go yaml; do
 GTS_COMPARE_LANGUAGE="$lang" bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output "/evidence/baseline-$lang.txt" --output "/evidence/candidate-$lang.txt" --runs 2 --seed-start 259001 --benchtime 750ms --tags gts_parsercorephase0,gts_compact_node_views --bench-regex '^BenchmarkCompactPublicOutput$' --lock-path /evidence/perf.lock > "/evidence/$lang-driver.log" 2>&1
done
printf 'complete\n' > /evidence/complete.txt
