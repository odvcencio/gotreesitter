from pathlib import Path
import hashlib,json,tarfile,shutil
p=Path(__file__).resolve().parent;root=p.parent
out=Path('/home/draco/work/gotreesitter/docs/benchmarks/20261024-public-compact-views')
assert (p/'measurements/complete.txt').exists()
assert (p/'measurements/exit.txt').read_text().strip()=='0'
assert (p/'extra-resume/complete.txt').exists()
assert (p/'extra-resume/exit.txt').read_text().strip()=='0'
for name in ['correctness-analysis.json','performance-analysis.json','retention-analysis.json']:assert (p/name).exists()
files=[]
for version in range(1,6):
 for f in sorted((root/f'compact-node-views-v{version}').rglob('*')):
  if not f.is_file() or '__pycache__' in f.parts or f.name=='receipt-manifest.json':continue
  with f.open('rb') as stream:
   if stream.read(4)==b'\x7fELF':continue
  files.append(f)
manifest={str(f.relative_to(root)):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files}
(p/'receipt-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'receipts.tar.gz','w:gz') as tar:
 for f in files+[p/'receipt-manifest.json']:tar.add(f,arcname=str(f.relative_to(root)),recursive=False)
for name in ['correctness-analysis.json','performance-analysis.json','retention-analysis.json','qualification.json','source-manifest.json','inherited-qualification.json']:
 shutil.copyfile(p/name,out/name)
for f in (p/'measurements').glob('benchstat-*.txt'):shutil.copyfile(f,out/f.name)
with tarfile.open(out/'receipts.tar.gz') as tar:
 for name,item in manifest.items():
  data=tar.extractfile(name).read();assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
print(json.dumps({'files':len(files),'archive_bytes':(out/'receipts.tar.gz').stat().st_size,'sha256':hashlib.sha256((out/'receipts.tar.gz').read_bytes()).hexdigest()}))
