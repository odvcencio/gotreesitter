set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOFLAGS='-p=1 -mod=readonly -overlay=/controls/overlay.json' GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/exit.txt; date -u +%FT%TZ > /evidence/finished.txt' EXIT
[[ -f /gate/correctness-complete.txt ]] || { echo 'qualification incomplete'; exit 2; }
date -u +%FT%TZ > /evidence/started.txt
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
mkdir -p /evidence/cogno /evidence/heap
cd /candidate/cgo_harness
go test -c -overlay=/controls/cogno-overlay-fixed.json -tags treesitter_c_parity,gts_parsercorephase0,gts_compact_node_views -o /evidence/cogno.test . > /evidence/cogno/build.log 2>&1
for route in production candidate; do
 for api in plain profiled; do
  for edit in insert replace delete; do
   label="$route-$api-$edit"
   if /evidence/cogno.test -test.run "^TestGoCognociente137KiBTopEditLockedC$/^$route$/^$api$/^$edit$" -test.v -test.count=1 -test.timeout=5m > "/evidence/cogno/$label.log" 2>&1; then code=0; else code=$?; fi
   printf '%s\t%s\n' "$label" "$code" >> /evidence/cogno/status.tsv
   if [[ "$edit" != delete && "$code" != 0 ]]; then exit "$code"; fi
  done
 done
done
for role in baseline candidate; do
 cd "/$role"
 go test -c -overlay=/controls/retention-overlay.json -tags gts_parsercorephase0,gts_compact_node_views -o "/evidence/$role-heap.test" . > "/evidence/$role-heap-build.log" 2>&1
done
mkdir -p /evidence/cold
for lang in go yaml; do
 for seed in $(seq 1 20); do
  roles='baseline candidate'; if (( seed % 2 )); then roles='candidate baseline'; fi
  for role in $roles; do
   cd "/$role"
   GTS_COMPARE_LANGUAGE="$lang" "/evidence/$role-heap.test" -test.run '^TestCompactPublicFirstOpenEditAllocations$' -test.count=1 -test.v -test.timeout=5m > "/evidence/cold/$role-$lang-$seed.log" 2>&1
  done
 done
 done
for lang in go yaml; do
 for operation in root walk; do
  for seed in $(seq 1 20); do
   roles='baseline candidate'; if (( seed % 2 )); then roles='candidate baseline'; fi
   for role in $roles; do
    cd "/$role"
    GTS_COMPARE_LANGUAGE="$lang" GTS_VIEW_OPERATION="$operation" /usr/bin/time -v -o "/evidence/heap/$role-$lang-$operation-$seed.rss" "/evidence/$role-heap.test" -test.run '^TestCompactPublicRetainedHeap$' -test.count=1 -test.v -test.timeout=5m > "/evidence/heap/$role-$lang-$operation-$seed.log" 2>&1
   done
  done
 done
done
cd /candidate
go test -c -overlay=/controls/perf-overlay.json -tags gts_parsercorephase0,gts_compact_node_views -o /evidence/profile.test . > /evidence/profile-build.log 2>&1
for lang in go yaml; do
 fixture=grammargen_lr_parse; if [[ "$lang" == yaml ]]; then fixture=eof8k_parse; fi
 GTS_COMPARE_LANGUAGE="$lang" GTS_BENCHMARK_SEED=257001 /evidence/profile.test -test.run '^$' -test.bench "^BenchmarkCompactPublicOutput$/^$fixture$" -test.benchtime=8s -test.count=1 -test.cpuprofile="/evidence/$lang.cpu" > "/evidence/$lang-profile.log" 2>&1
 go tool pprof -top -nodecount=40 /evidence/profile.test "/evidence/$lang.cpu" > "/evidence/$lang-profile-top.txt"
done
printf 'complete\n' > /evidence/complete.txt
