set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOFLAGS='-p=1 -mod=readonly -overlay=/controls/overlay.json' GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/exit.txt; date -u +%FT%TZ > /evidence/finished.txt' EXIT
date -u +%FT%TZ > /evidence/started.txt
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
go test ./internal/parsercorephase0 -count=1 -timeout=6m > /evidence/core.log 2>&1
go test -c -tags gts_parsercorephase0,gts_compact_node_views -o /evidence/candidate.test . > /evidence/build.log 2>&1
/evidence/candidate.test -test.run '^Test(NativeNodeViews|NodeViewArena)' -test.count=1 -test.v -test.timeout=5m > /evidence/views.log 2>&1
/evidence/candidate.test -test.run '^Test(CompactAcceptance(ChangedSourceKeepsRebuildBudget|CachedPublicationStopControl)|CompactMemoryBudgetDetectsGrowthAfterSmallPoll|CompactAcceptance.*(MemoryBudget|RetentionBound)|CompactArenaReserve.*(Budget|RetentionCap)|CompactExternalScannerCheckpointCopyMemoryBudget|CompactRecoveryMemoMemoryBudget|CompactBorrowedMaterializationProjectionMemoryBudget|G18RefSetSchedulerMemoryBudgetAccounting|RuntimeMemoryBudget.*|RuntimeMemoryHardCeilingStillStopsParse|ParseMemoryHardCeiling.*)$' -test.count=1 -test.v -test.timeout=8m > /evidence/memory.log 2>&1
for role in baseline candidate; do
 cd "/$role"
 go test -c -overlay=/controls/work-overlay.json -tags gts_parsercorephase0,gts_compact_node_views,gts_workcount -o "/evidence/$role-work.test" . > "/evidence/$role-work-build.log" 2>&1
 go build -tags gts_parsercorephase0,gts_compact_node_views -o "/evidence/$role-ledger" ./cmd/perfcounterledger > "/evidence/$role-ledger-build.log" 2>&1
done
mkdir -p /evidence/invariants /evidence/cgo /evidence/work /evidence/ledger /evidence/counter-deltas
for lang in go yaml; do
 cd /candidate
 GTS_ADMISSION_CANDIDATE=1 GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /evidence/candidate.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/invariants/1-$lang.log" 2>&1
 for role in baseline candidate; do
  cd "/$role"
  GTS_WORK_LANGUAGE="$lang" "/evidence/$role-work.test" -test.run '^TestDirectReductionWork$' -test.count=1 -test.timeout=5m > "/evidence/work/$role-$lang.log" 2>&1
  "/evidence/$role-ledger" --langs "$lang" > "/evidence/ledger/$role-$lang.json" 2> "/evidence/ledger/$role-$lang.log"
 done
 python3 /controls/compare-ledger.py "/evidence/ledger/baseline-$lang.json" "/evidence/ledger/candidate-$lang.json" "/evidence/counter-deltas/$lang.json" > "/evidence/counter-deltas/$lang.log"
done
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0,gts_compact_node_views -o /evidence/candidate-cgo.test . > /evidence/cgo-build.log 2>&1
for lang in go yaml; do
 GTS_ADMISSION_CANDIDATE=1 GTS_ADMISSION_REAL_CORPUS_LANGS="$lang" /evidence/candidate-cgo.test -test.run '^TestCompactR4StructuralLockedC$' -test.count=1 -test.v -test.timeout=5m > "/evidence/cgo/r4-$lang.log" 2>&1
done
/evidence/candidate-cgo.test -test.run '^TestCanonicalGoBenchmarkPreflight$' -test.count=1 -test.v -test.timeout=5m > /evidence/cgo/go-canonical.log 2>&1
GTS_YAML_LARGE_PROBE=1 /evidence/candidate-cgo.test -test.run '^Test(YAMLOwnedGrammarLockedCParity|CompactYAMLDocumentStreamLockedC|YAMLRecoveredMappingQuotesLockedC|YAMLEOFRecoverWrapCompactRoute|YAMLEOFRecoverWrapUnfinishedMappingDeclinesCompact|YAMLOneBytePrintableEOFAdmissionMatchesLockedC)$' -test.count=1 -test.v -test.timeout=8m > /evidence/cgo/yaml-focused.log 2>&1
printf 'complete\n' > /evidence/focused-complete.txt
cd /candidate
go test -race -tags gts_parsercorephase0,gts_compact_node_views -run '^Test(NativeNodeViews|NodeViewArena)' -count=1 -timeout=8m . > /evidence/race.log 2>&1
go test -race ./internal/parsercorephase0 -run '^Test(NativeSelected|SelectedStore)' -count=1 -timeout=5m > /evidence/core-race.log 2>&1
while IFS= read -r lang; do
 cd /candidate
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /evidence/candidate.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/invariants/$route-$lang.log" 2>&1
 done
 cd /candidate/cgo_harness
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GTS_PARITY_MODE=exhaustive /evidence/candidate-cgo.test -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${lang}$" -test.count=1 -test.v -test.timeout=5m > "/evidence/cgo/$route-$lang.log" 2>&1
 done
 if [[ "$lang" != go && "$lang" != yaml ]]; then
  for role in baseline candidate; do
   cd "/$role"
   GTS_WORK_LANGUAGE="$lang" "/evidence/$role-work.test" -test.run '^TestDirectReductionWork$' -test.count=1 -test.timeout=5m > "/evidence/work/$role-$lang.log" 2>&1
   "/evidence/$role-ledger" --langs "$lang" > "/evidence/ledger/$role-$lang.json" 2> "/evidence/ledger/$role-$lang.log"
  done
  python3 /controls/compare-ledger.py "/evidence/ledger/baseline-$lang.json" "/evidence/ledger/candidate-$lang.json" "/evidence/counter-deltas/$lang.json" > "/evidence/counter-deltas/$lang.log"
 fi
 printf '%s\n' "$lang" >> /evidence/progress.txt
done < <(printf '%s\n' go yaml)
python3 /controls/compare-work.py > /evidence/work-comparison.log
printf 'complete\n' > /evidence/correctness-complete.txt
