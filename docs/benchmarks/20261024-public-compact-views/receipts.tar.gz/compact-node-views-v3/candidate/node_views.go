package gotreesitter

// Views begin with a small header slab. They retain the ordinary full-tree
// growth and eviction limits once callers actually visit the whole tree.
// A separate pool avoids inheriting a large eager parse's unused reserve.
var nodeViewArenaPool = nodeArenaPool{class: arenaClassFull, maxSize: 4}

func acquireNodeViewArena() *nodeArena {
	p := &nodeViewArenaPool
	p.mu.Lock()
	var arena *nodeArena
	if n := len(p.free); n != 0 {
		arena = p.free[n-1]
		p.free = p.free[:n-1]
	}
	p.mu.Unlock()
	if arena == nil {
		arena = &nodeArena{class: arenaClassFull, viewArena: true, nodes: make([]Node, minArenaNodeCap)}
		arena.recomputeAllocatedBytes()
		if arenaProfileEnabled {
			arenaProfileData.FullNew++
		}
	}
	if arenaProfileEnabled {
		arenaProfileData.FullAcquire++
	}
	arena.refs.Store(1)
	arena.breakdownEnabled = arenaBreakdownEnabled.Load()
	arena.clearBudget()
	arena.audit = nil
	return arena
}

// nodeViewBacking is the adapter boundary between indexed syntax and the
// public pointer API. Reading creates stable views; mutation first restores
// the complete arena representation, including its reuse receipts.
type nodeViewBacking interface {
	childCount(*Node) int
	namedChildCount(*Node) int
	namedChild(*Node, int) *Node
	child(*Node, int) *Node
	children(*Node) []*Node
	parent(*Node) (*Node, int, bool)
	supertype(*Node) uint32
	executeQuery(*Query, *Node, *Language, []byte, []QueryMatch) ([]QueryMatch, bool)
	equalTree(*Node, *Node, *Language) bool
	copyTree(*Tree) *Tree
	retainedBytes() uint64
	materialize()
	release()
}

func nodeViews(n *Node) nodeViewBacking {
	if n == nil || n.ownerArena == nil {
		return nil
	}
	return n.ownerArena.views
}

func materializeNodeViews(n *Node) {
	if views := nodeViews(n); views != nil {
		views.materialize()
	}
}
