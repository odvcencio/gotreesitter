package gotreesitter

// nodeViewBacking is the adapter boundary between indexed syntax and the
// public pointer API. Reading creates stable views; mutation first restores
// the complete arena representation, including its reuse receipts.
type nodeViewBacking interface {
	childCount(*Node) int
	namedChildCount(*Node) int
	namedChild(*Node, int) *Node
	child(*Node, int) *Node
	children(*Node) []*Node
	parent(*Node) (*Node, int, bool)
	supertype(*Node) uint32
	executeQuery(*Query, *Node, *Language, []byte, []QueryMatch) ([]QueryMatch, bool)
	equalTree(*Node, *Node, *Language) bool
	copyTree(*Tree) *Tree
	retainedBytes() uint64
	materialize()
	release()
}

func nodeViews(n *Node) nodeViewBacking {
	if n == nil || n.ownerArena == nil {
		return nil
	}
	return n.ownerArena.views
}

func materializeNodeViews(n *Node) {
	if views := nodeViews(n); views != nil {
		views.materialize()
	}
}
