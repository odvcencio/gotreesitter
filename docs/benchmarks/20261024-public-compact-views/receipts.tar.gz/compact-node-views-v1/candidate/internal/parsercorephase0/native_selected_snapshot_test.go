package parsercorephase0

import "testing"

func TestNativeSelectedSnapshotOwnsReplay(t *testing.T) {
	c, root, replay, scratch := nativeSelectedFixture(t)
	snapshot, err := c.BuildNativeSelectedSnapshot([]SubtreeID{root}, []byte("x"), replay, scratch, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer snapshot.Release()
	id := snapshot.Store().Root()
	before, symbol, ok := snapshot.Record(id)
	if !ok || !before.ReplayPreKnown() || !before.ReplayStateKnown() || symbol != before.Symbol {
		t.Fatalf("missing replay: %+v", before)
	}
	if cap(scratch.replay) != 0 {
		t.Fatal("producer still owns replay backing")
	}
	second, err := c.BuildNativeSelectedSnapshot([]SubtreeID{root}, []byte("x"), replay, scratch, nil)
	if err != nil {
		t.Fatal(err)
	}
	second.Release()
	if err = c.Reset(); err != nil {
		t.Fatal(err)
	}
	after, _, ok := snapshot.Record(id)
	if !ok || before != after {
		t.Fatal("producer reuse changed replay proof")
	}
	if snapshot.RetainedBytes() <= snapshot.Store().RetainedBytes() {
		t.Fatal("replay bytes not accounted")
	}
	snapshot.Release()
	if _, _, ok = snapshot.Record(id); ok {
		t.Fatal("released snapshot is readable")
	}
	if snapshot.RetainedBytes() != 0 {
		t.Fatal("release retained backing")
	}
}
