//go:build !gts_compact_node_views && !gts_no_parsercorephase0

package gotreesitter

const compactNodeViewsEnabled = false
