//go:build gts_compact_node_views && !gts_no_parsercorephase0

package gotreesitter

// Qualification switch: ordinary parsing uses the complete public adapter,
// including indexed queries and the exclusive mutation boundary.
const compactNodeViewsEnabled = true
