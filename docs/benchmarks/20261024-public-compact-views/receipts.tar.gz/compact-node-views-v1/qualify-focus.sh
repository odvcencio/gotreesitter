set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOFLAGS='-p=1 -mod=readonly' GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/exit.txt' EXIT
git config --global --add safe.directory /candidate
cd /candidate
go test ./internal/parsercorephase0 -count=1 -timeout=6m > /evidence/core.log 2>&1
go test -c -tags gts_parsercorephase0,gts_compact_node_views -o /evidence/views.test . > /evidence/build.log 2>&1
/evidence/views.test -test.run '^TestNativeNodeViews' -test.count=1 -test.v -test.timeout=5m > /evidence/views.log 2>&1
for lang in go yaml; do
 GTS_ADMISSION_CANDIDATE=1 GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /evidence/views.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/invariants-$lang.log" 2>&1
done
go test -race -tags gts_parsercorephase0,gts_compact_node_views -run '^TestNativeNodeViews' -count=1 -timeout=5m . > /evidence/race.log 2>&1
