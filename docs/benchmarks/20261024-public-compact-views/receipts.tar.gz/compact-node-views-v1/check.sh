set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOFLAGS='-p=1 -mod=readonly' GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/exit.txt' EXIT
git config --global --add safe.directory /candidate
cd /candidate
go test ./internal/parsercorephase0 -run '^TestNativeSelected' -count=1 -v -timeout=5m > /evidence/core.log 2>&1
go test -tags gts_parsercorephase0 -run '^TestNativeNodeViews' -count=1 -v -timeout=5m . > /evidence/views.log 2>&1
