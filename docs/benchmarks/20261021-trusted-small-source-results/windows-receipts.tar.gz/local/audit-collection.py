from pathlib import Path
import json,hashlib
lab=Path('/home/draco/.local/state/gotreesitter-evidence/20261021-small-input-verification/clean-transfer-runtime-v4/native-windows-v1');win=Path('/mnt/c/Users/odvce/.local/state/gotreesitter-compute/20261021-native-windows')
seeds=list(range(140001,140016))+list(range(140022,140027))
required=set(json.loads((lab/'protocol.json').read_text())['required_benchmarks'])
post=json.loads((win/'raw/source-postcheck.stdout.json').read_text(encoding='utf-8-sig'))
assert post['goos']=='windows' and post['goarch']=='amd64' and post['go_version']=='go1.27.0'
binary_hashes={'baseline':'e0ece194ce06f9df3853289fb4c95c00978a41e6b29cadf3ca4c32725c265dca','candidate':'86cf5ae696f0fba0f9321d8b7d7cdce18cc9e81138e2e084bec6ea7a439ede85'}
for role,count in [('baseline',4331),('candidate',4332)]:assert post[role]['source_unchanged'] and post[role]['files']==count and post[role]['binary_sha256']==binary_hashes[role]
assert (win/'raw/source-postcheck.stderr.txt').read_bytes()==b''
source_receipt=json.loads((win/'raw/source-postcheck.receipt.json').read_text(encoding='utf-8-sig'));assert source_receipt['exit_code']==0
records={};orders={};rows_by_role={};hashes={}
for role in ['baseline','candidate']:
 aggregate=['# Authenticated native Windows Go1.27.0 data, D64 versus held V4.\n','# 15 initial and 5 new correctly ordered replacement pairs; failed transport and wrong-order batch retained separately.\n']
 for seed in seeds:
  stem=f'{role}-{seed}';raw=(win/'raw'/(stem+'.stdout.txt')).read_bytes();text=raw.decode();rows=[s for s in text.splitlines() if s.startswith('BenchmarkCognocienteGo137KiBSuite/')]
  assert len(rows)==9 and {s.split()[0] for s in rows}==required,(role,seed,'required set')
  assert '\nPASS\n' in text and 'goos: windows' in text and 'goarch: amd64' in text,(role,seed,'native pass')
  assert all(all(unit in r.split() for unit in ['ns/op','B/op','allocs/op']) for r in rows),(role,seed,'metrics')
  d=json.loads((win/'raw'/(stem+'.receipt.json')).read_text(encoding='utf-8-sig'))
  assert d['kind']=='sample' and d['role']==role and d['seed']==seed and d['exit_code']==0,(role,seed,'receipt identity')
  assert d['gomaxprocs']=='1' and d['processor_affinity']==128 and d['process_architecture']==d['os_architecture']=='X64',(role,seed,'stable settings')
  assert all(not d[k] for k in ['gogc','gomemlimit','node_limit_scale','glr_max_stacks']),(role,seed,'runtime override')
  args=d['arguments'];assert all(a in args for a in ['-test.count=1','-test.benchtime=750ms','-test.benchmem','-test.run=^$',f'-test.shuffle={seed}']),(role,seed,'test flags')
  assert (win/'raw'/(stem+'.stderr.txt')).read_bytes()==b'',(role,seed,'stderr')
  records[role,seed]=d;orders[role,seed]=[s.split()[0] for s in rows];hashes[stem]=hashlib.sha256(raw).hexdigest()
  if seed==seeds[0]:aggregate.extend(s+'\n' for s in text.splitlines() if s.startswith(('goos:','goarch:','pkg:','cpu:')))
  aggregate.append(f'# seed: {seed}\n');aggregate.extend(r+'\n' for r in rows)
 rows_by_role[role]=''.join(aggregate)
for index,seed in enumerate(seeds):
 assert orders['baseline',seed]==orders['candidate',seed],(seed,'child order')
 first='baseline' if index%2==0 else 'candidate';second='candidate' if first=='baseline' else 'baseline'
 assert first==('baseline' if seed%2 else 'candidate'),(seed,'absolute seed parity')
 assert records[first,seed]['finished_utc']<=records[second,seed]['started_utc'],(seed,'within-pair overlap/order')
 if index:
  old=seeds[index-1];oldlast='candidate' if (index-1)%2==0 else 'baseline'
  assert records[oldlast,old]['finished_utc']<=records[first,seed]['started_utc'],(seed,'cross-pair overlap')
for role,out in [('baseline','aggregate-before.txt'),('candidate','aggregate-after.txt')]:
 (lab/out).write_text(rows_by_role[role])
receipts={f'{role}-{seed}':d for (role,seed),d in records.items()}
audit={'passed':True,'pairs':20,'seeds':seeds,'analyzed_native_benchmark_processes':40,'additional_wrong_order_pairs_retained':5,'rows_per_variant':180,'matched_workload_order':True,'global_revision_order_alternates':True,'no_native_benchmark_process_overlap':True,'native_windows_amd64':True,'post_source_and_binary_audit':post,'postcheck_receipt':source_receipt,'raw_stdout_sha256':hashes,'selected_receipts':receipts,'exclusion_rule':'All five incorrectly inverted-role resume pairs140016..140020 are excluded on order metadata, before statistical comparison. Five new explicit seeds140022..140026 restore normal runner parity and global alternation. No successful sample was rerun; all excluded raw data retained.','comparison':'D64 runtime versus held V4, exact October21Cogno source; not v0.55.1-v0.56.0 and not WindowsARM64','owner_approval':False,'runtime_promoted':False}
(lab/'collection-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps({'passed':True,'pairs':20,'rows_per_variant':180,'sources_unchanged':True,'native_windows_amd64':True,'excluded_pairs_preserved':5}))
