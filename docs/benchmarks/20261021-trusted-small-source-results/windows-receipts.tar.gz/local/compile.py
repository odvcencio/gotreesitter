#!/usr/bin/env python3
from pathlib import Path
import json,subprocess,sys,hashlib
root=Path('/mnt/c/Users/odvce/.local/state/gotreesitter-compute/20261021-native-windows')
lab=Path('/home/draco/.local/state/gotreesitter-evidence/20261021-small-input-verification/clean-transfer-runtime-v4/native-windows-v1')
ps='/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe'
def w(p):
 p=Path(p).resolve();s=str(p)
 if not s.startswith('/mnt/c/'):raise RuntimeError('path outside private C-drive workspace')
 return 'C:\\'+s[len('/mnt/c/'):].replace('/','\\')
for role in (sys.argv[1:] or ['baseline','candidate']):
 assert role in ['baseline','candidate'] and (lab/(role+'-source-manifest.json')).is_file()
 cfg={'kind':'compile','role':role,'seed':0,'program':'C:\\Program Files\\Go\\bin\\go.exe','arguments':['test','-c','-tags','gts_parsercorephase0','-o',w(root/'binaries'/(role+'.test.exe')),'.'],'working_directory':w(root/role),'stdout':w(root/'raw'/(role+'-compile.stdout.txt')),'stderr':w(root/'raw'/(role+'-compile.stderr.txt')),'receipt':w(root/'raw'/(role+'-compile-receipt.json'))}
 path=root/'configs'/(role+'-compile.json');path.write_text(json.dumps(cfg,indent=2)+'\n')
 result=subprocess.run([ps,'-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',w(root/'driver.ps1'),'-ConfigPath',w(path)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (lab/(role+'-powershell-launch.log')).write_bytes(result.stdout)
 for suffix in ['stdout.txt','stderr.txt']:
  src=root/'raw'/(role+'-compile.'+suffix)
  if src.exists():(lab/(role+'-compile.'+suffix)).write_bytes(src.read_bytes())
 if result.returncode:
  print(json.dumps({'role':role,'exit':result.returncode,'powershell_output':result.stdout.decode(errors='replace')[-1000:]}),flush=True);sys.exit(result.returncode)
 receipt=json.loads((root/'raw'/(role+'-compile-receipt.json')).read_text(encoding='utf-8-sig'))
 assert receipt['exit_code']==0 and receipt['process_architecture']=='X64' and receipt['os_architecture']=='X64'
 binary=root/'binaries'/(role+'.test.exe');assert binary.read_bytes()[:2]==b'MZ'
 (lab/(role+'-compile-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({'compiled':role,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'native_windows_amd64':True}),flush=True)
if all((lab/(role+'-compile-receipt.json')).is_file() for role in ['baseline','candidate']):(lab/'compile-complete.txt').write_text('complete\n')
