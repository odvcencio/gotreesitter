package main
import (
 "crypto/sha256"
 "encoding/hex"
 "encoding/json"
 "fmt"
 "io"
 "os"
 "path/filepath"
 "runtime"
)
type entry struct { Bytes int64 `json:"bytes"`; SHA256 string `json:"sha256"` }
func digest(path string)(string,int64,error){f,err:=os.Open(path);if err!=nil{return "",0,err};defer f.Close();h:=sha256.New();n,err:=io.Copy(h,f);return hex.EncodeToString(h.Sum(nil)),n,err}
func main(){
 root:="C:/Users/odvce/.local/state/gotreesitter-compute/20261021-native-windows"
 result:=map[string]any{"goos":runtime.GOOS,"goarch":runtime.GOARCH,"go_version":runtime.Version()}
 for _,role:=range []string{"baseline","candidate"}{
  data,err:=os.ReadFile(filepath.Join(root,role+"-expected-manifest.json"));if err!=nil{panic(err)}
  var expected map[string]entry;if err=json.Unmarshal(data,&expected);err!=nil{panic(err)}
  actual:=0
  err=filepath.WalkDir(filepath.Join(root,role),func(path string,d os.DirEntry,e error)error{
   if e!=nil{return e};if d.IsDir(){return nil};if !d.Type().IsRegular(){return fmt.Errorf("nonregular source %s",path)}
   rel,e:=filepath.Rel(filepath.Join(root,role),path);if e!=nil{return e};rel=filepath.ToSlash(rel)
   want,ok:=expected[rel];if !ok{return fmt.Errorf("unexpected source file %s",rel)}
   hash,n,e:=digest(path);if e!=nil{return e};if hash!=want.SHA256||n!=want.Bytes{return fmt.Errorf("source changed %s",rel)};actual++;return nil
  });if err!=nil{panic(err)};if actual!=len(expected){panic("source file count changed")}
  binary,_,err:=digest(filepath.Join(root,"binaries",role+".test.exe"));if err!=nil{panic(err)}
  result[role]=map[string]any{"source_unchanged":true,"files":actual,"binary_sha256":binary}
 }
 if err:=json.NewEncoder(os.Stdout).Encode(result);err!=nil{panic(err)}
}
