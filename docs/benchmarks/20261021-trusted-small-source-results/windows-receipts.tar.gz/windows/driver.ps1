param([Parameter(Mandatory=$true)][string]$ConfigPath)
$ErrorActionPreference = 'Stop'
$cfg = Get-Content -Raw -LiteralPath $ConfigPath | ConvertFrom-Json
$root = 'C:\Users\odvce\.local\state\gotreesitter-compute\20261021-native-windows'
$env:GOMAXPROCS = '1'
$env:GOWORK = 'off'
$env:GOTOOLCHAIN = 'local'
$env:CGO_ENABLED = '0'
$env:GOFLAGS = '-p=1 -mod=readonly -buildvcs=false'
$env:GOCACHE = "$root\cache\build"
$env:GOMODCACHE = "$root\cache\gomod"
$env:GTS_BENCHMARK_SEED = [string]$cfg.seed
$env:GTS_ADMISSION_CANDIDATE = '0'
$mask = [long]1 -shl ([Math]::Min(7, [Environment]::ProcessorCount - 1))
(Get-Process -Id $PID).ProcessorAffinity = [IntPtr]$mask
$started = [DateTime]::UtcNow.ToString('o')
$proc = Start-Process -FilePath $cfg.program -ArgumentList $cfg.arguments -WorkingDirectory $cfg.working_directory -RedirectStandardOutput $cfg.stdout -RedirectStandardError $cfg.stderr -Wait -PassThru -NoNewWindow
$code = $proc.ExitCode
$record = [ordered]@{
 kind=$cfg.kind; role=$cfg.role; seed=$cfg.seed; program=$cfg.program;
 arguments=$cfg.arguments; working_directory=$cfg.working_directory;
 started_utc=$started; finished_utc=[DateTime]::UtcNow.ToString('o');
 exit_code=$code; processor_affinity=$mask;
 os_architecture=[System.Runtime.InteropServices.RuntimeInformation]::OSArchitecture.ToString();
 process_architecture=[System.Runtime.InteropServices.RuntimeInformation]::ProcessArchitecture.ToString();
 gomaxprocs=$env:GOMAXPROCS; gowork=$env:GOWORK; goflags=$env:GOFLAGS;
 cgo_enabled=$env:CGO_ENABLED; gotooolchain=$env:GOTOOLCHAIN;
 gogc=$env:GOGC; gomemlimit=$env:GOMEMLIMIT;
 node_limit_scale=$env:GOT_PARSE_NODE_LIMIT_SCALE; glr_max_stacks=$env:GOT_GLR_MAX_STACKS
}
$record | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 -LiteralPath $cfg.receipt
exit $code
