from pathlib import Path
import hashlib,json,os,re,statistics,subprocess
root=Path(__file__).resolve().parents[1]
out=root/'out/raw-summary-perf-fused-v7'
assert json.loads((out/'finished.json').read_text())['exit_code']==0,'campaign not successful'
assert (out/'completed.txt').is_file(),'campaign incomplete'
for name in ('source-before.log','source-after.log','controls-before.log','controls-after.log'):
 assert (out/name).read_text()=='',name
assert json.loads((out/'gates-before.json').read_text())['selected_semantic_gates_passed']
reports={}
for series,pattern,wanted in [
 ('go-primary','primary-{}.txt',['BenchmarkGraduationGoSuite/Full','BenchmarkGraduationGoSuite/Edit','BenchmarkGraduationGoSuite/NoEdit']),
 ('go-r4','r4-{}-go.txt',['BenchmarkCompactGraduationR4/legacy','BenchmarkCompactGraduationR4/compact']),
 ('yaml-r4','r4-{}-yaml.txt',['BenchmarkCompactGraduationR4/legacy','BenchmarkCompactGraduationR4/compact'])]:
 samples={};orders={};raw_ids={}
 for arm in ('before','after'):
  path=out/pattern.format(arm);text=path.read_text()
  raw_ids[arm]=hashlib.sha256(path.read_bytes()).hexdigest()
  assert text.rstrip().endswith('# status: complete'),path
  assert not re.search(r'^FAIL|--- (FAIL|SKIP):|panic:|WARNING: DATA RACE',text,re.M),path
  for header in ('# protocol: paired-alternating-seeds','# seeds: 1..20','# benchtime: 750ms','# GOMAXPROCS: 1','# count per process: 1','# build tags: gts_parsercorephase0'):
   assert header in text,(path,header)
  assert list(map(int,re.findall(r'^# completed seed: (\d+);',text,re.M)))==list(range(1,21)),path
  starts=list(re.finditer(r'^# seed: (\d+); position: (\d+)\n',text,re.M))
  assert len(starts)==20,path
  by_seed={};order_by_seed={}
  for i,match in enumerate(starts):
   seed,position=map(int,match.groups());assert seed==i+1
   expected=(1 if seed%2 else 2) if arm=='before' else (2 if seed%2 else 1)
   assert position==expected,(path,seed,position)
   chunk=text[match.end():starts[i+1].start() if i+1<len(starts) else len(text)]
   order=re.findall(r'^# workload order: (.*)',chunk,re.M)
   assert len(order)==1 and sorted(order[0].split(','))==sorted(wanted),(path,seed,order)
   order_by_seed[seed]=order[0]
   rows={}
   for line in chunk.splitlines():
    if not line.startswith('Benchmark'):continue
    name=line.split()[0];assert name in wanted and name not in rows,(path,seed,line)
    iterations=re.search(r'\s(\d+)\s+([0-9.]+) ns/op',line)
    assert iterations and int(iterations[1])>0,(path,seed,line)
    metrics={unit:float(value) for value,unit in re.findall(r'([0-9.]+) (ns/op|B/op|allocs/op|compact-routes/op|compact-fallbacks/op)',line)}
    assert {'ns/op','B/op','allocs/op'}<=metrics.keys() and metrics['ns/op']>0,(path,seed,line)
    if series!='go-primary':
     assert metrics.get('compact-fallbacks/op')==0 and metrics.get('compact-routes/op')==(1 if name.endswith('/compact') else 0),(path,seed,line)
    elif name.endswith('/NoEdit'):
     assert metrics['B/op']==metrics['allocs/op']==0,(path,seed,line)
    rows[name]=metrics
   assert set(rows)==set(wanted),(path,seed,rows)
   by_seed[seed]=rows
  assert set(by_seed)==set(range(1,21))
  samples[arm]=by_seed;orders[arm]=order_by_seed
 assert orders['before']==orders['after'],series
 result={}
 for name in wanted:
  result[name]={}
  for metric in ('ns/op','B/op','allocs/op'):
   b=[samples['before'][s][name][metric] for s in range(1,21)]
   a=[samples['after'][s][name][metric] for s in range(1,21)]
   before,after=statistics.median(b),statistics.median(a)
   ratios=[x/y for x,y in zip(a,b)] if all(b) else None
   result[name][metric]={'before_median':before,'after_median':after,'change_percent':None if before==0 else (after/before-1)*100,'median_paired_after_before_ratio':None if ratios is None else statistics.median(ratios),'ratio_of_medians':None if before==0 else after/before}
 route_ratios={}
 if series!='go-primary':
  legacy,compact=wanted
  for arm in ('before','after'):
   ratios=[samples[arm][s][compact]['ns/op']/samples[arm][s][legacy]['ns/op'] for s in range(1,21)]
   route_ratios[arm]={'median_paired_compact_legacy_ratio':statistics.median(ratios),'ratio_of_medians':statistics.median(samples[arm][s][compact]['ns/op'] for s in range(1,21))/statistics.median(samples[arm][s][legacy]['ns/op'] for s in range(1,21))}
 before=out/pattern.format('before');after=out/pattern.format('after')
 run=subprocess.run([os.environ.get('BENCHSTAT','/home/draco/go/bin/benchstat'),str(before),str(after)],capture_output=True,text=True)
 assert run.returncode==0,run.stderr
 (out/f'benchstat-{series}.txt').write_text(run.stdout+run.stderr)
 reports[series]={'paired_samples':20,'raw_sha256':raw_ids,'results':result,'route_ratios':route_ratios}
summary={'schema':'gts-raw-summary-compact-perf/v1','pairs':60,'processes':120,'seeds':list(range(1,21)),'benchtime':'750ms','GOMAXPROCS':1,'count_per_process':1,'route_fallbacks':0,'no_edit_allocations':0,'all_source_and_control_guards_passed':True,'failed_or_incomplete_processes':0,'results':reports,'private_prototype_promoted':False,'fleet_qualified':False,'E_A_qualification':False,'graduation_claim':False,'merges_held':True}
(out/'validated-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
