PRIVATE unexecuted pool footprint cache, independent add-on to compact-core-v5.
Only runtime change: raw_summary_pool_private.go. No producer/type/backing-layout changes.
retainedBytes reads actual sizeof(pool)+weak bookkeeping plus atomic cached backing bytes.
The existing mutex retains exclusive take/put/retire ownership. Complete backing charge is
published at each ownership transfer; a smaller/oversized/retired return changes no charge.
A zero-value pool still charges its real header. The new atomic field is charged by existing
unsafe.Sizeof(rawSummaryPool{}) startup reservation and the footprint header, without a
literal-size waiver. Live immutable lease charges do not include cached pool storage.

The three added test families independently census every retained capacity (including
inactive raw blocks and auxiliary planes), exercise exact initial header reservation,
real lease reset/retirement/late Release and concurrent readers/three owners/retirement.
Tests intentionally do not call cached geometry or backing retainedBytes for the oracle.
Baseline ordinary Core/public/lifetime/scanner/authority controls remain available in the
composed test map. Focused/release/workcount/race commands are in commands.json; parent
must run them in the shared Docker workflow. No build or runtime execution by author.

Measured old profile attribution was RawSummaryFootprint about4.87% cumulative and pool
retainedBytes about4.57% nested; those are a ceiling and source scope, not this patch's win.
Fused summary and YAML checkpoint variants are separate. overlay.own.* changes only this
pool and optional test; overlay.* composes exact compact-core-v5 for an independent trial.
