#!/usr/bin/env bash
set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly' GOMAXPROCS=1
: "${GTS_FINAL_OVERLAY:?set frozen combined overlay}" "${GTS_FINAL_OUT:?set evidence output directory}"
out=$GTS_FINAL_OUT
scratch=/runtime/tmp/gotreesitter-combined-correctness-v28
mkdir -p "$out" "$scratch"
: "${GTS_FINAL_INPUTS:?set frozen input manifest}"
sha256sum --quiet -c "$GTS_FINAL_INPUTS"
sha256sum --quiet -c /controls/combined-correctness/v28/source.sha256
trap 'rc=$?; sha256sum --quiet -c "$GTS_FINAL_INPUTS" || rc=1; sha256sum --quiet -c /controls/combined-correctness/v28/source.sha256 || rc=1; exit "$rc"' EXIT
cd /candidate
case "${1:?race or oracle}" in
 race)
  go test -race -c -overlay="$GTS_FINAL_OVERLAY" -tags gts_parsercorephase0 -o "$scratch/root-race.test" . > "$out/race-build.log" 2>&1
  "$scratch/root-race.test" -test.run '^Test(PrimitiveProbeIntoContract|AuthenticatedNativeReuseWitness|TrustedGoReuseShadowOriginalProducer|IdentifierAdmissionActualBoundaryCases|IdentifierAdmissionRealSources|TrustedGoShadowActualDefaultProducerContext|AuthenticatedGoReuseLifecycle|LanguageCopyDoesNotAuthenticate|ScannerAdaptationRevokesProducer)$' -test.count=1 -test.v -test.timeout=12m > "$out/race-focused.log" 2>&1
  for api in plain profiled; do
   "$scratch/root-race.test" -test.run "^TestTrustedGoReuseShadowCleanEditSession$/$api$" -test.count=1 -test.v -test.timeout=10m > "$out/race-clean-$api.log" 2>&1
  done
  sha256sum "$scratch/root-race.test" > "$out/race-binary.sha256"
  ;;
 oracle)
  : "${GTS_FINAL_C027_OVERLAY:?set combined c027 overlay}"
  cd /candidate/cgo_harness
  go test -c -overlay="$GTS_FINAL_OVERLAY" -tags treesitter_c_parity,gts_parsercorephase0 -o "$scratch/c025.test" . > "$out/c025-build.log" 2>&1
  "$scratch/c025.test" -test.run '^TestGo(Cognociente137KiBTopEditLockedC|MalformedDeclarationPrefixLockedC|AssignmentTargetEdits16SitesLockedC)$' -test.count=1 -test.v -test.timeout=12m > "$out/c025.log" 2>&1
  export GOFLAGS="-p=1 -mod=readonly -modfile=/controls/oracle0271-module-bind-v3/go.mod -overlay=$GTS_FINAL_C027_OVERLAY"
  go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o "$scratch/c027.test" . > "$out/c027-build.log" 2>&1
  "$scratch/c027.test" -test.run '^TestCOracle0271HeaderAndLinkProbe$' -test.count=1 -test.v -test.timeout=2m > "$out/c027-probe.log" 2>&1
  "$scratch/c027.test" -test.run '^TestGo(Cognociente137KiBTopEditLockedC|MalformedDeclarationPrefixLockedC|AssignmentTargetEdits16SitesLockedC)$' -test.count=1 -test.v -test.timeout=12m > "$out/c027.log" 2>&1
  for version in c025 c027; do
   sed -n -E "s/^[[:space:]]*--- PASS: ([^ ]+) \(.*\)$/\1/p" "$out/$version.log" > "$out/$version-records.txt"
   [[ $(wc -l < "$out/$version-records.txt") -eq 127 ]]
  done
  diff -u "$out/c025-records.txt" "$out/c027-records.txt" > "$out/oracle-records.diff"
  sha256sum "$scratch/c025.test" "$scratch/c027.test" > "$out/oracle-binary.sha256"
  ;;
 *) exit 2;;
esac
