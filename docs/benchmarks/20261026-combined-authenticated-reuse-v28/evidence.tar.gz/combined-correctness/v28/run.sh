#!/usr/bin/env bash
set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly' GOMAXPROCS=1
cd /candidate
: "${GTS_FINAL_OVERLAY:?set frozen combined overlay}"
: "${GTS_FINAL_OUT:?set evidence output directory}"
out=$GTS_FINAL_OUT
scratch=/runtime/tmp/gotreesitter-combined-correctness-v28
mkdir -p "$out" "$scratch"
: "${GTS_FINAL_INPUTS:?set frozen input manifest}"
sha256sum --quiet -c "$GTS_FINAL_INPUTS"
sha256sum --quiet -c /controls/combined-correctness/v28/source.sha256
trap 'rc=$?; sha256sum --quiet -c "$GTS_FINAL_INPUTS" || rc=1; sha256sum --quiet -c /controls/combined-correctness/v28/source.sha256 || rc=1; exit "$rc"' EXIT
bin="$scratch/root.test"
case "${1:?build, focused, or fleet}" in
 build)
  go test -c -overlay="$GTS_FINAL_OVERLAY" -tags gts_parsercorephase0 -o "$bin" . > "$out/root-build.log" 2>&1
  sha256sum "$bin" > "$out/root-binary.sha256"
  ;;
 focused)
  sha256sum -c "$out/root-binary.sha256"
  "$bin" -test.run '^Test(PrimitiveProbeIntoContract|AuthenticatedNativeReuseWitness|TrustedGoReuseShadowOriginalProducer|IdentifierAdmissionActualBoundaryCases|IdentifierAdmissionRealSources|TrustedGoShadowActualDefaultProducerContext|AuthenticatedGoReuseLifecycle|LanguageCopyDoesNotAuthenticate|ScannerAdaptationRevokesProducer)$' -test.count=1 -test.v -test.timeout=12m > "$out/focused.log" 2>&1
  for test in PrimitiveProbeIntoContract AuthenticatedNativeReuseWitness TrustedGoReuseShadowOriginalProducer IdentifierAdmissionActualBoundaryCases IdentifierAdmissionRealSources TrustedGoShadowActualDefaultProducerContext AuthenticatedGoReuseLifecycle LanguageCopyDoesNotAuthenticate ScannerAdaptationRevokesProducer; do
   grep -q "^--- PASS: Test$test " "$out/focused.log" || { echo "missing focused test: $test" >&2; exit 2; }
  done
  for api in plain profiled; do
   "$bin" -test.run "^TestTrustedGoReuseShadowCleanEditSession$/$api$" -test.count=1 -test.v -test.timeout=10m > "$out/clean-$api.log" 2>&1
  done
  ;;
 fleet)
  sha256sum -c "$out/root-binary.sha256"
  start=${2:?start index, 1-based}; end=${3:?end index, inclusive}
  mapfile -t langs < /controls/combined-correctness/v28/languages.txt
  [[ ${#langs[@]} == 206 && $start -ge 1 && $end -le 206 && $start -le $end ]]
  mkdir -p "$out/fleet"
  fail=0
  for ((i=start; i<=end; i++)); do
   lang=${langs[i-1]}
   for route in 0 1; do
    log="$out/fleet/$lang-$route.log"
    [[ ! -e "$log" ]] || { echo "refusing overwrite: $log" >&2; exit 2; }
    if GTS_ADMISSION_CANDIDATE=$route GOTREESITTER_V1_INVARIANT_LANGUAGE=$lang "$bin" -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "$log" 2>&1 && grep -q '^--- PASS: TestV1InvariantGateR4EditSession ' "$log" && ! grep -q '^--- SKIP:' "$log"; then
     printf '%s %s PASS\n' "$lang" "$route"
    else
     printf '%s %s FAIL\n' "$lang" "$route"; fail=1
    fi
   done
  done
  exit "$fail"
  ;;
 *) exit 2;;
esac
