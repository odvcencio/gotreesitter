#!/usr/bin/env bash
set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly' GOMAXPROCS=1 GTS_PARITY_C_REF_BUILD_CACHE=/c-cache
cd /candidate/cgo_harness
out=/evidence
scratch=/runtime/tmp/gotreesitter-combined-correctness-v28
mkdir -p "$scratch" "$out/c-fleet"
sha256sum --quiet -c /controls/combined-v28/inputs.sha256
sha256sum --quiet -c /controls/combined-correctness/v28/source.sha256
trap 'rc=$?; sha256sum --quiet -c /controls/combined-v28/inputs.sha256 || rc=1; sha256sum --quiet -c /controls/combined-correctness/v28/source.sha256 || rc=1; exit "$rc"' EXIT
case "${1:?}" in
 build-c)
  go test -c -overlay=/controls/combined-correctness/v28/tests.json -tags treesitter_c_parity,gts_parsercorephase0 -o "$scratch/c-fleet.test" . > "$out/c-fleet-build.log" 2>&1
  sha256sum "$scratch/c-fleet.test" > "$out/c-fleet-binary.sha256" ;;
 fleet-c)
  sha256sum -c "$out/c-fleet-binary.sha256"
  start=${2:?}; end=${3:?}; mapfile -t langs < /controls/combined-correctness/v28/languages.txt
  [[ ${#langs[@]} == 206 && $start -ge 1 && $end -le 206 && $start -le $end ]]
  fail=0
  for ((i=start;i<=end;i++)); do
   lang=${langs[i-1]}
   for route in 0 1; do
    log="$out/c-fleet/$lang-$route.log"
    [[ ! -e "$log" ]] || { echo "refusing overwrite: $log" >&2; exit 2; }
    if GTS_ADMISSION_CANDIDATE=$route GTS_PARITY_MODE=exhaustive "$scratch/c-fleet.test" -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${lang}$" -test.count=1 -test.v -test.timeout=5m > "$log" 2>&1 &&
      [[ $(grep -c '^--- PASS: TestParity' "$log") -eq 3 ]] && ! grep -qE '^--- (FAIL|SKIP):' "$log"; then
     printf '%s %s PASS\n' "$lang" "$route"
    else printf '%s %s FAIL\n' "$lang" "$route"; fail=1; fi
   done
  done
  exit "$fail" ;;
 *) exit 2;;
esac
