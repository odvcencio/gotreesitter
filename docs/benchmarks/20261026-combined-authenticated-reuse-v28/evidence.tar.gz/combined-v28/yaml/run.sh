set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly -overlay=/controls/combined-v28/yaml/overlay.json' GTS_ADMISSION_CANDIDATE=0
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
sha256sum --quiet -c /controls/combined-v28/inputs.sha256
sha256sum --quiet -c /controls/combined-correctness/v28/source.sha256
sha256sum --quiet -c /controls/combined-v28/yaml/execution-controls.sha256
python3 /controls/combined-v28/verify-sources.py
sha256sum --quiet -c /controls/out-combined-v28-yaml-preflight/yaml-inputs.sha256
sha256sum /controls/combined-v28/yaml/{overlay.json,bench_test.go,bridge_test.go} > /evidence/yaml-inputs.sha256
python3 - <<'PY'
import hashlib,json
from pathlib import Path
receipt=json.loads(Path('/controls/combined-correctness/v28/completed.json').read_text()); assert receipt['exit_code']==0 and receipt['combined_inputs_sha256']==hashlib.sha256(Path('/controls/combined-v28/inputs.sha256').read_bytes()).hexdigest()
c=json.loads(Path('/controls/out-combined-v28-counters/summary.json').read_text());assert c['languages']==206 and c['work_and_reuse_direction_passed'] and c['ledger_exports_byte_identical']
for arm in ('baseline','candidate'):
 log=Path('/controls/out-combined-v28-yaml-preflight/'+arm+'.log').read_text();assert 'PASS' in log and 'YAML_FIXTURE bytes=1998 sha256=5aa2c70bccfe73254f13eca40476c3f88f522c6a47aea499f9d672dbc5aae8c4 route=legacy' in log
PY
cd /candidate
bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/before.txt --output /evidence/after.txt --runs 20 --seed-start 1 --benchtime 750ms --bench-regex '^BenchmarkCombinedYAML$' --require-benchmarks 'BenchmarkCombinedYAML/full,BenchmarkCombinedYAML/edit,BenchmarkCombinedYAML/no_edit' --lock-path /runtime/tmp/gts-combined-v28-yaml.lock > /evidence/randomized.log 2>&1
sha256sum --quiet -c /evidence/yaml-inputs.sha256
sha256sum --quiet -c /controls/combined-v28/inputs.sha256
sha256sum --quiet -c /controls/combined-correctness/v28/source.sha256
sha256sum --quiet -c /controls/combined-v28/yaml/execution-controls.sha256
python3 /controls/combined-v28/verify-sources.py
