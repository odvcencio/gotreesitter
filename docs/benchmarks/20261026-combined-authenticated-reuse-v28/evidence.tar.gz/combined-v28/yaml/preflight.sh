set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly' GTS_ADMISSION_CANDIDATE=0 GTS_BENCHMARK_SEED=1
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
sha256sum --quiet -c /controls/combined-v28/inputs.sha256
python3 /controls/combined-v28/verify-sources.py
sha256sum /controls/combined-v28/yaml/{overlay.json,bench_test.go,bridge_test.go} > /evidence/yaml-inputs.sha256
scratch=/runtime/tmp/gts-combined-v28-yaml-preflight
mkdir -p "$scratch"
for arm in baseline candidate; do
 cd "/$arm"
 go test -c -overlay=/controls/combined-v28/yaml/overlay.json -tags gts_parsercorephase0 -o "$scratch/$arm.test" . > "/evidence/$arm-build.log" 2>&1
 "$scratch/$arm.test" -test.run '^$' -test.bench '^BenchmarkCombinedYAML$' -test.benchtime=1x -test.count=1 -test.benchmem > "/evidence/$arm.log" 2>&1
done
sha256sum "$scratch/"*.test > /evidence/binary.sha256
sha256sum --quiet -c /evidence/yaml-inputs.sha256
sha256sum --quiet -c /controls/combined-v28/inputs.sha256
python3 /controls/combined-v28/verify-sources.py
