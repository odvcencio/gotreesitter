set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
export GTS_ADMISSION_CANDIDATE=0
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
finish(){
 sha256sum --quiet -c /controls/combined-correctness/v28/source.sha256 > /evidence/correctness-source-after.log 2>&1
 sha256sum --quiet -c /controls/combined-v28/perf-controls.sha256 > /evidence/execution-controls-after.log 2>&1
 sha256sum --quiet -c /controls/combined-v28/inputs.sha256 > /evidence/combined-after.log 2>&1
 python3 /controls/combined-v28/verify-sources.py > /evidence/source-verification-after.log
}
trap finish EXIT
sha256sum --quiet -c /controls/combined-correctness/v28/source.sha256 > /evidence/correctness-source-before.log 2>&1
sha256sum --quiet -c /controls/combined-v28/perf-controls.sha256 > /evidence/execution-controls-before.log 2>&1
sha256sum --quiet -c /controls/combined-v28/inputs.sha256 > /evidence/combined-before.log 2>&1
python3 /controls/combined-v28/verify-sources.py > /evidence/source-verification-before.log
python3 - <<'GATE'
import hashlib, json
from pathlib import Path
counter=json.loads((Path('/controls/out-combined-v28-counters')/'summary.json').read_text())
assert counter['languages']==206 and counter['routes_per_language']==2 and counter['ledger_exports_byte_identical'] and counter['work_and_reuse_direction_passed']
receipt=json.loads((Path('/controls/combined-correctness/v28')/'completed.json').read_text())
assert receipt['exit_code']==0
assert receipt['combined_inputs_sha256']==hashlib.sha256(Path('/controls/combined-v28/inputs.sha256').read_bytes()).hexdigest()
print('Prerequisite correctness, counters and race qualification completed successfully')
GATE
scratch=/runtime/tmp/gts-combined-v28-perf-20261026
mkdir -p "$scratch"
cp /controls/perf/memory.go.txt "$scratch/memory.go"
cd /candidate
go test -overlay=/controls/combined-v28/perf.json -tags gts_parsercorephase0 -run '^Test(LegacyReuseAliasSidecarArenaAndBudget|LegacyReuseLookaheadRespectsSidecarBudget|ArenaMemoryBudget.*|ArenaResetRetainsOverflowWithinBudget|ParserScratchMemoryBudget.*|ParserScratchBudget.*|GoCompatCleanParseUnaffectedByMemoryBudgetFix|GoCompatFramesReleasedAboveRetentionCap)$' -count=1 -v -timeout=5m . > /evidence/memory-contracts.log 2>&1
for arm in baseline candidate; do
 cd "/$arm"
 extra=(); if [[ "$arm" == baseline ]]; then extra=(-overlay=/controls/combined-v28/perf.json); fi
 go build "${extra[@]}" -o "$scratch/$arm-memory" "$scratch/memory.go" > "/evidence/$arm-memory-build.log" 2>&1
 # Precompile both arms before measuring either one.
 go test -c -overlay=/controls/combined-v28/perf.json -tags gts_parsercorephase0 -o "$scratch/$arm.test" . > "/evidence/$arm-bench-build.log" 2>&1
done
for arm in baseline candidate; do
 /usr/bin/time -v -o "/evidence/chain-$arm.time" "$scratch/$arm-memory" 140288 1000 > "/evidence/chain-$arm.jsonl" 2> "/evidence/chain-$arm.stderr"
done
python3 - <<'RETENTION'
import hashlib, json
from pathlib import Path
for arm in ['baseline','candidate']:
 rows={r['step']:r for r in map(json.loads,(Path('/evidence')/f'chain-{arm}.jsonl').read_text().splitlines())}
 assert rows[1000]['heap_alloc'] <= rows[100]['heap_alloc']*1.10+1048576,(arm,rows)
print('1000-edit retained heap remains bounded after warmup in both arms')
RETENTION
cd /candidate
export GOFLAGS='-p=1 -mod=readonly -overlay=/controls/combined-v28/perf.json'
bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/before.txt --output /evidence/after.txt --runs 20 --seed-start 1 --benchtime 750ms --bench-regex '^BenchmarkGTSAuthenticatedReuse$' --require-benchmarks 'BenchmarkGTSAuthenticatedReuse/BenchmarkGoParseFullDFA,BenchmarkGTSAuthenticatedReuse/BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGTSAuthenticatedReuse/BenchmarkGoParseIncrementalNoEditDFA,BenchmarkGTSAuthenticatedReuse/Report137KiBFull,BenchmarkGTSAuthenticatedReuse/Report137KiBEdit,BenchmarkGTSAuthenticatedReuse/Report137KiBEditProfiled' --lock-path "$scratch/perf.lock" > /evidence/randomized.log 2>&1
for seed in $(seq 1 20); do
 arms=(baseline candidate); if ((seed % 2 == 0)); then arms=(candidate baseline); fi
 for arm in "${arms[@]}"; do
  for size in 140288 1048576; do
   steps=100; if ((size == 1048576)); then steps=0; fi
   /usr/bin/time -v -o "/evidence/rss-$arm-$size-$seed.time" "$scratch/$arm-memory" "$size" "$steps" > "/evidence/rss-$arm-$size-$seed.jsonl" 2> "/evidence/rss-$arm-$size-$seed.stderr"
  done
 done
done
sha256sum "$scratch/baseline.test" "$scratch/candidate.test" "$scratch/baseline-memory" "$scratch/candidate-memory" > /evidence/binary.sha256
