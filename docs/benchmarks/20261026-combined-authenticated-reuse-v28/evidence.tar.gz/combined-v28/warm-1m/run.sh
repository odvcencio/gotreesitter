set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly' GTS_ADMISSION_CANDIDATE=0 GTS_FRESH_MEMORY_LANG=go
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
finish(){ sha256sum --quiet -c /controls/combined-v28/warm-1m/controls.sha256 > /evidence/controls-after.log 2>&1; sha256sum --quiet -c /controls/combined-v28/inputs.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/combined-correctness/v28/source.sha256 > /evidence/correctness-source-after.log 2>&1; python3 /controls/combined-v28/verify-sources.py > /evidence/baseline-after.log; }
trap finish EXIT
sha256sum --quiet -c /controls/combined-v28/warm-1m/controls.sha256 > /evidence/controls-before.log 2>&1
sha256sum --quiet -c /controls/combined-v28/inputs.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/combined-correctness/v28/source.sha256 > /evidence/correctness-source-before.log 2>&1
python3 /controls/combined-v28/verify-sources.py > /evidence/baseline-before.log
python3 - <<'PY'
import hashlib,json
from pathlib import Path
receipt=json.loads(Path('/controls/combined-correctness/v28/completed.json').read_text());assert receipt['exit_code']==0 and receipt['combined_inputs_sha256']==hashlib.sha256(Path('/controls/combined-v28/inputs.sha256').read_bytes()).hexdigest()
c=json.loads(Path('/controls/out-combined-v28-counters/summary.json').read_text());assert c['languages']==206 and c['ledger_exports_byte_identical'] and c['work_and_reuse_direction_passed']
PY
scratch=/runtime/tmp/gts-combined-v28-warm-1m
mkdir -p "$scratch"
for arm in baseline candidate; do
 cd "/$arm/roottest/bench"
 go test -overlay=/controls/combined-v28/warm-1m/overlay.json -tags gts_parsercorephase0 -run '^TestV21FreshMemoryFixtureIdentity$' -count=1 -v > "/evidence/$arm-fixture.log" 2>&1
 go test -c -overlay=/controls/combined-v28/warm-1m/overlay.json -tags gts_parsercorephase0 -o "$scratch/$arm.test" . > "/evidence/$arm-build.log" 2>&1
done
# Paired allocation control uses the repository randomized runner. The
# separate direct-child run below preserves the historical RSS witness.
cd /candidate
GOFLAGS='-p=1 -mod=readonly -overlay=/controls/combined-v28/warm-1m/overlay.json' bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/randomized-before.txt --output /evidence/randomized-after.txt --runs 20 --seed-start 154001 --benchtime 2x --package ./roottest/bench --bench-regex '^BenchmarkFreshMemory$/^go$/^1024KiB$' --require-benchmarks 'BenchmarkFreshMemory/go/1024KiB' --lock-path /runtime/tmp/gts-combined-v28-warm-randomized.lock > /evidence/randomized.log 2>&1
for seed in $(seq 154001 154020); do
 arms=(baseline candidate); if ((seed%2==0)); then arms=(candidate baseline); fi
 for arm in "${arms[@]}"; do
  cd "/$arm/roottest/bench"
  /usr/bin/time -v -o "/evidence/$arm-$seed.time" "$scratch/$arm.test" -test.run '^$' -test.bench '^BenchmarkFreshMemory$/^go$/^1024KiB$' -test.benchtime=2x -test.count=1 -test.benchmem -test.shuffle="$seed" -test.timeout=5m > "/evidence/$arm-$seed.log" 2>&1
 done
done
sha256sum "$scratch/"*.test > /evidence/binary.sha256
