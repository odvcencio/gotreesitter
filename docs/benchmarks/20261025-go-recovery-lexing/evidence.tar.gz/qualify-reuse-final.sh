set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate/cgo_harness
go test -overlay=/controls/reuse-overlay.json -c -tags treesitter_c_parity,gts_parsercorephase0 -o /runtime/tmp/gotreesitter-go-delete/reuse-final-cgo.test . > /evidence/reuse-final-cgo-build.log 2>&1
/runtime/tmp/gotreesitter-go-delete/reuse-final-cgo.test -test.run '^Test(Go(Compact|TokenInvariant|Unterminated|GeneratedNUL|NewMake|Cognociente137KiBTopEditLockedC|MalformedDeclarationPrefixLockedC)|Stage6GoCompactCertification)' -test.v -test.count=1 > /evidence/reuse-final-go-cgo.log 2>&1
cd /candidate
go test -overlay=/controls/reuse-work-overlay.json -c -tags gts_parsercorephase0,gts_workcount -o /runtime/tmp/gotreesitter-go-delete/reuse-final-root.test . > /evidence/reuse-final-root-build.log 2>&1
/runtime/tmp/gotreesitter-go-delete/reuse-final-root.test -test.run '^Test(SmallFreshReuse.*|DefaultReuseProducerSourceAndContext|GoSmallFreshReuseProducerProvenance|ProbeZeroWidthExternalTokenNonlocalReadsDeclineCertificates|GoDeleteCompleteWork|CompactIncrementalExecution.*|CompactRecoveryMemoMemoryBudget|CompactAcceptanceReferenceAndRetainedArenasStayInMemoryBudget|CompactAcceptanceComparisonWorkspaceMemoryBudget|CompactAcceptanceChangedSourceKeepsRebuildBudget)$' -test.v -test.count=1 > /evidence/reuse-final-work.log 2>&1
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE=go /runtime/tmp/gotreesitter-go-delete/reuse-final-root.test -test.run '^TestV1InvariantGateR4EditSession$' -test.v -test.count=1 > /evidence/reuse-final-invariant-$route.log 2>&1
done
go test -overlay=/controls/reuse-overlay.json ./internal/incr -count=1 -v > /evidence/reuse-final-incr.log 2>&1
go build -overlay=/controls/reuse-overlay.json -tags gts_parsercorephase0 -o /runtime/tmp/gotreesitter-go-delete/reuse-final-ledger ./cmd/perfcounterledger > /evidence/reuse-final-ledger-build.log 2>&1
for route in default candidate; do
 GTS_ADMISSION_CANDIDATE=$([ "$route" = candidate ] && echo 1 || echo 0) /runtime/tmp/gotreesitter-go-delete/reuse-final-ledger --child-route="$route" --langs go > /evidence/reuse-final-ledger-$route.json
done

go test -overlay=/controls/reuse-overlay.json -race -tags gts_parsercorephase0 -run '^Test(SmallFreshReuse.*|DefaultReuseProducerSourceAndContext|GoSmallFreshReuseProducerProvenance|ProbeZeroWidthExternalTokenNonlocalReadsDeclineCertificates|CompactIncrementalExecutionLifetime)$' -count=1 -v . > /evidence/reuse-final-race.log 2>&1
