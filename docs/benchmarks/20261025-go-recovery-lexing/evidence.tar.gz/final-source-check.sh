set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate/cgo_harness
go test -tags treesitter_c_parity,gts_parsercorephase0 -run '^TestGo(Cognociente137KiBTopEditLockedC|MalformedDeclarationPrefixLockedC)$' -count=1 -v . > /evidence/final-source-cgo.log 2>&1
go test -overlay=/controls/reuse-overlay.json -tags treesitter_c_parity,gts_parsercorephase0 -run '^TestGo(Cognociente137KiBTopEditLockedC|MalformedDeclarationPrefixLockedC)$' -count=1 -v . > /evidence/final-source-reuse-cgo.log 2>&1
