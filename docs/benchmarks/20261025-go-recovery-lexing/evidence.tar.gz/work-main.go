//go:build gts_workcount

package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	gts "github.com/odvcencio/gotreesitter"
	"github.com/odvcencio/gotreesitter/grammars"
	"strings"
)

func main() {
	t := auditT{}
	var b bytes.Buffer
	b.WriteString("package main\n\nimport \"fmt\"\n\n")
	for i := 0; b.Len() < 137*1024; i++ {
		fmt.Fprintf(&b, "func f%d(a int, b int) int {\n\tx := a + b\n\tfmt.Println(\"f%d\", x)\n\treturn x\n}\n\n", i, i)
	}
	source := b.Bytes()
	site := bytes.Index(source, []byte("x := a + b"))
	if site != 57 || len(source) != 140368 {
		t.Fatal("fixture changed")
	}
	for _, candidate := range []bool{false, true} {
		for _, kind := range []string{"insert", "replace", "delete"} {
			oldEnd, newEnd := site+1, site+1
			replacement := []byte("y")
			if kind == "insert" {
				oldEnd = site
				newEnd = site + 1
				replacement = []byte("x")
			}
			if kind == "delete" {
				newEnd = site
				replacement = nil
			}
			edited := append([]byte(nil), source[:site]...)
			edited = append(edited, replacement...)
			edited = append(edited, source[oldEnd:]...)
			for _, phase := range []string{"fresh", "edit"} {
				parser := gts.NewParser(grammars.GoLanguage())
				parser.SetAdmissionCandidateRoute(candidate)
				var old *gts.Tree
				var err error
				if phase == "edit" {
					old, err = parser.Parse(source)
					if err != nil {
						t.Fatal(err)
					}
				}
				gts.BeginDiagnosticWorkCount()
				if old != nil {
					old.Edit(gts.InputEdit{StartByte: uint32(site), OldEndByte: uint32(oldEnd), NewEndByte: uint32(newEnd), StartPoint: pointForOffset(source, site), OldEndPoint: pointForOffset(source, oldEnd), NewEndPoint: pointForOffset(edited, newEnd)})
				}
				var tree *gts.Tree
				var selected map[string]any
				if phase == "fresh" {
					tree, err = parser.Parse(edited)
				} else {
					var profile gts.IncrementalParseProfile
					tree, profile, err = parser.ParseIncrementalProfiled(edited, old)
					data, e := json.Marshal(profile)
					if e != nil {
						t.Fatal(e)
					}
					if e = json.Unmarshal(data, &selected); e != nil {
						t.Fatal(e)
					}
					for k := range selected {
						if strings.HasSuffix(k, "Nanos") {
							delete(selected, k)
						}
					}
				}
				if err != nil {
					t.Fatal(err)
				}
				hasError, end := tree.RootNode().HasError(), tree.RootNode().EndByte()
				tree.Release()
				if old != nil {
					old.Release()
				}
				counts := gts.EndDiagnosticWorkCount()

				result := map[string]any{"candidate": candidate, "kind": kind, "phase": phase, "selected": selected, "work": counts, "has_error": hasError, "end_byte": end}
				data, err := json.Marshal(result)
				if err != nil {
					t.Fatal(err)
				}
				fmt.Printf("WORK %s\n", data)
			}
		}
	}
}

type auditT struct{}

func (auditT) Fatal(args ...any) { panic(fmt.Sprint(args...)) }
func pointForOffset(source []byte, end int) gts.Point {
	var p gts.Point
	for _, b := range source[:end] {
		if b == '\n' {
			p.Row++
			p.Column = 0
		} else {
			p.Column++
		}
	}
	return p
}
