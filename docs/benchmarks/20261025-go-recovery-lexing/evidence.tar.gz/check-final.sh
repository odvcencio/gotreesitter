set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
go test ./grammargen -run '^(TestGeneratedErrorModeRecognizesNonInitialPunctuation|TestErrorRecoveryLexModeExcludesContextualPatterns|TestMissingRecovery.*|TestAssemble.*ChildCountLimit|TestEmitGrammarGoIncludesImportMetadata|TestExtendGrammar.*)$' -count=1 -v > /evidence/final-generator-tests.log 2>&1
go run ./cmd/grammargen emit go -bin /evidence/go-final-reproduced.bin -go /evidence/go-final-source.go.txt > /evidence/final-generate.log 2>&1
for language in go regex swift yaml; do
 go test ./grammargen -run "^TestGrammargenOwnedBlobsAreReproducible$/$language$" -count=1 -v > /evidence/repro-$language.log 2>&1
done
