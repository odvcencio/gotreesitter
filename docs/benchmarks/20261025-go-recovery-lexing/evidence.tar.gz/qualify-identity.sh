set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
for version in identity; do
 overlay=/controls/candidate-work-overlay.json
 go test -overlay="$overlay" -c -tags gts_parsercorephase0,gts_workcount -o /runtime/tmp/gotreesitter-go-delete/$version-root.test . > /evidence/$version-root-build.log 2>&1
 /runtime/tmp/gotreesitter-go-delete/$version-root.test -test.run '^TestGoDeleteCompleteWork$' -test.v -test.count=1 > /evidence/$version-work.log 2>&1
 go build -overlay="$overlay" -tags gts_parsercorephase0 -o /runtime/tmp/gotreesitter-go-delete/$version-ledger ./cmd/perfcounterledger > /evidence/$version-ledger-build.log 2>&1
 for route in default candidate; do
  GTS_ADMISSION_CANDIDATE=$([ "$route" = candidate ] && echo 1 || echo 0) /runtime/tmp/gotreesitter-go-delete/$version-ledger --child-route="$route" --langs go > /evidence/$version-ledger-$route.json
 done
done
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE=go /runtime/tmp/gotreesitter-go-delete/identity-root.test -test.run '^TestV1InvariantGateR4EditSession$' -test.v -test.count=1 > /evidence/identity-invariant-$route.log 2>&1
done
/runtime/tmp/gotreesitter-go-delete/identity-root.test -test.run '^Test(IncrementalInvariantGateGo|GoLanguageFixtureLengthChangeIncrementalMatchesFresh|CleanGoIncrementalDoesNotRunAcceptedErrorRetry|TokenInvariantGoLeafDoesNotEnterAcceptedErrorRetryRoute|MalformedTokenInvariantGoLeafDoesNotRunBaseMergeRetry|MalformedGoIncrementalRunsOneBaseMergeRetryAndKeepsFirstResult|CompactIncrementalExecution.*|CompactRecoveryMemoMemoryBudget|CompactAcceptanceReferenceAndRetainedArenasStayInMemoryBudget|CompactAcceptanceComparisonWorkspaceMemoryBudget|CompactAcceptanceChangedSourceKeepsRebuildBudget)$' -test.v -test.count=1 > /evidence/identity-focused-root.log 2>&1

cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /runtime/tmp/gotreesitter-go-delete/identity-cgo.test . > /evidence/identity-cgo-build.log 2>&1
/runtime/tmp/gotreesitter-go-delete/identity-cgo.test -test.run '^Test(Go(Compact|TokenInvariant|Unterminated|GeneratedNUL|NewMake|Cognociente137KiBTopEditLockedC|MalformedDeclarationPrefixLockedC)|Stage6GoCompactCertification)' -test.v -test.count=1 > /evidence/identity-cgo.log 2>&1
GTS_ADMISSION_REAL_CORPUS_LANGS=go /runtime/tmp/gotreesitter-go-delete/identity-cgo.test -test.run '^TestCompactR4StructuralLockedC$' -test.v -test.count=1 > /evidence/identity-r4-cgo.log 2>&1
cd /candidate
go test ./internal/parsercorephase0 -run '^TestNativeSelectedSnapshotContracts$' -count=1 > /evidence/native-contract.log 2>&1
