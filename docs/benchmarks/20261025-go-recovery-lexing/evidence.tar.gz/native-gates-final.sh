set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
go test -tags gts_parsercorephase0 -run '^Test(DiagnosticParserCoreSummaryAcceptsExactQueryCompile|DiagnosticParserCoreSeedMatchesImmutableLegacyGolden|DiagnosticParserCoreCanonicalAdmissions|DiagnosticParserCoreBoundaryIndexCensus|NativeNodeViews.*|QuiescentNativeGo.*|SingleVersionDirectOutputGo)$' -count=1 -v . > /evidence/native-view-gates-final.log 2>&1
go test -race -tags gts_parsercorephase0 -run '^Test(NativeNodeViewsConcurrentReads|CompactIncrementalExecutionLifetime)$' -count=1 -v . > /evidence/identity-race.log 2>&1
