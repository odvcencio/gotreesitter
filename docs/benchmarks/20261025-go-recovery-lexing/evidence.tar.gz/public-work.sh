set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
for version in baseline identity reuse; do
 overlay=/controls/candidate-work-overlay.json
 if [ "$version" = baseline ]; then overlay=/controls/original-blob-overlay.json; fi
 if [ "$version" = reuse ]; then overlay=/controls/reuse-overlay.json; fi
 go build -overlay="$overlay" -tags gts_parsercorephase0,gts_workcount -o /runtime/tmp/gotreesitter-go-delete/public-work-$version /controls/work-main.go > /evidence/public-work-$version-build.log 2>&1
 /runtime/tmp/gotreesitter-go-delete/public-work-$version > /evidence/public-work-$version.log 2>&1
done
