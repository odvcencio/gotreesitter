set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local
cd /candidate/cgo_harness
for version in identity reuse-final; do
 /runtime/tmp/gotreesitter-go-delete/$version-cgo.test -test.run '^TestCanonicalGoBenchmarkPreflight$' -test.v -test.count=1 > /evidence/$version-canonical-cgo.log 2>&1
done
