set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly -overlay=/controls/paired-correctness-overlay.json'
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
go version > /evidence/paired-go-version.txt
GTS_ADMISSION_CANDIDATE=0 bash scripts/run_randomized_benchmarks.sh --output /evidence/repair-after.txt --baseline-root /baseline --baseline-output /evidence/repair-before.txt --lock-path /evidence/benchmark.lock --bench-regex '^BenchmarkSmallSourceReceiptProductionGo$' --require-benchmarks BenchmarkSmallSourceReceiptProductionGo/full_dfa,BenchmarkSmallSourceReceiptProductionGo/single_byte_edit_dfa,BenchmarkSmallSourceReceiptProductionGo/no_edit_dfa --runs 20 --seed-start 1 --benchtime 750ms > /evidence/repair-runner.log 2>&1
