package parsercorephase0

import "errors"

// IncludeChild preserves source containment and left-to-right checked score
// addition. The traversal calls it once per child, in child order,
// before publishing the parent. The initial precedence is the raw production's
// own contribution; alias wrappers use Emit with an already complete score.
func (r *NativeProjectionRecord) IncludeChild(start, end uint32, precedence int32) error {
	if start < r.StartByte || end > r.EndByte {
		return errors.New("parser-core phase zero: native child extends outside raw parent")
	}
	var err error
	r.DynamicPrecedence, err = checkedSelectedPrecedence(r.DynamicPrecedence, precedence)
	return err
}
