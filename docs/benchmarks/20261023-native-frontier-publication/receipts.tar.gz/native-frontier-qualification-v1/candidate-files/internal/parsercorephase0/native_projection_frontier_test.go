package parsercorephase0

import (
	"fmt"
	"testing"
	"unsafe"
)

type nativeFrontierTestSink struct {
	nativeWalkTestSink
	sealed []bool
}

func (s *nativeFrontierTestSink) Emit(r NativeProjectionRecord, ids []SelectedNodeID) (SelectedNodeID, error) {
	for _, id := range ids {
		if id == 0 || int(id) > len(s.sealed) || !s.sealed[id-1] {
			return 0, fmt.Errorf("child %d attached before final metadata", id)
		}
	}
	s.sealed = append(s.sealed, false)
	return s.nativeWalkTestSink.Emit(r, ids)
}

func (s *nativeFrontierTestSink) Read(SelectedNodeID) (NativeProjectionRecord, error) {
	panic("native projection must never read back an unfinished public node")
}

func (s *nativeFrontierTestSink) Rewrite(id SelectedNodeID, r NativeProjectionRecord) error {
	if id == 0 || int(id) > len(s.sealed) || s.sealed[id-1] {
		return fmt.Errorf("invalid or repeated final write: %d", id)
	}
	s.sealed[id-1] = true
	return s.nativeWalkTestSink.Rewrite(id, r)
}

func TestNativeProjectionFrontierFinalizesEachNodeOnce(t *testing.T) {
	for _, retainedAlias := range []bool{false, true} {
		t.Run(fmt.Sprint(retainedAlias), func(t *testing.T) {
			policy := selectedStoreTestPolicy(t, 2, 1, 4)
			policy.Unary[3*len(policy.Symbols)+1] = SelectedUnaryPass
			policy.SupertypeMasks = make([]uint32, len(policy.Symbols))
			policy.SupertypeMasks[3], policy.SupertypeMasks[6] = 1, 2
			if retainedAlias {
				policy.SetRetainedAliasChildren([]SelectedAliasChildPair{{Alias: 4, Child: 3}})
			}
			tables := &selectedStorePolicyTable{policy: policy}
			tables.fields = map[uint16][]FieldMapEntry{12: {{ChildIndex: 0, FieldID: 9}}}
			if retainedAlias {
				tables.aliases = map[productionKey][]Symbol{{productionID: 12, childCount: 1}: {4}}
			}
			c, err := New(tables, Limits{})
			if err != nil {
				t.Fatal(err)
			}
			leaf, err := c.appendSubtree(subtreeRecord{symbol: 1, terminal: true, endByte: 1, dynamicPrecedence: 2}, nil, nil, nil)
			if err != nil {
				t.Fatal(err)
			}
			unary, err := c.appendSubtree(subtreeRecord{symbol: 3, endByte: 1, dynamicPrecedence: 3, productionID: 11}, []SubtreeID{leaf}, nil, nil)
			if err != nil {
				t.Fatal(err)
			}
			child := unary
			var aliases []Symbol
			if retainedAlias {
				aliases = []Symbol{4}
			} else {
				child, err = c.appendSubtree(subtreeRecord{symbol: 6, endByte: 1, dynamicPrecedence: 42}, []SubtreeID{unary}, nil, nil)
				if err != nil {
					t.Fatal(err)
				}
			}
			root, err := c.appendSubtree(subtreeRecord{symbol: 2, endByte: 1, dynamicPrecedence: 7, productionID: 12}, []SubtreeID{child}, []FieldMapEntry{{ChildIndex: 0, FieldID: 9}}, aliases)
			if err != nil {
				t.Fatal(err)
			}
			var scratch MaterializationPostorderScratch
			var sink nativeFrontierTestSink
			replay := NativeProjectionReplay{Scratch: &scratch, Transition: func(pre StateID, _ *MaterializationReplayView) (StateID, bool, error) { return pre + 1, true, nil }}
			roots, err := c.StreamNativeProjection([]SubtreeID{root}, []byte("x"), &sink, replay, nil)
			if err != nil {
				t.Fatal(err)
			}
			wantCount := 2
			if retainedAlias {
				wantCount = 3
			}
			if len(sink.records) != wantCount || len(roots) != 1 || int(roots[0]) != wantCount {
				t.Fatalf("unexpected projection: %+v / %+v", roots, sink.records)
			}
			for _, sealed := range sink.sealed {
				if !sealed {
					t.Fatal("unfinished public node returned")
				}
			}
			first, last := sink.records[0], sink.records[len(sink.records)-1]
			if first.Symbol != 1 || first.Source != unary || first.DynamicPrecedence != 5 || first.ProductionID != 11 || !first.Terminal() || !first.ReplayStateKnown() || last.DynamicPrecedence != 12 || last.Symbol != 2 {
				t.Fatalf("final metadata: %+v", sink.records)
			}
			if retainedAlias {
				alias := sink.records[1]
				if first.Field != 0 || first.SupertypeMask != 1 || alias.Symbol != 4 || alias.Field != 9 || alias.DynamicPrecedence != 5 || alias.Terminal() {
					t.Fatalf("alias metadata: %+v", sink.records)
				}
			} else if first.Field != 9 || first.SupertypeMask != 3 {
				t.Fatalf("hidden metadata: %+v", first)
			}
			if len(scratch.nativeRecords) != 0 || scratch.inUse {
				t.Fatal("frontier remained active")
			}
			minimum := uint64(cap(scratch.nativeRecords)) * uint64(unsafe.Sizeof(NativeProjectionRecord{}))
			if minimum == 0 || scratch.RetainedBytes() < minimum {
				t.Fatal("frontier storage was not charged")
			}
		})
	}
}

func TestNativeProjectionFrontierPreservesDeeperFieldSpan(t *testing.T) {
	policy := selectedStoreTestPolicy(t, 2, 1)
	policy.SupertypeMasks = make([]uint32, len(policy.Symbols))
	policy.SupertypeMasks[7] = 2
	tables := &selectedStorePolicyTable{policy: policy}
	tables.fields = map[uint16][]FieldMapEntry{12: {{ChildIndex: 0, FieldID: 9}}, 13: {{ChildIndex: 0, FieldID: 9}}}
	c, err := New(tables, Limits{})
	if err != nil {
		t.Fatal(err)
	}
	var children []SubtreeID
	for i := 0; i < 3; i++ {
		id, err := c.appendSubtree(subtreeRecord{symbol: 1, terminal: true, startByte: uint32(i), endByte: uint32(i + 1), extra: i == 2, dynamicPrecedence: int16(i + 2)}, nil, nil, nil)
		if err != nil {
			t.Fatal(err)
		}
		children = append(children, id)
	}
	hidden, err := c.appendSubtree(subtreeRecord{symbol: 7, endByte: 3, dynamicPrecedence: 42, productionID: 13}, children, []FieldMapEntry{{ChildIndex: 0, FieldID: 9}}, nil)
	if err != nil {
		t.Fatal(err)
	}
	root, err := c.appendSubtree(subtreeRecord{symbol: 2, endByte: 3, dynamicPrecedence: 7, productionID: 12}, []SubtreeID{hidden}, []FieldMapEntry{{ChildIndex: 0, FieldID: 9}}, nil)
	if err != nil {
		t.Fatal(err)
	}
	var scratch MaterializationPostorderScratch
	var sink nativeFrontierTestSink
	replay := NativeProjectionReplay{Scratch: &scratch, Transition: func(pre StateID, _ *MaterializationReplayView) (StateID, bool, error) { return pre + 1, true, nil }}
	if _, err = c.StreamNativeProjection([]SubtreeID{root}, []byte("abc"), &sink, replay, nil); err != nil {
		t.Fatal(err)
	}
	if len(sink.records) != 4 || sink.records[0].Field != 9 || sink.records[1].Field != 0 || sink.records[2].Field != 0 || !sink.records[2].Extra() || sink.records[2].ReplayPreKnown() || sink.records[3].DynamicPrecedence != 16 {
		t.Fatalf("field or score semantics changed: %+v", sink.records)
	}
	for _, r := range sink.records[:3] {
		if r.SupertypeMask != 2 {
			t.Fatal("hidden supertype missing")
		}
	}
}
