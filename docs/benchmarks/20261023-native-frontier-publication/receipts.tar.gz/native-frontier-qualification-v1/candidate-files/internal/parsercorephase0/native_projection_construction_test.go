package parsercorephase0

import (
	"math"
	"testing"
)

func TestNativeProjectionConstructionCheckedChildOrder(t *testing.T) {
	for _, tc := range []struct {
		name     string
		initial  int32
		children []int32
		want     int32
		fail     bool
	}{
		{"sum", 3, []int32{4, -2}, 5, false},
		{"positive_boundary", math.MaxInt32 - 1, []int32{1}, math.MaxInt32, false},
		{"negative_boundary", math.MinInt32 + 1, []int32{-1}, math.MinInt32, false},
		{"positive_intermediate_overflow", math.MaxInt32, []int32{1, -1}, 0, true},
		{"negative_intermediate_overflow", math.MinInt32, []int32{-1, 1}, 0, true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			r := NativeProjectionRecord{StartByte: 2, EndByte: 9, DynamicPrecedence: tc.initial}
			var err error
			for _, score := range tc.children {
				if err = r.IncludeChild(3, 8, score); err != nil {
					break
				}
			}
			if (err != nil) != tc.fail || err == nil && r.DynamicPrecedence != tc.want {
				t.Fatalf("score=%d err=%v", r.DynamicPrecedence, err)
			}
		})
	}
	for _, span := range [][2]uint32{{1, 8}, {3, 10}} {
		r := NativeProjectionRecord{StartByte: 2, EndByte: 9, DynamicPrecedence: 17}
		if err := r.IncludeChild(span[0], span[1], 3); err == nil || r.DynamicPrecedence != 17 {
			t.Fatal("out-of-parent child changed score or was accepted")
		}
	}
}
