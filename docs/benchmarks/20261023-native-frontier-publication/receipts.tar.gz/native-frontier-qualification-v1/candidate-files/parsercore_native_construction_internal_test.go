//go:build gts_parsercorephase0

package gotreesitter

import (
	"fmt"
	"reflect"
	"testing"

	core "github.com/odvcencio/gotreesitter/internal/parsercorephase0"
)

func TestNativeProjectionConstructionMatchesGeneralParent(t *testing.T) {
	for _, count := range []int{0, 1, 2, 4, 257} {
		t.Run(fmt.Sprint(count), func(t *testing.T) {
			source := []byte(" a\nb ")
			points, err := newDiagnosticParserCorePointIndexInto(source, func() error { return nil }, nil)
			if err != nil {
				t.Fatal(err)
			}
			var nodes [2]*Node
			for mode := 0; mode < 2; mode++ {
				arena := newNodeArena(arenaClassFull)
				var scratch nativeProjectionWorkspace
				scratch.records.Append(nativeStreamRecord{})
				sink := nativeStreamSink{arena: arena, points: &points, scratch: &scratch}
				ids := make([]core.SelectedNodeID, count)
				children := make([]*Node, count)
				var fields []FieldID
				if count > 0 {
					fields = arena.allocFieldIDSlice(count)
				}
				for i := range children {
					child := newLeafNodeInArena(arena, 1, true, 1, 4, points.point(1), points.point(4))
					child.dynamicPrecedence = int32(i%3) - 1
					if i%2 == 0 {
						fields[i] = 7
					}
					scratch.records.Append(nativeStreamRecord{node: child, metadata: nativeStreamMetadata{field: core.FieldID(fields[i])}})
					ids[i], children[i] = core.SelectedNodeID(i+1), child
				}
				r := core.NativeProjectionRecord{Symbol: 2, Source: 11, StartByte: 0, EndByte: uint32(len(source)), ChildCount: uint32(count), ProductionID: 13, DynamicPrecedence: 19, SupertypeMask: 4}
				for _, child := range children {
					r.DynamicPrecedence += child.dynamicPrecedence
				}
				if mode == 0 {
					n := newParentNodeInArena(arena, 2, false, children, fields, 13)
					id := core.SelectedNodeID(scratch.records.Len())
					scratch.records.Append(nativeStreamRecord{node: n})
					if err := sink.rewrite(id, r); err != nil {
						t.Fatal(err)
					}
					nodes[mode] = n
				} else {
					id, err := sink.emit(r, ids)
					if err != nil {
						t.Fatal(err)
					}
					if err := sink.rewrite(id, r); err != nil {
						t.Fatal(err)
					}
					nodes[mode] = scratch.records.At(int(id)).node
				}
				for i, child := range children {
					if child.parent != nodes[mode] || int(child.childIndex) != i {
						t.Fatal("parent ownership differs")
					}
				}
				if arena.parentNodesConstructed != 1 {
					t.Fatal("parent work accounting differs")
				}
			}
			a, b := *nodes[0], *nodes[1]
			a.children, b.children = nil, nil
			a.fieldMetadata, b.fieldMetadata = nil, nil
			a.ownerArena, b.ownerArena = nil, nil
			if !reflect.DeepEqual(a, b) || !reflect.DeepEqual(nodes[0].fieldIDs(), nodes[1].fieldIDs()) || !reflect.DeepEqual(nodes[0].fieldSources(), nodes[1].fieldSources()) || nodes[0].supertypeMask() != nodes[1].supertypeMask() {
				t.Fatalf("constructed metadata differs: %+v / %+v", a, b)
			}
		})
	}
}

func TestNativeProjectionConstructionRejectsInvalidChildren(t *testing.T) {
	for _, bad := range []string{"handle", "count"} {
		t.Run(bad, func(t *testing.T) {
			arena := newNodeArena(arenaClassFull)
			var scratch nativeProjectionWorkspace
			scratch.records.Append(nativeStreamRecord{})
			child := newLeafNodeInArena(arena, 1, true, 1, 2, Point{Column: 1}, Point{Column: 2})
			child.dynamicPrecedence = 1
			scratch.records.Append(nativeStreamRecord{node: child})
			s := nativeStreamSink{arena: arena, scratch: &scratch}
			r := core.NativeProjectionRecord{StartByte: 0, EndByte: 3, ChildCount: 1}
			ids := []core.SelectedNodeID{1}
			switch bad {
			case "handle":
				ids[0] = 2
			case "count":
				r.ChildCount = 2
			}
			if _, err := s.emit(r, ids); err == nil {
				t.Fatal("invalid construction accepted")
			}
			if scratch.records.Len() != 2 {
				t.Fatal("failed parent published a stream record")
			}
		})
	}
}
