from pathlib import Path
import json,hashlib
p=Path('/candidate')
print(json.dumps({str(x.relative_to(p)):hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted(p.rglob('*.go'))},sort_keys=True))
