from pathlib import Path
import subprocess,json,fcntl,os
p=Path(__file__).resolve().parent
def save(name, value):
 q=p/'out'/name;t=q.with_name(q.name+'.tmp');t.write_text(json.dumps(value,indent=2)+'\n');os.replace(t,q)
with open('/tmp/gotreesitter-compact-storage-docker.lock','w') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 args=json.loads((p/'command.json').read_text());name=args[args.index('--name')+1]
 with (p/'out/container.log').open('wb') as f:
  try: code=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=10800).returncode
  except subprocess.TimeoutExpired:
   code=124;subprocess.run(['docker','stop','--time','10',name],stdout=f,stderr=subprocess.STDOUT)
 info=json.loads(subprocess.check_output(['docker','inspect',name],text=True))[0]
 save('inspect.json',info);save('audit.json',{'exit_code':code,'state':info['State']})
 subprocess.run(['docker','rm',name],check=True,stdout=subprocess.DEVNULL)
