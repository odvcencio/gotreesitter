from pathlib import Path
import hashlib,json
print(json.dumps({role:{str(q.relative_to(Path('/'+role))):hashlib.sha256(q.read_bytes()).hexdigest() for q in sorted(Path('/'+role).rglob('*.go'))} for role in ['baseline','candidate']},sort_keys=True))
