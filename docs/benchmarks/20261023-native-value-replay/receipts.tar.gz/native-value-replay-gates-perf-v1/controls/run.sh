set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
python3 /controls/source_hashes.py > /evidence/source-before.json
cd /candidate
mkdir /evidence/invariants /evidence/cgo /evidence/ledger
while IFS= read -r lang; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /compiled/candidate.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/invariants/$route-$lang.log" 2>&1
  printf 'invariant\t%s\t%s\n' "$lang" "$route" >> /evidence/progress.tsv
 done
done < /controls/languages.txt
cd /candidate/cgo_harness
while IFS= read -r lang; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GTS_PARITY_MODE=exhaustive /compiled/candidate-cgo.test -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${lang}$" -test.count=1 -test.v -test.timeout=5m > "/evidence/cgo/$route-$lang.log" 2>&1
  printf 'C\t%s\t%s\n' "$lang" "$route" >> /evidence/progress.tsv
 done
done < /controls/languages.txt
cd /candidate
while IFS= read -r lang; do
 /compiled/baseline-ledger --langs "$lang" > "/evidence/ledger/baseline-$lang.json" 2> "/evidence/ledger/baseline-$lang.log"
 /compiled/candidate-ledger --langs "$lang" > "/evidence/ledger/candidate-$lang.json" 2> "/evidence/ledger/candidate-$lang.log"
 cmp "/evidence/ledger/baseline-$lang.json" "/evidence/ledger/candidate-$lang.json"
 printf 'ledger\t%s\n' "$lang" >> /evidence/progress.tsv
done < /controls/languages.txt
printf 'correctness-and-ledger-complete\n' > /evidence/correctness-complete.txt
export CGO_ENABLED=0
bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-yaml.txt --output /evidence/candidate-yaml.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 181001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputYAML$' --require-benchmarks 'BenchmarkCompactThroughputYAML/r4_legacy,BenchmarkCompactThroughputYAML/eof8k_legacy,BenchmarkCompactThroughputYAML/r4_ordinary,BenchmarkCompactThroughputYAML/eof8k_ordinary,BenchmarkCompactThroughputYAML/r4_owned,BenchmarkCompactThroughputYAML/eof8k_owned' > /evidence/yaml-driver.log 2>&1
bash scripts/run_randomized_benchmarks.sh --primary-go-suite --baseline-root /baseline --baseline-output /evidence/baseline-go.txt --output /evidence/candidate-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 182001 --benchtime 750ms > /evidence/go-driver.log 2>&1
GTS_ADMISSION_CANDIDATE=1 bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-compact-go.txt --output /evidence/candidate-compact-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 183001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputGo$' --require-benchmarks 'BenchmarkCompactThroughputGo/full_dfa,BenchmarkCompactThroughputGo/single_byte_edit_dfa,BenchmarkCompactThroughputGo/no_edit_dfa,BenchmarkCompactThroughputGo/fresh_one_mib,BenchmarkCompactThroughputGo/query_compile,BenchmarkCompactThroughputGo/grammargen_lr' > /evidence/compact-go-driver.log 2>&1
python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'complete\n' > /evidence/complete.txt
