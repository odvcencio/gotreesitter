set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
python3 /controls/source_hashes.py > /evidence/source-before.json
for role in baseline candidate; do
 cd "/$role/cgo_harness"
 go test -c -overlay=/controls/cgo-overlay.json -tags treesitter_c_parity,gts_parsercorephase0 -o "/evidence/$role-cgo.test" . > "/evidence/$role-cgo-build.log" 2>&1
 "/evidence/$role-cgo.test" -test.run '^TestWarmCapacityLargeGoLockedC$' -test.count=1 -test.v -test.timeout=5m > "/evidence/$role-large-go-C.log" 2>&1
done
printf 'large-Go-C-and-work-complete\n' > /evidence/correctness-complete.txt
cd /candidate
export CGO_ENABLED=0 GOFLAGS='-p=1 -mod=readonly -buildvcs=false -overlay=/controls/benchmark-overlay.json'
bash scripts/run_randomized_benchmarks.sh --primary-go-suite --baseline-root /baseline --baseline-output /evidence/baseline-go.txt --output /evidence/candidate-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 188001 --benchtime 750ms > /evidence/go-driver.log 2>&1
GTS_ADMISSION_CANDIDATE=1 bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-compact-go.txt --output /evidence/candidate-compact-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 189001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputGo$' --require-benchmarks 'BenchmarkCompactThroughputGo/full_dfa,BenchmarkCompactThroughputGo/single_byte_edit_dfa,BenchmarkCompactThroughputGo/no_edit_dfa,BenchmarkCompactThroughputGo/fresh_one_mib,BenchmarkCompactThroughputGo/query_compile,BenchmarkCompactThroughputGo/grammargen_lr' > /evidence/compact-go-driver.log 2>&1
printf 'complete\n' > /evidence/complete.txt
