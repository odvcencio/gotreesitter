set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
python3 /controls/source_hashes.py > /evidence/source-before.json
cd /candidate
go test -c -overlay=/controls/overlay.json -tags gts_parsercorephase0 -o /evidence/foam-probe.test . > /evidence/foam-build.log 2>&1
/evidence/foam-probe.test -test.run '^TestNativeFoamReuseMetadataDiagnosis$' -test.v -test.count=1 -test.timeout=5m > /evidence/foam-diagnosis.log 2>&1
python3 /controls/ledger-diagnosis.py > /evidence/progress.log 2>&1
python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'diagnostic complete; counter failures retained in failures.json\n' > /evidence/complete.txt
