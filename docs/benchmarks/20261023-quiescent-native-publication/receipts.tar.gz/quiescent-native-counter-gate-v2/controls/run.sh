set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
python3 /controls/source_hashes.py > /evidence/source-before.json
for lang in go yaml; do
 python3 /controls/compare-ledger.py "/compiled/baseline-$lang-ledger.json" "/compiled/candidate-$lang-ledger.json" "/evidence/$lang-counter-gate.json" > "/evidence/$lang-counter-gate.log"
done
cd /candidate
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -run '^Test(CheckpointReserve.*|CompactLinkStorage.*|Observed.*|ReserveRecord.*|ProjectRecord.*)' -count=1 -v -timeout=5m > /evidence/core-386.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test -c -tags gts_parsercorephase0 -o /evidence/candidate-386.test . > /evidence/root-386-build.log 2>&1
/evidence/candidate-386.test -test.run '^TestQuiescentNativeGo.*$' -test.v -test.count=1 -test.timeout=8m > /evidence/root-386.log 2>&1
python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'complete\n' > /evidence/complete.txt
