import json,sys
from pathlib import Path
before=json.loads(Path(sys.argv[1]).read_text());after=json.loads(Path(sys.argv[2]).read_text());changes=[];metadata=[]
assert before['schema']==after['schema'] and len(before['rows'])==len(after['rows'])
down={'tokens','new_nodes','max_live_versions','multi_version_token_share_ppm'};up={'reused_bytes','block_splices'}
def counters(a,b,path):
 assert set(a)==set(b)
 for k,v in a.items():
  n=b[k]
  if k in down:assert n<=v,(path,k,v,n)
  elif k in up:assert n>=v,(path,k,v,n)
  else:assert n==v,(path,k,v,n)
  if n!=v:changes.append({'row':path+'/'+k,'before':v,'after':n})
for a,b in zip(before['rows'],after['rows']):
 for key in ['language','fixture','fixture_sha256','session_sha256','route']:assert a[key]==b[key]
 name=a['language']+'/'+a['route'];counters(a['full'],b['full'],name+'/full');assert len(a['edits'])==len(b['edits'])
 for x,y in zip(a['edits'],b['edits']):
  assert x['step']==y['step'] and x['kind']==y['kind'];counters(x['counters'],y['counters'],name+'/edit/'+str(x['step']))
  for key in ['route','decline_reason']:
   if x.get(key)!=y.get(key):metadata.append({'row':name+'/edit/'+str(x['step'])+'/'+key,'before':x.get(key),'after':y.get(key)})
result={'passed':True,'changes':changes,'route_metadata_changes':metadata,'policy':'strict work decreases or equality; reuse increases or equality; source identity, completion, coverage and error flags exact'}
if len(sys.argv)>3:Path(sys.argv[3]).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
