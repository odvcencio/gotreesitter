from pathlib import Path
import subprocess,json
p=Path('/evidence');(p/'ledger').mkdir();(p/'deltas').mkdir();rows=[]
for lang in Path('/controls/languages.txt').read_text().splitlines():
 for role in ['baseline','candidate']:
  with (p/'ledger'/(role+'-'+lang+'.json')).open('w') as f, (p/'ledger'/(role+'-'+lang+'.log')).open('w') as e:subprocess.run(['/evidence/'+role+'-ledger','--langs',lang],cwd='/'+role,check=True,stdout=f,stderr=e)
 with (p/'deltas'/(lang+'.log')).open('w') as f:
  code=subprocess.run(['python3','/controls/compare-ledger.py',str(p/'ledger'/('baseline-'+lang+'.json')),str(p/'ledger'/('candidate-'+lang+'.json')),str(p/'deltas'/(lang+'.json'))],stdout=f,stderr=subprocess.STDOUT).returncode
 rows.append({'language':lang,'exit_code':code});(p/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(lang,code,flush=True)
(p/'failures.json').write_text(json.dumps([x for x in rows if x['exit_code']],indent=2)+'\n')
