set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
python3 /controls/source_hashes.py > /evidence/source-before.json
cd /candidate
go test -c -overlay=/controls/overlay.json -tags gts_parsercorephase0 -o /evidence/probe.test . > /evidence/build.log 2>&1
/evidence/probe.test -test.run '^TestQuiescentNativeReuseMetadataMatchesReference$' -test.v -test.count=1 -test.timeout=5m > /evidence/diagnosis.log 2>&1
for role in baseline candidate; do
 cd "/$role"
 go build -tags gts_parsercorephase0 -o "/evidence/$role-ledger" ./cmd/perfcounterledger > "/evidence/$role-ledger-build.log" 2>&1
done
python3 /controls/ledger-diagnosis.py > /evidence/progress.log 2>&1
python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'diagnostic complete; failures retained\n' > /evidence/complete.txt
