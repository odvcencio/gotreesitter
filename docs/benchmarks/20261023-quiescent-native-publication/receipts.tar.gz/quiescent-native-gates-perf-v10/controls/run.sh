set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
python3 /controls/source_hashes.py > /evidence/source-before.json
cd /candidate
go test ./internal/parsercorephase0 -count=1 -v -timeout=8m > /evidence/core-unit.log 2>&1
go test -tags gts_eof_recovery_shadow ./internal/parsercorephase0 -count=1 -v -timeout=8m > /evidence/core-shadow.log 2>&1
go test -race ./internal/parsercorephase0 -run '^Test(Checkpoint|EmptyCheckpoint|CoreCheckpoint|.*PrivateCopy.*|CompactLinkStorage.*|ObservedRecordDensity.*)' -count=1 -v -timeout=8m > /evidence/core-race.log 2>&1
/compiled/candidate.test -test.run '^Test(DiagnosticParserCoreVersionLexerSnapshot.*|VersionLexerPairedValidation.*|FreshSnapshotPages.*|SnapshotPairFootprint.*|CompactExternalScannerCheckpoint.*|DiagnosticParserCoreElectionPreservesInvalidCheckpointDeclines|DiagnosticParserCoreCheckpointCompactLayoutsAMD64|DiagnosticParserCore.*Ownership.*|DiagnosticParserCore.*OwnedLexer.*|CompactYAMLReductionSelectionPreservesSampleWork|QuiescentNative.*|NativeProjection.*|DiagnosticParserCoreSelectedStore.*|CompactReuseDependencyPublicationAndReset|CompactLegacyRead.*)$' -test.count=1 -test.v -test.timeout=5m > /evidence/root-checkpoint.log 2>&1
/compiled/candidate.test -test.run '^Test(CompactAcceptance(ChangedSourceKeepsRebuildBudget|CachedPublicationStopControl)|CompactMemoryBudgetDetectsGrowthAfterSmallPoll|CompactAcceptance.*(MemoryBudget|RetentionBound)|CompactArenaReserve.*(Budget|RetentionCap)|CompactExternalScannerCheckpointCopyMemoryBudget|CompactRecoveryMemoMemoryBudget|CompactBorrowedMaterializationProjectionMemoryBudget|G18RefSetSchedulerMemoryBudgetAccounting|RuntimeMemoryBudget.*|RuntimeMemoryHardCeilingStillStopsParse|ParseMemoryHardCeiling.*)$' -test.count=1 -test.v -test.timeout=8m > /evidence/memory.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -run '^Test(CheckpointReserve.*|CompactLinkStorage.*|Observed.*|ReserveRecord.*|ProjectRecord.*)' -count=1 -v -timeout=5m > /evidence/core-386.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test -c -tags gts_parsercorephase0 -o /evidence/root-386.test . > /evidence/root-386-build.log 2>&1
/evidence/root-386.test -test.run '^Test(QuiescentNative.*|NativeProjectionAliasReceiptRejectsChangedPublication)$' -test.count=1 -test.v -test.timeout=5m > /evidence/root-386.log 2>&1
cd /candidate/cgo_harness
GTS_YAML_LARGE_PROBE=1 /compiled/candidate-cgo.test -test.run '^Test(YAMLOwnedGrammarLockedCParity|CompactYAMLDocumentStreamLockedC|YAMLRecoveredMappingQuotesLockedC|YAMLEOFRecoverWrapCompactRoute|YAMLEOFRecoverWrapUnfinishedMappingDeclinesCompact|YAMLOneBytePrintableEOFAdmissionMatchesLockedC)$' -test.count=1 -test.v -test.timeout=8m > /evidence/yaml-owned-cgo.log 2>&1
cd /candidate
go test -c -overlay=/controls/go-receipt-overlay.json -tags gts_parsercorephase0 -o /evidence/go-receipt.test . > /evidence/go-receipt-build.log 2>&1
/evidence/go-receipt.test -test.run '^TestQuiescentNativeGoPublicationMatchesReference$' -test.v -test.count=1 -test.timeout=5m > /evidence/go-receipts.log 2>&1
for role in baseline candidate; do
 cd "/$role"
 go build -tags gts_parsercorephase0 -o "/evidence/$role-ledger" ./cmd/perfcounterledger > "/evidence/$role-ledger-build.log" 2>&1
done
cd /candidate
mkdir /evidence/invariants /evidence/cgo /evidence/ledger /evidence/counter-deltas
while IFS= read -r lang; do
 /evidence/baseline-ledger --langs "$lang" > "/evidence/ledger/baseline-$lang.json" 2> "/evidence/ledger/baseline-$lang.log"
 /evidence/candidate-ledger --langs "$lang" > "/evidence/ledger/candidate-$lang.json" 2> "/evidence/ledger/candidate-$lang.log"
 python3 /controls/compare-ledger.py "/evidence/ledger/baseline-$lang.json" "/evidence/ledger/candidate-$lang.json" "/evidence/counter-deltas/$lang.json" > "/evidence/counter-deltas/$lang.log"
 printf 'ledger\t%s\n' "$lang" >> /evidence/progress.tsv
done < /controls/languages.txt
while IFS= read -r lang; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /compiled/candidate.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/invariants/$route-$lang.log" 2>&1
  printf 'invariant\t%s\t%s\n' "$lang" "$route" >> /evidence/progress.tsv
 done
done < /controls/languages.txt
cd /candidate/cgo_harness
while IFS= read -r lang; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GTS_PARITY_MODE=exhaustive /compiled/candidate-cgo.test -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${lang}$" -test.count=1 -test.v -test.timeout=5m > "/evidence/cgo/$route-$lang.log" 2>&1
  printf 'C\t%s\t%s\n' "$lang" "$route" >> /evidence/progress.tsv
 done
done < /controls/languages.txt
cd /candidate
cd /candidate/cgo_harness
mkdir /evidence/cogno
go test -c -overlay=/controls/cogno-overlay.json -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/cogno/probe.test . > /evidence/cogno/build.log 2>&1
for route in production candidate; do
 for api in plain profiled; do
  for edit in insert replace delete; do
   label="$route-$api-$edit"
   if /evidence/cogno/probe.test -test.run "^TestGoCognociente137KiBTopEditLockedC$/^$route$/^$api$/^$edit$" -test.v -test.count=1 -test.timeout=5m > "/evidence/cogno/$label.log" 2>&1; then code=0; else code=$?; fi
   printf '%s\t%s\n' "$label" "$code" >> /evidence/cogno/status.tsv
   if [[ "$edit" != delete && "$code" != 0 ]]; then exit "$code"; fi
  done
 done
done
python3 - <<'COGNO'
from pathlib import Path
p=Path('/evidence/cogno');rows=(p/'status.tsv').read_text().splitlines();assert len(rows)==12
for row in rows:
 name,code=row.split('\t');text=(p/(name+'.log')).read_text();assert 'D8 incremental/fresh Go and incremental/fresh C agree independently:' in text
 if name.endswith('-delete'):
  assert code=='1' and 'Path:/source_file/function_declaration[2]/block[4]/ERROR[1] Category:shape GoValue:children=1 CValue:children=2' in text
 else:assert code=='0' and 'independent fresh Go versus fresh C: exact symbols, fields, spans, points, flags' in text
COGNO
cd /candidate
printf 'correctness-and-ledger-complete\n' > /evidence/correctness-complete.txt
export CGO_ENABLED=0
bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-yaml.txt --output /evidence/candidate-yaml.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 184001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputYAML$' --require-benchmarks 'BenchmarkCompactThroughputYAML/r4_legacy,BenchmarkCompactThroughputYAML/eof8k_legacy,BenchmarkCompactThroughputYAML/r4_ordinary,BenchmarkCompactThroughputYAML/eof8k_ordinary,BenchmarkCompactThroughputYAML/r4_owned,BenchmarkCompactThroughputYAML/eof8k_owned' > /evidence/yaml-driver.log 2>&1
bash scripts/run_randomized_benchmarks.sh --primary-go-suite --baseline-root /baseline --baseline-output /evidence/baseline-go.txt --output /evidence/candidate-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 185001 --benchtime 750ms > /evidence/go-driver.log 2>&1
GTS_ADMISSION_CANDIDATE=1 bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-compact-go.txt --output /evidence/candidate-compact-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 186001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputGo$' --require-benchmarks 'BenchmarkCompactThroughputGo/full_dfa,BenchmarkCompactThroughputGo/single_byte_edit_dfa,BenchmarkCompactThroughputGo/no_edit_dfa,BenchmarkCompactThroughputGo/fresh_one_mib,BenchmarkCompactThroughputGo/query_compile,BenchmarkCompactThroughputGo/grammargen_lr' > /evidence/compact-go-driver.log 2>&1
python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'complete\n' > /evidence/complete.txt
