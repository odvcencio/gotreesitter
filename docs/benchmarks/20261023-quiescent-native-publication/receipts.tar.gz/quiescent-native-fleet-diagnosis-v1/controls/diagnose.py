from pathlib import Path
import subprocess,os,json
p=Path('/evidence');(p/'invariants').mkdir();rows=[]
for lang in Path('/controls/languages.txt').read_text().splitlines():
 if lang<'ini':continue
 log=p/'invariants'/(lang+'.log')
 with log.open('w') as f:
  code=subprocess.run(['/compiled/candidate.test','-test.run','^TestV1InvariantGateR4EditSession$','-test.count=1','-test.v','-test.timeout=5m'],cwd='/candidate',env={**os.environ,'GTS_ADMISSION_CANDIDATE':'1','GOTREESITTER_V1_INVARIANT_LANGUAGE':lang},stdout=f,stderr=subprocess.STDOUT).returncode
 rows.append({'language':lang,'exit_code':code});(p/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(lang,code,flush=True)
(p/'failures.json').write_text(json.dumps([x for x in rows if x['exit_code']],indent=2)+'\n')
