set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1
python3 /controls/source_hashes.py > /evidence/source-before.json
python3 /controls/diagnose.py > /evidence/progress.log 2>&1
python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'diagnostic complete; test failures retained in failures.json\n' > /evidence/complete.txt
