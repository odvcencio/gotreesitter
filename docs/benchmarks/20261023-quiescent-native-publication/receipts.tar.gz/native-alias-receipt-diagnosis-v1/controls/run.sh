set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
python3 /controls/source_hashes.py > /evidence/source-before.json
cd /candidate
go test -c -overlay=/controls/overlay.json -tags gts_parsercorephase0 -o /evidence/probe.test . > /evidence/build.log 2>&1
set +e
/evidence/probe.test -test.run '^TestQuiescentNativeReuseMetadataMatchesReference/(pkl|smithy)$' -test.v -test.count=1 -test.timeout=5m > /evidence/diagnosis.log 2>&1
result=$?
set -e
python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
exit "$result"
