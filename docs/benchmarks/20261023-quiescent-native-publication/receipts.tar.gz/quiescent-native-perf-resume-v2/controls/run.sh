set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
python3 /controls/source_hashes.py > /evidence/source-before.json
python3 - <<'VERIFY'
from pathlib import Path
import json,hashlib
p=Path('/qualified-large-C');before=json.loads((p/'source-before.json').read_text());after=json.loads((p/'source-after-final.json').read_text());current=json.loads(Path('/evidence/source-before.json').read_text());assert before==after==current
logs={}
for role in ['baseline','candidate']:
 f=p/(role+'-large-go-C.log');text=f.read_text();assert '--- FAIL:' not in text and text.count('warmed 1 MiB Go: exact symbols, fields, spans, points, flags, and deep digest')==6
 logs[role]=hashlib.sha256(f.read_bytes()).hexdigest()
Path('/evidence/reused-correctness-receipt.json').write_text(json.dumps({'source_manifests_equal':True,'large_C_comparisons':12,'raw_logs_sha256':logs,'scope':'Independent validation of completed exact-source results; no new C tests executed in this resume.'},indent=2)+'\n')
VERIFY
cd /candidate
export CGO_ENABLED=0 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
bash scripts/run_randomized_benchmarks.sh --primary-go-suite --baseline-root /baseline --baseline-output /evidence/baseline-go.txt --output /evidence/candidate-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 188001 --benchtime 750ms > /evidence/go-driver.log 2>&1
export GOFLAGS='-p=1 -mod=readonly -buildvcs=false -overlay=/controls/benchmark-overlay.json'
GTS_ADMISSION_CANDIDATE=1 bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-compact-go.txt --output /evidence/candidate-compact-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 189001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputGo$' --require-benchmarks 'BenchmarkCompactThroughputGo/full_dfa,BenchmarkCompactThroughputGo/single_byte_edit_dfa,BenchmarkCompactThroughputGo/no_edit_dfa,BenchmarkCompactThroughputGo/fresh_one_mib,BenchmarkCompactThroughputGo/query_compile,BenchmarkCompactThroughputGo/grammargen_lr' > /evidence/compact-go-driver.log 2>&1
printf 'complete\n' > /evidence/complete.txt
