#!/usr/bin/env bash
set -euo pipefail
# UNAPPLIED DEFAULT-API PREFLIGHT ONLY. Root schedules this after the census in
# the existing bounded container/shared workload lock. This script acquires no
# independent lock, creates no checkout, and runs no benchmark.
controls=/controls/oracle0271
out=${GTS_ORACLE0271_RESULTS:-/evidence/oracle0271-trial}
binary=${GTS_ORACLE0271_BINARY:-/runtime/tmp/gotreesitter-oracle0271/preflight.test}
[[ "$out" = /* && "$binary" = /* ]] || { echo 'absolute output/binary paths required' >&2; exit 2; }
[[ ! -e "$out/started.json" && ! -e "$binary" ]] || { echo 'refusing to overwrite an earlier oracle trial' >&2; exit 2; }
mkdir -p "$out" "$(dirname "$binary")"
export GOWORK=off GOTOOLCHAIN=local GOMAXPROCS=1 CGO_ENABLED=1 GOPROXY=off
export GOFLAGS="-p=1 -mod=readonly -modfile=/controls/oracle0271-module-bind-v2/go.mod -overlay=/controls/oracle0271-module-bind-v2/overlay.json"
[[ "$(go env GOMODCACHE)" = /go-mod ]] || { echo 'overlay requires the read-only module cache mounted at /go-mod' >&2; exit 2; }
printf '{"status":"started","scope":"unpromoted default-API C0271 preflight; unsupported deprecated controls panic","started":"%s"}\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" > "$out/started.json"
# Check exact dependency originals, every upstream extracted file, every
# overlay, the source tar and this control script before reading build inputs.
sha256sum -c "$controls/checksums.container.sha256" > "$out/input-checks-before.log" 2>&1
cd /candidate
git --no-optional-locks rev-parse HEAD > "$out/head-before.txt"
git --no-optional-locks status --short > "$out/status-before.txt"
git --no-optional-locks diff HEAD --binary > "$out/source-diff-before.patch"
# Conservative canonical source/asset census; no source snapshot/copy.
git ls-files -co --exclude-standard -z -- '*.go' '*.c' '*.h' '*.bin' 'go.mod' 'go.sum' 'cgo_harness/go.mod' 'cgo_harness/go.sum' 'cgo_harness/testdata/*' 'internal/benchfixtures/testdata/*' 'internal/benchfixtures/real_corpus.json' | LC_ALL=C sort -zu | xargs -0 sha256sum > "$out/canonical-source-before.sha256"
go version > "$out/go-version.txt"
go env -json GOOS GOARCH GOVERSION CGO_ENABLED GOMODCACHE GOCACHE > "$out/go-env.json"
cd /candidate/cgo_harness
set +e
timeout --foreground --kill-after=10s 10m go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o "$binary" . > "$out/build.log" 2>&1
build_code=$?
set -e
printf '{"phase":"build","exit_code":%s}\n' "$build_code" > "$out/build-status.json"
if (( build_code != 0 )); then exit "$build_code"; fi
sha256sum "$binary" > "$out/binary.sha256"
cd /candidate
git --no-optional-locks rev-parse HEAD > "$out/head-after.txt"
git --no-optional-locks status --short > "$out/status-after.txt"
git --no-optional-locks diff HEAD --binary > "$out/source-diff-after.patch"
git ls-files -co --exclude-standard -z -- '*.go' '*.c' '*.h' '*.bin' 'go.mod' 'go.sum' 'cgo_harness/go.mod' 'cgo_harness/go.sum' 'cgo_harness/testdata/*' 'internal/benchfixtures/testdata/*' 'internal/benchfixtures/real_corpus.json' | LC_ALL=C sort -zu | xargs -0 sha256sum > "$out/canonical-source-after.sha256"
cmp "$out/head-before.txt" "$out/head-after.txt"
cmp "$out/status-before.txt" "$out/status-after.txt"
cmp "$out/source-diff-before.patch" "$out/source-diff-after.patch"
cmp "$out/canonical-source-before.sha256" "$out/canonical-source-after.sha256"
sha256sum -c "$controls/checksums.container.sha256" > "$out/input-checks-after.log" 2>&1
cd /candidate/cgo_harness
set +e
timeout --foreground --kill-after=10s 120s "$binary" -test.run '^TestCOracle0271(HeaderAndLinkProbe|RemovedControlsFailClosed|GoIncrementalAndFresh)$' -test.count=1 -test.v > "$out/private-preflight.log" 2>&1
private_code=$?
timeout --foreground --kill-after=10s 120s "$binary" -test.run '^Test(GoMalformedDeclarationPrefixLockedC|GoTokenInvariantLookaheadNumeric(Repair|Reuse)LockedC|GoUnterminatedStringCommaMatchesLockedC)$' -test.count=1 -test.v > "$out/go-small-parity.log" 2>&1
parity_code=$?
set -e
printf '{"status":"finished","build_exit_code":%s,"private_preflight_exit_code":%s,"small_go_parity_exit_code":%s,"scope":"unpromoted default-API preflight only; not general binding compatibility or graduation","ended":"%s"}\n' "$build_code" "$private_code" "$parity_code" "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" > "$out/finished.json"
(( private_code == 0 && parity_code == 0 ))
