package tree_sitter

/*
#cgo CFLAGS: -I/controls/oracle0271/runtime/lib/include -I/controls/oracle0271/runtime/lib/src -std=c11 -D_POSIX_C_SOURCE=200112L -D_DEFAULT_SOURCE -DGTS_PRIVATE_ORACLE0271=1
#include "/controls/oracle0271/runtime/lib/include/tree_sitter/api.h"
#include "/controls/oracle0271/runtime/lib/src/lib.c" // <- This is needed to build the C library from the C source code, but cannot be included in files that have other declarations.
*/
import "C"
