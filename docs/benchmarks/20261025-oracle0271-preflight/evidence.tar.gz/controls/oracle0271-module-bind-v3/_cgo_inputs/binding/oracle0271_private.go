package tree_sitter

/*
#cgo CFLAGS: -I/controls/oracle0271/runtime/lib/include -I/controls/oracle0271/runtime/lib/src -std=c11 -D_POSIX_C_SOURCE=200112L -D_DEFAULT_SOURCE -DGTS_PRIVATE_ORACLE0271=1
#include "/controls/oracle0271/runtime/lib/include/tree_sitter/api.h"
*/
import "C"

// Oracle0271PrivateLinkProbe is private diagnostic surface added by this
// overlay. It cannot link against the unmodified 0.25.1 runtime.
func Oracle0271PrivateLinkProbe(language *Language) bool {
	return language != nil && bool(C.ts_language_is_parseable(language.Inner))
}
