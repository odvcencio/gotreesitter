#!/usr/bin/env python3
"""Authenticate filename-only cgo adapters; never compile or mutate inputs."""
from pathlib import Path
import hashlib
import json


def digest(path):
    data = path.read_bytes()
    return hashlib.sha256(data).hexdigest(), len(data)


p = Path(__file__).resolve().parent
controls = p.parent
staged = json.loads((p / "staged-inputs.json").read_text())
overlay = json.loads((p / "overlay.json").read_text())["Replace"]
old_rows = json.loads((controls / "oracle0271/overlay-source-manifest.json").read_text())
old = {row["logical_path"].replace("/go-mod/github.com/tree-sitter/go-tree-sitter@v0.25.0/", "/oracle-binding/"): row for row in old_rows}
assert len(staged["staged"]) == 14
for row in staged["staged"]:
    logical, backing = row["logical"], Path(row["backing"])
    assert not logical.startswith("/go-mod/"), logical
    assert logical.endswith(".go") and backing.suffix == ".go", (logical, backing)
    assert Path(logical).name == backing.name, (logical, backing)
    assert "_cgo_inputs" in backing.parts, backing
    assert overlay[logical] == str(backing)
    assert digest(backing) == (row["sha256"], row["bytes"]), backing
    assert digest(Path(row["frozen_source"])) == digest(backing), backing
    assert 'import "C"' in backing.read_text(), backing
    original = old[logical]
    physical = Path(logical)
    if original["original_sha256"] is None:
        assert not physical.exists(), physical
    else:
        assert digest(physical)[0] == original["original_sha256"], physical
header = staged["adjacent_header"]
assert digest(Path(header["source"])) == digest(Path(header["backing"])) == (header["sha256"], header["bytes"])
assert (p / "go.mod").read_bytes() == (controls / "oracle0271-module-bind-v2/go.mod").read_bytes()
assert (p / "go.sum").read_bytes() == (controls / "oracle0271-module-bind-v2/go.sum").read_bytes()
print(json.dumps({"scope": "static authentication only", "cgo_files": 14,
                  "bodies_byte_identical_to_frozen_adaptation": True,
                  "basenames_preserved": True, "backings_have_go_suffix": True,
                  "dependency_adapter_is_not_checkout_or_module_clone": True,
                  "module_cache_changed": False, "runtime_sources_changed": False,
                  "project_dependencies_changed": False}, indent=2))
