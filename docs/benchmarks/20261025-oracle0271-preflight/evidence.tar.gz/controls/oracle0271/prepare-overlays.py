#!/usr/bin/env python3
"""Prepare per-file dependency overlays only; never build or mutate the cache."""
from pathlib import Path
import hashlib
import json
import re
import subprocess

repo = Path('/home/draco/work/gotreesitter')
controls = repo / 'harness_out/docker/go-reuse-20261025/oracle0271'
binding = Path('/home/draco/.local/state/gotreesitter-evidence/20261021-runtime-rss-architecture/compact-link-storage-v1/main-cgo-v1/dependencies/go-mod/github.com/tree-sitter/go-tree-sitter@v0.25.0')
module = '/go-mod/github.com/tree-sitter/go-tree-sitter@v0.25.0'
container = '/controls/oracle0271'
overlays = controls / 'go-overlays'
overlays.mkdir(exist_ok=True)
replacement = {}
manifest = []
flags = '#cgo CFLAGS: -Iinclude -Isrc -std=c11 -D_POSIX_C_SOURCE=200112L -D_DEFAULT_SOURCE'
newflags = f'#cgo CFLAGS: -I{container}/runtime/lib/include -I{container}/runtime/lib/src -std=c11 -D_POSIX_C_SOURCE=200112L -D_DEFAULT_SOURCE -DGTS_PRIVATE_ORACLE0271=1'
header = f'#include "{container}/runtime/lib/include/tree_sitter/api.h"'
message = 'private C 0.27.1 preflight: deprecated timeout/cancellation API is unsupported; use progress callbacks; not a general binding upgrade'

def sha(data): return hashlib.sha256(data).hexdigest()
def store(logical, source, changed, name):
    path=overlays/(name+'.txt'); path.write_text(changed)
    replacement[logical] = container+'/go-overlays/'+path.name
    manifest.append({'logical_path':logical,'original_sha256':sha(source.encode()) if source is not None else None,'overlay_path':str(path.relative_to(controls)),'overlay_sha256':sha(changed.encode()),'bytes':len(changed.encode())})

for original in sorted(binding.glob('*.go')):
    if original.name.endswith('_test.go'): continue
    source=original.read_text()
    if 'import "C"' not in source or '#include <tree_sitter/api.h>' not in source: continue
    assert flags in source, original.name
    changed=source.replace(flags,newflags).replace('#include <tree_sitter/api.h>',header)
    if original.name=='tree_sitter.go':
        assert '#include "lib.c"' in changed
        changed=changed.replace('#include "lib.c"',f'#include "{container}/runtime/lib/src/lib.c"')
    if original.name=='language.go':
        assert changed.count('C.ts_language_version(l.Inner)')==1
        changed=changed.replace('C.ts_language_version(l.Inner)','C.ts_language_abi_version(l.Inner)')
    if original.name=='parser.go':
        bodies={
          'TimeoutMicros': 'return uint64(C.ts_parser_timeout_micros(p._inner))',
          'SetTimeoutMicros': 'C.ts_parser_set_timeout_micros(p._inner, C.uint64_t(timeoutMicros))',
          'CancellationFlag': 'return (*uintptr)(unsafe.Pointer(C.ts_parser_cancellation_flag(p._inner)))',
          'SetCancellationFlag': 'C.ts_parser_set_cancellation_flag(p._inner, (*C.size_t)(unsafe.Pointer(flag)))',
        }
        for name,body in bodies.items():
            assert changed.count(body)==1,(original.name,name)
            changed=changed.replace(body,'panic('+json.dumps(message)+')')
        # The deprecated context wrapper relies on the removed cancellation
        # pointer. Background contexts preserve Parse; cancellable contexts
        # are explicitly rejected before spawning a goroutine.
        match=re.search(r'func \(p \*Parser\) ParseCtx\(ctx context.Context, text \[\]byte, oldTree \*Tree\) \*Tree \{.*?\n\}',changed,re.S)
        assert match
        changed=changed[:match.start()]+'''func (p *Parser) ParseCtx(ctx context.Context, text []byte, oldTree *Tree) *Tree {
\tif ctx.Done() != nil {
\t\tpanic('''+json.dumps(message)+''')
\t}
\treturn p.Parse(text, oldTree)
}'''+changed[match.end():]
        assert changed.count('"sync/atomic"')==1
        changed=changed.replace('\n\t"sync/atomic"','')
    if original.name=='query.go':
        for body in ['C.ts_query_cursor_set_timeout_micros(qc._inner, C.uint64_t(timeoutMicros))','return uint64(C.ts_query_cursor_timeout_micros(qc._inner))']:
            assert changed.count(body)==1
            changed=changed.replace(body,'panic('+json.dumps(message)+')')
    store(module+'/'+original.name,source,changed,original.name)

# This additional private binding file calls a symbol absent from 0.25.1.
# Linking/executing it gives a useful independent check beyond metadata strings.
probe='''package tree_sitter

/*
'''+newflags+'\n'+header+'''
*/
import "C"

// Oracle0271PrivateLinkProbe is private diagnostic surface added by this
// overlay. It cannot link against the unmodified 0.25.1 runtime.
func Oracle0271PrivateLinkProbe(language *Language) bool {
\treturn language != nil && bool(C.ts_language_is_parseable(language.Inner))
}
'''
store(module+'/oracle0271_private.go',None,probe,'oracle0271_private.go')

original=repo/'cgo_harness/parity_c_loader_cgo.go';source=original.read_text();changed=source
assert changed.count('COracleRuntimeVersion  = "0.25.1"')==1
assert changed.count('COracleRuntimeCommit   = "f5afe475deb7c0bae6407fb776c76824f717bb61"')==1
changed=changed.replace('COracleRuntimeVersion  = "0.25.1"','COracleRuntimeVersion  = "0.27.1"').replace('COracleRuntimeCommit   = "f5afe475deb7c0bae6407fb776c76824f717bb61"','COracleRuntimeCommit   = "10eb5ac119eec9cb4267a8e035066473983f5f3a"')
oldcomment='''// The C oracle contract is intentionally explicit. The Go binding release is
// pinned by cgo_harness/go.mod; its repository commit pins the upstream
// tree-sitter runtime submodule below. Grammar commits come from
// grammars/languages.lock.'''
assert oldcomment in changed
changed=changed.replace(oldcomment,'''// Private unpromoted 0.27.1 preflight: the module remains v0.25.0, with
// per-file dependency overlays selecting the authenticated new runtime and
// headers. Removed deprecated controls fail closed. Extra identity fields
// disclose this limited binding adaptation. Grammar commits remain locked.''')
needle=re.search(r'\tBindingCommit\s+string[^\n]*\n',changed); assert needle
changed=changed[:needle.end()]+'''\tBindingAdaptation string `json:"binding_adaptation,omitempty"`
\tRuntimeSourceArchiveSHA256 string `json:"runtime_source_archive_sha256,omitempty"`
'''+changed[needle.end():]
needle=re.search(r'\t\tBindingCommit:\s+COracleBindingCommit,\n',changed); assert needle
changed=changed[:needle.end()]+'''\t\tBindingAdaptation: "private-v0.25.0-overlay/default-api-only; removed-deprecated-controls-panic; unpromoted",
\t\tRuntimeSourceArchiveSHA256: "71bbc0a7a98013b519b104e281e6ad98524a438c8c822a095e6f27de05d15562",
'''+changed[needle.end():]
# The source archive is the only newly fetched source. A trial may load only
# an already compiled pinned grammar artifact; no clone or grammar checkout is
# allowed on a cache miss.
match=re.search(r'func buildParityCRef\(rootDir, cacheDir string, entry parityLockEntry\) \(\*parityCRef, error\) \{.*?\n\}',changed,re.S)
assert match
changed=changed[:match.start()]+'''func buildParityCRef(rootDir, cacheDir string, entry parityLockEntry) (*parityCRef, error) {
\tif ref, ok := loadCachedParityCRef(cacheDir, entry); ok {
\t\treturn ref, nil
\t}
\treturn nil, fmt.Errorf("private C 0.27.1 preflight: pinned compiled grammar cache miss for %s; cloning and grammar builds are disabled", entry.Name)
}'''+changed[match.end():]
store('/candidate/cgo_harness/parity_c_loader_cgo.go',source,changed,'parity_c_loader_cgo.go')

# Regenerate the entire inspectable overlay, including the independent probe.
preflight=controls/'preflight-test.go.txt'
assert preflight.is_file()
subprocess.run(['/usr/local/go/bin/gofmt','-w',*[str(overlays/(row['overlay_path'].split('/')[-1])) for row in manifest],str(preflight)],check=True)
for row in manifest:
    data=(controls/row['overlay_path']).read_bytes();row['overlay_sha256']=sha(data);row['bytes']=len(data)
logical='/candidate/cgo_harness/oracle0271_private_preflight_test.go'
data=preflight.read_bytes();replacement[logical]=container+'/preflight-test.go.txt'
manifest.append({'logical_path':logical,'original_sha256':None,'overlay_path':'preflight-test.go.txt','overlay_sha256':sha(data),'bytes':len(data)})
(controls/'overlay.json').write_text(json.dumps({'Replace':replacement},indent=2)+'\n')
(controls/'overlay-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(controls/'compatibility.json').write_text(json.dumps({
 'schema':'gts-unapplied-oracle0271-binding-adaptation/v1',
 'upstream_binding_module':'github.com/tree-sitter/go-tree-sitter','upstream_binding_version':'v0.25.0',
 'upstream_binding_base_commit':'adc13ffd8b2c0b01b878fda9f7c422ce0df5fad3',
 'runtime_version':'0.27.1','runtime_commit':'10eb5ac119eec9cb4267a8e035066473983f5f3a',
 'adaptations':[
  'Every binding Go preamble that imports tree_sitter/api.h uses the same authenticated absolute 0.27.1 header; old include/src CFLAGS are replaced.',
  'The sole tree_sitter.go amalgamation include selects authenticated 0.27.1 lib/src/lib.c by absolute path. Runtime C sources remain byte-exact upstream.',
  'Deprecated Language.Version delegates to the retained ts_language_abi_version API.',
  'Parser TimeoutMicros/SetTimeoutMicros/CancellationFlag/SetCancellationFlag and QueryCursor timeout methods panic explicitly when called; no timeout/cancellation is silently disabled.',
  'Deprecated Parser.ParseCtx preserves background-context Parse and explicitly rejects cancellable contexts. Supported progress-callback APIs remain byte-for-byte binding code.',
  'A private binding link probe calls new ts_language_is_parseable, which is absent from 0.25.1.',
  'The private harness loader accepts only precompiled pinned grammar cache hits; a miss fails before any clone or grammar build.',
  'COracle runtime version/commit identify 0.27.1. Module/base-binding identity stays v0.25.0; added binding_adaptation and runtime_source_archive_sha256 disclose the private fork.'
 ],
 'unsupported':['removed deprecated timeout and cancellation control API','cancellable deprecated ParseCtx'],
 'not_claimed':['general v0.25 binding API compatibility','C oracle approval/promotion','graduation correctness','static-C throughput','platform qualification'],
 'build_executed':False,'parity_executed':False
},indent=2)+'\n')
print('prepared per-file overlays:',len(replacement))
