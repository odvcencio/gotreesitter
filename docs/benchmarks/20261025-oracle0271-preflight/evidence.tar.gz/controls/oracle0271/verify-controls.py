#!/usr/bin/env python3
"""Read-only static authentication. Does not compile or run the oracle."""
from pathlib import Path
import hashlib,json,re
p=Path(__file__).resolve().parent
repo=Path('/home/draco/work/gotreesitter')
mod=Path('/home/draco/.local/state/gotreesitter-evidence/20261021-runtime-rss-architecture/compact-link-storage-v1/main-cgo-v1/dependencies/go-mod/github.com/tree-sitter/go-tree-sitter@v0.25.0')
sha=lambda data:hashlib.sha256(data).hexdigest()
provenance=json.loads((p/'upstream-provenance.json').read_text())
archive=p/'tree-sitter-10eb5ac119eec9cb4267a8e035066473983f5f3a.tar.gz'
assert sha(archive.read_bytes())=='71bbc0a7a98013b519b104e281e6ad98524a438c8c822a095e6f27de05d15562'
for name,row in provenance['files'].items():
 data=(p/'runtime'/name).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256'],name
 assert hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()==row['git_blob_sha1'],name
assert provenance['files']['Cargo.toml']['git_blob_sha1']=='fe40983f88679d21828f26dc4a1cfc80eb287f20'
assert provenance['files']['lib/include/tree_sitter/api.h']['git_blob_sha1']=='334b25f3b5e5e7f50e01744127020a4688394f73'
for row in json.loads((p/'overlay-source-manifest.json').read_text()):
 data=(p/row['overlay_path']).read_bytes();assert sha(data)==row['overlay_sha256'],row['overlay_path']
 logical=row['logical_path']
 if logical.startswith('/candidate/'):
  original=repo/logical.removeprefix('/candidate/')
 elif logical.startswith('/go-mod/github.com/tree-sitter/go-tree-sitter@v0.25.0/'):
  original=mod/logical.split('@v0.25.0/',1)[1]
 else:raise AssertionError('unexpected overlay target '+logical)
 if row['original_sha256'] is None:assert not original.exists(),str(original)
 else:assert sha(original.read_bytes())==row['original_sha256'],str(original)
api=(p/'runtime/lib/include/tree_sitter/api.h').read_text();names=set(re.findall(r'\b(ts_\w+)\s*\(',api))
for path in (p/'go-overlays').glob('*.txt'):
 if path.name=='parity_c_loader_cgo.go.txt':continue
 data=path.read_text();assert '#include <tree_sitter/api.h>' not in data,path.name
 missing=set(re.findall(r'\bC\.(ts_\w+)',data))-names;assert not missing,(path.name,missing)
print(json.dumps({'scope':'static authentication only; no build or runtime executed','upstream_files_verified':len(provenance['files']),'overlay_files_verified':len(json.loads((p/'overlay-source-manifest.json').read_text())),'runtime_C_sources_modified':False,'binding_cache_modified':False,'removed_deprecated_controls_silently_accepted':False},indent=2))
