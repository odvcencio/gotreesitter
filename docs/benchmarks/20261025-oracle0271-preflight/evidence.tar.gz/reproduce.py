#!/usr/bin/env python3
"""Print the portable V3 command; execute only with --execute. No inputs change."""
import argparse, fcntl, hashlib, json, pathlib, subprocess
p=argparse.ArgumentParser()
for name in ["repo","module-cache","c-cache","runtime","output"]: p.add_argument("--"+name,required=True,type=pathlib.Path)
p.add_argument("--cpu",required=True,type=int)
p.add_argument("--lock",type=pathlib.Path,default=pathlib.Path("/tmp/gotreesitter-compact-storage-docker.lock"))
p.add_argument("--execute",action="store_true")
p.add_argument("--expanded-go",action="store_true",help="also replay the retained bounded Go selectors after successful preflight")
a=p.parse_args(); home=pathlib.Path(__file__).resolve().parent
for key in ["repo","module_cache","c_cache","runtime"]:
 value=getattr(a,key).resolve(); assert value.is_dir(),value; setattr(a,key,value)
out=a.output.resolve(); assert not out.exists(),"choose a new output directory"
assert subprocess.check_output(["git","rev-parse","HEAD"],cwd=a.repo,text=True).strip()=="9580313574e273cd0e920cd120c6afe5dc357c8e"
for line in (home/"payload.sha256").read_text().splitlines():
 digest,name=line.split("  ",1); assert hashlib.sha256((home/name).read_bytes()).hexdigest()==digest,name
manifest=home/"runs/oracle0271-preflight-958-v3/probe/canonical-source-before.sha256"
for line in manifest.read_text().splitlines():
 digest,name=line.split("  ",1); assert hashlib.sha256((a.repo/name).read_bytes()).hexdigest()==digest,name
task=json.loads((home/"commands/commands-oracle0271-preflight-958-v3.json").read_text())[0]
cmd=task["args"][:]; old_controls="/home/draco/work/gotreesitter/harness_out/docker/go-reuse-20261025"
old_mod="/home/draco/.local/state/gotreesitter-evidence/20261021-runtime-rss-architecture/compact-link-storage-v1/main-cgo-v1/dependencies/go-mod"
old_c="/home/draco/.local/state/gotreesitter-evidence/20261021-runtime-rss-architecture/compact-link-storage-v1/main-cgo-v1/dependencies/c-cache"
bindings={"/baseline":a.repo,"/candidate":a.repo,"/controls":home/"controls","/prior-controls":home/"controls","/go-mod":a.module_cache,"/c-cache":a.c_cache,"/oracle-binding":a.module_cache/"github.com/tree-sitter/go-tree-sitter@v0.25.0","/runtime":a.runtime,"/evidence":out,"/measurement-lock":a.lock.resolve()}
for i,arg in enumerate(cmd):
 if i and cmd[i-1]=="-v":
  source,target,*mode=arg.split(":")
  if target in bindings: cmd[i]=str(bindings[target])+":"+target+(":"+":".join(mode) if mode else "")
cmd[cmd.index("--name")+1]="gts-oracle0271-reproduce-"+hashlib.sha256(str(out).encode()).hexdigest()[:12]
cmd[cmd.index("--cpuset-cpus")+1]=str(a.cpu)
cmd[-1]=cmd[-1].replace("/runtime/tmp/gotreesitter-oracle0271-958-v3/preflight.test","/runtime/tmp/"+cmd[cmd.index("--name")+1]+"/preflight.test")
commands=[cmd]
if a.expanded_go:
 extra=json.loads((home/"commands/commands-oracle0271-go-qualification-v1.json").read_text())[0]["args"][:]
 for i,arg in enumerate(extra):
  if i and extra[i-1]=="-v":
   source,target,*mode=arg.split(":")
   if target in bindings:
    bind=out/"expanded-go" if target=="/evidence" else bindings[target]
    extra[i]=str(bind)+":"+target+(":"+":".join(mode) if mode else "")
   elif target=="/qualification-controls": extra[i]=str(home)+":/qualification-controls:ro"
 extra[extra.index("--name")+1]=cmd[cmd.index("--name")+1]+"-expanded"
 extra[extra.index("--cpuset-cpus")+1]=str(a.cpu)
 extra[-1]=extra[-1].replace("/runtime/tmp/gotreesitter-oracle0271-958-v3/preflight.test","/runtime/tmp/"+cmd[cmd.index("--name")+1]+"/preflight.test").replace("/qualification-controls/out/oracle0271-preflight-958-v3/probe/canonical-source-before.sha256","/qualification-controls/runs/oracle0271-preflight-958-v3/probe/canonical-source-before.sha256")
 commands.append(extra)
print(json.dumps(commands,indent=2))
if a.execute:
 out.mkdir(parents=True,exist_ok=False)
 with a.lock.open("a") as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  for index,command in enumerate(commands):
   directory=out if index==0 else out/"expanded-go"
   directory.mkdir(parents=True,exist_ok=True)
   with (directory/"container.log").open("w") as log: result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=900)
   if result.returncode: break
 raise SystemExit(result.returncode)
