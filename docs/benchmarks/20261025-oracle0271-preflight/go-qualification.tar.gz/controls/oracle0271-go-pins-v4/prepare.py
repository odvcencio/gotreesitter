#!/usr/bin/env python3
"""Compose private V4 test metadata over frozen V3 cgo controls; never build."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

p = Path(__file__).resolve().parent
controls = p.parent
root = p.parents[3]
def sha(data): return hashlib.sha256(data).hexdigest()
def dump(name, obj): (p/name).write_text(json.dumps(obj,indent=2)+'\n')

next_path = 'cgo_harness/go_next_live_probe_test.go'
query_path = 'cgo_harness/parity_query_semantics_test.go'
original = {name:(root/name).read_text() for name in [next_path,query_path]}
replacements = {
 next_path: [
  ('\tgoNextCRuntimeVersion = "0.25.1"','\tgoNextCRuntimeVersion = "0.27.1"'),
  ('\tgoNextCRuntimeCommit  = "f5afe475deb7c0bae6407fb776c76824f717bb61"','\tgoNextCRuntimeCommit  = "10eb5ac119eec9cb4267a8e035066473983f5f3a"'),
 ],
 query_path: [(
  '\t{lang: "go", query: `(_simple_type/type_identifier) @t`,\n\t\tknown: "grammargen supertype map: an aliased subtype (identifier aliased to type_identifier) is recorded as its target symbol, so the subtype check rejects the alias name C accepts"},',
  '\t{lang: "go", query: `(_simple_type/type_identifier) @t`},'
 )],
}
candidate={}
for name,text in original.items():
 for old,new in replacements[name]:
  assert text.count(old)==1,(name,old)
  text=text.replace(old,new,1)
 candidate[name]=text
 backing=p/(Path(name).name+'.txt')
 backing.write_text(text)
 subprocess.check_call(['gofmt','-w',str(backing)],cwd=root)
 candidate[name]=backing.read_text()
 restored=candidate[name]
 for old,new in reversed(replacements[name]):
  assert restored.count(new)==1,(name,new)
  restored=restored.replace(new,old,1)
 assert restored==original[name],name

assert candidate[query_path].split('func TestParityQuerySemantics',1)[1]==original[query_path].split('func TestParityQuerySemantics',1)[1]
base=controls/'oracle0271-module-bind-v3/overlay.json'
base_map=json.loads(base.read_text())['Replace']
mapping=dict(base_map)
for name in original:
 logical='/candidate/'+name
 assert logical not in mapping
 mapping[logical]='/controls/oracle0271-go-pins-v4/'+Path(name).name+'.txt'
dump('overlay.json',{'Replace':mapping})
assert {k:v for k,v in mapping.items() if k not in ['/candidate/'+x for x in original]}==base_map
(p/'metadata.patch').write_text(''.join(''.join(difflib.unified_diff(original[name].splitlines(True),candidate[name].splitlines(True),fromfile='a/'+name,tofile='b/'+name)) for name in original))
guard={
 'schema':'gts-oracle0271-go-test-metadata-diffguard/v4',
 'runtime':'0.27.1','runtime_commit':'10eb5ac119eec9cb4267a8e035066473983f5f3a',
 'only_changed_logical_source_files':list(original),
 'allowed_replacements':{name:[{'before':a,'after':b} for a,b in rows] for name,rows in replacements.items()},
 'byte_exact_original_restored_by_reversing_only_allowed_replacements':True,
 'query_comparator_function_body_byte_identical':True,
 'GoNext_grammar_artifact_source_digest_pass_assertions_unchanged':True,
 'V3_overlay_entries_unchanged':len(base_map),'composed_overlay_entries':len(mapping),
 'V3_overlay_sha256':sha(base.read_bytes()),
 'source':{name:{'original_sha256':sha(original[name].encode()),'candidate_sha256':sha(candidate[name].encode())} for name in original},
 'query_and_source_unchanged':True,
 'removed_known_metadata_effect':'existing compiler/capture equality comparator is mandatory; mismatches fail rather than skip',
 'C027_causality_for_query_expectation':'not inferred; no matched old-C A/B in this control',
}
dump('diffguard.json',guard)
sources={
 **{'/candidate/'+name:sha(original[name].encode()) for name in original},
 '/controls/oracle0271-module-bind-v3/overlay.json':sha(base.read_bytes()),
 **{'/controls/oracle0271-module-bind-v3/'+name:sha((controls/'oracle0271-module-bind-v3'/name).read_bytes()) for name in ['go.mod','go.sum','checksums.container.sha256']},
}
(p/'source-auth.sha256').write_text(''.join(value+'  '+name+'\n' for name,value in sorted(sources.items())))
verify='''#!/usr/bin/env python3
"""Read-only exact V4 metadata/overlay authentication; no build or execution."""
from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent
guard=json.loads((p/'diffguard.json').read_text())
def sha(data):return hashlib.sha256(data).hexdigest()
for name,expected in guard['source'].items():
 original=Path('/candidate',name).read_bytes()
 candidate=(p/(Path(name).name+'.txt')).read_bytes()
 assert sha(original)==expected['original_sha256'],name
 assert sha(candidate)==expected['candidate_sha256'],name
 restored=candidate.decode()
 for row in reversed(guard['allowed_replacements'][name]):
  assert restored.count(row['after'])==1,name
  restored=restored.replace(row['after'],row['before'],1)
 assert restored.encode()==original,name
base=Path('/controls/oracle0271-module-bind-v3/overlay.json')
assert sha(base.read_bytes())==guard['V3_overlay_sha256']
old=json.loads(base.read_text())['Replace'];new=json.loads((p/'overlay.json').read_text())['Replace']
assert all(new.get(k)==v for k,v in old.items())
assert set(new)-set(old)=={'/candidate/'+x for x in guard['source']}
print(json.dumps({'only_two_runtime_constants_and_one_known_metadata_entry_changed':True,'V3_cgo_overlay_entries_preserved':len(old),'exact_query_comparator_preserved':True,'build_executed':False},indent=2))
'''
(p/'verify-inputs.py').write_text(verify)
selector1='^Test(GoGroupedBindingSeparatorsLockedC|GoGroupedConstSeparatorEditsMatchLockedC|GoIssue490FragmentBoundaryLockedC|GoHiddenMissingSemicolonEditsMatchLockedC|GoMalformedDeclarationPrefixLockedC|GoTokenInvariantLookaheadNumeric(Repair|Reuse)LockedC|GoUnterminatedStringCommaMatchesLockedC|GoNextLiveArmProbe|Stage6GoCompactCertification|GoCompactIncrementalExecutionParity|GoCompactNestedReuse.*)$'
selector2='^Test(ParityFreshParse|ParityIncrementalParse|ParityHasNoErrors|ParityHighlight|ParityQueryExactTop50Generated|ParityQuerySemantics)$/^go$'
frozen=root/'docs/benchmarks/20261025-oracle0271-preflight'
assert sha((frozen/'evidence.tar.gz').read_bytes())=='ea3d84e1094cde6244f3e0f02cb6b89421b685a10964f7ef78997d28ab20fc05'
dump('manifest.json',{
 'schema':'gts-unpromoted-oracle0271-go-pins-control/v4',
 'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'scope':'private Go qualification metadata update only; no oracle adoption or runtime changes',
 'build_cwd':'/candidate/cgo_harness','tags':'treesitter_c_parity,gts_parsercorephase0',
 'GOFLAGS':'-p=1 -mod=readonly -modfile=/controls/oracle0271-module-bind-v3/go.mod -overlay=/controls/oracle0271-go-pins-v4/overlay.json',
 'selectors':[selector1,selector2],
 'parity_environment':{'GTS_PARITY_MODE':'exhaustive','GTS_ADMISSION_CANDIDATE':'1','GTS_PARITY_COMPARE_FIELDS':'1','GTS_PARITY_COMPARE_HAS_ERROR':'1','GTS_PARITY_IGNORE_KNOWN_SKIPS':'1'},
 'same_second_read_only_binding_mount':'/oracle-binding',
 'frozen_red_receipt_unchanged':{str(x.relative_to(root)):sha(x.read_bytes()) for x in sorted(frozen.iterdir()) if x.is_file()},
 'original_red_records_retained':{'regression_fail_records':1,'query_fail_records':2,'archive_sha256':'ea3d84e1094cde6244f3e0f02cb6b89421b685a10964f7ef78997d28ab20fc05'},
 'production_files_modified':False,'builds_tests_Docker_run':False,
 'files':{x.name:{'bytes':x.stat().st_size,'sha256':sha(x.read_bytes())} for x in sorted(p.iterdir()) if x.is_file() and x.name not in ['manifest.json','checksums.container.sha256']}})
(p/'checksums.container.sha256').write_text(''.join(sha(x.read_bytes())+'  /controls/oracle0271-go-pins-v4/'+x.name+'\n' for x in sorted(p.iterdir()) if x.is_file() and x.name!='checksums.container.sha256'))
print(json.dumps({'runtime_constants_changed':2,'known_metadata_entries_removed':1,'overlay_entries':len(mapping),'overlay_sha256':sha((p/'overlay.json').read_bytes()),'no_builds_tests':True}))
