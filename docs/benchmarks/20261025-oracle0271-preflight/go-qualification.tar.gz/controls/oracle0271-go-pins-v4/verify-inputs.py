#!/usr/bin/env python3
"""Read-only exact V4 metadata/overlay authentication; no build or execution."""
from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parent
guard=json.loads((p/'diffguard.json').read_text())
def sha(data):return hashlib.sha256(data).hexdigest()
for name,expected in guard['source'].items():
 original=Path('/candidate',name).read_bytes()
 candidate=(p/(Path(name).name+'.txt')).read_bytes()
 assert sha(original)==expected['original_sha256'],name
 assert sha(candidate)==expected['candidate_sha256'],name
 restored=candidate.decode()
 for row in reversed(guard['allowed_replacements'][name]):
  assert restored.count(row['after'])==1,name
  restored=restored.replace(row['after'],row['before'],1)
 assert restored.encode()==original,name
base=Path('/controls/oracle0271-module-bind-v3/overlay.json')
assert sha(base.read_bytes())==guard['V3_overlay_sha256']
old=json.loads(base.read_text())['Replace'];new=json.loads((p/'overlay.json').read_text())['Replace']
assert all(new.get(k)==v for k,v in old.items())
assert set(new)-set(old)=={'/candidate/'+x for x in guard['source']}
print(json.dumps({'only_two_runtime_constants_and_one_known_metadata_entry_changed':True,'V3_cgo_overlay_entries_preserved':len(old),'exact_query_comparator_preserved':True,'build_executed':False},indent=2))
