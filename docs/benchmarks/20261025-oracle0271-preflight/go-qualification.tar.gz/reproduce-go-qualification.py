#!/usr/bin/env python3
"""Print the exact supplemental Go Docker command; --execute is explicit."""
import argparse,fcntl,hashlib,json,pathlib,subprocess
p=argparse.ArgumentParser()
for name in ['repo','module-cache','c-cache','runtime','output']:p.add_argument('--'+name,required=True,type=pathlib.Path)
p.add_argument('--cpu',required=True,type=int);p.add_argument('--execute',action='store_true')
p.add_argument('--lock',type=pathlib.Path,default=pathlib.Path('/tmp/gotreesitter-compact-storage-docker.lock'))
a=p.parse_args();home=pathlib.Path(__file__).resolve().parent
for name in ['repo','module_cache','c_cache','runtime']:
 v=getattr(a,name).resolve();assert v.is_dir(),v;setattr(a,name,v)
out=a.output.resolve();assert not out.exists(),'choose a new output directory'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=a.repo,text=True).strip()=='9580313574e273cd0e920cd120c6afe5dc357c8e'
for checksum in ['payload.sha256','go-qualification-payload.sha256']:
 for line in (home/checksum).read_text().splitlines():
  expected,name=line.split('  ',1);assert hashlib.sha256((home/name).read_bytes()).hexdigest()==expected,name
for line in (home/'runs/oracle0271-preflight-958-v3/probe/canonical-source-before.sha256').read_text().splitlines():
 expected,name=line.split('  ',1);assert hashlib.sha256((a.repo/name).read_bytes()).hexdigest()==expected,name
cmd=json.loads((home/'commands/commands-oracle0271-go-qualification-v2.json').read_text())[0]['args'][:]
binds={'/candidate':a.repo,'/baseline':a.repo,'/controls':home/'controls','/prior-controls':home/'controls','/qualification-controls':home,'/go-mod':a.module_cache,'/c-cache':a.c_cache,'/runtime':a.runtime,'/oracle-binding':a.module_cache/'github.com/tree-sitter/go-tree-sitter@v0.25.0','/evidence':out,'/measurement-lock':a.lock.resolve()}
for i,arg in enumerate(cmd):
 if i and cmd[i-1]=='-v':
  source,target,*mode=arg.split(':')
  if target in binds:cmd[i]=str(binds[target])+':'+target+(':'+':'.join(mode) if mode else '')
name='gts-oracle0271-go-reproduce-'+hashlib.sha256(str(out).encode()).hexdigest()[:12]
cmd[cmd.index('--name')+1]=name;cmd[cmd.index('--cpuset-cpus')+1]=str(a.cpu)
cmd[-1]=cmd[-1].replace('/runtime/tmp/gotreesitter-oracle0271-go-pins-v4','/runtime/tmp/'+name).replace('/qualification-controls/out/oracle0271-preflight-958-v3/probe/canonical-source-before.sha256','/qualification-controls/runs/oracle0271-preflight-958-v3/probe/canonical-source-before.sha256')
print(json.dumps(cmd,indent=2))
if a.execute:
 out.mkdir(parents=True,exist_ok=False)
 with a.lock.open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  with (out/'container.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=900)
 raise SystemExit(r.returncode)
