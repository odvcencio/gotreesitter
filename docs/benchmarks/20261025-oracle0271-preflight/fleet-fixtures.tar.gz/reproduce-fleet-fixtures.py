#!/usr/bin/env python3
"""Print the exact bounded fleet command using the already-qualified binary."""
import argparse,fcntl,hashlib,json,pathlib,re,subprocess
p=argparse.ArgumentParser()
for x in ['repo','binary','module-cache','c-cache','runtime','output']:p.add_argument('--'+x,required=True,type=pathlib.Path)
p.add_argument('--cpu',required=True,type=int);p.add_argument('--execute',action='store_true')
p.add_argument('--lock',type=pathlib.Path,default=pathlib.Path('/tmp/gotreesitter-compact-storage-docker.lock'))
a=p.parse_args();home=pathlib.Path(__file__).resolve().parent
for name in ['payload.sha256','go-qualification-payload.sha256','fleet-fixtures-payload.sha256']:
 for line in (home/name).read_text().splitlines():
  h,n=line.split('  ',1);assert hashlib.sha256((home/n).read_bytes()).hexdigest()==h,n
for x in ['repo','module_cache','c_cache','runtime']:
 value=getattr(a,x).resolve();assert value.is_dir(),value;setattr(a,x,value)
a.binary=a.binary.resolve();assert a.binary.is_file() and hashlib.sha256(a.binary.read_bytes()).hexdigest()=='f0ea72de8403b28b10de117ddc1359874e35dd765cc34f0a611bff119fdb930d'
for line in (home/'runs/oracle0271-preflight-958-v3/probe/canonical-source-before.sha256').read_text().splitlines():
 h,n=line.split('  ',1);assert hashlib.sha256((a.repo/n).read_bytes()).hexdigest()==h,n
out=a.output.resolve();assert not out.exists(),'choose a new output directory and preserve earlier evidence'
cmd=json.loads((home/'commands/commands-oracle0271-fleet-fixtures-v1.json').read_text())[0]['args'][:]
binds={'/baseline':a.repo,'/candidate':a.repo,'/controls':home/'controls','/prior-controls':home/'controls',
 '/qualification-controls':home,'/evidence':out,'/go-mod':a.module_cache,'/c-cache':a.c_cache,
 '/measurement-lock':a.lock.resolve(),'/runtime':a.runtime,'/usr/bin/time':pathlib.Path('/usr/bin/time'),
 '/oracle-binding':a.module_cache/'github.com/tree-sitter/go-tree-sitter@v0.25.0'}
for i,arg in enumerate(cmd):
 if i and cmd[i-1]=='-v':
  src,dst,*mode=arg.split(':');assert dst in binds,dst
  cmd[i]=str(binds[dst])+':'+dst+(':'+':'.join(mode) if mode else '')
image=cmd.index('golang@sha256:116d58cbd88c1297624acc6e967a060012422bacf9930927e23fb719189c6f36')
cmd[image:image]=['-v',str(a.binary)+':/qualified-oracle.test:ro']
cmd[cmd.index('--name')+1]='gts-c027-fleet-replay-'+hashlib.sha256(str(out).encode()).hexdigest()[:12]
cmd[cmd.index('--cpuset-cpus')+1]=str(a.cpu)
cmd[-1]=cmd[-1].replace('/runtime/tmp/gotreesitter-oracle0271-go-pins-v4/qualification.test','/qualified-oracle.test').replace('/qualification-controls/out/oracle0271-preflight-958-v3/probe/canonical-source-before.sha256','/qualification-controls/runs/oracle0271-preflight-958-v3/probe/canonical-source-before.sha256')
print(json.dumps(cmd,indent=2))
if a.execute:
 out.mkdir(parents=True,exist_ok=False)
 with a.lock.open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  with (out/'container.log').open('w') as log:
   try:result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=1300)
   except subprocess.TimeoutExpired:
    subprocess.run(['docker','stop','--time','10',cmd[cmd.index('--name')+1]],capture_output=True)
    raise SystemExit(124)
 if result.returncode:raise SystemExit(result.returncode)
 languages=(home/'fleet-controls/languages.txt').read_text().splitlines()
 statuses=[x.split('\t') for x in (out/'process-status.tsv').read_text().splitlines()]
 assert len(languages)==len(set(languages))==206 and [x[0] for x in statuses]==languages
 assert all(x[1]=='0' for x in statuses)
 assert {x.stem for x in (out/'grammars').glob('*.log')}==set(languages)
 for language in languages:
  text=(out/'grammars'/(language+'.log')).read_text()
  assert text.rstrip().endswith('PASS') and not re.search(r'(?m)^\s*--- (FAIL|SKIP):|^FAIL|^panic:|no tests to run',text),language
  passes=re.findall(r'^\s*--- PASS: (\S+)',text,re.M);assert len(passes)==6,language
  for kind in ['FreshParse','IncrementalParse','HasNoErrors']:
   assert passes.count('TestParity'+kind)==passes.count('TestParity'+kind+'/'+language)==1,(language,kind)
 assert (out/'source-before.log').read_bytes()==(out/'source-after.log').read_bytes()==b''
 assert (out/'binary.sha256').read_text().split()[0]=='f0ea72de8403b28b10de117ddc1359874e35dd765cc34f0a611bff119fdb930d'
 print(json.dumps({'grammar_processes':206,'leaf_C_checks':618,'failed_or_skipped':0,'scope':'smoke fixtures only'}))
 raise SystemExit(0)
