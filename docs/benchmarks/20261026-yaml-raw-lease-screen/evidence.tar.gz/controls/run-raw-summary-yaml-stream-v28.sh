set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/raw-summary-yaml-stream-v28/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/raw-summary-yaml-stream-v28/controls.sha256 > /evidence/controls-before.log 2>&1
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/raw-summary-yaml-stream-v28
mkdir -p "$scratch"
cd /candidate/cgo_harness
go test -overlay=/controls/raw-summary-output-v1/yaml-raw-lease-v1/stream-lease-proof-v28/overlay.cgo.tests.json -tags treesitter_c_parity,gts_parsercorephase0 -run '^TestRawSummaryFreshYAMLDocumentLeaseLockedC$' -count=1 -v -timeout=5m . > /evidence/streams-locked-c.log 2>&1
