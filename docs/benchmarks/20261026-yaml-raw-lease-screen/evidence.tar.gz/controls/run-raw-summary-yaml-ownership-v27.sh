set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/raw-summary-yaml-ownership-v27/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/raw-summary-yaml-ownership-v27/controls.sha256 > /evidence/controls-before.log 2>&1
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/raw-summary-yaml-ownership-v27
mkdir -p "$scratch"
cd /baseline/cgo_harness
go test -tags treesitter_c_parity,gts_parsercorephase0 -run '^TestCompactYAMLVersionOwnershipCOracle$' -count=1 -v -timeout=5m . > /evidence/baseline-original-ownership.log 2>&1
cd /candidate/cgo_harness
go test -c -overlay=/controls/raw-summary-output-v1/yaml-raw-lease-v1/ownership-contract-v27/overlay.cgo.tests.json -tags treesitter_c_parity,gts_parsercorephase0 -o "$scratch/cgo.test" . > /evidence/cgo-build.log 2>&1
"$scratch/cgo.test" -test.run '^TestRawSummaryFreshYAMLCheckpointLockedC$' -test.count=1 -test.v -test.timeout=5m > /evidence/yaml-raw-locked-c.log 2>&1
GTS_ADMISSION_CANDIDATE=1 "$scratch/cgo.test" -test.run '^Test(CompactYAMLVersionOwnershipCOracle|CompactYAMLDocumentStreamLockedC|YAMLRecoveredMappingQuotesLockedC|YAMLOwnedGrammarLockedCParity|YAMLEOFRecoverWrapCompactRoute|YAMLEOFRecoverWrapUnfinishedMappingDeclinesCompact|YAMLOneBytePrintableEOFAdmissionMatchesLockedC|YAMLResultCompatibilityErrorsLockedC)$' -test.count=1 -test.v -test.timeout=5m > /evidence/yaml-existing-locked-c.log 2>&1
for arm in baseline candidate; do
 cd "/$arm"
 if [[ "$arm" == candidate ]]; then extra=(-overlay=/controls/raw-summary-output-v1/yaml-raw-lease-v1/public-contract-proof-v25/overlay.runtime.json); else extra=(); fi
 go build "${extra[@]}" -tags gts_parsercorephase0 -o "$scratch/$arm-ledger" ./cmd/perfcounterledger > "/evidence/$arm-ledger-build.log" 2>&1
 for route in default candidate; do
  mode=0; if [[ "$route" == candidate ]]; then mode=1; fi
  GTS_ADMISSION_CANDIDATE=$mode "$scratch/$arm-ledger" --child-route "$route" --langs yaml > "/evidence/$arm-$route-yaml.json" 2> "/evidence/$arm-$route-yaml.stderr"
 done
done
sha256sum "$scratch/cgo.test" "$scratch/baseline-ledger" "$scratch/candidate-ledger" > /evidence/binary.sha256
