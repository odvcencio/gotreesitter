from pathlib import Path
import json,hashlib
repo=Path('/home/draco/work/gotreesitter');r=repo/'harness_out/docker/go-ci-blockers-20261025';y=r/'raw-summary-output-v1/yaml-raw-lease-v1';d=y/'value-identity-v29';d.mkdir(exist_ok=False)
files={}
files['/candidate/internal/scannerstate/identity_value_private.go']='''package scannerstate

// CheckpointIdentityValue carries exact immutable 32-byte identities by value.
// A provider must return the same bytes and validity as CheckpointIdentity.
// Invalid value results are final: callers must never retry a weaker capability.
// Returning values prevents callers from mutating the scanner's binding and
// avoids allocating owned slices for each authority check.
type CheckpointIdentityValue struct { Scanner, Grammar [32]byte }
type CheckpointIdentityValueProvider interface {
 CheckpointIdentityValue() (CheckpointIdentityValue, bool)
}
'''
files['/candidate/external_scanner_checkpoint_identity_value_private.go']='''package gotreesitter

import "github.com/odvcencio/gotreesitter/internal/scannerstate"

// Keep provider lookup and its capability callback on every validation. Only
// the ownership of returned identity bytes changes; no identity is cached across
// callbacks, and an invalid value provider cannot fall through to slice data.
func (s *externalScannerCheckpointIdentityState) setLanguageValue(lang *Language) bool {
 if lang==nil {return false}
 provider,required:=externalScannerCheckpointIdentityProviderForScanner(lang.ExternalScanner)
 if !required {return false}
 if valueProvider,ok:=provider.(scannerstate.CheckpointIdentityValueProvider);ok {
  value,valid:=valueProvider.CheckpointIdentityValue()
  return valid && s.set(ExternalScannerCheckpointIdentity{Scanner:value.Scanner[:],Grammar:value.Grammar[:]})
 }
 value,valid:=provider.CheckpointIdentity()
 return valid && s.set(value)
}
func (s *externalScannerCheckpointIdentityState) matchesLanguageValue(lang *Language) bool {
 if lang==nil {return false}
 provider,required:=externalScannerCheckpointIdentityProviderForScanner(lang.ExternalScanner)
 if !required {return false}
 if valueProvider,ok:=provider.(scannerstate.CheckpointIdentityValueProvider);ok {
  value,valid:=valueProvider.CheckpointIdentityValue()
  return valid && s.matches(ExternalScannerCheckpointIdentity{Scanner:value.Scanner[:],Grammar:value.Grammar[:]})
 }
 value,valid:=provider.CheckpointIdentity()
 return valid && s.matches(value)
}
'''
s=(repo/'external_scanner_checkpoint_capability.go').read_text()
a=s.index('func (a *nodeArena) setExternalScannerCheckpointIdentityForLanguage(');b=s.index('\nfunc (a *nodeArena) inheritExternalScannerCheckpointIdentity',a)
part=s[a:b]
part=part.replace('''	identity, required, valid := externalScannerCheckpointIdentityStatus(lang)
	if !required || !valid {
		return false
	}
''','')
part=part.replace('a.externalScannerCheckpointIdentity.set(identity)','a.externalScannerCheckpointIdentity.setLanguageValue(lang)')
files['/candidate/external_scanner_checkpoint_capability.go']=s[:a]+part+s[b:]
s=(y/'scanner-capability-v1/yaml_checkpoint_capability_private.go.txt').read_text().replace('"encoding/binary"','"encoding/binary"\n "github.com/odvcencio/gotreesitter/internal/scannerstate"')
s+='''
// Return owned values so repeated publication-authority checks allocate nothing.
func (s *YamlExternalScanner) CheckpointIdentityValue() (scannerstate.CheckpointIdentityValue,bool) {
 if s==nil || s.binding==nil || !s.binding.checkpointIdentityValid {return scannerstate.CheckpointIdentityValue{},false}
 return scannerstate.CheckpointIdentityValue{Scanner:s.binding.checkpointScanner,Grammar:s.binding.checkpointGrammar},true
}
'''
files['/candidate/grammars/runtime/yaml_checkpoint_capability_private.go']=s
s=(y/'fresh-only-v1/root/parsercore_raw_summary_checkpoint_private.go.txt').read_text()
old='''	identity, required, valid := externalScannerCheckpointIdentityStatus(lang)
	if !required || !valid {
		return false
	}
	o := &s.rawSummaryReadOrigin
	if !o.checkpointIdentity.set(identity) {'''
new='''	o := &s.rawSummaryReadOrigin
	if !o.checkpointIdentity.setLanguageValue(lang) {''';assert old in s;s=s.replace(old,new)
s=s.replace('identity, required, valid := externalScannerCheckpointIdentityStatus(lang)','valid := o.checkpointIdentity.matchesLanguageValue(lang)')
s=s.replace('return required && valid && o.checkpointIdentity.matches(identity) &&','return valid &&')
files['/candidate/parsercore_raw_summary_checkpoint_private.go']=s
runtime=json.loads((y/'public-contract-proof-v25/overlay.runtime.json').read_text());changes={}
for target,source in files.items():
 path=d/(target.removeprefix('/candidate/').replace('/','__')+'.txt');path.write_text(source);changes[target]='/controls/'+str(path.relative_to(r));runtime['Replace'][target]=changes[target]
(d/'overlay.runtime.json').write_text(json.dumps(runtime,indent=2)+'\n')
# Focused tests for zero-allocation value matching and preserved invalidation.
unit='''package gotreesitter
import (
 "testing"
 "github.com/odvcencio/gotreesitter/internal/scannerstate"
)
type privateIdentityValueScanner struct {
 *c26lCheckpointScanner
 value scannerstate.CheckpointIdentityValue
 valueOK bool
 valueCalls int
 sliceCalls int
}
func(s *privateIdentityValueScanner) CheckpointIdentityValue()(scannerstate.CheckpointIdentityValue,bool){s.valueCalls++;return s.value,s.valueOK}
func(s *privateIdentityValueScanner) CheckpointIdentity()(ExternalScannerCheckpointIdentity,bool){s.sliceCalls++;return s.c26lCheckpointScanner.CheckpointIdentity()}
func TestPrivateIdentityValueOwnershipAndInvalidation(t *testing.T){
 scanner:=&privateIdentityValueScanner{c26lCheckpointScanner:newC26lCheckpointScanner(),valueOK:true}
 scanner.value.Scanner[0]=1;scanner.value.Grammar[0]=2
 lang:=&Language{ExternalScanner:scanner};var state externalScannerCheckpointIdentityState
 if !state.setLanguageValue(lang)||!state.matchesLanguageValue(lang){t.Fatal("valid value refused")}
 value,_:=scanner.CheckpointIdentityValue();clear(value.Scanner[:]);clear(value.Grammar[:])
 if !state.matchesLanguageValue(lang){t.Fatal("caller mutation reached immutable binding")}
 calls:=scanner.valueCalls
 if n:=testing.AllocsPerRun(100,func(){if !state.matchesLanguageValue(lang){panic("lost authority")}});n!=0 {t.Fatalf("identity validation allocated %v",n)}
 if scanner.valueCalls-calls!=101||scanner.sliceCalls!=0 {t.Fatal("validation skipped callback or retried slice provider")}
 scanner.valueOK=false
 if state.matchesLanguageValue(lang)||state.setLanguageValue(lang)||scanner.sliceCalls!=0 {t.Fatal("invalid value fell back")}
 scanner.valueOK=true;scanner.value.Scanner[0]++
 if state.matchesLanguageValue(lang)||state.setLanguageValue(lang) {t.Fatal("changed scanner identity accepted")}
 scanner.value.Scanner[0]--
 if state.matchesLanguageValue(lang){t.Fatal("conflicting identity forgot conflict")}
 var clean externalScannerCheckpointIdentityState
 if !clean.setLanguageValue(lang){t.Fatal("fresh state refused")}
 scanner.value.Grammar[0]++
 if clean.matchesLanguageValue(lang){t.Fatal("changed grammar identity accepted")}
 scanner.checkpoint=false
 if clean.setLanguageValue(lang)||clean.matchesLanguageValue(lang){t.Fatal("capability loss accepted")}
 plain:=newC26lCheckpointScanner();lang.ExternalScanner=plain
 var fallback externalScannerCheckpointIdentityState
 if !fallback.setLanguageValue(lang)||!fallback.matchesLanguageValue(lang){t.Fatal("slice-only provider changed")}
 plain.identityOK=false
 if fallback.matchesLanguageValue(lang){t.Fatal("invalid slice-only provider accepted")}
}
'''
path=d/'identity_value_private_test.go.txt';path.write_text(unit);test_changes={'/candidate/external_scanner_checkpoint_identity_value_private_test.go':'/controls/'+str(path.relative_to(r))}
# Exercise the actual fixed-value path at each already-proved mutation seam.
wrappers='''package gotreesitter
import "github.com/odvcencio/gotreesitter/internal/scannerstate"
type privateYAMLIdentityValueScanner struct{rawSummaryYAMLIdentityScanner}
func(s *privateYAMLIdentityValueScanner) CheckpointIdentityValue()(scannerstate.CheckpointIdentityValue,bool){
 id,ok:=s.rawSummaryYAMLIdentityScanner.CheckpointIdentity();var value scannerstate.CheckpointIdentityValue
 if !ok||len(id.Scanner)!=32||len(id.Grammar)!=32{return value,false};copy(value.Scanner[:],id.Scanner);copy(value.Grammar[:],id.Grammar);return value,true
}
type privateYAMLLateIdentityValueScanner struct{rawSummaryYAMLLateIdentityScanner}
func(s *privateYAMLLateIdentityValueScanner) CheckpointIdentityValue()(scannerstate.CheckpointIdentityValue,bool){
 id,ok:=s.rawSummaryYAMLLateIdentityScanner.CheckpointIdentity();var value scannerstate.CheckpointIdentityValue
 if !ok||len(id.Scanner)!=32||len(id.Grammar)!=32{return value,false};copy(value.Scanner[:],id.Scanner);copy(value.Grammar[:],id.Grammar);return value,true
}
'''
path=d/'identity_value_wrappers_private_test.go.txt';path.write_text(wrappers);test_changes['/candidate/raw_summary_identity_value_wrappers_private_test.go']='/controls/'+str(path.relative_to(r))
for sourcefile,oldtype,newtype in [
 ('fresh-only-v1/root/raw_summary_fresh_yaml_authority_private_test.go.txt','rawSummaryYAMLIdentityScanner','privateYAMLIdentityValueScanner'),
 ('fresh-only-v1/root/raw_summary_fresh_yaml_late_callback_private_test.go.txt','rawSummaryYAMLLateIdentityScanner','privateYAMLLateIdentityValueScanner'),
 ('public-proof-v14/raw_summary_fresh_yaml_public_authority_private_test.go.txt','rawSummaryYAMLIdentityScanner','privateYAMLIdentityValueScanner'),
 ('public-proof-v14/raw_summary_fresh_yaml_public_late_private_test.go.txt','rawSummaryYAMLLateIdentityScanner','privateYAMLLateIdentityValueScanner')]:
 source=(y/sourcefile).read_text();source=source.replace('func TestRawSummaryFreshYAML','func TestRawSummaryValueYAML')
 source=source.replace('&'+oldtype+'{ExternalScannerCheckpointIdentityProvider: provider}', '&'+newtype+'{'+oldtype+': '+oldtype+'{ExternalScannerCheckpointIdentityProvider: provider}}')
 name='value_'+Path(sourcefile).name;path=d/name;path.write_text(source);test_changes['/candidate/'+name.removesuffix('.txt')]='/controls/'+str(path.relative_to(r))
# Same value contract against the actual immutable grammar binding.
s='''//go:build !grammar_subset || grammar_subset_yaml
package grammarruntime
import("bytes";"testing")
func TestPrivateYAMLCheckpointValueMatchesSliceContract(t *testing.T){
 s:=privateYAMLCheckpointBound(t);want,ok:=s.CheckpointIdentity();value,valid:=s.CheckpointIdentityValue()
 if !ok||!valid||!bytes.Equal(want.Scanner,value.Scanner[:])||!bytes.Equal(want.Grammar,value.Grammar[:]){t.Fatal("value changed identity")}
 clear(value.Scanner[:]);clear(value.Grammar[:]);again,valid:=s.CheckpointIdentityValue()
 if !valid||!bytes.Equal(want.Scanner,again.Scanner[:])||!bytes.Equal(want.Grammar,again.Grammar[:]){t.Fatal("returned value aliases binding")}
 if n:=testing.AllocsPerRun(100,func(){v,ok:=s.CheckpointIdentityValue();if !ok||v!=again{panic("identity changed")}});n!=0{t.Fatalf("value allocated %v",n)}
 var nilScanner *YamlExternalScanner
 for _,bad:=range []*YamlExternalScanner{nilScanner,{},s.ExternalScannerForLanguage(nil).(*YamlExternalScanner)}{if _,ok:=bad.CheckpointIdentityValue();ok{t.Fatal("invalid scanner granted identity")}}
}
''';path=d/'yaml_value_private_test.go.txt';path.write_text(s);test_changes['/candidate/grammars/runtime/yaml_checkpoint_value_private_test.go']='/controls/'+str(path.relative_to(r))
for name,prior in [('overlay.tests.json',y/'public-contract-proof-v25/overlay.tests.json'),('overlay.cgo.tests.json',y/'stream-lease-proof-v28/overlay.cgo.tests.json')]:
 ov=json.loads(prior.read_text());ov['Replace'].update(changes);ov['Replace'].update(test_changes);(d/name).write_text(json.dumps(ov,indent=2)+'\n')
print('prepared',len(changes),'runtime changes;',len(runtime['Replace']),'total targets; runtime SHA',hashlib.sha256((d/'overlay.runtime.json').read_bytes()).hexdigest())
