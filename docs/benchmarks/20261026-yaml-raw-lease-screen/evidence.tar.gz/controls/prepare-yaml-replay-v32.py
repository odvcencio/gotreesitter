from pathlib import Path
import json,hashlib,subprocess
repo=Path('/home/draco/work/gotreesitter');r=repo/'harness_out/docker/go-ci-blockers-20261025';y=r/'raw-summary-output-v1/yaml-raw-lease-v1';old=y/'value-identity-v29';d=y/'replay-once-v32';d.mkdir(exist_ok=False)
changes={}
s=(repo/'parsercore_phase0_per_version_lexer_state.go').read_text().replace('"unsafe"','"unsafe"\n "github.com/odvcencio/gotreesitter/internal/scannerstate"')
a=s.index('func diagnosticParserCoreVersionLexerCheckpointIdentity(');b=s.index('\nfunc ',a+5)
s=s[:a]+'''func diagnosticParserCoreVersionLexerCheckpointIdentity(language *Language) ([32]byte, bool, bool) {
 if language==nil {return [32]byte{},false,false}
 provider,required:=externalScannerCheckpointIdentityProviderForScanner(language.ExternalScanner)
 if !required {return [32]byte{},false,false}
 if valueProvider,ok:=provider.(scannerstate.CheckpointIdentityValueProvider);ok {
  value,valid:=valueProvider.CheckpointIdentityValue()
  if !valid {return [32]byte{},true,false}
  return parserCoreExternalScannerIdentityFingerprint(ExternalScannerCheckpointIdentity{Scanner:value.Scanner[:],Grammar:value.Grammar[:]}),true,true
 }
 identity,valid:=provider.CheckpointIdentity()
 if !valid || !identity.complete(){return [32]byte{},true,false}
 return parserCoreExternalScannerIdentityFingerprint(identity),true,true
}
'''+s[b:]
p=d/'parsercore_phase0_per_version_lexer_state.go.txt';p.write_text(s);changes['/candidate/parsercore_phase0_per_version_lexer_state.go']='/controls/'+str(p.relative_to(r))
s=(y/'fresh-root-forest-v11/raw_summary_producer_private.go.txt').read_text()
needle='\ts := &p.body.summaries[id-1]\n\tfast := r.fieldCount == 0 && r.aliasCount == 0';assert needle in s;s=s.replace(needle,'\ts := &p.body.summaries[id-1]\n\tbuiltBefore := s.built\n\tfast := r.fieldCount == 0 && r.aliasCount == 0',1)
a=s.index('\tif !fast {\n\t\t// Exceptional work is independently bounded');b=s.index('\t\t_, normalProof, e = rawSummaryCounts(children)',a)
reference=(r/'raw-summary-output-v1/pure-gap-fused-v1/raw_summary_producer_private.go.txt').read_text();ra=reference.index('\tif !fast {\n\t\t// A new exceptional summary');rb=reference.index('\t\t_, normalProof, e = rawSummaryCounts(children)',ra)
s=s[:a]+reference[ra:rb]+s[b:]
p=d/'raw_summary_producer_private.go.txt';p.write_text(s);changes['/candidate/internal/parsercorephase0/raw_summary_producer_private.go']='/controls/'+str(p.relative_to(r))
unit='''//go:build !gts_no_parsercorephase0
package gotreesitter
import "testing"
func TestPrivateIdentityValueVersionLexerFingerprint(t *testing.T){
 scanner:=&privateIdentityValueScanner{c26lCheckpointScanner:newC26lCheckpointScanner(),valueOK:true}
 scanner.value.Scanner[0]=8;scanner.value.Grammar[0]=9
 lang:=&Language{ExternalScanner:scanner}
 want:=parserCoreExternalScannerIdentityFingerprint(ExternalScannerCheckpointIdentity{Scanner:scanner.value.Scanner[:],Grammar:scanner.value.Grammar[:]})
 digest,required,valid:=diagnosticParserCoreVersionLexerCheckpointIdentity(lang)
 if !required||!valid||digest!=want {t.Fatal("fingerprint encoding changed")}
 calls:=scanner.valueCalls
 if n:=testing.AllocsPerRun(100,func(){digest,required,valid:=diagnosticParserCoreVersionLexerCheckpointIdentity(lang);if !required||!valid||digest!=want{panic("identity changed")}});n!=0 {t.Fatalf("fingerprint allocated %v",n)}
 if scanner.valueCalls-calls!=101||scanner.sliceCalls!=0{t.Fatal("identity callback skipped or slice provider retried")}
 scanner.valueOK=false
 if _,required,valid:=diagnosticParserCoreVersionLexerCheckpointIdentity(lang);!required||valid||scanner.sliceCalls!=0{t.Fatal("invalid identity gained authority")}
 scanner.valueOK=true;scanner.value.Grammar[0]++
 if digest,required,valid:=diagnosticParserCoreVersionLexerCheckpointIdentity(lang);!required||!valid||digest==want{t.Fatal("changed grammar did not change fingerprint")}
 scanner.checkpoint=false
 if _,required,valid:=diagnosticParserCoreVersionLexerCheckpointIdentity(lang);required||valid{t.Fatal("capability loss retained identity")}
}
'''
p=d/'identity_fingerprint_private_test.go.txt';p.write_text(unit);test_changes={'/candidate/raw_summary_identity_fingerprint_private_test.go':'/controls/'+str(p.relative_to(r))}
work='''//go:build go1.24 && gts_workcount && gts_parsercorephase0 && !gts_no_parsercorephase0
package gotreesitter
import("bytes";"encoding/json";"testing")
func TestRawSummaryFreshYAMLFormationWork(t *testing.T){
 sample:=rawSummaryFreshYAMLSource(t);document:=append([]byte("---\\n"),sample...);document=append(document,'\\n')
 for _,source:=range [][]byte{sample,bytes.Repeat(document,4),bytes.Repeat(document,16)} {
  p:=NewParser(yamlSelectedProjectionLanguageForTest);p.SetAdmissionCandidateRoute(true);tree,err:=p.Parse(source)
  if err!=nil||tree==nil{t.Fatal(err)}
  before,err:=PrivateRawSummaryOrdinaryWorkForTest(tree);if err!=nil||before.ArenaNodes!=1{t.Fatal("actual raw lease absent",err)}
  var walk func(*Node)uint64;walk=func(n *Node)uint64{count:=uint64(1);for i:=0;i<n.ChildCount();i++{count+=walk(n.Child(i))};return count}
  if count:=walk(tree.RootNode());count!=before.PublicNodes{t.Fatal("walk count changed",count,before.PublicNodes)}
  after,err:=PrivateRawSummaryOrdinaryWorkForTest(tree);if err!=nil||before.Formation!=after.Formation{t.Fatal("reads changed formation",err)}
  walk(tree.RootNode());warm,err:=PrivateRawSummaryOrdinaryWorkForTest(tree);if err!=nil||after!=warm{t.Fatal("warm reads repeated work",err)}
  data,_:=json.Marshal(struct{Bytes int;Before,After,Warm PrivateRawSummaryOrdinaryWork}{len(source),before,after,warm});t.Logf("YAML_FORMATION_WORK %s",data);tree.Release()
 }
}
''';p=d/'yaml_formation_work_private_test.go.txt';p.write_text(work);test_changes['/candidate/raw_summary_yaml_formation_work_private_test.go']='/controls/'+str(p.relative_to(r))
for name in ['overlay.runtime.json','overlay.tests.json','overlay.cgo.tests.json']:
 ov=json.loads((old/name).read_text());ov['Replace'].update(changes)
 if name!='overlay.runtime.json':ov['Replace'].update(test_changes)
 (d/name).write_text(json.dumps(ov,indent=2)+'\n')
# The reference gets exactly the same work witness, with unchanged v29 runtime.
ov=json.loads((old/'overlay.tests.json').read_text());ov['Replace'].update(test_changes);(d/'overlay.reference.work.json').write_text(json.dumps(ov,indent=2)+'\n')
subprocess.run(['gofmt','-w',*[str(p) for p in d.glob('*.go.txt')]],check=True)
label='raw-summary-yaml-replay-v32';before='raw-summary-yaml-value-v29';(r/'out'/label).mkdir(exist_ok=False);(r/label).mkdir(exist_ok=False)
run=(r/('run-'+before+'.sh')).read_text().replace(before,label).replace('value-identity-v29/','replay-once-v32/')
run=run.replace("'^Test(PrivateIdentityValue|C26lCheckpoint|RawSummaryValueYAML)'", "'^Test(PrivateIdentityValue|C26[q]|ExternalScannerOrderAdapter|DiagnosticParserCoreVersionLexer(Snapshot|Clone|Request)|RawSummaryValueYAML)'")
needle='go test -c -overlay="$overlay" -tags gts_parsercorephase0 -o "$scratch/root.test" . > /evidence/root-build.log 2>&1'
addition='''
for arm in reference candidate; do
 if [[ "$arm" == reference ]]; then workoverlay=/controls/raw-summary-output-v1/yaml-raw-lease-v1/replay-once-v32/overlay.reference.work.json; else workoverlay="$overlay"; fi
 go test -overlay="$workoverlay" -tags gts_parsercorephase0,gts_workcount -run '^TestRawSummaryFreshYAMLFormationWork$' -count=1 -v -timeout=4m . > "/evidence/$arm-formation-work.log" 2>&1
done
'''
assert needle in run;run=run.replace(needle,needle+addition)
(r/('run-'+label+'.sh')).write_text(run)
commands=json.loads((r/('commands-'+before+'.json')).read_text());commands=json.loads(json.dumps(commands).replace(before,label));(r/('commands-'+label+'.json')).write_text(json.dumps(commands,indent=2)+'\n')
(r/('worker-'+label+'.py')).write_text((r/('worker-'+before+'.py')).read_text().replace(before,label))
paths=set()
for p in d.glob('overlay.*.json'):
 paths.add('/controls/'+str(p.relative_to(r)));paths.update(json.loads(p.read_text())['Replace'].values())
paths.update('/controls/'+name for name in ['run-'+label+'.sh','commands-'+label+'.json','worker-'+label+'.py','sealed-reduction-perf-v1/source.sha256'])
(r/label/'controls.sha256').write_text(''.join(hashlib.sha256((r/n.removeprefix('/controls/')).read_bytes()).hexdigest()+'  '+n+'\n' for n in sorted(paths)))
print('prepared lexer value checks + one exceptional projection per new summary; runtime targets',len(json.loads((d/'overlay.runtime.json').read_text())['Replace']))
