from pathlib import Path
import hashlib,json
repo=Path('/home/draco/work/gotreesitter');r=repo/'harness_out/docker/go-ci-blockers-20261025';d=r/'raw-summary-output-v1/yaml-raw-lease-v1/value-identity-v29'
# Preserve callback ordering around arena accounting: read first, then account.
p=d/'external_scanner_checkpoint_capability.go.txt';s=p.read_text();a=s.index('func (a *nodeArena) setExternalScannerCheckpointIdentityForLanguage(');b=s.index('\nfunc (a *nodeArena) inheritExternalScannerCheckpointIdentity',a)
s=s[:a]+'''func (a *nodeArena) setExternalScannerCheckpointIdentityForLanguage(lang *Language) bool {
 if a==nil || lang==nil {return false}
 provider,required:=externalScannerCheckpointIdentityProviderForScanner(lang.ExternalScanner)
 if !required {return false}
 if valueProvider,ok:=provider.(scannerstate.CheckpointIdentityValueProvider);ok {
  value,valid:=valueProvider.CheckpointIdentityValue()
  if !valid {return false}
  return a.installExternalScannerCheckpointIdentity(ExternalScannerCheckpointIdentity{Scanner:value.Scanner[:],Grammar:value.Grammar[:]})
 }
 identity,valid:=provider.CheckpointIdentity()
 if !valid || !identity.complete(){return false}
 return a.installExternalScannerCheckpointIdentity(identity)
}

func(a *nodeArena) installExternalScannerCheckpointIdentity(identity ExternalScannerCheckpointIdentity) bool {
 before:=a.externalScannerCheckpointIdentity.bytesAllocated()
 ok:=a.externalScannerCheckpointIdentity.set(identity)
 a.allocatedBytes+=a.externalScannerCheckpointIdentity.bytesAllocated()-before
 return ok
}
'''+s[b:]
s=s.replace('import "bytes"','import ("bytes";"github.com/odvcencio/gotreesitter/internal/scannerstate")');p.write_text(s)
label='raw-summary-yaml-value-v29';(r/'out'/label).mkdir(exist_ok=False);(r/label).mkdir(exist_ok=False)
old='raw-summary-yaml-full-v25';run=(r/('run-'+old+'.sh')).read_text().replace(old,label).replace('public-contract-proof-v25/','value-identity-v29/')
run=run.replace("go test -overlay=\"$overlay\" -tags gts_parsercorephase0 -run",'''go test -overlay="$overlay" -tags gts_parsercorephase0 -run '^TestPrivateYAMLCheckpoint' -count=1 -v -timeout=4m ./grammars/runtime > /evidence/scanner.log 2>&1
go test -overlay="$overlay" -tags gts_parsercorephase0 -run''',1)
run=run.replace("\"$scratch/root.test\" -test.run '^TestRawSummaryFreshYAML",'''"$scratch/root.test" -test.run '^Test(PrivateIdentityValue|C26lCheckpoint|RawSummaryValueYAML)' -test.count=1 -test.v -test.timeout=4m > /evidence/value-identity.log 2>&1
"$scratch/root.test" -test.run '^TestRawSummaryFreshYAML''',1)
run=run.replace("-run '^TestRawSummaryFreshYAML(OrdinaryCheckpointLifetime", "-run '^Test(PrivateIdentityValue.*|RawSummaryValueYAML.*|RawSummaryFreshYAML(OrdinaryCheckpointLifetime").replace("PublicCheckpointLatePublicationCallbacks)$' -count=1 -v -timeout=5m . > /evidence/yaml-race.log", "PublicCheckpointLatePublicationCallbacks))$' -count=1 -v -timeout=5m . > /evidence/yaml-race.log")
run=run.replace("'^TestRawSummaryFreshYAMLCheckpointLockedC$'","'^TestRawSummaryFreshYAML(CheckpointLockedC|DocumentLeaseLockedC)$'")
(r/('run-'+label+'.sh')).write_text(run)
commands=json.loads((r/('commands-'+old+'.json')).read_text());commands=json.loads(json.dumps(commands).replace(old,label));(r/('commands-'+label+'.json')).write_text(json.dumps(commands,indent=2)+'\n')
(r/('worker-'+label+'.py')).write_text((r/('worker-'+old+'.py')).read_text().replace(old,label))
paths=set()
for name in ['overlay.runtime.json','overlay.tests.json','overlay.cgo.tests.json']:
 p=d/name;paths.add('/controls/'+str(p.relative_to(r)));paths.update(json.loads(p.read_text())['Replace'].values())
paths.update('/controls/'+str((r/name).relative_to(r)) for name in ['run-'+label+'.sh','commands-'+label+'.json','worker-'+label+'.py','sealed-reduction-perf-v1/source.sha256'])
(r/label/'controls.sha256').write_text(''.join(hashlib.sha256((r/n.removeprefix('/controls/')).read_bytes()).hexdigest()+'  '+n+'\n' for n in sorted(paths)))
print('Prepared all affected gates, scanner tests, original/value-path attacks,8KiB/32KiB exact C, counters; pins',len(paths))
