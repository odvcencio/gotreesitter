from pathlib import Path
import json,hashlib
r=Path('/home/draco/work/gotreesitter/harness_out/docker/go-ci-blockers-20261025');d=r/'yaml-c027-profile-v30';d.mkdir(exist_ok=False)
y=r/'raw-summary-output-v1/yaml-raw-lease-v1/value-identity-v29';oldmap=r/'raw-summary-output-v1/pure-gap-fused-v2';a=json.loads((oldmap/'overlay.cgo.tests.json').read_text())['Replace'];b=json.loads((oldmap/'overlay.c027.json').read_text())['Replace'];overlay=json.loads((y/'overlay.cgo.tests.json').read_text())
extra={k:v for k,v in b.items() if a.get(k)!=v};overlay['Replace'].update(extra);(d/'overlay.c027.json').write_text(json.dumps(overlay,indent=2)+'\n')
old=r/'raw-summary-c027-pure-gap-v2b';run=(old/'run.sh').read_text().replace('raw-summary-c027-pure-gap-v2b','yaml-c027-profile-v30').replace('/controls/raw-summary-output-v1/pure-gap-fused-v2/overlay.c027.json','/controls/yaml-c027-profile-v30/overlay.c027.json')
run=run.replace("'^TestRawSummaryOrdinaryLockedC$'", "'^TestRawSummaryFreshYAML(CheckpointLockedC|DocumentLeaseLockedC)$'").replace('/evidence/ordinary-cgo.log','/evidence/yaml-raw-c027.log')
run+='''GTS_ADMISSION_CANDIDATE=1 "$scratch/cgo.test" -test.run '^Test(CompactYAMLVersionOwnershipCOracle|CompactYAMLDocumentStreamLockedC|YAMLRecoveredMappingQuotesLockedC|YAMLOwnedGrammarLockedCParity|YAMLEOFRecoverWrapCompactRoute|YAMLEOFRecoverWrapUnfinishedMappingDeclinesCompact|YAMLOneBytePrintableEOFAdmissionMatchesLockedC|YAMLResultCompatibilityErrorsLockedC)$' -test.count=1 -test.v -test.timeout=5m > /evidence/yaml-existing-c027.log 2>&1
cd /candidate
export GOFLAGS='-p=1 -mod=readonly'
go test -overlay=/controls/raw-summary-output-v1/yaml-raw-lease-v1/value-identity-v29/overlay.tests.json -tags gts_parsercorephase0 -run '^Test(C26q|ExternalScannerOrderAdapter)' -count=1 -v -timeout=4m . > /evidence/identity-compatibility.log 2>&1
go test -c -overlay=/controls/yaml-raw-perf-v2/overlay.container.json -tags gts_parsercorephase0 -o "$scratch/profile.test" . > /evidence/profile-build.log 2>&1
GTS_ADMISSION_REAL_CORPUS_LANGS=yaml /usr/bin/time -v "$scratch/profile.test" -test.run '^$' -test.bench '^BenchmarkAdmissionR4Compact$' -test.count=1 -test.benchtime=5s -test.benchmem -test.cpuprofile=/evidence/yaml.cpu -test.memprofile=/evidence/yaml.mem > /evidence/profile-run.log 2> /evidence/profile-time.txt
go tool pprof -top -nodecount=50 "$scratch/profile.test" /evidence/yaml.cpu > /evidence/profile-top.txt 2>&1
go tool pprof -top -cum -nodecount=50 "$scratch/profile.test" /evidence/yaml.cpu > /evidence/profile-cum.txt 2>&1
go tool pprof -top -alloc_objects -nodecount=30 "$scratch/profile.test" /evidence/yaml.mem > /evidence/profile-allocs.txt 2>&1
sha256sum "$scratch/profile.test" > /evidence/profile-binary.sha256
'''
(d/'run.sh').write_text(run)
commands=json.loads((old/'commands.json').read_text());commands=json.loads(json.dumps(commands).replace('raw-summary-c027-pure-gap-v2b','yaml-c027-profile-v30'))
(d/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
worker=(r/'yaml-raw-perf-v2/worker.py').read_text().replace('paired performance qualification','C027 and attribution qualification').replace('paired performance processes','C027 and attribution processes');(d/'worker.py').write_text(worker)
paths={str(p.relative_to(r)) for p in d.iterdir() if p.is_file()}
for path in [d/'overlay.c027.json',y/'overlay.tests.json',r/'yaml-raw-perf-v2/overlay.container.json']:
 paths.add(str(path.relative_to(r)))
 paths.update(v.removeprefix('/controls/') for v in json.loads(path.read_text())['Replace'].values())
# Retain the original pinned oracle/module controls, including their own guards.
for line in (old/'controls.sha256').read_text().splitlines():
 _,name=line.split('  ',1)
 if name.startswith('/controls/oracle'):paths.add(name.removeprefix('/controls/'))
paths.add('sealed-reduction-perf-v1/source.sha256')
(d/'controls.sha256').write_text(''.join(hashlib.sha256((r/n).read_bytes()).hexdigest()+'  /controls/'+n+'\n' for n in sorted(paths)))
print('prepared actual C027 YAML, compatibility tests, and candidate-only attribution; pins',len(paths))
