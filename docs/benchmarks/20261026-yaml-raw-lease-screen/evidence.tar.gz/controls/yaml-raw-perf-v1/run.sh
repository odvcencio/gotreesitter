set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly -overlay=/controls/yaml-raw-perf-v1/overlay.container.json'
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
python3 /controls/yaml-raw-perf-v1/check-gates.py > /evidence/gates-before.json
finish(){ cd /candidate; sha256sum --quiet -c /controls/yaml-raw-perf-v1/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/yaml-raw-perf-v1/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/yaml-raw-perf-v1/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/yaml-raw-perf-v1/controls.sha256 > /evidence/controls-before.log 2>&1
go version > /evidence/toolchain.txt
GTS_ADMISSION_REAL_CORPUS_LANGS=yaml bash scripts/run_randomized_benchmarks.sh --output /evidence/r4-after-yaml.txt --baseline-root /baseline --baseline-output /evidence/r4-before-yaml.txt --lock-path /evidence/benchmark.lock --bench-regex '^BenchmarkCompactGraduationR4$' --require-benchmarks BenchmarkCompactGraduationR4/legacy,BenchmarkCompactGraduationR4/compact --runs 20 --seed-start 1 --benchtime 750ms > /evidence/r4-runner-yaml.log 2>&1
printf 'all20 matched YAML shuffle pairs complete; private fresh-only raw-lease screen, no graduation claim\n' > /evidence/completed.txt
