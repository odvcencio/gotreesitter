from pathlib import Path
import json, hashlib
root=Path('/home/draco/work/gotreesitter'); r=root/'harness_out/docker/go-ci-blockers-20261025'
y=r/'raw-summary-output-v1/yaml-raw-lease-v1'; d=y/'ownership-contract-v26';d.mkdir(exist_ok=False)
s=(root/'cgo_harness/compact_r4_parity_test.go').read_text()
s=s.replace('testCompactR4StructuralLockedC(t, name, false)', 'testCompactR4StructuralLockedC(t, name, false, false)')
s=s.replace('testCompactR4StructuralLockedC(t, "yaml", true)', '''for _, freshOnly := range []bool{false, true} {
		t.Run(fmt.Sprintf("fresh_raw=%t", freshOnly), func(t *testing.T) {
			t.Cleanup(gts.PrivateSetRawSummaryForCQualification(freshOnly))
			testCompactR4StructuralLockedC(t, "yaml", true, freshOnly)
		})
	}''')
s=s.replace('requireCompact bool) {', 'requireCompact, freshOnly bool) {')
old='''		// A scanner can certify transfer without storing checkpoints. The
		// published tree must retain that proof after comparison-only trials.
		if !runtime.CompactExternalScannerCheckpointTransferProven {
			t.Fatal("published scanner transfer lost its proof after acceptance trials")
		}'''
new='''		if freshOnly {
			// Owning raw checkpoints does not certify every public sidecar.
			// Require the actual immutable lease and forbid reuse authority.
			if _, err := gts.PrivateRequireFreshYAMLRawCheckpointForCQualification(tree); err != nil {
				t.Fatal(err)
			}
			if runtime.CompactExternalScannerCheckpointTransferProven {
				t.Fatal("fresh-only lease incorrectly certified public checkpoint transfer")
			}
		} else {
			if _, err := gts.PrivateRequireRawSummaryForCQualification(tree, false); err != nil {
				t.Fatal(err)
			}
			// Preserve the original materialized publisher's stronger contract.
			if !runtime.CompactExternalScannerCheckpointTransferProven {
				t.Fatal("published scanner transfer lost its proof after acceptance trials")
			}
		}
		assertLockedCTreeExactWithErrors(t, fmt.Sprintf("YAML ownership fresh_raw=%t", freshOnly), tree, lang, cTree)'''
assert old in s;s=s.replace(old,new)
p=d/'compact_r4_parity_test.go.txt';p.write_text(s)
ov=json.loads((y/'public-contract-proof-v25/overlay.cgo.tests.json').read_text());ov['Replace']['/candidate/cgo_harness/compact_r4_parity_test.go']='/controls/'+str(p.relative_to(r))
(d/'overlay.cgo.tests.json').write_text(json.dumps(ov,indent=2)+'\n')
label='raw-summary-yaml-ownership-v26';out=r/'out'/label;out.mkdir(exist_ok=False);ctl=r/label;ctl.mkdir(exist_ok=False)
oldrun=(r/'run-raw-summary-yaml-full-v25.sh').read_text(); prefix=oldrun[:oldrun.index('overlay=/controls/')]
prefix=prefix.replace('raw-summary-yaml-full-v25',label)
rest=oldrun[oldrun.index('cd /candidate/cgo_harness'):]
rest=rest.replace('public-contract-proof-v25/overlay.cgo.tests.json','ownership-contract-v26/overlay.cgo.tests.json')
rest=rest.replace('"$scratch/root.test" ', '')
(r/('run-'+label+'.sh')).write_text(prefix+rest)
commands=json.loads((r/'commands-raw-summary-yaml-full-v25.json').read_text());commands=json.loads(json.dumps(commands).replace('raw-summary-yaml-full-v25',label).replace('32m','12m'))
(r/('commands-'+label+'.json')).write_text(json.dumps(commands,indent=2)+'\n')
worker=(r/'worker-raw-summary-yaml-full-v25.py').read_text().replace('raw-summary-yaml-full-v25',label).replace('timeout=2050','timeout=850')
(r/('worker-'+label+'.py')).write_text(worker)
paths=set()
for line in (r/'raw-summary-yaml-full-v25/controls.sha256').read_text().splitlines():
 _,name=line.split('  ',1)
 if 'raw-summary-yaml-full-v25' not in name:paths.add(name)
paths.update('/controls/'+str(a.relative_to(r)) for a in [p,d/'overlay.cgo.tests.json',r/('run-'+label+'.sh'),r/('commands-'+label+'.json'),r/('worker-'+label+'.py')])
lines=[]
for name in sorted(paths):
 actual=r/name.removeprefix('/controls/');lines.append(hashlib.sha256(actual.read_bytes()).hexdigest()+'  '+name)
(ctl/'controls.sha256').write_text('\n'.join(lines)+'\n')
print('Prepared test-only dual contract; pure runtime unchanged:',hashlib.sha256((y/'public-contract-proof-v25/overlay.runtime.json').read_bytes()).hexdigest())
print('control pins:',len(paths))
