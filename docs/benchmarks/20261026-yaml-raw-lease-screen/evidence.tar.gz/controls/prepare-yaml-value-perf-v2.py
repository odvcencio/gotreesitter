from pathlib import Path
import json,hashlib,shutil
r=Path('/home/draco/work/gotreesitter/harness_out/docker/go-ci-blockers-20261025');old=r/'yaml-raw-perf-v1';d=r/'yaml-raw-perf-v2';d.mkdir(exist_ok=False)
runtime=r/'raw-summary-output-v1/yaml-raw-lease-v1/value-identity-v29/overlay.runtime.json'
for name in ['run.sh','worker.py','validate.py','benchmark-source.go.txt','source.sha256','commands.json']:
 source=(old/name).read_text().replace('yaml-raw-perf-v1','yaml-raw-perf-v2');(d/name).write_text(source)
overlay=json.loads(runtime.read_text())
for arm in ['baseline','candidate']:overlay['Replace'][f'/{arm}/benchmark_admission_candidate_route_test.go']='/controls/yaml-raw-perf-v2/benchmark-source.go.txt'
(d/'overlay.container.json').write_text(json.dumps(overlay,indent=2)+'\n')
gate=(old/'check-gates.py').read_text();a=gate.index("p=check('raw-summary-yaml-full-v25'");b=gate.index("work={'tokens'",a)
gate=gate[:a]+'''p=check('raw-summary-yaml-value-v29',{'scanner.log':(5,10),'core-release.log':(93,205),'core-workcount.log':(29,66),'core-race.log':(29,66),'value-identity.log':(18,44),'yaml-lifetime.log':(5,10),'yaml-authority-budget.log':(17,41),'go-preserved.log':(1,3),'yaml-race.log':(12,44),'invariants-yaml-0.log':(1,1),'invariants-yaml-1.log':(1,1),'yaml-raw-locked-c.log':(2,6),'yaml-existing-locked-c.log':(8,186)})
for route in (0,1):assert 'session_steps=72 no_edit_allocs=0' in (p/f'invariants-yaml-{route}.log').read_text()
s=(p/'yaml-lifetime.log').read_text()
assert 'records=231 state_known=230 pre_known=209' in s and 'unproved=0' in s
s=(p/'yaml-raw-locked-c.log').read_text()
assert 'bytes=8012' in s and 'bytes=32048' in s and s.count('actual_lease=true public_checkpoint_transfer=false')==2
'''+gate[b:]
gate=gate.replace('public-contract-proof-v25/overlay.runtime.json','value-identity-v29/overlay.runtime.json').replace('65ad187290d2e00417da10449c78bb239b614e0310d420807008b0c9bc1cabc3',hashlib.sha256(runtime.read_bytes()).hexdigest()).replace('len(original)==31','len(original)==34').replace("'C025_families':8", "'C025_families':10").replace("'selected_semantic_gates_passed':True", "'selected_semantic_gates_passed':True,'identity_value_checks_allocate_zero':True,'stream_lease_bytes':[8012,32048]")
(d/'check-gates.py').write_text(gate)
manifest=json.loads((old/'manifest.json').read_text());manifest.update(runtime_map=str(runtime.relative_to(r)),runtime_sha256=hashlib.sha256(runtime.read_bytes()).hexdigest(),runtime_targets=34,change='Same checkpoint authority callbacks with exact immutable identity values; no skipped validation or new reuse authority')
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
paths={str(p.relative_to(r)) for p in d.iterdir() if p.is_file()};paths.add(str(runtime.relative_to(r)));paths.update(v.removeprefix('/controls/') for v in overlay['Replace'].values())
paths.add('raw-summary-yaml-value-v29/controls.sha256')
paths.update(str(p.relative_to(r)) for p in (r/'out/raw-summary-yaml-value-v29').iterdir() if p.is_file() and p.suffix in ['.json','.log'])
(d/'controls.sha256').write_text(''.join(hashlib.sha256((r/n).read_bytes()).hexdigest()+'  /controls/'+n+'\n' for n in sorted(paths)))
print('prepared value-identity paired comparison; controls',len(paths))
