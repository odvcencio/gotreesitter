from pathlib import Path
import gzip,hashlib,io,json,tarfile
r=Path(__file__).resolve().parent;repo=r.parents[2];d=repo/'docs/benchmarks/20261026-yaml-raw-lease-screen';d.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
base=repo/'docs/benchmarks/20261025-compact-raw-screen/evidence.tar.gz'
assert sha(base.read_bytes())=='73fe52b4ef05a02a6741265da9b447ed3e2610338880592a6d1ff57c5f8c90fa'
inherited={}
with tarfile.open(base) as t:
 for m in t:
  assert m.isfile();inherited[m.name]=t.extractfile(m).read()
files={}
def add(key,path):
 data=path.read_bytes()
 if key in inherited:assert inherited[key]==data,key;return
 if key in files:assert files[key]==data,key;return
 files[key]=data
def folder(rel,virtual):
 p=r/rel
 if not p.exists():return
 for f in sorted(p.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts and f.suffix in ('.json','.txt','.log','.sha256','.py','.sh','.cpu','.mem'):
   add(virtual+'/'+f.relative_to(p).as_posix(),f)
variants=['raw-summary-yaml-history-diagnostic-v20','raw-summary-yaml-actual-state-proof-v22','raw-summary-yaml-all-state-diagnostic-v24','raw-summary-yaml-full-v25','raw-summary-yaml-ownership-v26','raw-summary-yaml-ownership-v27','raw-summary-yaml-stream-v28','raw-summary-yaml-value-v29','raw-summary-yaml-replay-v32','yaml-c027-profile-v30','yaml-c027-profile-v31','yaml-c027-profile-v33','yaml-raw-perf-v1','yaml-raw-perf-v2','yaml-raw-perf-v3']
for name in variants:
 folder(name,'controls/'+name);folder('out/'+name,'outputs/'+name)
 for prefix,suffix in [('run-','.sh'),('worker-','.py'),('commands-','.json')]:
  p=r/(prefix+name+suffix)
  if p.is_file():add('controls/'+p.name,p)
for name in ['raw-summary-yaml-history-diagnostic-v20','raw-summary-yaml-actual-state-proof-v22','raw-summary-yaml-all-state-diagnostic-v24']:
 folder('out/'+name,'outputs/'+name)
for name in ['prepare-yaml-ownership-contract-v26.py','prepare-yaml-ownership-contract-v27.py','prepare-yaml-stream-lease-v28.py','prepare-yaml-raw-perf-v1.py','prepare-yaml-value-identity-v29.py','prepare-yaml-value-gates-v29.py','prepare-yaml-value-perf-v2.py','prepare-yaml-c027-profile-v30.py','prepare-yaml-replay-v32.py','prepare-yaml-replay-perf-v3.py','package-yaml-raw-lease-screen.py']:
 add('controls/'+name,r/name)
add('controls/raw-summary-output-v1/pure-gap-fused-v1/raw_summary_producer_private.go.txt',r/'raw-summary-output-v1/pure-gap-fused-v1/raw_summary_producer_private.go.txt')
def local(name):
 p=r/name
 if p.is_file():return p
 p=repo/'harness_out/docker/go-reuse-20261025'/name
 assert p.is_file(),name
 return p
def key_for(path):
 assert path.startswith('/controls/'),path
 return 'outputs/'+path.removeprefix('/controls/out/') if path.startswith('/controls/out/') else path.lstrip('/')
done=set()
while True:
 pending=[(key,data) for key,data in files.items() if key not in done and Path(key).name in ('controls.sha256','checksums.container.sha256')]
 if not pending:break
 for key,data in pending:
  done.add(key)
  for line in data.decode().splitlines():
   digest,path=line.split('  ',1)
   if not path.startswith('/controls/'):continue
   target=key_for(path)
   if target not in files and target not in inherited:add(target,local(path.removeprefix('/controls/')))
   assert sha(files[target] if target in files else inherited[target])==digest,(key,path)
# Every runtime/test overlay backing is available, including diagnostics whose
# source pins were supplied by their enclosing gate controls.
while True:
 missing=[]
 for key,data in list(files.items()):
  if key.endswith('.json') and '/overlay.' in key:
   for path in json.loads(data).get('Replace',{}).values():
    if path.startswith('/controls/'):
     target=key_for(path)
     if target not in files and target not in inherited:missing.append((target,path))
 if not missing:break
 for key,path in missing:add(key,local(path.removeprefix('/controls/')))
index=[{'path':key,'bytes':len(data),'sha256':sha(data)} for key,data in sorted(files.items())]
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w',format=tarfile.PAX_FORMAT) as t:
 for key,data in sorted(files.items()):
  info=tarfile.TarInfo(key);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
(d/'evidence.tar.gz').write_bytes(gzip.compress(buffer.getvalue(),mtime=0));(d/'contents.json.gz').write_bytes(gzip.compress(json.dumps(index,indent=2).encode(),mtime=0))
summary={'schema':'gts-yaml-raw-lease-screen/v1','archive_members':len(files),'base_evidence_sha256':sha(base.read_bytes()),'runtime_map':'controls/raw-summary-output-v1/yaml-raw-lease-v1/replay-once-v32/overlay.runtime.json','runtime_sha256':sha((r/'raw-summary-output-v1/yaml-raw-lease-v1/replay-once-v32/overlay.runtime.json').read_bytes()),'runtime_targets':35,'gate':json.loads((r/'out/yaml-raw-perf-v3/gates-before.json').read_text()),'screens':{name:json.loads((r/'out'/name/'validated-summary.json').read_text()) for name in ['yaml-raw-perf-v1','yaml-raw-perf-v2','yaml-raw-perf-v3']},'production_promoted':False,'graduated':False,'merges_held':True}
(d/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'members':len(files),'bytes':(d/'evidence.tar.gz').stat().st_size,'sha256':sha((d/'evidence.tar.gz').read_bytes())}))
