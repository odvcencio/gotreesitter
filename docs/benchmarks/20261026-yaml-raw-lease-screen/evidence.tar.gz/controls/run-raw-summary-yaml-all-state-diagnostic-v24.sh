set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/raw-summary-yaml-all-state-diagnostic-v24/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/raw-summary-yaml-all-state-diagnostic-v24/controls.sha256 > /evidence/controls-before.log 2>&1
go test -overlay=/controls/raw-summary-output-v1/yaml-raw-lease-v1/all-state-diagnostic-v24/overlay.tests.json -tags gts_parsercorephase0 -run '^TestRawSummaryFreshYAMLAllStateDifferencesDiagnostic$' -count=1 -v -timeout=4m . > /evidence/diagnosis.log 2>&1
