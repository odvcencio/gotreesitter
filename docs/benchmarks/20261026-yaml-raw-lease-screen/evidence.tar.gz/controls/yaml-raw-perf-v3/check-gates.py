from pathlib import Path
import json,re,hashlib
r=Path(__file__).resolve().parents[1];out=r/'out'
def check(folder,logs,exit_code=0):
 p=out/folder
 assert json.loads((p/'finished.json').read_text())['exit_code']==exit_code,folder
 for n in ('source-before.log','source-after.log','controls-before.log','controls-after.log'):assert (p/n).read_text()=='',(folder,n)
 for n,(tops,records) in logs.items():
  s=(p/n).read_text()
  assert len(re.findall(r'^--- PASS:',s,re.M))==tops and len(re.findall(r'^\s*--- PASS:',s,re.M))==records,(folder,n)
  assert not re.search(r'--- (FAIL|SKIP):|^FAIL\b|WARNING: DATA RACE|panic:',s,re.M),(folder,n)
 return p
p=check('raw-summary-yaml-replay-v32',{'scanner.log':(5,10),'core-release.log':(93,205),'core-workcount.log':(29,66),'core-race.log':(29,66),'value-identity.log':(48,72),'yaml-lifetime.log':(5,10),'yaml-authority-budget.log':(17,41),'go-preserved.log':(1,3),'yaml-race.log':(13,45),'invariants-yaml-0.log':(1,1),'invariants-yaml-1.log':(1,1),'yaml-raw-locked-c.log':(2,6),'yaml-existing-locked-c.log':(8,186)})
for route in (0,1):assert 'session_steps=72 no_edit_allocs=0' in (p/f'invariants-yaml-{route}.log').read_text()
s=(p/'yaml-lifetime.log').read_text()
assert 'records=231 state_known=230 pre_known=209' in s and 'unproved=0' in s
s=(p/'yaml-raw-locked-c.log').read_text()
assert 'bytes=8012' in s and 'bytes=32048' in s and s.count('actual_lease=true public_checkpoint_transfer=false')==2
work={'tokens','new_nodes','max_live_versions','multi_version_token_share_ppm'};reuse={'reused_bytes','block_splices'}
def compare(a,b,path=''):
 assert type(a)==type(b),(path,'type')
 if isinstance(a,dict):
  assert a.keys()==b.keys(),(path,'keys')
  return [x for k in a for x in compare(a[k],b[k],path+'/'+k)]
 if isinstance(a,list):
  assert len(a)==len(b),(path,'length')
  return [x for i in range(len(a)) for x in compare(a[i],b[i],path+'/'+str(i))]
 if a==b:return []
 key=path.rsplit('/',1)[-1]
 assert type(a)==int and a>=0 and b>=0,(path,'non-counter difference',a,b)
 assert (key in work and b<=a) or (key in reuse and b>=a),(path,'counter regression or unknown',a,b)
 return [{'path':path,'before':a,'after':b}]
rows=[]
for route in ('default','candidate'):
 a=json.loads((p/f'baseline-{route}-yaml.json').read_text());b=json.loads((p/f'candidate-{route}-yaml.json').read_text())
 rows.append({'route':route,'changes':compare(a,b)})
assert rows[0]['changes']==[]
assert rows[1]['changes']==[{'path':'/0/full/new_nodes','before':232,'after':1},{'path':'/0/edits/0/counters/new_nodes','before':232,'after':1}]
formation={}
for arm in ('reference','candidate'):
 log=(p/f'{arm}-formation-work.log').read_text()
 assert len(re.findall(r'^--- PASS:',log,re.M))==1 and not re.search(r'--- (FAIL|SKIP):|^FAIL\b|panic:',log,re.M)
 formation[arm]=[json.loads(line.split('YAML_FORMATION_WORK ',1)[1]) for line in log.splitlines() if 'YAML_FORMATION_WORK ' in line]
 assert [x['Bytes'] for x in formation[arm]]==[1998,8012,32048]
 for row in formation[arm]:
  assert row['Before']['Formation']==row['After']['Formation'] and row['After']==row['Warm']
  assert row['Before']['ArenaNodes']==1 and row['Before']['RegisteredContexts']==1
formation_changes=[]
for before,after in zip(formation['reference'],formation['candidate']):
 diff={}
 for k,v in before['Before']['Formation'].items():
  changed=after['Before']['Formation'][k]
  assert changed<=v,(before['Bytes'],k,v,changed)
  if changed!=v:diff[k]={'before':v,'after':changed}
 assert set(diff)=={'FormationRawEdges','FormationLocalRootRefs','FormationHiddenSteps'}
 aa=json.loads(json.dumps(after));bb=json.loads(json.dumps(before))
 for stage in ('Before','After','Warm'):
  del aa[stage]['Formation'];del bb[stage]['Formation']
 assert aa==bb,'non-formation work/storage/state changed'
 formation_changes.append({'bytes':before['Bytes'],'changes':diff})
runtime=r/'raw-summary-output-v1/yaml-raw-lease-v1/replay-once-v32/overlay.runtime.json'
assert hashlib.sha256(runtime.read_bytes()).hexdigest()=='195c8bf9321a4d8e5888552235bc17ab2a284789359ec28617279ac5956431fe'
original=json.loads(runtime.read_text())['Replace'];timed=json.loads((Path(__file__).parent/'overlay.container.json').read_text())['Replace']
assert len(original)==35 and all(timed[k]==v for k,v in original.items())
assert set(timed)-set(original)=={'/baseline/benchmark_admission_candidate_route_test.go','/candidate/benchmark_admission_candidate_route_test.go'}
print(json.dumps({'schema':'gts-yaml-raw-preperf/v1','selected_semantic_gates_passed':True,'identity_value_checks_allocate_zero':True,'stream_lease_bytes':[8012,32048],'runtime_sha256':hashlib.sha256(runtime.read_bytes()).hexdigest(),'C025_families':10,'D8_sessions':2,'D8_steps':144,'no_edit_allocations':0,'counter_rows':rows,'adverse_counter_changes':0,'formation_changes':formation_changes,'counter_exceptions_used':False,'reuse_disabled':True,'production_promoted':False,'graduated':False,'merges_held':True}))
