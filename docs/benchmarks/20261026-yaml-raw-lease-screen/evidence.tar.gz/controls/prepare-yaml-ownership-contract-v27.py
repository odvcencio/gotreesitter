from pathlib import Path
import json,hashlib
r=Path('/home/draco/work/gotreesitter/harness_out/docker/go-ci-blockers-20261025');y=r/'raw-summary-output-v1/yaml-raw-lease-v1';old=y/'ownership-contract-v26';d=y/'ownership-contract-v27';d.mkdir(exist_ok=False)
s=(old/'compact_r4_parity_test.go.txt').read_text().replace('requireCompact','ownershipWitness')
s=s.replace('if ownershipWitness && (routed-beforeRouted != 1 || fallback != beforeFallback) {','if ownershipWitness && freshOnly && (routed-beforeRouted != 1 || fallback != beforeFallback) {')
s=s.replace('''			// Preserve the original materialized publisher's stronger contract.
			if !runtime.CompactExternalScannerCheckpointTransferProven {
				t.Fatal("published scanner transfer lost its proof after acceptance trials")
			}''','''			// Opting the scanner into real checkpoint ownership exposes hidden
			// state changes that the old native publisher cannot retain. It must
			// refuse that publication, fall back, and return exact C output.
			if routed != beforeRouted || fallback-beforeFallback != 1 || !strings.Contains(gts.AdmissionCandidateLastFallbackReason(), "native projection would hide a scanner checkpoint") {
				t.Fatal("old checkpoint publisher did not refuse hidden state")
			}
			if runtime.CompactExternalScannerCheckpointTransferProven {
				t.Fatal("fallback falsely acquired compact checkpoint-transfer proof")
			}''')
(d/'compact_r4_parity_test.go.txt').write_text(s)
ov=json.loads((old/'overlay.cgo.tests.json').read_text());ov['Replace']['/candidate/cgo_harness/compact_r4_parity_test.go']='/controls/'+str((d/'compact_r4_parity_test.go.txt').relative_to(r));(d/'overlay.cgo.tests.json').write_text(json.dumps(ov,indent=2)+'\n')
label='raw-summary-yaml-ownership-v27';before='raw-summary-yaml-ownership-v26';(r/'out'/label).mkdir(exist_ok=False);(r/label).mkdir(exist_ok=False)
run=(r/('run-'+before+'.sh')).read_text().replace(before,label).replace('ownership-contract-v26/','ownership-contract-v27/')
needle='cd /candidate/cgo_harness\n';control='''cd /baseline/cgo_harness
go test -tags treesitter_c_parity,gts_parsercorephase0 -run '^TestCompactYAMLVersionOwnershipCOracle$' -count=1 -v -timeout=5m . > /evidence/baseline-original-ownership.log 2>&1
'''
run=run.replace(needle,control+needle,1);(r/('run-'+label+'.sh')).write_text(run)
commands=json.loads((r/('commands-'+before+'.json')).read_text());commands=json.loads(json.dumps(commands).replace(before,label));(r/('commands-'+label+'.json')).write_text(json.dumps(commands,indent=2)+'\n')
(r/('worker-'+label+'.py')).write_text((r/('worker-'+before+'.py')).read_text().replace(before,label))
paths=set()
for line in (r/before/'controls.sha256').read_text().splitlines():
 _,name=line.split('  ',1)
 if before not in name:paths.add(name)
paths.update('/controls/'+str(a.relative_to(r)) for a in [d/'compact_r4_parity_test.go.txt',d/'overlay.cgo.tests.json',r/('run-'+label+'.sh'),r/('commands-'+label+'.json'),r/('worker-'+label+'.py')])
(r/label/'controls.sha256').write_text(''.join(hashlib.sha256((r/name.removeprefix('/controls/')).read_bytes()).hexdigest()+'  '+name+'\n' for name in sorted(paths)))
print('Prepared',label,'with original baseline test and candidate hidden-checkpoint refusal plus fresh raw ownership.')
