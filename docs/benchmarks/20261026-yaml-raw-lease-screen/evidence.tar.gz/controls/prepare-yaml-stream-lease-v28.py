from pathlib import Path
import json,hashlib
r=Path('/home/draco/work/gotreesitter/harness_out/docker/go-ci-blockers-20261025'); y=r/'raw-summary-output-v1/yaml-raw-lease-v1';d=y/'stream-lease-proof-v28';d.mkdir(exist_ok=False)
s='''//go:build cgo && treesitter_c_parity && gts_parsercorephase0 && !gts_no_parsercorephase0
package cgoharness
import (
 "bytes"
 "crypto/sha256"
 "fmt"
 "os"
 "testing"
 gts "github.com/odvcencio/gotreesitter"
 "github.com/odvcencio/gotreesitter/grammars"
)
func TestRawSummaryFreshYAMLDocumentLeaseLockedC(t *testing.T) {
 sample, err := os.ReadFile("../internal/benchfixtures/testdata/real/yaml")
 if err != nil || len(sample)!=1998 || fmt.Sprintf("%x",sha256.Sum256(sample))!="5aa2c70bccfe73254f13eca40476c3f88f522c6a47aea499f9d672dbc5aae8c4" {t.Fatal("R4 source changed",err)}
 document:=append([]byte("---\\n"),sample...);document=append(document,'\\n')
 cl,err:=ParityCLanguage("yaml");if err!=nil {t.Fatal(err)}
 t.Cleanup(gts.PrivateSetRawSummaryForCQualification(true))
 for _,fixture:=range []struct{count,bytes int;digest string}{{4,8012,"778d1dec01bef4da1cef26acff6b8012c9701a23af67bdb9511b419912f04400"},{16,32048,"0483b9bd82647089af4772155e54d2f06617a993253a08b5c6445537e4853be2"}} {
  t.Run(fmt.Sprintf("documents=%d",fixture.count),func(t *testing.T){
   source:=bytes.Repeat(document,fixture.count)
   if len(source)!=fixture.bytes || fmt.Sprintf("%x",sha256.Sum256(source))!=fixture.digest {t.Fatal("document witness identity changed")}
   ct:=compactT3ParseC(t,cl,source);defer ct.Close()
   p:=gts.NewParser(grammars.YamlLanguage());p.SetAdmissionCandidateRoute(true)
   before,fb:=gts.AdmissionCandidateCounters();tree,err:=p.Parse(source)
   if err!=nil||tree==nil {t.Fatal(err)};defer tree.Release()
   after,afb:=gts.AdmissionCandidateCounters();if after-before!=1||afb!=fb {t.Fatal("ordinary document route fell back",gts.AdmissionCandidateLastFallbackReason())}
   nodes,err:=gts.PrivateRequireFreshYAMLRawCheckpointForCQualification(tree);if err!=nil {t.Fatal(err)}
   runtime:=tree.ParseRuntime()
   if runtime.CompactExternalScannerCheckpointTransferProven || tree.ParseStoppedEarly() || tree.RootNode().HasError() || tree.RootNode().EndByte()!=uint32(len(source)) {t.Fatal("incomplete or overcertified document lease")}
   assertLockedCTreeExactWithErrors(t,"ordinary document raw lease",tree,grammars.YamlLanguage(),ct)
   t.Logf("YAML_STREAM_LEASE bytes=%d sha256=%s public_nodes=%d entry_nodes=%d actual_lease=true public_checkpoint_transfer=false",len(source),fixture.digest,nodes,runtime.NodesAllocated)
  })
 }
}
'''
p=d/'stream_cgo_test.go.txt';p.write_text(s)
ov=json.loads((y/'ownership-contract-v27/overlay.cgo.tests.json').read_text());ov['Replace']['/candidate/cgo_harness/raw_summary_stream_lease_private_test.go']='/controls/'+str(p.relative_to(r));(d/'overlay.cgo.tests.json').write_text(json.dumps(ov,indent=2)+'\n')
label='raw-summary-yaml-stream-v28';(r/'out'/label).mkdir(exist_ok=False);(r/label).mkdir(exist_ok=False)
old='raw-summary-yaml-ownership-v27';run=(r/('run-'+old+'.sh')).read_text();run=run[:run.index('cd /baseline/cgo_harness')].replace(old,label)
run+='''cd /candidate/cgo_harness
go test -overlay=/controls/raw-summary-output-v1/yaml-raw-lease-v1/stream-lease-proof-v28/overlay.cgo.tests.json -tags treesitter_c_parity,gts_parsercorephase0 -run '^TestRawSummaryFreshYAMLDocumentLeaseLockedC$' -count=1 -v -timeout=5m . > /evidence/streams-locked-c.log 2>&1
'''
(r/('run-'+label+'.sh')).write_text(run)
commands=json.loads((r/('commands-'+old+'.json')).read_text());commands=json.loads(json.dumps(commands).replace(old,label).replace('12m','8m'));(r/('commands-'+label+'.json')).write_text(json.dumps(commands,indent=2)+'\n')
(r/('worker-'+label+'.py')).write_text((r/('worker-'+old+'.py')).read_text().replace(old,label).replace('timeout=850','timeout=550'))
paths=set()
for line in (r/old/'controls.sha256').read_text().splitlines():
 _,name=line.split('  ',1)
 if old not in name:paths.add(name)
paths.update('/controls/'+str(a.relative_to(r)) for a in [p,d/'overlay.cgo.tests.json',r/('run-'+label+'.sh'),r/('commands-'+label+'.json'),r/('worker-'+label+'.py')])
(r/label/'controls.sha256').write_text(''.join(hashlib.sha256((r/n.removeprefix('/controls/')).read_bytes()).hexdigest()+'  '+n+'\n' for n in sorted(paths)))
print('prepared exact8KiB/32KiB lease and C proof; runtime unchanged; waits for shared lock')
