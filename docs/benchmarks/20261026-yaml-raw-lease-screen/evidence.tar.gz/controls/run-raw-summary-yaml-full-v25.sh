set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/raw-summary-yaml-full-v25/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/raw-summary-yaml-full-v25/controls.sha256 > /evidence/controls-before.log 2>&1
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/raw-summary-yaml-full-v25
mkdir -p "$scratch"
overlay=/controls/raw-summary-output-v1/yaml-raw-lease-v1/public-contract-proof-v25/overlay.tests.json
go test -overlay="$overlay" -tags gts_parsercorephase0 -run '^Test(RawSummary|Native|Selected|DirectReduction|SingleVersion)' -count=1 -v -timeout=5m ./internal/parsercorephase0 > /evidence/core-release.log 2>&1
for tags in gts_parsercorephase0,gts_workcount gts_parsercorephase0; do
 race=(); if [[ "$tags" == gts_parsercorephase0 ]]; then race=(-race); fi
 label=workcount; if (( ${#race[@]} )); then label=race; fi
 go test "${race[@]}" -overlay="$overlay" -tags "$tags" -run '^TestRawSummary' -count=1 -v -timeout=5m ./internal/parsercorephase0 > "/evidence/core-$label.log" 2>&1
done
go test -c -overlay="$overlay" -tags gts_parsercorephase0 -o "$scratch/root.test" . > /evidence/root-build.log 2>&1
"$scratch/root.test" -test.run '^TestRawSummaryFreshYAML(OrdinaryCheckpointLifetime|ExactNativeRecordOracle|ActualGSSStateOracle|ActualRecoveryNeverTransfers|ConcurrentReadersCopyResetAndRelease)$' -test.count=1 -test.v -test.timeout=5m > /evidence/yaml-lifetime.log 2>&1
"$scratch/root.test" -test.run '^Test(RawSummaryFreshYAML(AuthorityRejectsEOFMutation|CheckpointLatePublicationCallbacks|PublicAuthorityRejectsEOFMutation|PublicCheckpointLatePublicationCallbacks)|RawSummaryCheckpointSnapshotReservationCoversArenaGrowth|RuntimeMemory.*|ParseMemory.*)$' -test.count=1 -test.v -test.timeout=5m > /evidence/yaml-authority-budget.log 2>&1
"$scratch/root.test" -test.run '^TestRawSummaryOrdinaryPublicParity$' -test.count=1 -test.v -test.timeout=4m > /evidence/go-preserved.log 2>&1
go test -race -overlay="$overlay" -tags gts_parsercorephase0 -run '^TestRawSummaryFreshYAML(OrdinaryCheckpointLifetime|ExactNativeRecordOracle|ActualGSSStateOracle|ActualRecoveryNeverTransfers|ConcurrentReadersCopyResetAndRelease|PublicAuthorityRejectsEOFMutation|PublicCheckpointLatePublicationCallbacks)$' -count=1 -v -timeout=5m . > /evidence/yaml-race.log 2>&1
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE=$route GOTREESITTER_V1_INVARIANT_LANGUAGE=yaml "$scratch/root.test" -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=4m > "/evidence/invariants-yaml-$route.log" 2>&1
done
cd /candidate/cgo_harness
go test -c -overlay=/controls/raw-summary-output-v1/yaml-raw-lease-v1/public-contract-proof-v25/overlay.cgo.tests.json -tags treesitter_c_parity,gts_parsercorephase0 -o "$scratch/cgo.test" . > /evidence/cgo-build.log 2>&1
"$scratch/cgo.test" -test.run '^TestRawSummaryFreshYAMLCheckpointLockedC$' -test.count=1 -test.v -test.timeout=5m > /evidence/yaml-raw-locked-c.log 2>&1
GTS_ADMISSION_CANDIDATE=1 "$scratch/cgo.test" -test.run '^Test(CompactYAMLVersionOwnershipCOracle|CompactYAMLDocumentStreamLockedC|YAMLRecoveredMappingQuotesLockedC|YAMLOwnedGrammarLockedCParity|YAMLEOFRecoverWrapCompactRoute|YAMLEOFRecoverWrapUnfinishedMappingDeclinesCompact|YAMLOneBytePrintableEOFAdmissionMatchesLockedC|YAMLResultCompatibilityErrorsLockedC)$' -test.count=1 -test.v -test.timeout=5m > /evidence/yaml-existing-locked-c.log 2>&1
for arm in baseline candidate; do
 cd "/$arm"
 if [[ "$arm" == candidate ]]; then extra=(-overlay=/controls/raw-summary-output-v1/yaml-raw-lease-v1/public-contract-proof-v25/overlay.runtime.json); else extra=(); fi
 go build "${extra[@]}" -tags gts_parsercorephase0 -o "$scratch/$arm-ledger" ./cmd/perfcounterledger > "/evidence/$arm-ledger-build.log" 2>&1
 for route in default candidate; do
  mode=0; if [[ "$route" == candidate ]]; then mode=1; fi
  GTS_ADMISSION_CANDIDATE=$mode "$scratch/$arm-ledger" --child-route "$route" --langs yaml > "/evidence/$arm-$route-yaml.json" 2> "/evidence/$arm-$route-yaml.stderr"
 done
done
sha256sum "$scratch/root.test" "$scratch/cgo.test" "$scratch/baseline-ledger" "$scratch/candidate-ledger" > /evidence/binary.sha256
