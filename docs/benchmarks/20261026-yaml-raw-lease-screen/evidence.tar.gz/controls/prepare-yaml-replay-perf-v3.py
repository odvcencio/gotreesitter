from pathlib import Path
import json,hashlib
r=Path('/home/draco/work/gotreesitter/harness_out/docker/go-ci-blockers-20261025');old=r/'yaml-raw-perf-v2';d=r/'yaml-raw-perf-v3';d.mkdir(exist_ok=False);runtime=r/'raw-summary-output-v1/yaml-raw-lease-v1/replay-once-v32/overlay.runtime.json'
for f in old.iterdir():
 if f.is_file() and f.name!='controls.sha256':d.joinpath(f.name).write_text(f.read_text().replace('yaml-raw-perf-v2','yaml-raw-perf-v3').replace('raw-summary-yaml-value-v29','raw-summary-yaml-replay-v32').replace('value-identity-v29/','replay-once-v32/'))
overlay=json.loads(runtime.read_text())
for arm in ['baseline','candidate']:overlay['Replace'][f'/{arm}/benchmark_admission_candidate_route_test.go']='/controls/yaml-raw-perf-v3/benchmark-source.go.txt'
(d/'overlay.container.json').write_text(json.dumps(overlay,indent=2)+'\n')
gate=(d/'check-gates.py').read_text().replace("'value-identity.log':(18,44)","'value-identity.log':(48,72)").replace("'yaml-race.log':(12,44)","'yaml-race.log':(13,45)").replace('len(original)==34','len(original)==35').replace('65154f05fb199237fb00eb90870e0471be49bb976a287059069625dfa2a6bcdd',hashlib.sha256(runtime.read_bytes()).hexdigest())
a=gate.index("runtime=r/'raw-summary-output-v1/")
proof='''formation={}
for arm in ('reference','candidate'):
 log=(p/f'{arm}-formation-work.log').read_text()
 assert len(re.findall(r'^--- PASS:',log,re.M))==1 and not re.search(r'--- (FAIL|SKIP):|^FAIL\\b|panic:',log,re.M)
 formation[arm]=[json.loads(line.split('YAML_FORMATION_WORK ',1)[1]) for line in log.splitlines() if 'YAML_FORMATION_WORK ' in line]
 assert [x['Bytes'] for x in formation[arm]]==[1998,8012,32048]
 for row in formation[arm]:
  assert row['Before']['Formation']==row['After']['Formation'] and row['After']==row['Warm']
  assert row['Before']['ArenaNodes']==1 and row['Before']['RegisteredContexts']==1
formation_changes=[]
for before,after in zip(formation['reference'],formation['candidate']):
 diff={}
 for k,v in before['Before']['Formation'].items():
  changed=after['Before']['Formation'][k]
  assert changed<=v,(before['Bytes'],k,v,changed)
  if changed!=v:diff[k]={'before':v,'after':changed}
 assert set(diff)=={'FormationRawEdges','FormationLocalRootRefs','FormationHiddenSteps'}
 aa=json.loads(json.dumps(after));bb=json.loads(json.dumps(before))
 for stage in ('Before','After','Warm'):
  del aa[stage]['Formation'];del bb[stage]['Formation']
 assert aa==bb,'non-formation work/storage/state changed'
 formation_changes.append({'bytes':before['Bytes'],'changes':diff})
'''
gate=gate[:a]+proof+gate[a:];gate=gate.replace("'adverse_counter_changes':0", "'adverse_counter_changes':0,'formation_changes':formation_changes")
(d/'check-gates.py').write_text(gate)
manifest=json.loads((d/'manifest.json').read_text());manifest.update(runtime_map=str(runtime.relative_to(r)),runtime_sha256=hashlib.sha256(runtime.read_bytes()).hexdigest(),runtime_targets=35,change='Preserve exact identity callbacks without slice allocations; reuse a newly formed exceptional child list instead of projecting it twice')
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
paths={str(f.relative_to(r)) for f in d.iterdir() if f.is_file()};paths.add(str(runtime.relative_to(r)));paths.update(v.removeprefix('/controls/') for v in overlay['Replace'].values());paths.add('raw-summary-yaml-replay-v32/controls.sha256');paths.update(str(p.relative_to(r)) for p in (r/'out/raw-summary-yaml-replay-v32').iterdir() if p.is_file() and p.suffix in ['.json','.log'])
(d/'controls.sha256').write_text(''.join(hashlib.sha256((r/n).read_bytes()).hexdigest()+'  /controls/'+n+'\n' for n in sorted(paths)))
print('prepared final paired screen with exact physical-work gate')
