set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly -modfile=/controls/oracle0271-module-bind-v3/go.mod -overlay=/controls/yaml-c027-profile-v30/overlay.c027.json'
git config --global --add safe.directory /candidate
cd /candidate
finish(){
 cd /candidate
 sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-after.log 2>&1
 sha256sum --quiet -c /controls/yaml-c027-profile-v30/controls.sha256 > /evidence/controls-after.log 2>&1
 sha256sum --quiet -c /controls/oracle0271/checksums.container.sha256 > /evidence/oracle-after.log 2>&1
 sha256sum --quiet -c /controls/oracle0271-module-bind-v3/checksums.container.sha256 > /evidence/binding-after.log 2>&1
 python3 /controls/oracle0271-module-bind-v3/verify-inputs.py > /evidence/staged-after.json
}
trap finish EXIT
sha256sum --quiet -c /controls/sealed-reduction-perf-v1/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/yaml-c027-profile-v30/controls.sha256 > /evidence/controls-before.log 2>&1
sha256sum --quiet -c /controls/oracle0271/checksums.container.sha256 > /evidence/oracle-before.log 2>&1
sha256sum --quiet -c /controls/oracle0271-module-bind-v3/checksums.container.sha256 > /evidence/binding-before.log 2>&1
python3 /controls/oracle0271-module-bind-v3/verify-inputs.py > /evidence/staged-before.json
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/yaml-c027-profile-v30
mkdir -p "$scratch"
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o "$scratch/cgo.test" . > /evidence/cgo-build.log 2>&1
"$scratch/cgo.test" -test.run '^TestCOracle0271HeaderAndLinkProbe$' -test.count=1 -test.v -test.timeout=2m > /evidence/runtime-probe.log 2>&1
"$scratch/cgo.test" -test.run '^TestRawSummaryFreshYAML(CheckpointLockedC|DocumentLeaseLockedC)$' -test.count=1 -test.v -test.timeout=5m > /evidence/yaml-raw-c027.log 2>&1
sha256sum "$scratch/cgo.test" > /evidence/binary.sha256
GTS_ADMISSION_CANDIDATE=1 "$scratch/cgo.test" -test.run '^Test(CompactYAMLVersionOwnershipCOracle|CompactYAMLDocumentStreamLockedC|YAMLRecoveredMappingQuotesLockedC|YAMLOwnedGrammarLockedCParity|YAMLEOFRecoverWrapCompactRoute|YAMLEOFRecoverWrapUnfinishedMappingDeclinesCompact|YAMLOneBytePrintableEOFAdmissionMatchesLockedC|YAMLResultCompatibilityErrorsLockedC)$' -test.count=1 -test.v -test.timeout=5m > /evidence/yaml-existing-c027.log 2>&1
cd /candidate
export GOFLAGS='-p=1 -mod=readonly'
go test -overlay=/controls/raw-summary-output-v1/yaml-raw-lease-v1/value-identity-v29/overlay.tests.json -tags gts_parsercorephase0 -run '^Test(C26q|ExternalScannerOrderAdapter)' -count=1 -v -timeout=4m . > /evidence/identity-compatibility.log 2>&1
go test -c -overlay=/controls/yaml-raw-perf-v2/overlay.container.json -tags gts_parsercorephase0 -o "$scratch/profile.test" . > /evidence/profile-build.log 2>&1
GTS_ADMISSION_REAL_CORPUS_LANGS=yaml /usr/bin/time -v "$scratch/profile.test" -test.run '^$' -test.bench '^BenchmarkAdmissionR4Compact$' -test.count=1 -test.benchtime=5s -test.benchmem -test.cpuprofile=/evidence/yaml.cpu -test.memprofile=/evidence/yaml.mem > /evidence/profile-run.log 2> /evidence/profile-time.txt
go tool pprof -top -nodecount=50 "$scratch/profile.test" /evidence/yaml.cpu > /evidence/profile-top.txt 2>&1
go tool pprof -top -cum -nodecount=50 "$scratch/profile.test" /evidence/yaml.cpu > /evidence/profile-cum.txt 2>&1
go tool pprof -top -alloc_objects -nodecount=30 "$scratch/profile.test" /evidence/yaml.mem > /evidence/profile-allocs.txt 2>&1
sha256sum "$scratch/profile.test" > /evidence/profile-binary.sha256
