from pathlib import Path
import json,hashlib,shutil
r=Path('/home/draco/work/gotreesitter/harness_out/docker/go-ci-blockers-20261025');d=r/'yaml-raw-perf-v1';d.mkdir(exist_ok=False)
old=r/'raw-summary-perf-pure-gap-v2';runtime=r/'raw-summary-output-v1/yaml-raw-lease-v1/public-contract-proof-v25/overlay.runtime.json'
overlay=json.loads(runtime.read_text());shutil.copyfile(old/'benchmark-source.go.txt',d/'benchmark-source.go.txt')
for arm in ['baseline','candidate']:overlay['Replace'][f'/{arm}/benchmark_admission_candidate_route_test.go']='/controls/yaml-raw-perf-v1/benchmark-source.go.txt'
(d/'overlay.container.json').write_text(json.dumps(overlay,indent=2)+'\n')
shutil.copyfile(old/'source.sha256',d/'source.sha256')
run=(old/'run.sh').read_text().replace('raw-summary-perf-pure-gap-v2','yaml-raw-perf-v1')
run='\n'.join(line for line in run.splitlines() if not line.startswith('GTS_ADMISSION_CANDIDATE=1 bash') and not line.startswith('GTS_ADMISSION_REAL_CORPUS_LANGS=go bash'))+'\n'
run=run.replace('all60 matched shuffle pairs complete; private compact raw-lease screen, no graduation claim','all20 matched YAML shuffle pairs complete; private fresh-only raw-lease screen, no graduation claim')
(d/'run.sh').write_text(run)
commands=json.loads((old/'commands.json').read_text());commands=json.loads(json.dumps(commands).replace('raw-summary-perf-pure-gap-v2','yaml-raw-perf-v1'))
(d/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');shutil.copyfile(old/'worker.py',d/'worker.py')
(d/'check-gates.py').write_text('''from pathlib import Path
import json,re,hashlib
r=Path(__file__).resolve().parents[1];out=r/'out'
def check(folder,logs,exit_code=0):
 p=out/folder
 assert json.loads((p/'finished.json').read_text())['exit_code']==exit_code,folder
 for n in ('source-before.log','source-after.log','controls-before.log','controls-after.log'):assert (p/n).read_text()=='',(folder,n)
 for n,(tops,records) in logs.items():
  s=(p/n).read_text()
  assert len(re.findall(r'^--- PASS:',s,re.M))==tops and len(re.findall(r'^\\s*--- PASS:',s,re.M))==records,(folder,n)
  assert not re.search(r'--- (FAIL|SKIP):|^FAIL\\b|WARNING: DATA RACE|panic:',s,re.M),(folder,n)
 return p
p=check('raw-summary-yaml-full-v25',{'core-release.log':(93,205),'core-workcount.log':(29,66),'core-race.log':(29,66),'yaml-lifetime.log':(5,10),'yaml-authority-budget.log':(17,41),'go-preserved.log':(1,3),'yaml-race.log':(7,21),'invariants-yaml-0.log':(1,1),'invariants-yaml-1.log':(1,1),'yaml-raw-locked-c.log':(1,3)},1)
# The original stronger public-sidecar assertion failed. Preserve that failure;
# v27 re-runs the whole C suite with explicit materialized and raw contracts.
s=(p/'yaml-existing-locked-c.log').read_text()
assert re.findall(r'^--- FAIL: (\\S+)',s,re.M)==['TestCompactYAMLVersionOwnershipCOracle']
assert 'published scanner transfer lost its proof after acceptance trials' in s
for route in (0,1):assert 'session_steps=72 no_edit_allocs=0' in (p/f'invariants-yaml-{route}.log').read_text()
p=check('raw-summary-yaml-ownership-v27',{'baseline-original-ownership.log':(1,1),'yaml-existing-locked-c.log':(8,186),'yaml-raw-locked-c.log':(1,3)})
work={'tokens','new_nodes','max_live_versions','multi_version_token_share_ppm'};reuse={'reused_bytes','block_splices'}
def compare(a,b,path=''):
 assert type(a)==type(b),(path,'type')
 if isinstance(a,dict):
  assert a.keys()==b.keys(),(path,'keys')
  return [x for k in a for x in compare(a[k],b[k],path+'/'+k)]
 if isinstance(a,list):
  assert len(a)==len(b),(path,'length')
  return [x for i in range(len(a)) for x in compare(a[i],b[i],path+'/'+str(i))]
 if a==b:return []
 key=path.rsplit('/',1)[-1]
 assert type(a)==int and a>=0 and b>=0,(path,'non-counter difference',a,b)
 assert (key in work and b<=a) or (key in reuse and b>=a),(path,'counter regression or unknown',a,b)
 return [{'path':path,'before':a,'after':b}]
rows=[]
for route in ('default','candidate'):
 a=json.loads((p/f'baseline-{route}-yaml.json').read_text());b=json.loads((p/f'candidate-{route}-yaml.json').read_text())
 rows.append({'route':route,'changes':compare(a,b)})
assert rows[0]['changes']==[]
assert rows[1]['changes']==[{'path':'/0/full/new_nodes','before':232,'after':1},{'path':'/0/edits/0/counters/new_nodes','before':232,'after':1}]
runtime=r/'raw-summary-output-v1/yaml-raw-lease-v1/public-contract-proof-v25/overlay.runtime.json'
assert hashlib.sha256(runtime.read_bytes()).hexdigest()=='65ad187290d2e00417da10449c78bb239b614e0310d420807008b0c9bc1cabc3'
original=json.loads(runtime.read_text())['Replace'];timed=json.loads((Path(__file__).parent/'overlay.container.json').read_text())['Replace']
assert len(original)==31 and all(timed[k]==v for k,v in original.items())
assert set(timed)-set(original)=={'/baseline/benchmark_admission_candidate_route_test.go','/candidate/benchmark_admission_candidate_route_test.go'}
print(json.dumps({'schema':'gts-yaml-raw-preperf/v1','selected_semantic_gates_passed':True,'runtime_sha256':hashlib.sha256(runtime.read_bytes()).hexdigest(),'C025_families':8,'D8_sessions':2,'D8_steps':144,'no_edit_allocations':0,'counter_rows':rows,'adverse_counter_changes':0,'counter_exceptions_used':False,'reuse_disabled':True,'production_promoted':False,'graduated':False,'merges_held':True}))
''')
# Reuse the strict seed/order parser, restricting it to this one cohort.
v=(old/'validate.py').read_text().replace('raw-summary-perf-pure-gap-v2','yaml-raw-perf-v1')
v=v.replace(" ('go-primary','primary-{}.txt',['BenchmarkGraduationGoSuite/Full','BenchmarkGraduationGoSuite/Edit','BenchmarkGraduationGoSuite/NoEdit']),\n",'').replace(" ('go-r4','r4-{}-go.txt',['BenchmarkCompactGraduationR4/legacy','BenchmarkCompactGraduationR4/compact']),\n",'')
v=v.replace("'pairs':60,'processes':120", "'pairs':20,'processes':40").replace("'no_edit_allocations':0,", "'no_edit_allocations_correctness_gate':0,")
(d/'validate.py').write_text(v)
manifest={'schema':'gts-yaml-raw-perf/v1','baseline_head':'810f7126fe2b231d7320359ddfe059396798fddc','runtime_map':str(runtime.relative_to(r)),'runtime_sha256':hashlib.sha256(runtime.read_bytes()).hexdigest(),'runtime_targets':31,'protocol':{'pairs':20,'processes':40,'seeds':list(range(1,21)),'benchtime':'750ms','GOMAXPROCS':1,'count':1,'benchmem':True,'tags':'gts_parsercorephase0','shuffled_child_order':True,'alternating_arm_order':True},'input':{'bytes':1998,'sha256':'5aa2c70bccfe73254f13eca40476c3f88f522c6a47aea499f9d672dbc5aae8c4'},'claims_limited_to':['R4 fresh parse and release','Linux amd64 pinned Go1.26.6','no end-user traversal timing','no incremental reuse authority','no graduation or main merge']}
(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
paths={str(p.relative_to(r)) for p in d.iterdir() if p.is_file()}
paths.add(str(runtime.relative_to(r)))
paths.update(v.removeprefix('/controls/') for v in overlay['Replace'].values())
for label in ['raw-summary-yaml-full-v25','raw-summary-yaml-ownership-v27']:
 paths.add(label+'/controls.sha256')
 paths.update(str(p.relative_to(r)) for p in (r/'out'/label).iterdir() if p.is_file() and p.suffix in ['.json','.log'])
(d/'controls.sha256').write_text(''.join(hashlib.sha256((r/n).read_bytes()).hexdigest()+'  /controls/'+n+'\n' for n in sorted(paths)))
print('prepared',len(paths),'frozen controls; runtime targets31 unchanged')
