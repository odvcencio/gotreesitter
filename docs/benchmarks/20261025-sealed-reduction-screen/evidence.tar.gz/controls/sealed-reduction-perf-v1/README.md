# Sealed deterministic reduction timing controls

Prepared only. This independent screen compares frozen runtime map `aef67f5f76465be98c9587a27d44ff242db8e59a555fb622aa413e381fb14ca8` with canonical source `7f7b7633515540e6d75f527539dbaacf6c682e09`. It contains no activation instrumentation or other prototype runtime. Both read-only mounts use the canonical checkout; the candidate alone receives the ten sealed runtime overrides. The common benchmark file is identical in both arms and retains the timed R4 body byte-for-byte.

The unchanged randomized runner performs 20 matched seeds for each of three cohorts: primary Go full/edit/no-edit, ordinary Go R4 legacy/compact, and ordinary YAML R4 legacy/compact. Each seed uses one process per arm, 750 ms, count 1, benchmem and GOMAXPROCS 1, with equal seeded child order and alternating arm order. Total: 60 pairs, 120 processes. All same-grammar R4 tests include candidate attempts and fallback cost; the validator requires actual route 1/fallback 0 for the selected compact samples.

Parent-owned execution from the canonical host checkout:

```sh
python3 harness_out/docker/go-ci-blockers-20261025/sealed-reduction-perf-v1/worker.py
python3 harness_out/docker/go-ci-blockers-20261025/sealed-reduction-perf-v1/validate.py
```

`commands.json` holds the exact isolated Docker command; `run.sh` holds all three exact runner invocations. The worker waits for the existing shared measurement lock, refuses to replace an earlier attempt, and records every failure/timeout. It never creates another checkout or Go cache. Source/control hashes are checked before and after; `check-gates.py` requires the actual completed Core, ordinary-activation, C/report/D8/counter, cold-footprint/cache and public-race prerequisites. The validator rejects missing, duplicate, failed or incomplete samples and emits benchstat plus both paired ratios and ratios of medians. No seeds are discarded or rerun automatically.

Use the resulting screen to decide whether further fleet qualification is justified. This is not E-A/M1 qualification, a C speed comparison, RSS/large-file proof, ARM/platform proof, graduation, promotion or permission to merge main.
