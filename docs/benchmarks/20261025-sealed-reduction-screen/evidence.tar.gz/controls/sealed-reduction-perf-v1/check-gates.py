from pathlib import Path
import hashlib,json,re
root=Path(__file__).resolve().parents[1]
out=root/'out'
def check(folder, logs):
 p=out/folder
 assert json.loads((p/'finished.json').read_text())['exit_code']==0,folder
 for name in ('source-before.log','source-after.log','controls-before.log','controls-after.log'):
  assert (p/name).read_text()=='',(folder,name)
 for name,count in logs.items():
  text=(p/name).read_text()
  assert len(re.findall(r'^--- PASS:',text,re.M))==count,(folder,name)
  assert not re.search(r'--- (FAIL|SKIP):|WARNING: DATA RACE|^FAIL\b|panic:',text,re.M),(folder,name)
 return p
check('sealed-reduction-initial-qualification-v2',{'core-release.log':23,'core-workcount.log':23,'core-clone.log':1,'ordinary-go.log':1,'ordinary-yaml.log':1})
p=check('sealed-reduction-activation-v1',{'activation-go.log':1,'activation-yaml.log':1})
a=json.loads((p/'validated-summary.json').read_text())
assert a['actual_activation_proved'] and a['instrumentation_for_qualification_only']
for name in ('go','yaml'):
 assert a[name]['avoided']>0 and a[name]['before_plans']>a[name]['after_plans'] and a[name]['equal_gotos']>0 and a[name]['equal_core_reductions']>0
p=check('sealed-reduction-semantic-v1',{'core-reference.log':55,'core-race.log':23,'focused.log':36,'go-public-api.log':3,'go-cgo.log':10,'go-report-cgo.log':3,'yaml-cgo.log':8,**{f'invariants-{name}-{mode}.log':1 for name in ('go','yaml') for mode in (0,1)}})
for name in ('go','yaml'):
 for route in ('default','candidate'):
  f=f'{route}-{name}.json'
  assert json.loads((p/f).read_text())==json.loads((out/'packed-snapshot-budget-final/ledger'/f).read_text()),f
 for mode in (0,1):
  assert 'session_steps=72 no_edit_allocs=0' in (p/f'invariants-{name}-{mode}.log').read_text()
check('sealed-reduction-memory-race-v1',{'cold-go.log':1,'cold-yaml.log':1,'existing-cold.log':2,'public-race.log':3})
print(json.dumps({'schema':'gts-sealed-reduction-preperf/v1','selected_semantic_gates_passed':True,'ordinary_plan_provider_avoidance':{k:a[k]['avoided'] for k in ('go','yaml')},'actual_ledger_rows_equal':4,'D8_sessions':4,'D8_steps':288,'no_edit_allocations':0,'production_promoted':False,'fleet_qualified':False,'merges_held':True}))
