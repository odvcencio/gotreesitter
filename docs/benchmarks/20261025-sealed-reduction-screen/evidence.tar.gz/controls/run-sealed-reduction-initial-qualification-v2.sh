set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/sealed-reduction-initial-qualification-v2/controls.sha256 > /evidence/controls-after.log 2>&1; python3 /controls/sealed-reduction-cell-v1/authenticate.py > /evidence/frozen-inputs-after.json; }
trap finish EXIT
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/sealed-reduction-initial-qualification-v2/controls.sha256 > /evidence/controls-before.log 2>&1
python3 /controls/sealed-reduction-cell-v1/authenticate.py > /evidence/frozen-inputs-before.json
overlay=/controls/sealed-reduction-cell-v1/repair-v2/overlay.tests.json
go test -overlay="$overlay" -run '^Test(SealedReduction|DirectReduction|SingleVersion)' -count=1 -v -timeout=4m ./internal/parsercorephase0 > /evidence/core-release.log 2>&1
go test -overlay="$overlay" -tags gts_workcount -run '^Test(SealedReduction|DirectReduction|SingleVersion)' -count=1 -v -timeout=4m ./internal/parsercorephase0 > /evidence/core-workcount.log 2>&1
go test -overlay="$overlay" -tags gts_workcount,gts_eof_recovery_shadow -run '^TestSealedReductionDiagnosticCloneDropsProviderBinding$' -count=1 -v -timeout=3m ./internal/parsercorephase0 > /evidence/core-clone.log 2>&1
GTS_SEALED_REDUCTION_LANGUAGE=go go test -overlay="$overlay" -tags gts_workcount,gts_parsercorephase0 -run '^TestPrivateSealedReductionOrdinaryEntry$' -count=1 -v -timeout=4m . > /evidence/ordinary-go.log 2>&1
GTS_SEALED_REDUCTION_LANGUAGE=yaml go test -overlay="$overlay" -tags gts_workcount,gts_parsercorephase0 -run '^TestPrivateSealedReductionOrdinaryEntry$' -count=1 -v -timeout=4m . > /evidence/ordinary-yaml.log 2>&1
printf 'sealed reduction initial correctness/counter gates terminal; no timing or graduation claim\n' > /evidence/completed.txt
