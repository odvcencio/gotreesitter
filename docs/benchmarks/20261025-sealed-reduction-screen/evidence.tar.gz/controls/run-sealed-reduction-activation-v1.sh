set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/sealed-reduction-activation-v1/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/sealed-reduction-activation-v1/controls.sha256 > /evidence/controls-before.log 2>&1
for language in go yaml; do
 GTS_SEALED_REDUCTION_LANGUAGE=$language go test -overlay=/controls/sealed-reduction-cell-v1/activation-v1/overlay.tests.json -tags gts_parsercorephase0,gts_workcount -run '^TestPrivateSealedReductionProviderActivation$' -count=1 -v -timeout=4m . > "/evidence/activation-$language.log" 2>&1
done
printf 'actual provider call avoidance and full output/work/receipt equality tested; no performance claim\n' > /evidence/completed.txt
