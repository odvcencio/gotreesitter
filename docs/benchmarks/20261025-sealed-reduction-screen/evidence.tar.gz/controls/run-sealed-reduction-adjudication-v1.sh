set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/sealed-reduction-adjudication-v1/controls.sha256 > /evidence/controls-before.log 2>&1
set +e
go test -overlay=/controls/sealed-reduction-cell-v1/adjudication-v1/overlay.tests.json -run '^TestSealedReductionIdenticalWitnessAdjudication$' -count=1 -v -timeout=4m ./internal/parsercorephase0 > /evidence/adjudication.log 2>&1
result=$?
set -e
printf '%s\n' "$result" > /evidence/test-exit.txt
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1
sha256sum --quiet -c /controls/sealed-reduction-adjudication-v1/controls.sha256 > /evidence/controls-after.log 2>&1
