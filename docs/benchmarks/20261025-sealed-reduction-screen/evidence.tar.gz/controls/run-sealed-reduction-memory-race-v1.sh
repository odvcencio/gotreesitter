set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/sealed-reduction-memory-race-v1/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/sealed-reduction-memory-race-v1/controls.sha256 > /evidence/controls-before.log 2>&1
overlay=/controls/sealed-reduction-cell-v1/cold-footprint-v1/overlay.tests.json
for language in go yaml; do
 GTS_SEALED_REDUCTION_LANGUAGE=$language go test -overlay="$overlay" -tags=gts_parsercorephase0 -run '^TestPrivateSealedReductionColdTableFootprint$' -count=1 -v -timeout=4m . > /evidence/cold-$language.log 2>&1
done
go test -overlay="$overlay" -tags=gts_parsercorephase0 -run '^TestParserCoreLanguageTables(Footprint|CacheSharesAcrossParsers)$' -count=1 -v -timeout=4m . > /evidence/existing-cold.log 2>&1
go test -race -overlay="$overlay" -tags=gts_parsercorephase0 -run '^TestNativeNodeViews(ConcurrentReads|RecycledMetadataDetachesResult|TypeArgumentsPreserveEditAndCopy)$' -count=1 -v -timeout=4m . > /evidence/public-race.log 2>&1
