#!/usr/bin/env python3
"""Package the completed private screen. Preparation never executes workloads."""
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import json
import runpy
import subprocess
import tarfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--decision-file", type=Path, required=True, help="root-authored JSON containing a nonempty decision and its rationale")
    parser.add_argument("--destination", type=Path, default=Path("docs/benchmarks/20261025-sealed-reduction-screen"))
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    checkout = root.parents[2]
    destination = args.destination if args.destination.is_absolute() else checkout / args.destination
    decision = json.loads(args.decision_file.read_text())
    assert isinstance(decision, dict) and isinstance(decision.get("decision"), str) and decision["decision"].strip()
    assert isinstance(decision.get("rationale"), str) and decision["rationale"].strip()
    variants = [
        "sealed-reduction-initial-qualification-v1",
        "sealed-reduction-adjudication-v1",
        "sealed-reduction-initial-qualification-v2",
        "sealed-reduction-activation-v1",
        "sealed-reduction-semantic-v1",
        "sealed-reduction-memory-race-v1",
        "sealed-reduction-perf-v1",
    ]
    # Fail before writing to docs if timing is live or local validation absent.
    perf = root / "out/sealed-reduction-perf-v1"
    assert json.loads((perf / "finished.json").read_text())["exit_code"] == 0
    assert (perf / "completed.txt").is_file() and (perf / "validated-summary.json").is_file()
    template = root / "sealed-reduction-screen-package-v1/validate-evidence.py.txt"
    validator = runpy.run_path(str(template))
    files = {}

    def add(path, archive_name):
        assert path.is_file(), path
        assert archive_name not in files, archive_name
        files[archive_name] = path.read_bytes()

    def add_tree(path, archive_prefix, outputs=False):
        assert path.is_dir(), path
        for entry in sorted(path.rglob("*")):
            if not entry.is_file() or "__pycache__" in entry.parts or entry.suffix == ".pyc":
                continue
            if outputs and entry.suffix not in (".log", ".json", ".txt", ".stderr", ".sha256"):
                continue
            assert entry.suffix not in (".test", ".exe", ".prof", ".pb"), entry
            add(entry, archive_prefix + str(entry.relative_to(path)))

    add_tree(root / "sealed-reduction-cell-v1", "controls/sealed-reduction-cell-v1/")
    for variant in variants:
        add_tree(root / variant, "controls/" + variant + "/")
        # The independent perf campaign keeps these inside its own directory.
        if variant != "sealed-reduction-perf-v1":
            for prefix, suffix in (("run-", ".sh"), ("worker-", ".py"), ("commands-", ".json")):
                name = prefix + variant + suffix
                add(root / name, "controls/" + name)
        add_tree(root / "out" / variant, "outputs/" + variant + "/", outputs=True)
    add(root / "packed-snapshot-budget-final/source.sha256", "controls/packed-snapshot-budget-final/source.sha256")
    add(Path(__file__).resolve(), "controls/package-sealed-reduction-screen.py")
    add(template, "controls/sealed-reduction-screen-package-v1/validate-evidence.py.txt")
    for route in ("default", "candidate"):
        for language in ("go", "yaml"):
            name = f"{route}-{language}.json"
            add(root / "out/packed-snapshot-budget-final/ledger" / name, "baselines/" + name)

    # Independently recompute every numerical/selection claim before creating
    # the artifact. No Go, benchstat, Docker or source mutation occurs here.
    verification = validator["validate_payloads"](files)
    digest = validator["digest"]
    measured_manifest = json.loads(files["controls/sealed-reduction-perf-v1/manifest.json"])
    summary = {
        "schema": "gts-sealed-deterministic-reduction-screen/v1",
        "root_decision": decision,
        "performance": verification["performance"],
        "ordinary_activation": verification["activation"],
        "cold_tables": verification["cold_tables"],
        "actual_counter_rows_exact_equal": 4,
        "D8_sessions": 4,
        "D8_steps": 288,
        "no_edit_allocations": 0,
        "historical_failures_preserved": verification["historical_failed_families_preserved"],
        "historical_failure_explanation": [
            "The initial collision fixture contained only the shifted canonical boundary; both old and sealed entries correctly published a distinct unshifted reduction. The repaired fixture primes a genuine unshifted collision and keeps exact one-use GOTO handoff assertions.",
            "The initial mutation assertion compared pre-callback state with post-callback state, including BeginFrontier's deliberate boundary-map clear. Exact-witness adjudication proves both old and sealed entries reject stale classification without publishing beyond the captured callback state. The repaired test retains poisoning/reset checks.",
        ],
        "source_base_head": measured_manifest["baseline_head"],
        "runtime_promoted": False,
        "default_route_changed": False,
        "fleet_qualified": False,
        "E_A_qualified": False,
        "M1_qualified": False,
        "language_graduated": False,
        "ARM_or_other_platform_qualified": False,
        "RSS_or_large_file_performance_qualified": False,
        "merges_to_main_held": True,
    }
    identities = {
        "schema": "gts-sealed-deterministic-reduction-source/v1",
        "benchmark_base_head": measured_manifest["baseline_head"],
        "packaged_at_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=checkout, text=True).strip(),
        "frozen_original_source_base_head": json.loads(files["controls/sealed-reduction-cell-v1/manifest.json"])["base_head"],
        "measured_runtime_overlay_sha256": validator["RUNTIME_SHA"],
        "measured_overlay_with_common_benchmark_sha256": digest(files["controls/sealed-reduction-perf-v1/overlay.container.json"]),
        "canonical_source_manifest_sha256": digest(files["controls/sealed-reduction-perf-v1/source.sha256"]),
        "canonical_source_manifest_entries": len(files["controls/sealed-reduction-perf-v1/source.sha256"].splitlines()),
        "input_identities": measured_manifest["inputs"],
        "actual_toolchain": files["outputs/sealed-reduction-perf-v1/toolchain.txt"].decode(),
        "artifact_controls": {name: digest(data) for name, data in sorted(files.items()) if name.startswith("controls/")},
        "baseline_counter_files": {name: digest(data) for name, data in sorted(files.items()) if name.startswith("baselines/")},
        "binary_identity_receipt": "outputs/sealed-reduction-semantic-v1/binary.sha256 (hashes only; binaries excluded)",
        "scope": "Linux amd64 private screen; historical and current control versions retained. Canonical checkout and dependency/runtime caches are not copied.",
    }
    artifact_names = ["evidence.tar.gz", "contents.json.gz", "source-identities.json", "verification.json", "summary.json", "validate-evidence.py", "SHA256SUMS"]
    assert not any((destination / name).exists() for name in artifact_names), "refusing to overwrite a frozen receipt"
    destination.mkdir(parents=True, exist_ok=True)
    (destination / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    (destination / "verification.json").write_text(json.dumps(verification, indent=2) + "\n")
    (destination / "source-identities.json").write_text(json.dumps(identities, indent=2) + "\n")
    (destination / "validate-evidence.py").write_bytes(template.read_bytes())
    index = []
    with (destination / "evidence.tar.gz").open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w") as archive:
                for name, data in sorted(files.items()):
                    info = tarfile.TarInfo(name)
                    info.size, info.mode, info.mtime = len(data), 0o644, 0
                    archive.addfile(info, io.BytesIO(data))
                    index.append({"path": name, "bytes": len(data), "sha256": digest(data)})
    with (destination / "contents.json.gz").open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
            compressed.write((json.dumps(index, indent=2) + "\n").encode())
    checksums = []
    for name in artifact_names[:-1]:
        checksums.append(f"{digest((destination / name).read_bytes())}  {name}\n")
    (destination / "SHA256SUMS").write_text("".join(checksums))
    print(json.dumps({"destination": str(destination), "members": len(files), "evidence_sha256": digest((destination / "evidence.tar.gz").read_bytes()), "contents_sha256": digest((destination / "contents.json.gz").read_bytes()), "root_decision": decision, "next": "Root writes README, then runs python3 <destination>/validate-evidence.py. README is not part of the frozen artifact checksum list."}, indent=2))


if __name__ == "__main__":
    main()
