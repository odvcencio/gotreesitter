# Test-only repair V2

Prepared only; no compilation or execution. The initial V1 failures and the successful identical-witness adjudication remain frozen. This map changes ONLY the execution test backing and retains the adjudication test plus all original runtime backings.

The collision fixture now follows canonical TestDirectReductionFallbackReusesGoto: both arms first publish a real unshifted reduction, prove shifted/unshifted keys are distinct, and then revisit the original shifted head. Setup counters are never reset. The actual compared operation must spend one additional GOTO, use its exact classified-boundary memo once, perform one generic plan callback, and preserve final graph/output/work equality. The existing no-publication handoff assertions remain.

The frontier callback intentionally changes the canonical index. The test captures its complete post-callback state and requires the rejected operation to add no further effects; stale/authority errors, empty memo, poison/reset and callback-count assertions remain. Provider mutation still must leave the graph unchanged even inside its own callback.

Use overlay.tests.json with the same release/instrumented/clone/one-grammar ordinary-entry commands as V1 commands.json. Core selector is ^Test(SealedReduction|DirectReduction|SingleVersion); ordinary entry needs gts_parsercorephase0,gts_workcount and one GTS_SEALED_REDUCTION_LANGUAGE=go or yaml per process. Parent owns execution and all subsequent C/D8/counter/memory/race/performance gates. Runtime map is unchanged; no performance or graduation claim follows.
