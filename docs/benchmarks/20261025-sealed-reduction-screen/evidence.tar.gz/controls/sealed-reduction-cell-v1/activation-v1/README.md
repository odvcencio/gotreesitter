# Sealed provider activation qualification

Prepared only; not built or executed. This separate workcount qualification counts actual root `ReductionPlan` and `Goto` entry calls on the pinned ordinary Go and YAML R4 fixtures. Both public candidate parses must return route 1/fallback 0 and clean complete trees. The bound arm must avoid a positive number of plan-provider calls while full output, cold receipts, all deterministic work/board counters, positive Core reductions and positive GOTO-provider counts stay equal.

`parsercore_phase0_driver_instrumented.go.txt` differs from the frozen measured driver by exactly the two atomic additions in `instrumentation-only.patch`. The measured runtime map remains `aef67f5f76465be98c9587a27d44ff242db8e59a555fb622aa413e381fb14ca8`. This map must never be used for timing. The inherited repaired tests and measured runtime backings stay unchanged.

With the canonical candidate bound at `/candidate` and the parent ignored evidence directory at `/controls`, execute one grammar per process from `/candidate`:

```sh
GTS_SEALED_REDUCTION_LANGUAGE=go go test -overlay=/controls/sealed-reduction-cell-v1/activation-v1/overlay.tests.json -tags=gts_parsercorephase0,gts_workcount -run '^TestPrivateSealedReductionProviderActivation$' -count=1 -v .
GTS_SEALED_REDUCTION_LANGUAGE=yaml go test -overlay=/controls/sealed-reduction-cell-v1/activation-v1/overlay.tests.json -tags=gts_parsercorephase0,gts_workcount -run '^TestPrivateSealedReductionProviderActivation$' -count=1 -v .
```

The `SEALED_PROVIDER_ACTIVATION` and `SEALED_PROVIDER_AVOIDED` records distinguish binding eligibility from actual execution. Atomics are read by monotone deltas, not reset. No runtime, diagnostic-work or scheduler counters are reset. The language runner pool is drained before each binding arm, matching the existing ordinary-entry test.
