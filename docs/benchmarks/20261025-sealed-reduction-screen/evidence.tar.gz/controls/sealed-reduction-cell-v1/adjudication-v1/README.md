# Identical-witness adjudication, prepared only

Frozen V1 runtime/tests and the initial failed execution remain unchanged. This new test uses those exact finite fixtures on the unbound ordinary entry and bound prepared entry, requiring graph/work/result/callback/error parity. It records shifted-versus-unshifted boundary facts and snapshots the deliberate BeginFrontier effect before checking any further operation publication. Original assertions are not changed or skipped inside their frozen files.

```
go test -overlay=/controls/sealed-reduction-cell-v1/adjudication-v1/overlay.tests.json ./internal/parsercorephase0 -run '^TestSealedReductionIdenticalWitnessAdjudication$' -count=1 -v -timeout=3m
```

No author compilation or execution. Parent owns the isolated trial. This is diagnostic proof, not repaired qualification or timing.
