import hashlib,json,pathlib
r=pathlib.Path('/controls/sealed-reduction-cell-v1')
m=json.loads((r/'manifest.json').read_text())
for f in m['files']:
 p=pathlib.Path('/candidate')/f['target']
 before=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
 assert before==f['base_sha256'],f['target']
 assert hashlib.sha256((r/f['backing']).read_bytes()).hexdigest()==f['candidate_sha256'],f['backing']
print(json.dumps({'authenticated':len(m['files']),'base_head':m['base_head'],'prepared_only':True}))
