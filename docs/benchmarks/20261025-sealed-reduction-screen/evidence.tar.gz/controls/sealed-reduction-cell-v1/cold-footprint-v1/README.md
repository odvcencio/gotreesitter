# Cold language-table storage receipt

Prepared only; no builds or execution. This map adds one qualification test and inherits every repaired runtime/test backing unchanged. The measured runtime map remains `aef67f5f76465be98c9587a27d44ff242db8e59a555fb622aa413e381fb14ca8`.

Run one grammar per process from `/candidate`, with the parent evidence directory mounted at `/controls`:

```sh
GTS_SEALED_REDUCTION_LANGUAGE=go go test -overlay=/controls/sealed-reduction-cell-v1/cold-footprint-v1/overlay.tests.json -tags=gts_parsercorephase0 -run '^TestPrivateSealedReductionColdTableFootprint$' -count=1 -v -timeout=4m .
GTS_SEALED_REDUCTION_LANGUAGE=yaml go test -overlay=/controls/sealed-reduction-cell-v1/cold-footprint-v1/overlay.tests.json -tags=gts_parsercorephase0 -run '^TestPrivateSealedReductionColdTableFootprint$' -count=1 -v -timeout=4m .
go test -overlay=/controls/sealed-reduction-cell-v1/cold-footprint-v1/overlay.tests.json -tags=gts_parsercorephase0 -run '^TestParserCoreLanguageTables(Footprint|CacheSharesAcrossParsers)$' -count=1 -v -timeout=4m .
```

The first two commands report actual total, nonempty and sealed row counts, plus exact unique incremental bytes through `privateDeterministicReductionTableBytes`. Empty rows have no allocated row header. Every populated row adds a pointer slot; each exact singleton reduction adds one authority record; the language table owns one set pointer and set record. The pre-existing immutable plan field/alias buffers remain shared, so this increment excludes charging them again per row. The Core binding has separate accounting and is not included in this Language-owned increment.

The same test independently measures the complete fresh table allocation using the existing `GC/ReadMemStats` heap-census method and the 4 MiB guard. This heap delta includes the pre-existing row/action/plan/index storage as well as new records; it is neither the logical incremental census nor an exact allocator-size prediction. Existing canonical footprint/cache tests remain unchanged and Go-only; the cache-sharing assertion verifies the existing per-Language cache, while this new test builds tables directly without adding another cache.
