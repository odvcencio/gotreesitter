set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/ci-cobol-full-current-v2
mkdir -p "$scratch"
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -overlay=/controls/ci-followup/cobol/full-flags-test/overlay.current-v2.json -o "$scratch/cgo.test" . > /evidence/build.log 2>&1
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE=$route "$scratch/cgo.test" -test.run '^TestCobolCGOErrorOracleParity$' -test.count=1 -test.v > "/evidence/cobol-$route.log" 2>&1
done
sha256sum "$scratch/cgo.test" > /evidence/binary.sha256
printf 'all five COBOL fixtures match C on all axes and deep digests on both routes\n' > /evidence/completed.txt
