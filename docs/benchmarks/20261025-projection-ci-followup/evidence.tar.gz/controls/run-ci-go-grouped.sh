set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate/cgo_harness
go test -tags treesitter_c_parity -overlay=/controls/ci-followup/go/overlay.json -run '^TestPrivateGoGroupedBindingsLockedC$' -count=1 -timeout=2m -v . > /evidence/go.log 2>&1
printf 'Go grouped original and explicit separator C comparisons passed\n' > /evidence/completed.txt
