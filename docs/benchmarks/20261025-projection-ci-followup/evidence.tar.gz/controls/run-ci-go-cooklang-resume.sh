set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/ci-combined-candidate
sha256sum "$scratch/root.test" "$scratch/cgo.test" > /evidence/binary.sha256
cd /candidate/cgo_harness
"$scratch/cgo.test" -test.run '^TestCooklangNextLiveArmLockedCRoutes$' -test.count=1 -test.v > /evidence/cooklang.log 2>&1
"$scratch/cgo.test" -test.run '^Test(GoGroupedBindingsProjectedMissingLockedC|GoGroupedBindingSeparatorsLockedC|GoIssue490FragmentBoundaryLockedC|GoHiddenMissingSemicolonEditsMatchLockedC|GoNextLiveArmProbe|IncludedRangesGoRootParity)$' -test.count=1 -test.v > /evidence/go.log 2>&1
printf 'scoped Go and unchanged-known-gap Cooklang snapshot checks passed; COBOL candidate still rejected\n' > /evidence/completed.txt
