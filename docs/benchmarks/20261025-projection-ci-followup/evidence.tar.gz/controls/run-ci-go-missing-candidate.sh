set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/ci-go-missing-candidate
mkdir -p "$scratch"
cd /candidate
overlay=/controls/ci-followup/go/overlay.qualified-candidate.json
go test -c -tags gts_parsercorephase0 -overlay="$overlay" -o "$scratch/root.test" . > /evidence/root-build.log 2>&1
"$scratch/root.test" -test.run '^Test(HiddenMissing.*|GoMissingSemicolonProjectionRetainsElidedHistory|MissingTurnRangeExclusion.*|ReservedRuntimePrefilter.*|Issue490GoGrammarRegression|FactDeclarationsGo.*|GoCompat.*|WalkGoCompat.*|NormalizeGoCompatibilityWithParserPropagatesMemoryBudgetStop)$' -test.count=1 -test.v > /evidence/root.log 2>&1
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE=$route GOTREESITTER_V1_INVARIANT_LANGUAGE=go "$scratch/root.test" -test.run '^TestV1InvariantGateR4EditSession$' -test.v -test.count=1 > "/evidence/go-invariant-$route.log" 2>&1
done
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -overlay="$overlay" -o "$scratch/cgo.test" . > /evidence/cgo-build.log 2>&1
"$scratch/cgo.test" -test.run '^Test(GoGroupedBindingsProjectedMissingLockedC|GoGroupedBindingSeparatorsLockedC|GoIssue490FragmentBoundaryLockedC|GoHiddenMissingSemicolonEditsMatchLockedC|GoAssignmentTargetEdits16SitesLockedC|GoCognociente137KiBTopEditLockedC|GoMalformedDeclarationPrefixLockedC|GoNextLiveArmProbe|IncludedRangesGoRootParity)$' -test.count=1 -test.v > /evidence/go-cgo.log 2>&1
sha256sum "$scratch/root.test" "$scratch/cgo.test" > /evidence/binary.sha256
printf 'Go grouped missing proof and clean facts fixture qualified; original C assertions retained\n' > /evidence/completed.txt
