set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate/cgo_harness
GTS_ADMISSION_CANDIDATE=0 go test -tags treesitter_c_parity,gts_parsercorephase0 -overlay=/controls/ci-followup/cobol/overlay.run-eff.json -run '^TestCobolCGOErrorOracleParity$' -count=1 -timeout=2m -v . > /evidence/cobol.log 2>&1
printf 'COBOL strict C suite passed\n' > /evidence/completed.txt
