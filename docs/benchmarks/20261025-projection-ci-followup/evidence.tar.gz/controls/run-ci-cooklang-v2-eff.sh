set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate/cgo_harness
go test -tags treesitter_c_parity,gts_parsercorephase0 -overlay=/controls/ci-followup/cooklang/overlay.v2-eff.json -run '^TestCooklangCurrentCAdjudicationPrivate$' -count=1 -timeout=2m -v . > /evidence/cooklang.log 2>&1
