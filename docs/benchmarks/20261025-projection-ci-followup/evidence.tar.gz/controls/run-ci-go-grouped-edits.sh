set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate/cgo_harness
go test -tags treesitter_c_parity,gts_parsercorephase0 -overlay=/controls/ci-followup/go/overlay.grouped-edits.json -run '^TestGoGrouped(BindingSeparatorsLockedC|ConstSeparatorEditsMatchLockedC)$' -count=1 -timeout=2m -v . > /evidence/go.log 2>&1
printf 'Go grouped separator original/clean and both API edit-cycle C qualification passed\n' > /evidence/completed.txt
