#!/usr/bin/env python3
"""Prepare the constrained private candidate; never build or run Go."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

CONTROL = Path(__file__).resolve().parent
COBOL = CONTROL.parent
EVIDENCE = COBOL.parent.parent
ROOT = EVIDENCE.parents[2]
original = (ROOT / "parser_result_cobol.go").read_text()
guard = "func normalizeCobolIfHeaderExecCICSClassError(header *Node, source []byte, lang *Language) bool {\n\tif header == nil || header.hasError() || int(header.endByte) > len(source) {\n\t\treturn false\n\t}\n"
assert original.count(guard) == 1
replacement = guard.replace("header == nil || header.hasError() ||", "header == nil ||")
replacement += "\tif header.hasError() && !cobolRetainedMissingExecCICSClassHeader(header, source, lang) {\n\t\treturn false\n\t}\n"
candidate = original.replace(guard, replacement, 1)
tail = "\t\tif child.IsError() || child.HasError() {\n\t\t\tout = cobolAppendCommentEntryMarkers"
assert candidate.count(tail) == 1
candidate = candidate.replace(tail,
    "\t\tif child.IsError() || (child.HasError() && !cobolRetainedMissingExecCICSClassHeader(child, source, lang)) {\n\t\t\tout = cobolAppendCommentEntryMarkers", 1)
candidate += "\n" + (CONTROL / "retained_exec_cics_helpers.go.txt").read_text()
(CONTROL / "parser_result_cobol.go.source").write_text(candidate)
runtime = {"/candidate/parser_result_cobol.go": "/controls/ci-followup/cobol/candidate/parser_result_cobol.go.source"}
tests = {"/candidate/cobol_retained_missing_class_private_test.go": "/controls/ci-followup/cobol/candidate/cobol_retained_missing_class_test.go.txt"}
for name, mapping in (("runtime", runtime), ("tests", runtime | tests)):
    (CONTROL / f"overlay.{name}.json").write_text(json.dumps({"Replace": mapping}, indent=2) + "\n")
    host = {key.replace("/candidate/", str(ROOT) + "/", 1): str(EVIDENCE) + val.removeprefix("/controls") for key, val in mapping.items()}
    (CONTROL / f"overlay.{name}.host.json").write_text(json.dumps({"Replace": host}, indent=2) + "\n")
record = {
    "private_candidate_only": True, "production_files_changed": False, "builds_tests_Docker_run": False,
    "preserves_shared_MISSING_creation_fix": True, "retained_HasError_never_cleared_to_force_repair": True,
    "two_changed_guards": ["class header repair", "tail comment-entry collapse"],
    "certification": ["existing EXEC-CICS bounds", "exact qualified-word/CICS class prefix", "three-child expr with zero-width AND",
                      "genuine hidden MISSING retained by AND raw history", "no public ERROR/MISSING anywhere in header"],
    "idempotence": "Repaired header contains real public ERROR and no longer has the uncertified three-child conjunction shape; subsequent class repair declines.",
    "existing_strict_C_tests_unchanged": True,
    "source_sha256": hashlib.sha256(original.encode()).hexdigest(),
    "files": {p.name: {"bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
              for p in CONTROL.iterdir() if p.is_file() and p.name != "manifest.json"}}
(CONTROL / "manifest.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"runtime_candidate_written": True, "builds_tests_Docker_run": False}))
