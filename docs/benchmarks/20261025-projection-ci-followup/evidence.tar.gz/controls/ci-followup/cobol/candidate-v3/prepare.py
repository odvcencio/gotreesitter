#!/usr/bin/env python3
"""Prepare the single proven ERROR.Extra repair; never build or run Go."""
from pathlib import Path
import hashlib
import json
import re

CONTROL = Path(__file__).resolve().parent
COBOL = CONTROL.parent
EVIDENCE = COBOL.parent.parent
ROOT = EVIDENCE.parents[2]
V2 = COBOL / "candidate-v2"
source = (V2 / "parser_result_cobol.go.source").read_text()
match = re.search(r"^func normalizeCobolIfHeaderExecCICSClassError\(.*?^}\n", source, re.M | re.S)
assert match is not None
body = match.group()
anchor = "\terr.setHasError(true)\n"
assert body.count(anchor) == 1
changed = body.replace(anchor, anchor + "\terr.setExtra(true)\n", 1)
candidate = source[:match.start()] + changed + source[match.end():]
# Restore only this function's exact new line, preserving all other source.
assert changed.replace("\terr.setExtra(true)\n", "", 1) == body
assert len(candidate) == len(source) + len("\terr.setExtra(true)\n")
(CONTROL / "parser_result_cobol.go.source").write_text(candidate)

unit = (V2 / "cobol_retained_missing_class_test.go.txt").read_text()
anchor = 'resultChildCount(class) != 3 || !resultChildAt(class, 1).IsError() {'
assert unit.count(anchor) == 1
unit = unit.replace(anchor, 'resultChildCount(class) != 3 || !resultChildAt(class, 1).IsError() || !resultChildAt(class, 1).IsExtra() {', 1)
unit = unit.replace('t.Fatal("class repair did not retain the public EXEC error")',
                    't.Fatal("class repair did not retain the C-matching extra EXEC error")', 1)
(CONTROL / "cobol_retained_missing_class_test.go.txt").write_text(unit)

runtime = {"/candidate/parser_result_cobol.go": "/controls/ci-followup/cobol/candidate-v3/parser_result_cobol.go.source"}
tests = {"/candidate/cobol_retained_missing_class_private_test.go": "/controls/ci-followup/cobol/candidate-v3/cobol_retained_missing_class_test.go.txt"}
strong = json.loads((COBOL / "full-flags-test/overlay.test-only.json").read_text())["Replace"]
for name, mapping in (("runtime", runtime), ("tests", runtime | tests), ("full-flags", runtime | strong)):
    (CONTROL / f"overlay.{name}.json").write_text(json.dumps({"Replace": mapping}, indent=2) + "\n")
    (CONTROL / f"overlay.{name}.host.json").write_text(json.dumps({"Replace": {
        key.replace("/candidate/", str(ROOT)+"/", 1): str(EVIDENCE)+value.removeprefix("/controls")
        for key,value in mapping.items()}}, indent=2) + "\n")
record = {
    "v2_frozen_source_sha256": hashlib.sha256(source.encode()).hexdigest(),
    "v2_delta": "Exactly err.setExtra(true) on the class repair's hand-built EXEC ERROR; positive unit additionally requires IsExtra.",
    "v2_logic_and_other_error_flags_unchanged": True,
    "original_strict_C_tests_and_stronger_full_flag_assertions_unchanged": True,
    "proven_preexisting_gap": "Old eff and v2 both differ from C only at EXEC ERROR.Extra=false instead of true on the three class-repair witnesses.",
    "required_execution": "Both route processes for all five strong-C cases, all existing COBOL gates, units, invariants and race before promotion.",
    "runtime_and_permanent_tests_modified": False, "builds_tests_Docker_run": False,
    "files": {p.name: {"bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}
              for p in CONTROL.iterdir() if p.is_file() and p.name != "manifest.json"}}
(CONTROL / "manifest.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"tiny_private_v3_prepared":True,"source_sha256":hashlib.sha256(candidate.encode()).hexdigest(),"builds_tests_Docker_run":False}))
