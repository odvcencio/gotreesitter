#!/usr/bin/env python3
"""Prepare the stronger existing five-case C oracle; never build/run Go."""
from pathlib import Path
import hashlib
import json
import re

CONTROL = Path(__file__).resolve().parent
COBOL = CONTROL.parent
EVIDENCE = COBOL.parent.parent
ROOT = EVIDENCE.parents[2]
PATH = "cgo_harness/cobol_cgo_regression_test.go"
original = (ROOT / PATH).read_text()
match = re.search(r"^func TestCobolCGOErrorOracleParity\(.*?^}\n", original, re.M | re.S)
assert match is not None
body = match.group()
anchor = "\t\t})\n\t}\n}\n"
assert body.count(anchor) == 1
extra = '\t\t\tassertLockedCTreeExactWithErrors(t, "COBOL full-axis "+tc.name, goTree, goLang, cTree)\n'
extra += '\t\t\tt.Logf("COBOL full-axis fixture=%s input_bytes=%d HasError=%t runtime=%+v", tc.name, len(src), goRoot.HasError(), goTree.ParseRuntime())\n'
changed = body.replace(anchor, extra + anchor, 1)
source = original[:match.start()] + changed + original[match.end():]
(CONTROL / "cobol_cgo_regression_test.go.source").write_text(source)
test_map = {"/candidate/" + PATH: "/controls/ci-followup/cobol/full-flags-test/cobol_cgo_regression_test.go.source"}
v2 = json.loads((COBOL / "candidate-v2/overlay.runtime.json").read_text())["Replace"]
eff = json.loads((COBOL / "overlay.eff.json").read_text())["Replace"]
for variant, mapping in (("test-only", test_map), ("current-v2", v2 | test_map), ("eff", eff | test_map)):
    (CONTROL / f"overlay.{variant}.json").write_text(json.dumps({"Replace": mapping}, indent=2) + "\n")
    host = {key.replace("/candidate/", str(ROOT)+"/", 1): str(EVIDENCE)+value.removeprefix("/controls") if value else ""
            for key, value in mapping.items()}
    (CONTROL / f"overlay.{variant}.host.json").write_text(json.dumps({"Replace": host}, indent=2) + "\n")
assert source.replace(extra, "", 1) == original
record = {
    "original_test_path": PATH,
    "test_selector": "^TestCobolCGOErrorOracleParity$",
    "build_tags": "treesitter_c_parity,gts_parsercorephase0",
    "one_grammar_per_process": True,
    "route_processes": [{"GTS_ADMISSION_CANDIDATE":"0"}, {"GTS_ADMISSION_CANDIDATE":"1"}],
    "all_five_original_cases_and_original_expectations_preserved": True,
    "only_additions": ["existing all-axis flag/digest assertion after original comparator", "post-comparison runtime log"],
    "original_source_restored_by_removing_exact_inserted_text": True,
    "compares_HasError_on_every_node_and_MISSING_ERROR_extra_fields_spans_points": True,
    "independent_C_deep_digest": True,
    "strict_failures_are_not_waived": True,
    "v2_and_old_eff_runtime_maps_are_separate": True,
    "eff_embed_binding": "../eff-runtime-bindings.json",
    "frozen_v1_and_v2_runtime_sources_modified": False,
    "production_source_tests_or_receipts_modified": False,
    "builds_tests_Docker_run": False,
    "original_sha256": hashlib.sha256(original.encode()).hexdigest(),
    "stronger_test_sha256": hashlib.sha256(source.encode()).hexdigest()}
(CONTROL / "manifest.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"five_cases":True, "current_v2_and_eff_maps":True, "test_sha256":record["stronger_test_sha256"], "builds_tests_Docker_run":False}))
