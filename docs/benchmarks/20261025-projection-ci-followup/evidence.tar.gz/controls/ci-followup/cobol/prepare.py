#!/usr/bin/env python3
"""Prepare private one-grammar controls only; do not build or execute Go."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import subprocess

CONTROL = Path(__file__).resolve().parent
EVIDENCE = CONTROL.parent.parent
ROOT = EVIDENCE.parents[2]
BASE = "eff701aa3962f88fbf6e8cd3b5994d7dca1d0a32"
HEAD = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def dump(name: str, value: object) -> None:
    (CONTROL / name).write_text(json.dumps(value, indent=2) + "\n")


def write(name: str, data: bytes) -> None:
    path = CONTROL / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


changes = subprocess.check_output(["git", "diff", "--name-status", "--no-renames", BASE, HEAD, "--", "*.go", "*.bin"], cwd=ROOT, text=True)
old_map = {}
changed_sources = {}
for line in changes.splitlines():
    status, path = line.split("\t")
    if status == "A":
        old_map["/candidate/" + path] = ""
        changed_sources[path] = {"old_absent": True, "current_sha256": sha((ROOT / path).read_bytes())}
        continue
    assert status in ("M", "D"), status
    data = subprocess.check_output(["git", "show", BASE + ":" + path], cwd=ROOT)
    relative = "eff-files/" + path + ".source"
    write(relative, data)
    old_map["/candidate/" + path] = "/controls/ci-followup/cobol/" + relative
    changed_sources[path] = {"old_bytes": len(data), "old_sha256": sha(data),
                             "current_sha256": sha((ROOT / path).read_bytes()) if (ROOT / path).is_file() else None}

parser = (ROOT / "parser.go").read_text()
reduce = (ROOT / "parser_reduce.go").read_text()
for name, text in (("parser.go", parser), ("parser_reduce.go", reduce)):
    anchor = "\t\tleaf.setHasError(true)\n\t\tp.retainExternalFallbackMissingFlags = true\n" if name == "parser.go" else "\t\t\tleaf.setHasError(true)\n\t\t\tp.retainExternalFallbackMissingFlags = true\n"
    assert text.count(anchor) == 1
    replacement = anchor.replace("\t\tp.retainExternalFallbackMissingFlags = true\n" if name == "parser.go" else "\t\t\tp.retainExternalFallbackMissingFlags = true\n", "")
    write("no-creation/" + name + ".source", text.replace(anchor, replacement, 1).encode())

cobol = (ROOT / "parser_result_cobol.go").read_text()
guard = "func normalizeCobolIfHeaderExecCICSClassError(header *Node, source []byte, lang *Language) bool {\n\tif header == nil || header.hasError() || int(header.endByte) > len(source) {"
assert cobol.count(guard) == 1
diagnostic = cobol.replace(guard, guard.replace("header == nil || header.hasError() ||", "header == nil ||"), 1)
write("guard-off/parser_result_cobol.go.source", diagnostic.encode())

maps = {
    "current": {},
    "eff": old_map,
    "no-creation": {"/candidate/" + name: "/controls/ci-followup/cobol/no-creation/" + name + ".source" for name in ("parser.go", "parser_reduce.go")},
    "guard-off": {"/candidate/parser_result_cobol.go": "/controls/ci-followup/cobol/guard-off/parser_result_cobol.go.source"},
}
for variant, mapping in maps.items():
    dump("overlay." + variant + ".json", {"Replace": mapping})
    dump("overlay." + variant + ".host.json", {"Replace": {
        key.replace("/candidate/", str(ROOT) + "/", 1): (str(EVIDENCE) + value.removeprefix("/controls") if value else "")
        for key, value in mapping.items()}})

stable = {}
for path in ("cgo_harness/cobol_cgo_regression_test.go", "parser_result_cobol.go", "grammars/grammar_blobs/cobol.bin", "cgo_harness/go.mod", "cgo_harness/parity_c_loader_cgo.go"):
    old = subprocess.check_output(["git", "show", BASE + ":" + path], cwd=ROOT)
    now = (ROOT / path).read_bytes()
    stable[path] = {"bytes": len(now), "sha256": sha(now), "unchanged_since_eff": old == now}
assert all(row["unchanged_since_eff"] for row in stable.values())

selector = "^TestCobolCGOErrorOracleParity$"
dump("run-plan.json", {
    "root_owns_container_and_workload_lock": True,
    "cwd": "/candidate/cgo_harness", "GOMAXPROCS": "1", "GTS_ADMISSION_CANDIDATE": "0",
    "build_tags": "treesitter_c_parity,gts_parsercorephase0",
    "selector": selector,
    "build_argv_template": ["go", "test", "-c", "-tags", "treesitter_c_parity,gts_parsercorephase0",
                            "-overlay=/controls/ci-followup/cobol/overlay.<variant>.json", "-o", "/runtime/tmp/cobol-<variant>.test", "."],
    "execute_argv_template": ["/runtime/tmp/cobol-<variant>.test", "-test.run", selector, "-test.count=1", "-test.v", "-test.timeout=2m"],
    "variants_in_priority_order": ["current", "eff", "no-creation", "guard-off"],
    "skips_are_not_qualification": True,
    "guard_off_diagnostic_is_not_a_fix": "header.hasError was also an idempotence guard; removing it may repeatedly rebuild nodes. Require structural canonical-shape certification and convergence tests before any proposal.",
    "optional_same_grammar_root_selector_after_a_proposal": "^TestCobol(ProcedureRootRecoveryConvergesOnFirstApplication|CGOWitnessRootHasErrorBaseBehavior)$"})

blob_path = "grammars/grammar_blobs/go.bin"
old_blob = CONTROL / "eff-files" / (blob_path + ".source")
dump("eff-runtime-bindings.json", {"required_for_exact_eff_embed_identity": True,
    "bindings": [{"source": "/controls/ci-followup/cobol/eff-files/" + blob_path + ".source",
                  "target": "/candidate/" + blob_path, "read_only": True, "sha256": sha(old_blob.read_bytes())}],
    "note": "COBOL blob is unchanged, but Go embed ignores file overlays for embedded bytes; bind the old Go blob only for eff's build/runtime if exact revision identity is claimed."})
dump("manifest.json", {
    "base": BASE, "current": HEAD, "changed_go_bin_paths": len(changed_sources),
    "modified_or_old_files_only_not_checkout_copy": True,
    "old_source_overlays": changed_sources, "stable_COBOL_inputs": stable,
    "strict_original_test_unchanged": True, "production_files_modified": False,
    "baseline_pass_or_fail_unestablished_without_parent_run": True,
    "likely_causal_path": ["generic real-MISSING latch", "pushStackNode retained raw child HasError", "if_header.HasError true before COBOL compatibility", "normalizeCobolIfHeaderExecCICSClassError:1164 clean-header guard skips", "expr remains3children instead of rebuilt expr1is_class"],
    "builds_tests_Docker_run": False,
    "files": {str(path.relative_to(CONTROL)): {"bytes": path.stat().st_size, "sha256": sha(path.read_bytes())}
              for path in sorted(CONTROL.rglob("*")) if path.is_file() and path.name != "manifest.json"}})
print(json.dumps({"base": BASE, "current": HEAD, "overlay_variants": list(maps), "changed_go_bin_paths": len(changed_sources), "COBOL_test_grammar_compat_identical_to_base": True, "builds_tests_Docker_run": False}))
