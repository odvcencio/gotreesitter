#!/usr/bin/env python3
"""Prepare clause-level tracing of the frozen predicate; no Go execution."""
from pathlib import Path
import hashlib
import json
import re

CONTROL = Path(__file__).resolve().parent
COBOL = CONTROL.parent
EVIDENCE = COBOL.parent.parent
ROOT = EVIDENCE.parents[2]
source = (COBOL / "candidate/parser_result_cobol.go.source").read_text()
start = source.index("func cobolRetainedMissingExecCICSClassHeader(")
end = source.index("\n}\n", start) + 3
helper = source[start:end]
labels = ["header-kind-or-state", "EXEC-CICS-bounds", "outer-expr-arity",
          "prefix-conjunction-suffix", "class-prefix-arity", "condition-word-source",
          "public-ERROR-or-MISSING", "AND-raw-history-unavailable"]
assert helper.count("\t\treturn false\n") == len(labels)
remaining_labels = iter(labels)
helper = re.sub(r"\t\treturn false\n", lambda match:
    '\t\tcobolCITraceTree("predicate-reject.' + next(remaining_labels) + '", header, source, lang)\n\t\treturn false\n', helper)
last = "\treturn retainedHiddenMissingFlags(conjunction, lang, conjunction.ownerArena)\n"
assert helper.count(last) == 1
helper = helper.replace(last,
    "\tproof := retainedHiddenMissingFlags(conjunction, lang, conjunction.ownerArena)\n"
    "\tif proof {\n\t\tcobolCITraceTree(\"predicate-accept.hidden-MISSING\", header, source, lang)\n"
    "\t} else {\n\t\tcobolCITraceTree(\"predicate-reject.hidden-MISSING-visibility-or-absence\", header, source, lang)\n\t}\n"
    "\treturn proof\n", 1)
source = source[:start] + helper + source[end:]
for function, node, phase in (
    ("normalizeCobolIfHeaderExecCICSClassError", "header", "class"),
    ("normalizeCobolRecoveredTailErrorChildren", "tail", "tail-collapse"),
):
    signature = re.search(r"func " + function + r"\([^\n]*\) (?:bool )?\{\n", source).group()
    assert source.count(signature) == 1
    source = source.replace(signature, signature +
        '\tcobolCITraceTree("' + phase + '-entry", ' + node + ', source, lang)\n' +
        '\tdefer cobolCITraceTree("' + phase + '-exit", ' + node + ', source, lang)\n', 1)
(CONTROL / "parser_result_cobol.go.source").write_text(source)
logger = (COBOL / "trace/parser_cobol_ci_trace_private.go.txt").read_text()
logger = logger.replace('"os"\n', '"os"\n\tsharedrecover "github.com/odvcencio/gotreesitter/internal/recover"\n', 1)
logger = logger.replace('"comment_entry", "ERROR":', '"comment_entry", "ERROR", "AND":', 1)
logger = logger.replace("\t\tdefault:\n\t\t\tcontinue\n", "\t\tdefault:\n\t\t\tif !n.hasError() && !n.isMissing() {\n\t\t\t\tcontinue\n\t\t\t}\n", 1)
anchor = '\t\tcobolCITraceLog(map[string]any{\n\t\t\t"stage": stage'
assert logger.count(anchor) == 1
logger = logger.replace(anchor,
    '\t\tvar firstRawMissing map[string]any\n'
    '\t\tif name == "AND" {\n'
    '\t\t\tsharedrecover.ContainsMissing(rawStackWalkEntry{entry: newStackEntryNode(n.parseState, n)}, func(item rawStackWalkEntry) (bool, int) {\n'
    '\t\t\t\tsymbol, count, _ := rawStackWalkEntryHeader(n.ownerArena, item)\n'
    '\t\t\t\tif stackEntryNodeIsMissing(item.entry) {\n'
    '\t\t\t\t\tvisible := lang != nil && int(symbol) < len(lang.SymbolMetadata) && lang.SymbolMetadata[symbol].Visible\n'
    '\t\t\t\t\tfirstRawMissing = map[string]any{"symbol": symbol, "type": cobolCITraceSymbol(lang, symbol), "metadata_visible": visible, "child_count": count}\n'
    '\t\t\t\t\treturn true, count\n\t\t\t\t}\n\t\t\t\treturn false, count\n'
    '\t\t\t}, func(item rawStackWalkEntry, index int) (rawStackWalkEntry, bool) {\n'
    '\t\t\t\treturn rawStackWalkChildAt(n.ownerArena, item, index)\n\t\t\t})\n\t\t}\n'
    + anchor, 1)
logger = logger.replace('"raw_ref": fmt.Sprint(n.rawShape),', '"first_raw_MISSING": firstRawMissing, "raw_ref": fmt.Sprint(n.rawShape),', 1)
(CONTROL / "parser_cobol_ci_trace_private.go.txt").write_text(logger)
mapping = {
    "/candidate/parser_result_cobol.go": "/controls/ci-followup/cobol/candidate-reject-trace/parser_result_cobol.go.source",
    "/candidate/parser_cobol_ci_trace_private.go": "/controls/ci-followup/cobol/candidate-reject-trace/parser_cobol_ci_trace_private.go.txt",
}
(CONTROL / "overlay.json").write_text(json.dumps({"Replace": mapping}, indent=2) + "\n")
manifest = {
    "frozen_candidate_source_sha256": hashlib.sha256((COBOL / "candidate/parser_result_cobol.go.source").read_bytes()).hexdigest(),
    "private_diagnostic_only": True, "no_candidate_conditions_changed": True,
    "named_rejection_clauses": labels + ["hidden-MISSING-visibility-or-absence"],
    "AND_public_and_raw_entries_included": True,
    "first_raw_MISSING_records_symbol_visibility_without_changing_it": True,
    "strict_C_assertions_unchanged": True,
    "selector": "^TestCobolCGOErrorOracleParity$",
    "tags": "treesitter_c_parity,gts_parsercorephase0", "builds_tests_Docker_run": False}
(CONTROL / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"named_rejection_trace_prepared": True, "builds_tests_Docker_run": False}))
