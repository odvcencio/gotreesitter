#!/usr/bin/env python3
"""Freeze the trace-proven private v2; no Go builds or executions."""
from pathlib import Path
import hashlib
import json

CONTROL = Path(__file__).resolve().parent
COBOL = CONTROL.parent
EVIDENCE = COBOL.parent.parent
ROOT = EVIDENCE.parents[2]
V1 = COBOL / "candidate"
original = (ROOT / "parser_result_cobol.go").read_text()
helper = (V1 / "retained_exec_cics_helpers.go.txt").read_text()
assert helper.count("conjunction.startByte < cicsEnd") == 1
helper = helper.replace("conjunction.startByte < cicsEnd", "conjunction.startByte != cicsStart", 1)
old = """\tif condition == nil || condition.Type(lang) != "qualified_word" || condition.endByte > execStart ||
\t\tword == nil || word.Type(lang) != "WORD" || word.startByte != cicsStart || word.endByte != cicsEnd {
\t\treturn false
\t}
"""
new = """\tif condition == nil || condition.Type(lang) != "qualified_word" || condition.IsExtra() ||
\t\tcondition.startByte < header.startByte || condition.endByte <= condition.startByte || condition.endByte > execStart ||
\t\tword == nil || word.Type(lang) != "WORD" || word.startByte != execStart || word.endByte != execStart+uint32(len("EXEC")) {
\t\treturn false
\t}
\tif prefix.startByte != condition.startByte || prefix.endByte != word.endByte ||
\t\tclass.startByte != condition.startByte || class.endByte != word.endByte ||
\t\texpr.startByte != condition.startByte || expr.endByte != header.endByte || suffix.endByte != expr.endByte {
\t\treturn false
\t}
\t// The parser classified EXEC as the first class's WORD, inserted a
\t// hidden MISSING conjunction at CICS, and started a second expression
\t// with CICS. Trace-proven suffixes are either that qualified_word alone
\t// or a class containing it plus the following WORD (for example LINK).
\tif resultChildCount(suffix) != 1 || suffix.startByte != cicsStart {
\t\treturn false
\t}
\tcics := resultChildAt(suffix, 0)
\tif cics != nil && cics.Type(lang) == "is_class" {
\t\tif resultChildCount(cics) != 2 {
\t\t\treturn false
\t\t}
\t\ttailWord := resultChildAt(cics, 1)
\t\tif tailWord == nil || tailWord.Type(lang) != "WORD" || tailWord.startByte < cicsEnd {
\t\t\treturn false
\t\t}
\t\tcics = resultChildAt(cics, 0)
\t}
\tif cics == nil || cics.Type(lang) != "qualified_word" || cics.IsExtra() ||
\t\tcics.startByte != cicsStart || cics.endByte != cicsEnd {
\t\treturn false
\t}
"""
assert helper.count(old) == 1
helper = helper.replace(old, new, 1)
helper = helper.replace("condition/CICS class shape joined", "condition/EXEC class shape joined", 1)
(CONTROL / "retained_exec_cics_helpers.go.txt").write_text(helper)
guard = "func normalizeCobolIfHeaderExecCICSClassError(header *Node, source []byte, lang *Language) bool {\n\tif header == nil || header.hasError() || int(header.endByte) > len(source) {\n\t\treturn false\n\t}\n"
assert original.count(guard) == 1
replacement = guard.replace("header == nil || header.hasError() ||", "header == nil ||")
replacement += "\tif header.hasError() && !cobolRetainedMissingExecCICSClassHeader(header, source, lang) {\n\t\treturn false\n\t}\n"
candidate = original.replace(guard, replacement, 1)
tail = "\t\tif child.IsError() || child.HasError() {\n\t\t\tout = cobolAppendCommentEntryMarkers"
assert candidate.count(tail) == 1
candidate = candidate.replace(tail,
    "\t\tif child.IsError() || (child.HasError() && !cobolRetainedMissingExecCICSClassHeader(child, source, lang)) {\n\t\t\tout = cobolAppendCommentEntryMarkers", 1)
(CONTROL / "parser_result_cobol.go.source").write_text(candidate + "\n" + helper)

unit = (V1 / "cobol_retained_missing_class_test.go.txt").read_text()
start = unit.index('\tsource := []byte("       IF FLAG')
end = unit.index("\tleaf := func(", start)
unit = unit[:start] + r'''	source := []byte("       identification division.\n" +
		"       program-id. a.\n" +
		"       procedure division.\n" +
		"      * Procedure comment\n" +
		"           MOVE SPACES TO ABEND-REASON\n" +
		"           COPY CABENDPO.\n" +
		"           IF BANK-MAP-FUNCTION-GET\n" +
		"              EXEC CICS LINK PROGRAM(X)\n")
	conditionStart := uint32(strings.Index(string(source), "BANK-MAP-FUNCTION-GET"))
	execStart := uint32(strings.Index(string(source), "EXEC"))
	cicsStart := uint32(strings.Index(string(source), "CICS"))
	cicsEnd := cicsStart + 4
	linkStart := uint32(strings.Index(string(source), "LINK"))
''' + unit[end:]
unit = unit.replace("conditionStart+4)", 'conditionStart+uint32(len("BANK-MAP-FUNCTION-GET")))', 1)
unit = unit.replace("word := leaf(5, cicsStart, cicsEnd)", 'word := leaf(5, execStart, execStart+uint32(len("EXEC")))', 1)
unit = unit.replace("leaf(6, returnStart, returnStart)", "leaf(6, cicsStart, cicsStart)", 1)
unit = unit.replace("leaf(7, returnStart, returnStart)", "leaf(7, cicsStart, cicsStart)", 1)
unit = unit.replace('\tleaf := func(', '\tif len(source) != 248 || conditionStart != 186 || execStart != 222 || cicsStart != 227 || linkStart != 232 {\n\t\tt.Fatal("positive fixture no longer matches the actual failing trace")\n\t}\n\tleaf := func(', 1)
old = """\tsuffixWord := leaf(4, returnStart, returnStart+6)
\tsuffix := newParentNodeInArenaNoLinksWithFieldSources(arena, 2, true, []*Node{suffixWord}, nil, nil, 0, false)
"""
new = """\tcicsWord := leaf(4, cicsStart, cicsEnd)
\tlinkWord := leaf(5, linkStart, linkStart+4)
\tsuffixClass := newParentNodeInArenaNoLinksWithFieldSources(arena, 3, true, []*Node{cicsWord, linkWord}, nil, nil, 0, false)
\tsuffix := newParentNodeInArenaNoLinksWithFieldSources(arena, 2, true, []*Node{suffixClass}, nil, nil, 0, false)
"""
assert unit.count(old) == 1
unit = unit.replace(old, new, 1)
unit = unit.replace('"wrong-CICS-word-span"', '"wrong-EXEC-word-span"', 2)
unit = unit.replace('f.suffix.children = []*Node{child}', '''cics := resultChildAt(resultChildAt(f.suffix, 0), 0)
\t\t\tcics.children = []*Node{child}
\t\t\tcics.setHasError(true)''')
unit = unit.replace('f.suffix.startByte, f.suffix.endByte, f.suffix.startPoint, f.suffix.endPoint)',
    'f.suffix.startByte, f.cicsEnd, f.suffix.startPoint, advancePointByBytes(Point{}, f.source[:f.cicsEnd]))')
unit = unit.replace('[]string{"raw-proof-absent", "public-error", "public-missing", "unknown-header", "unknown-expr-shape", "nonzero-conjunction", "stale-conjunction-flag", "wrong-EXEC-word-span", "wrong-source"}',
    '[]string{"raw-proof-absent", "public-error", "public-missing", "unknown-header", "unknown-expr-shape", "nonzero-conjunction", "stale-conjunction-flag", "wrong-EXEC-word-span", "wrong-CICS-operand-span", "wrong-source"}')
unit = unit.replace('\t\t\tcase "wrong-source":',
    '\t\t\tcase "wrong-CICS-operand-span":\n\t\t\t\tresultChildAt(resultChildAt(f.suffix, 0), 0).endByte--\n\t\t\tcase "wrong-source":', 1)
unit += r'''

func TestCobolRetainedMissingClassHeaderAcceptsCICSOnlySuffix(t *testing.T) {
	f := newCobolRetainedMissingFixture(t)
	expr := resultChildAt(f.header, 0)
	cics := resultChildAt(resultChildAt(f.suffix, 0), 0)
	f.suffix.children = []*Node{cics}
	f.suffix.endByte, f.suffix.endPoint = cics.endByte, cics.endPoint
	expr.endByte, expr.endPoint = cics.endByte, cics.endPoint
	f.header.endByte, f.header.endPoint = cics.endByte, cics.endPoint
	if !cobolRetainedMissingExecCICSClassHeader(f.header, f.source, f.language) ||
		!normalizeCobolIfHeaderExecCICSClassError(f.header, f.source, f.language) || !f.header.HasError() {
		t.Fatal("observed CICS-only suffix did not preserve the class error repair")
	}
}

func TestCobolRetainedMissingClassHeaderPrefixTrimKeepsCorrectGeometry(t *testing.T) {
	f := newCobolRetainedMissingFixture(t)
	if !cobolRetainedMissingExecCICSClassHeader(f.header, f.source, f.language) {
		t.Fatal("untrimmed trace-proven header did not certify")
	}
	execEnd := f.classWord.endByte
	cobolTrimNodeEndForRecovery(f.header, f.source, execEnd)
	normalizeCobolRecoveredProcedurePrefixNode(f.header, f.source, f.language)
	if f.header.endByte != execEnd || f.header.HasError() {
		t.Fatal("existing prefix trim failed to remove the out-of-span missing conjunction")
	}
	if normalizeCobolIfHeaderExecCICSClassError(f.header, f.source, f.language) {
		t.Fatal("class repair crossed the trimmed header boundary into the CICS error tail")
	}
	expr := resultChildAt(f.header, 0)
	if resultChildCount(expr) != 1 || resultChildAt(expr, 0).Type(f.language) != "is_class" || resultChildCount(resultChildAt(expr, 0)) != 2 {
		t.Fatal("prefix trim changed the retained condition/EXEC class geometry")
	}
}
'''
(CONTROL / "cobol_retained_missing_class_test.go.txt").write_text(unit)
runtime = {"/candidate/parser_result_cobol.go": "/controls/ci-followup/cobol/candidate-v2/parser_result_cobol.go.source"}
tests = {"/candidate/cobol_retained_missing_class_private_test.go": "/controls/ci-followup/cobol/candidate-v2/cobol_retained_missing_class_test.go.txt"}
for name, mapping in (("runtime", runtime), ("tests", runtime | tests)):
    (CONTROL / f"overlay.{name}.json").write_text(json.dumps({"Replace": mapping}, indent=2) + "\n")
    (CONTROL / f"overlay.{name}.host.json").write_text(json.dumps({"Replace": {
        k.replace("/candidate/", str(ROOT)+"/", 1): str(EVIDENCE)+v.removeprefix("/controls") for k,v in mapping.items()}}, indent=2) + "\n")
record = {
    "private_candidate_only": True, "failed_v1_unchanged": True, "production_files_changed": False,
    "trace_evidence": "out/ci-cobol-reject-trace/cobol.log",
    "proven_missing_carrier": "AND wrapper has Missing=false, HasError=true; raw hidden _AND symbol65 is Missing=true, metadataVisible=false",
    "geometry": "condition/EXEC class; zero-width conjunction exactly at CICSstart; suffix is CICS qualified_word or class(CICS,followingWORD)",
    "first_case_prefix_trim": "Existing source split ends at EXECend; removes conjunction/CICS suffix, naturally clears its error, and cannot rewrite beyond the header into CICS.",
    "two_changed_guards": ["class repair", "tail collapse"],
    "no_retention_latches_removed": True, "no_manual_error_flag_clearing_added": True,
    "unit_selector": "^TestCobolRetainedMissingClassHeader",
    "strict_C_tests_unchanged": True, "builds_tests_Docker_run": False,
    "files": {p.name: {"bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()}
              for p in CONTROL.iterdir() if p.is_file() and p.name != "manifest.json"}}
(CONTROL / "manifest.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"private_v2_prepared": True, "failed_v1_preserved": True, "builds_tests_Docker_run": False}))
