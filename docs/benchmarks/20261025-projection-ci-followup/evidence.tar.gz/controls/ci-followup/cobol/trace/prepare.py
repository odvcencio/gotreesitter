#!/usr/bin/env python3
"""Prepare nonmaterializing compatibility-stage tracing; never run Go."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

CONTROL = Path(__file__).resolve().parent
COBOL = CONTROL.parent
EVIDENCE = COBOL.parent.parent
ROOT = EVIDENCE.parents[2]
path = ROOT / "parser_result_cobol.go"
source = path.read_text()
start = source.index("func normalizeCobolCompatibility(")
end = source.index("\n}\n", start) + 3
original = source[start:end]
lines = []
for index, line in enumerate(original.splitlines(keepends=True)):
    lines.append(line)
    if index == 0:
        lines.append('\tcobolCITraceTree("pipeline-entry", root, source, lang)\n')
    match = re.match(r"^(\t+)(?:\w+ := )?(normalizeCobol\w+)\(", line)
    if match:
        lines.append(match.group(1) + 'cobolCITraceTree("after.' + match.group(2) + '", root, source, lang)\n')
traced = source[:start] + "".join(lines) + source[end:]
anchor = "func normalizeCobolIfHeaderExecCICSClassError(header *Node, source []byte, lang *Language) bool {\n"
assert traced.count(anchor) == 1
traced = traced.replace(anchor, anchor +
    '\tcobolCITraceTree("class-helper-entry", header, source, lang)\n' +
    '\tdefer cobolCITraceTree("class-helper-exit", header, source, lang)\n', 1)
guard = "if header == nil || header.hasError() || int(header.endByte) > len(source) {"
assert traced.count(guard) == 1
off = traced.replace(guard, "if header == nil || int(header.endByte) > len(source) {", 1)
(CONTROL / "parser_result_cobol.current-trace.go.source").write_text(traced)
(CONTROL / "parser_result_cobol.guard-off-trace.go.source").write_text(off)
for variant, base_name, replacement in (
    ("current", "current", "parser_result_cobol.current-trace.go.source"),
    ("eff", "eff", "parser_result_cobol.current-trace.go.source"),
    ("no-creation", "no-creation", "parser_result_cobol.current-trace.go.source"),
    ("guard-off", "current", "parser_result_cobol.guard-off-trace.go.source"),
):
    mapping = json.loads((COBOL / f"overlay.{base_name}.json").read_text())["Replace"]
    mapping["/candidate/parser_result_cobol.go"] = "/controls/ci-followup/cobol/trace/" + replacement
    mapping["/candidate/parser_cobol_ci_trace_private.go"] = "/controls/ci-followup/cobol/trace/parser_cobol_ci_trace_private.go.txt"
    (CONTROL / f"overlay.{variant}.json").write_text(json.dumps({"Replace": mapping}, indent=2) + "\n")
manifest = {
    "private_diagnostic_only": True, "does_not_qualify_performance_or_work_counters": True,
    "traces": ["pipeline entry", "after each existing compatibility stage", "class helper entry and exit"],
    "public_children_read_without_materializing_accessors": True,
    "native_node_view_child_boundary_not_expanded": True,
    "raw_history_immediate_entries_only": True, "node_cap_per_snapshot": 1024,
    "new_parser_node_or_tree_fields": False, "baseline_cobol_source_identical_to_current": True,
    "first_case_selector": "^TestCobolCGOErrorOracleParity$/^exec_cics_tail_after_clean_prefix$",
    "tags": "treesitter_c_parity,gts_parsercorephase0",
    "existing_source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
    "builds_tests_Docker_run": False,
    "files": {p.name: {"bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()}
              for p in CONTROL.iterdir() if p.is_file() and p.name != "manifest.json"}}
(CONTROL / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"variants": ["current", "eff", "no-creation", "guard-off"], "builds_tests_Docker_run": False}))
