from pathlib import Path
import json,re,collections
p=Path(__file__).resolve().parent.parent;o=p/'out/ci-followup-final'
assert json.loads((o/'finished.json').read_text())['exit_code']==0
langs=(p/'fleet-controls/languages.txt').read_text().splitlines();assert len(langs)==len(set(langs))==206
assert len((o/'invariant-status.tsv').read_text().splitlines())==412
fixtures=collections.Counter()
for route in [0,1]:
 for lang in langs:
  s=(o/f'invariants/{route}-{lang}.log').read_text();assert '--- PASS: TestV1InvariantGateR4EditSession ' in s and 'SKIP' not in s and 'FAIL' not in s
  m=re.search(r'language='+re.escape(lang)+r' fixture=(\S+) sample_bytes=\d+ session_steps=72 no_edit_allocs=0',s);assert m,lang
  fixtures[m[1]]+=1
assert len((o/'cgo-status.tsv').read_text().splitlines())==206
for lang in langs:
 s=(o/f'cgo/{lang}.log').read_text();assert 'SKIP' not in s and 'FAIL' not in s,lang
 for case in ['FreshParse','IncrementalParse','HasNoErrors']:assert f'--- PASS: TestParity{case}/{lang} ' in s,(lang,case)
changed=[]
for route in ['default','candidate']:
 for lang in langs:
  before=json.loads((p/f'out/final-ledger-fleet/after/{route}-{lang}.json').read_text());after=json.loads((o/f'ledger/{route}-{lang}.json').read_text())
  if before!=after:changed.append({'route':route,'language':lang,'before':before,'after':after})
(o/'ledger-comparison.json').write_text(json.dumps({'rows':412,'unchanged':412-len(changed),'changed':changed},indent=2)+'\n')
def records(file):
 out={}
 for line in file.read_text().splitlines():
  if line.startswith('WORK '):
   row=json.loads(line[5:]);key=tuple(row[k] for k in ['assignment','candidate','kind','phase']);assert key not in out;out[key]=row
 return out
wa={};wb={}
for a in [0,1]:
 wa.update(records(p/f'out/recovery-guard/final-work-{a}.log'));wb.update(records(o/f'work-{a}.log'))
assert len(wa)==len(wb)==24
wd=[{'key':list(k),'before':wa[k],'after':wb[k]} for k in wa if wa[k]!=wb[k]]
(o/'work-comparison.json').write_text(json.dumps({'cases':24,'unchanged':24-len(wd),'changes':wd},indent=2)+'\n')
assert not changed, f'new ledger changes: {len(changed)}'
assert not wd, f'new complete Go work changes: {len(wd)}'
s={'schema':'gts-projection-ci-followup/v1','base_head':'44c44cd3559eb83c7dc8f03d5570f96291ace9b2','languages':206,'sessions':412,'session_fixture_types':dict(fixtures),'edit_steps':29664,'no_edit_allocations':0,'C_fixture_checks':618,'failed':0,'skipped':0,'new_ledger_changes':0,'ledger_rows_unchanged':412,'complete_Go_work_cases_unchanged':24,'root_Go_files':756,'all_Cobol_full_C_cases_each_route':5,'new_Go_edit_cycle_states':20,'new_Go_edit_apis':['plain','profiled'],'earlier_C_EDS_exceptions_still_unapproved':4,'earlier_Go_assignment_exception_still_unapproved':True,'merges_held':True,'performance_claim':False,'native_or_dense_prototypes_promoted':False}
(o/'validated-summary.json').write_text(json.dumps(s,indent=2)+'\n')
print(json.dumps(s,indent=2))
