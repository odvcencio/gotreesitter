set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/ci-combined-candidate
mkdir -p "$scratch"
cd /candidate
overlay=/controls/ci-followup/overlay.combined-candidate.json
go test -c -tags gts_parsercorephase0 -overlay="$overlay" -o "$scratch/root.test" . > /evidence/root-build.log 2>&1
"$scratch/root.test" -test.run '^TestCobol' -test.count=1 -test.v > /evidence/root-cobol.log 2>&1
"$scratch/root.test" -test.run '^Test(HiddenMissing.*|GoMissingSemicolonProjectionRetainsElidedHistory|MissingTurnRangeExclusion.*|ReservedRuntimePrefilter.*|Issue490GoGrammarRegression|FactDeclarationsGo.*|GoCompat.*|WalkGoCompat.*|NormalizeGoCompatibilityWithParserPropagatesMemoryBudgetStop)$' -test.count=1 -test.v > /evidence/root-go.log 2>&1
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -overlay="$overlay" -o "$scratch/cgo.test" . > /evidence/cgo-build.log 2>&1
"$scratch/cgo.test" -test.run '^TestCobol' -test.count=1 -test.v > /evidence/cgo-cobol.log 2>&1
"$scratch/cgo.test" -test.run '^TestCooklangNextLiveArmLockedCRoutes$' -test.count=1 -test.v > /evidence/cgo-cooklang-diagnostic.log 2>&1
"$scratch/cgo.test" -test.run '^Test(GoGroupedBindingsProjectedMissingLockedC|GoGroupedBindingSeparatorsLockedC|GoIssue490FragmentBoundaryLockedC|GoHiddenMissingSemicolonEditsMatchLockedC|GoNextLiveArmProbe|IncludedRangesGoRootParity)$' -test.count=1 -test.v > /evidence/cgo-go.log 2>&1
for route in 0 1; do
 for language in go cobol; do
  cd /candidate
  GTS_ADMISSION_CANDIDATE=$route GOTREESITTER_V1_INVARIANT_LANGUAGE=$language "$scratch/root.test" -test.run '^TestV1InvariantGateR4EditSession$' -test.v -test.count=1 > "/evidence/invariant-$route-$language.log" 2>&1
 done
done
cd /candidate
go test -race -tags gts_parsercorephase0 -overlay="$overlay" -run '^Test(HiddenMissing.*|GoMissingSemicolonProjectionRetainsElidedHistory|CobolRetainedMissingClassHeader.*)$' -count=1 -v . > /evidence/race.log 2>&1
sha256sum "$scratch/root.test" "$scratch/cgo.test" > /evidence/binary.sha256
printf 'combined Go/Cobol fixes and diagnostic-only Cooklang pin changes qualified; no timing claim\n' > /evidence/completed.txt
