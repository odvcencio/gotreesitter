set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/raw-summary-perf-fused-v7/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/trusted-go-shadow-probe-v1/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/raw-summary-perf-fused-v7/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/trusted-go-shadow-probe-v1/controls.sha256 > /evidence/controls-before.log 2>&1
cd /candidate
go test -overlay=/controls/trusted-go-shadow-v1/overlay.tests.json ./internal/incr -run "^TestPrivateTrusted" -count=1 -v > /evidence/internal-policy.log 2>&1
cd /candidate
go test -overlay=/controls/trusted-go-shadow-v1/overlay.tests.json ./grammars/runtime -run "^TestTrustedGoReuseShadowArtifactScope$" -count=1 -v > /evidence/artifact-scope.log 2>&1
cd /candidate
go test -overlay=/controls/trusted-go-shadow-v1/overlay.tests.json -tags=gts_parsercorephase0 . -run "^TestTrustedGoShadowActualDefaultProducerContext$" -count=1 -v > /evidence/actual-producer-guards.log 2>&1
cd /candidate
go test -overlay=/controls/trusted-go-shadow-v1/overlay.tests.json -tags=gts_parsercorephase0 . -run "^TestTrustedGoReuseShadowOriginalProducer$" -count=1 -v -timeout=8m > /evidence/original-Go-producer-shadow.log 2>&1
cd /candidate/cgo_harness
go test -overlay=/controls/trusted-go-shadow-v1/overlay.tests.json -tags=treesitter_c_parity,gts_parsercorephase0 . -run "^TestGo(Cognociente137KiBTopEditLockedC|MalformedDeclarationPrefixLockedC|AssignmentTargetEdits16SitesLockedC)$" -count=1 -v -timeout=12m > /evidence/existing-strong-C-Go.log 2>&1
