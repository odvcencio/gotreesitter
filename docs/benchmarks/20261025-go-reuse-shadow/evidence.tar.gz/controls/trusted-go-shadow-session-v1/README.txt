PRIVATE prepared Go-native shadow clean edit sessions; no author execution.
Two separate plain/profiled chains each run72span-changing identifier edits
across16functions spread over the original140368B1760function witness.
All genuine incoming would-certify results require absolute independent fresh
structure/state/precedence equality while real fresh verification stays active.
Every final result also compares strictly with an independent fresh parse,
checks freshVerified=true/certified=false, and noedit allocation0.
Actual would/decline counts are logged perstep; no claim all72certify.
Plain reuse proof is actual pointer-identical old top-level nodes observed
in the incoming candidate; profiled additionally requires positive API reuse.
Each phase restores the exact original source by the final edit.
Inherited V2 unsupported-producer controls remain unchanged in complete map.

See commands.json. Parent owns bounded Docker execution under shared flock.
No tests/builds/performance by author. Preserve any first failure and budgets.
