set -uo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/raw-summary-perf-fused-v7/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/trusted-go-shadow-state-control-v1/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/raw-summary-perf-fused-v7/source.sha256 > /evidence/source-before.log 2>&1 || exit 2
sha256sum --quiet -c /controls/trusted-go-shadow-state-control-v1/controls.sha256 > /evidence/controls-before.log 2>&1 || exit 2
result=0
for arm in baseline candidate capability-off; do
 go test -overlay="/controls/trusted-go-shadow-v2-adjudication/overlay.$arm.tests.json" -tags=gts_parsercorephase0 . -run '^TestTrustedGoShadowHistoricalStateControl$' -count=1 -v -timeout=6m > "/evidence/$arm.log" 2>&1
 code=$?
 echo "$code" > "/evidence/$arm.exit"
 if [[ "$code" != 0 ]]; then result=1; fi
done
exit "$result"
