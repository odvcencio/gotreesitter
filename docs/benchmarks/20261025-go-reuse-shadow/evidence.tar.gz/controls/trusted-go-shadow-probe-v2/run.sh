set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/raw-summary-perf-fused-v7/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/trusted-go-shadow-probe-v2/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/raw-summary-perf-fused-v7/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/trusted-go-shadow-probe-v2/controls.sha256 > /evidence/controls-before.log 2>&1
cd /candidate
go test -overlay=/controls/trusted-go-shadow-v2/overlay.tests.json ./internal/incr -run "^TestPrivateTrusted" -count=1 -v > /evidence/internal-policy.log 2>&1
cd /candidate
go test -overlay=/controls/trusted-go-shadow-v2/overlay.tests.json ./grammars/runtime -run "^TestTrustedGoReuseShadowArtifactScope$" -count=1 -v > /evidence/artifact-scope.log 2>&1
cd /candidate
go test -overlay=/controls/trusted-go-shadow-v2/overlay.tests.json -tags=gts_parsercorephase0 . -run "^TestTrustedGoShadowActualDefaultProducerContext$" -count=1 -v > /evidence/actual-producer-guards.log 2>&1
cd /candidate
go test -overlay=/controls/trusted-go-shadow-v2/overlay.tests.json -tags=gts_parsercorephase0 . -run "^TestTrustedGoReuseShadowOriginalProducer$" -count=1 -v -timeout=8m > /evidence/original-Go-producer-shadow.log 2>&1
cd /candidate
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE=$route GOTREESITTER_V1_INVARIANT_LANGUAGE=go go test -overlay=/controls/trusted-go-shadow-v2/overlay.tests.json -tags=gts_parsercorephase0 . -run '^TestV1InvariantGateR4EditSession$' -count=1 -v -timeout=4m > "/evidence/invariants-go-$route.log" 2>&1
done
go test -overlay=/controls/trusted-go-shadow-v2/overlay.tests.json -tags=gts_parsercorephase0 . -run '^Test(RuntimeMemory.*|ParseMemory.*)$' -count=1 -v -timeout=4m > /evidence/memory.log 2>&1
go test -race -overlay=/controls/trusted-go-shadow-v2/overlay.tests.json ./internal/incr -run '^TestPrivateTrusted' -count=1 -v -timeout=4m > /evidence/internal-race.log 2>&1
go test -race -overlay=/controls/trusted-go-shadow-v2/overlay.tests.json -tags=gts_parsercorephase0 . -run '^TestTrustedGo(ReuseShadowOriginalProducer|ShadowActualDefaultProducerContext)$' -count=1 -v -timeout=6m > /evidence/producer-race.log 2>&1
