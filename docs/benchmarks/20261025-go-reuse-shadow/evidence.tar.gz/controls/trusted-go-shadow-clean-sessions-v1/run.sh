set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/raw-summary-perf-fused-v7/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/trusted-go-shadow-clean-sessions-v1/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/raw-summary-perf-fused-v7/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/trusted-go-shadow-clean-sessions-v1/controls.sha256 > /evidence/controls-before.log 2>&1
cd /candidate
go test -overlay=/controls/trusted-go-shadow-session-v1/overlay.tests.json -tags=gts_parsercorephase0 . -run "^TestTrustedGoReuseShadowCleanEditSession$/^plain$" -count=1 -v -timeout=12m > /evidence/clean-plain-session.log 2>&1
cd /candidate
go test -overlay=/controls/trusted-go-shadow-session-v1/overlay.tests.json -tags=gts_parsercorephase0 . -run "^TestTrustedGoReuseShadowCleanEditSession$/^profiled$" -count=1 -v -timeout=12m > /evidence/clean-profiled-session.log 2>&1
cd /candidate
go test -overlay=/controls/trusted-go-shadow-session-v1/overlay.tests.json -tags=gts_parsercorephase0 . -run "^TestTrustedGoReuseShadowOriginalProducer$" -count=1 -v -timeout=8m > /evidence/inherited-producer-negatives.log 2>&1
