PRIVATE Go-only trusted reuse SHADOW; prepared, unexecuted, no timing claim.
Baseline is the current canonical source; no raw publisher/fused/hybrid runtime is layered.
The exact Go9ad runtime-profile registration grants a generic artifact capability outside
engine files. Every new small scheduling, read-frontier, raw-alias or span-edit decision
requires that capability or a positive producer receipt only this scope may stamp.
All other artifacts retain their established threshold paths; new Language metadata is
cold and its footprint still requires qualification. Reads budgets charge actual header.

The candidate binds actual native owned DFA/source identity/default controls/fresh policy,
then transfers the fresh reuse schedule conservatively. Old compact/forest producers,
Copy, transformed factories/wrappers and incomplete histories cannot enter small mode.
Small clean would-certify results NEVER set legacyIncrementalReuseCertified. The existing
fresh verifier is forced active for new small mode, including its EOF-extra shortcut.
Test/diagnostic/workcount builds synchronously observe the incoming and actual fresh trees
before replacement; ordinary builds contain an empty observation hook. A verified equal
would-certify result may retain the matching independent fresh producer's key for chaining,
but retains freshVerified=true and bypass certification=false.

Focused controls cover exact original140368B source, native insertion chain, Copy,
transformed '+'→'-' old source, identity wrapper, actual compact old producer, absent
capability; actual producer guard dimensions and stale/same-name/foreign artifact checks.
All source transformations preserve verifier calls. Existing original declaration and
138608B assignment16site C tests remain unchanged. See commands.json. Any failed positive
or negative must be kept as a failed qualification, not weakened. No runtime promotion,
owner exception, ledger reset, compact graduation, Windows/ARM or new speed claim.
