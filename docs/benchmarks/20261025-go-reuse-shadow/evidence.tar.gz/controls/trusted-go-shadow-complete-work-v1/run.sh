set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/raw-summary-perf-fused-v7/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/trusted-go-shadow-complete-work-v1/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/raw-summary-perf-fused-v7/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/trusted-go-shadow-complete-work-v1/controls.sha256 > /evidence/controls-before.log 2>&1
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/trusted-go-shadow-complete-work-v1
mkdir -p "$scratch"
cd /baseline
go build -tags gts_parsercorephase0,gts_workcount -o "$scratch/before-work" /prior-controls/recovery-work-main.go > /evidence/before-build.log 2>&1
cd /candidate
go build -tags gts_parsercorephase0,gts_workcount -overlay=/controls/trusted-go-shadow-v1/overlay.runtime.json -o "$scratch/after-work" /prior-controls/recovery-work-main.go > /evidence/after-build.log 2>&1
for role in before after; do
 for assignment in 0 1; do
  GTS_PROBE_ASSIGNMENT=$assignment "$scratch/$role-work" > "/evidence/$role-work-$assignment.log" 2>&1
 done
done
sha256sum "$scratch/before-work" "$scratch/after-work" > /evidence/binary.sha256
