set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/reserved-counters
mkdir -p "$scratch"
cd /baseline
sha256sum --quiet -c /controls/counter-controls/baseline-source.sha256 > /evidence/source-authentication-before.log 2>&1
go build -tags gts_parsercorephase0 -o "$scratch/before-ledger" ./cmd/perfcounterledger > /evidence/before-ledger-build.log 2>&1
go build -tags gts_parsercorephase0,gts_workcount -o "$scratch/before-work" /prior-controls/recovery-work-main.go > /evidence/before-work-build.log 2>&1
cd /candidate
go build -tags gts_parsercorephase0 -overlay=/controls/reserved-projection-overlay.json -o "$scratch/after-ledger" ./cmd/perfcounterledger > /evidence/after-ledger-build.log 2>&1
go build -tags gts_parsercorephase0,gts_workcount -overlay=/controls/reserved-projection-overlay.json -o "$scratch/after-work" /prior-controls/recovery-work-main.go > /evidence/after-work-build.log 2>&1
for role in before after; do
 for route in default candidate; do
  GTS_ADMISSION_CANDIDATE=$([ "$route" = candidate ] && echo 1 || echo 0) "$scratch/$role-ledger" --child-route="$route" --langs go > "/evidence/$role-ledger-$route.json"
 done
 for assignment in 0 1; do
  GTS_PROBE_ASSIGNMENT=$assignment "$scratch/$role-work" > "/evidence/$role-work-$assignment.log" 2>&1
 done
done
# Capture the unchanged baseline's full C range differences for adjudication.
cd /baseline/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -overlay=/controls/counter-controls/baseline-range-overlay.json -o "$scratch/before-ranges.test" . > /evidence/before-ranges-build.log 2>&1
set +e
GTS_GO_RANGE_DIFF_RECEIPT_OUT=/evidence/before-ranges.json "$scratch/before-ranges.test" -test.run '^TestGoIncludedRangeFullTreeDiffsPrivate$' -test.v -test.count=1 > /evidence/before-ranges.log 2>&1
code=$?
set -e
printf 'baseline_included_range_exact_c\t%s\n' "$code" > /evidence/status.tsv
cd /baseline
sha256sum --quiet -c /controls/counter-controls/baseline-source.sha256 > /evidence/source-authentication-after.log 2>&1
sha256sum "$scratch/before-ledger" "$scratch/after-ledger" "$scratch/before-work" "$scratch/after-work" "$scratch/before-ranges.test" > /evidence/binary.sha256
printf 'deterministic counters complete; no timing qualification\n' > /evidence/completed.txt
