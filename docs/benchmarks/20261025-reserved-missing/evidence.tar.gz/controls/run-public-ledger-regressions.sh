set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate/cgo_harness
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/public-ledger-regressions
mkdir -p "$scratch"
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o "$scratch/cgo.test" . > /evidence/build.log 2>&1
for name in CHiddenMissingCorpusFreshLockedC CHiddenMissingCorpusFirstEditLockedC EDSHiddenMissingCorpusFreshLockedC EDSHiddenMissingCorpusFirstEditLockedC; do
 "$scratch/cgo.test" -test.run "^Test${name}$" -test.count=1 -test.v > "/evidence/$name.log" 2>&1
 printf '%s\t0\n' "$name" >> /evidence/status.tsv
done
sha256sum /candidate/cgo_harness/hidden_missing_corpus_parity_test.go "$scratch/cgo.test" > /evidence/source-and-binary.sha256
printf 'permanent regressions pass on final source with each test isolated\n' > /evidence/completed.txt
