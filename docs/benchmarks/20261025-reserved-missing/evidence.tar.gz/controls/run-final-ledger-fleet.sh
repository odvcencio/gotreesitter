set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/final-ledger-fleet
mkdir -p "$scratch"
cd /candidate
sha256sum --quiet -c /controls/final-promoted-source.sha256 > /evidence/source-before.log 2>&1
go build -tags gts_parsercorephase0 -o "$scratch/after-ledger" ./cmd/perfcounterledger > /evidence/build.log 2>&1
for role in before after; do
 binary="$scratch/after-ledger"
 if [[ "$role" = before ]]; then binary=/runtime/tmp/gotreesitter-go-ci-20261025/reserved-counters/before-ledger; fi
 mkdir -p "/evidence/$role"
 for route in default candidate; do
  candidate=0
  if [[ "$route" = candidate ]]; then candidate=1; fi
  while IFS= read -r language; do
   set +e
   GTS_ADMISSION_CANDIDATE=$candidate "$binary" --child-route="$route" --langs "$language" > "/evidence/$role/$route-$language.json" 2> "/evidence/$role/$route-$language.stderr"
   code=$?
   set -e
   printf '%s\t%s\t%s\t%s\n' "$role" "$route" "$language" "$code" >> /evidence/status.tsv
   [[ "$code" = 0 ]] || exit "$code"
  done < /controls/fleet-controls/languages.txt
 done
done
sha256sum --quiet -c /controls/final-promoted-source.sha256 > /evidence/source-after.log 2>&1
sha256sum "$scratch/after-ledger" /runtime/tmp/gotreesitter-go-ci-20261025/reserved-counters/before-ledger > /evidence/binary.sha256
printf 'all isolated before/after counter processes complete; review every delta before timing qualification\n' > /evidence/completed.txt
