set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
[[ -f /controls/out/reserved-contained-c4/completed.txt ]] || { echo 'required scoped qualification has not passed' >&2; exit 2; }
cd /candidate
sha256sum --quiet -c /controls/fleet-controls/binaries.sha256 > /evidence/binary-authentication.log 2>&1
sha256sum --quiet -c /controls/counter-controls/baseline-source.sha256 > /evidence/source-before.log 2>&1
binary=/runtime/tmp/gotreesitter-go-ci-20261025/reserved-contained/root.test
mkdir -p /evidence/invariants /evidence/cgo
for route in 0 1; do
 while IFS= read -r language; do
  set +e
  GTS_ADMISSION_CANDIDATE=$route GOTREESITTER_V1_INVARIANT_LANGUAGE=$language "$binary" -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=3m > "/evidence/invariants/$route-$language.log" 2>&1
  code=$?
  set -e
  printf '%s\t%s\t%s\n' "$route" "$language" "$code" >> /evidence/invariant-status.tsv
  [[ "$code" = 0 ]] || exit "$code"
 done < /controls/fleet-controls/languages.txt
done
cd /candidate/cgo_harness
binary=/runtime/tmp/gotreesitter-go-ci-20261025/reserved-contained/cgo.test
while IFS= read -r language; do
 set +e
 GTS_ADMISSION_CANDIDATE=1 GTS_PARITY_MODE=exhaustive GTS_PARITY_COMPARE_FIELDS=1 GTS_PARITY_COMPARE_HAS_ERROR=1 GTS_PARITY_IGNORE_KNOWN_SKIPS=1 "$binary" -test.run "^TestParity(FreshParse|IncrementalParse|HasNoErrors)$/^${language}$" -test.count=1 -test.v -test.timeout=3m > "/evidence/cgo/$language.log" 2>&1
 code=$?
 set -e
 printf '%s\t%s\n' "$language" "$code" >> /evidence/cgo-status.tsv
 [[ "$code" = 0 ]] || exit "$code"
done < /controls/fleet-controls/languages.txt
GTS_ADMISSION_REAL_CORPUS_LANGS=yaml "$binary" -test.run '^TestCompactR4StructuralLockedC$' -test.count=1 -test.v > /evidence/yaml-r4.log 2>&1
"$binary" -test.run '^TestCompactYAMLVersionOwnershipCOracle$' -test.count=1 -test.v > /evidence/yaml-owned.log 2>&1
cd /candidate
sha256sum --quiet -c /controls/counter-controls/baseline-source.sha256 > /evidence/source-after.log 2>&1
sha256sum --quiet -c /controls/fleet-controls/binaries.sha256 > /evidence/binary-authentication-after.log 2>&1
printf 'fleet process loop complete; validate exact session and C case coverage from all logs\n' > /evidence/completed.txt
