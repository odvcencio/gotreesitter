set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/recovery-guard
mkdir -p "$scratch"
cd /candidate
sha256sum --quiet -c /controls/counter-controls/baseline-source.sha256 > /evidence/source-before.log 2>&1
go test -c -tags gts_parsercorephase0 -overlay=/controls/recovery-guard-overlay.json -o "$scratch/root.test" . > /evidence/build.log 2>&1
set +e
GTS_OWNED_RECOVERY_EXPECT_BLOB_SHA256=9ad1f8d7d0f2b9aa32c61bd8295b56177caabb0ae2fb8dd4617559ee0f71fed4 "$scratch/root.test" -test.run '^TestPrivateOwnedRecoveryGuardTrace(SoleSurvivor)?$' -test.count=1 -test.v > /evidence/guard-trace.log 2>&1
code=$?
set -e
printf 'guard_trace\t%s\n' "$code" >> /evidence/status.tsv
# Complete the earlier diagnostics with their required route environment.
for language in caddy chatito; do
 set +e
 GTS_ADMISSION_CANDIDATE=1 /runtime/tmp/gotreesitter-go-ci-20261025/reserved-counters/after-ledger --child-route=candidate --langs "$language" > "/evidence/$language-ledger.json" 2> "/evidence/$language-ledger-stderr.log"
 code=$?
 set -e
 printf '%s_ledger\t%s\n' "$language" "$code" >> /evidence/status.tsv
 cd /candidate/cgo_harness
 set +e
 GTS_ADMISSION_REAL_CORPUS_LANGS=$language /runtime/tmp/gotreesitter-go-ci-20261025/reserved-contained/cgo.test -test.run '^TestCompactR4StructuralLockedC$' -test.count=1 -test.v > "/evidence/$language-r4-c.log" 2>&1
 code=$?
 set -e
 printf '%s_strict_c\t%s\n' "$language" "$code" >> /evidence/status.tsv
 cd /candidate
done
cd /candidate/cgo_harness
REPRO_LANG=doxygen REPRO_FILE=/candidate/internal/benchfixtures/testdata/real/doxygen REPRO_CLOG=1 REPRO_GO_BACKEND=registry /runtime/tmp/gotreesitter-go-ci-20261025/doxygen-trace/cgo.test -test.run '^TestCTreeDumpDiag$' -test.count=1 -test.v > /evidence/doxygen-physical-c-trace.log 2>&1
# Verify final-composition ordinary counters, separate from debug instrumentation.
cd /candidate
go build -tags gts_parsercorephase0,gts_workcount -overlay=/controls/reserved-contained-c4-overlay.json -o "$scratch/final-work" /prior-controls/recovery-work-main.go > /evidence/final-work-build.log 2>&1
for assignment in 0 1; do
 GTS_PROBE_ASSIGNMENT=$assignment "$scratch/final-work" > "/evidence/final-work-$assignment.log" 2>&1
done
sha256sum --quiet -c /controls/counter-controls/baseline-source.sha256 > /evidence/source-after.log 2>&1
sha256sum "$scratch/root.test" "$scratch/final-work" > /evidence/binary.sha256
printf 'strict unsupported recovery diagnostics and final work records complete; no timing claim\n' > /evidence/completed.txt
