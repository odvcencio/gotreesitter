set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate/cgo_harness
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/reserved-candidate
mkdir -p "$scratch"
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -overlay=/controls/reserved-candidate-overlay.json -o "$scratch/cgo.test" . > /evidence/build.log 2>&1
for selector in protocol exact-issue490 included-ranges; do
 case "$selector" in
 protocol) pattern='^TestGoCIRecoveryProtocolMatrix$';;
 exact-issue490) pattern='^TestGoIssue490FragmentBoundaryLockedC$';;
 included-ranges) pattern='^TestIncludedRangesGoRootParity$';;
 esac
 set +e
 GTS_GO_CI_PROTOCOL=current "$scratch/cgo.test" -test.run "$pattern" -test.v -test.count=1 > "/evidence/$selector.log" 2>&1
 code=$?
 set -e
 printf '%s\t%s\n' "$selector" "$code" >> /evidence/status.tsv
done
GTS_ADMISSION_REAL_CORPUS_LANGS=go "$scratch/cgo.test" -test.run '^TestCompactR4StructuralLockedC$' -test.v -test.count=1 > /evidence/r4-go.log 2>&1
sha256sum "$scratch/cgo.test" > /evidence/binary.sha256
printf 'reserved candidate diagnostics complete; inspect exact C status rows\n' > /evidence/completed.txt
