#!/usr/bin/env python3
"""Prepare/read-authenticate controls only; no Go builds, parsers or tests."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import struct
import subprocess

CONTROL = Path(__file__).resolve().parent
PARENT = CONTROL.parent
ROOT = PARENT.parents[2]
TEST = "ledger_first_edit_parity_test.go.txt"
TARGET = "cgo_harness/ledger_default_first_edit_exact_c_v2_private_test.go"
V1_TARGET = "cgo_harness/ledger_default_first_edit_exact_c_private_test.go"
V1_SHA = "b7ca8e62114489080e30ee980216a5910f555e2689500efca9d648c2e8fd872b"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def dump(name: str, value: object) -> None:
    (CONTROL / name).write_text(json.dumps(value, indent=2) + "\n")


def point(data: bytes, offset: int) -> tuple[int, int]:
    prefix = data[:offset]
    return prefix.count(b"\n"), offset - prefix.rfind(b"\n") - 1


def session(initial: bytes) -> tuple[str, dict]:
    current = initial
    state = 4242
    result = hashlib.sha256()
    first = {}
    for index in range(72):
        state = (state * 1664525 + 1013904223) & 0xffffffff
        at = state % len(current) if current else 0
        old_end = new_end = at
        if index % 3 == 0:
            after = current[:at] + b"x" + current[at:]
            new_end += 1
        elif index % 3 == 1:
            old_end += int(at < len(current))
            after = current[:at] + current[old_end:]
        else:
            old_end += int(at < len(current))
            new_end += int(at < len(current))
            after = current
            if at < len(current):
                after = current[:at] + (b"y" if current[at] == ord("x") else b"x") + current[at + 1:]
        fields = (at, old_end, new_end, *point(current, at), *point(current, old_end), *point(after, new_end))
        result.update(struct.pack("<9I", *fields))
        result.update(hashlib.sha256(after).digest())
        if index == 0:
            first = {"start_byte": at, "old_end_byte": old_end, "new_end_byte": new_end,
                     "start_point": point(current, at), "old_end_point": point(current, old_end),
                     "new_end_point": point(after, new_end), "bytes": len(after), "sha256": sha(after)}
        current = after
    return result.hexdigest(), first


v1 = PARENT / "ledger-parity" / TEST
assert sha(v1.read_bytes()) == V1_SHA, "frozen v1 changed"
manifest_path = ROOT / "internal/benchfixtures/real_corpus.json"
entries = json.loads(manifest_path.read_text())["entries"]
# Match the collector's assignment policy over the complete entry sequence.
selected = {row["language"]: row for row in entries if row["role"] == "sample"}
fixtures = []
for name in ("c", "eds"):
    row = selected[name]
    source = (ROOT / "internal/benchfixtures" / row["committed_path"]).read_bytes()
    editing_session_sha, first = session(source)
    assert sha(source) == row["sha256"]
    assert editing_session_sha == row["session_sha256"]
    assert len(source) == row["bytes"]
    references = {}
    for variant in ("before", "after"):
        path = PARENT / f"out/final-ledger-fleet/{variant}/default-{name}.json"
        rows = json.loads(path.read_text())
        assert len(rows) == 1
        reference = rows[0]
        assert reference["language"] == name and reference["route"] == "default" and reference["fixture"] == "real_sample"
        assert reference["fixture_sha256"] == row["sha256"]
        assert reference["session_sha256"] == editing_session_sha
        assert reference["full"]["input_bytes"] == len(source)
        assert len(reference["edits"]) == 1
        assert reference["edits"][0]["step"] == 1 and reference["edits"][0]["kind"] == "insert"
        assert reference["edits"][0]["counters"]["input_bytes"] == first["bytes"]
        references[variant] = {"path": "/controls/" + str(path.relative_to(PARENT)),
                               "bytes": path.stat().st_size, "sha256": sha(path.read_bytes())}
    fixtures.append({"language": name, "committed_path": row["committed_path"], "bytes": len(source),
                     "sha256": row["sha256"], "session_sha256": editing_session_sha,
                     "first_edit": first, "counter_references": references})

for placement, root, controls in (("container", "/candidate", "/controls/ledger-parity-v2"),
                                   ("host", str(ROOT), str(CONTROL))):
    dump("overlay." + placement + ".json", {"Replace": {
        root + "/" + TARGET: controls + "/" + TEST,
        root + "/" + V1_TARGET: ""}})

source = (CONTROL / TEST).read_text()
body = source[source.index("func TestLedgerDefaultFirstEditExactCV2("):source.index("func ledgerParityV2RequireCounters(")]
start = body.index("parser := gts.NewParser(language)")
capture = body.index("// Everything above is complete before inspection or any C interaction.")
hot = body[start:capture]
for forbidden in ("InspectGoTree", "assertLockedCTree", "COracle", "sitter.NewParser", "t.Log", "json.Marshal", ".Child("):
    assert forbidden not in hot, "forbidden work before first-edit capture: " + forbidden
assert hot.count("gts.NewParser(") == 1
assert hot.index("old.Edit(step.Edit)") < hot.index("parser.ParseIncrementalProfiled(step.Source, old)")
assert body.index("COracleLanguage(name)") > capture
assert body.index("freshParser := gts.NewParser(language)") > capture
assert 'if mode == "initial-only" {' in body
assert 'ledgerParityV2RequireCounters(t, path, name, want.sha, want.session, full, editCounters)' in body
assert 'check("full", rows[0].Full, full)' in source
assert 'check("first-edit", rows[0].Edits[0].Counters, *edit)' in source

source_paths = ["cmd/perfcounterledger/main.go", "internal/benchfixtures/edit_session.go",
                "internal/benchfixtures/go_tree_digest.go", "internal/benchfixtures/deep_digest.go",
                "cgo_harness/parity_swift_condition_field_regression_test.go",
                "cgo_harness/benchmark_real_corpus_parity_test.go", "cgo_harness/parity_c_loader_cgo.go", "parser_api.go"]
dump("manifest.json", {
    "git_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "purpose": "Uninspected default C/EDS first-edit ledger sequence followed by strict C/D8 adjudication",
    "v1_preserved_sha256": V1_SHA,
    "v1_limit": "Old Go children were inspected before Tree.Edit; do not use v1 to authenticate untouched ledger counters.",
    "build_tags": "treesitter_c_parity", "selector": "^TestLedgerDefaultFirstEditExactCV2$",
    "environment_one_grammar_and_mode_per_process": {
        "GTS_LEDGER_PARITY_LANGUAGE": "c OR eds", "GTS_LEDGER_PARITY_MODE": "initial-only OR first-edit",
        "GTS_LEDGER_PARITY_EXPECTED_COUNTERS": "/controls/out/final-ledger-fleet/before-or-after/default-<language>.json",
        "GTS_ADMISSION_CANDIDATE": "0", "GOMAXPROCS": "1"},
    "optional_counter_reference_mismatch_fails_test": True,
    "initial_only_reference_checks_full_only": True,
    "first_edit_reference_checks_both_full_and_edit_exact_schema_and_integer_values": True,
    "C_old_tree_built_after_profile": True,
    "all_parity_checks_after_counter_capture": True,
    "first_edit_direct_D8_full_axis_and_digest": True,
    "runtime_overlays_supplied_by_parent": True, "source_manifest_sha256": sha(manifest_path.read_bytes()),
    "fixtures": fixtures,
    "sources": {path: {"bytes": (ROOT / path).stat().st_size, "sha256": sha((ROOT / path).read_bytes())} for path in source_paths},
    "test": {"bytes": (CONTROL / TEST).stat().st_size, "sha256": sha((CONTROL / TEST).read_bytes())},
    "static_control_flow_check": "One NewParser before capture; no child walk, C setup, logging, JSON or extra Go parse in the measured sequence.",
    "builds_tests_benchmarks_run": False})
print(json.dumps({"test_sha256": sha((CONTROL / TEST).read_bytes()), "v1_preserved": True,
                  "fixture_and_counter_identities_match": True, "static_control_flow_check_passed": True,
                  "builds_tests_benchmarks_run": False}))
