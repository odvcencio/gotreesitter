set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly -overlay=/controls/reserved-perf-overlay.json'
[[ -f /controls/out/reserved-fleet/validated-summary.json && -f /controls/out/reserved-contained-c4/completed.txt ]] || exit 2
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
sha256sum --quiet -c /controls/counter-controls/baseline-source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/perf-controls/control-inputs.sha256 > /evidence/controls-before.log 2>&1
sha256sum --quiet -c /controls/perf-controls/r4-input.sha256 > /evidence/r4-input-before.log 2>&1
for language in go yaml; do
 GTS_ADMISSION_REAL_CORPUS_LANGS=$language bash scripts/run_randomized_benchmarks.sh --output "/evidence/r4-after-$language.txt" --baseline-root /baseline --baseline-output "/evidence/r4-before-$language.txt" --lock-path /evidence/benchmark.lock --bench-regex '^BenchmarkCompactGraduationR4$' --require-benchmarks BenchmarkCompactGraduationR4/legacy,BenchmarkCompactGraduationR4/compact --runs 20 --seed-start 1 --benchtime 750ms > "/evidence/r4-runner-$language.log" 2>&1
done
sha256sum --quiet -c /controls/counter-controls/baseline-source.sha256 > /evidence/source-after.log 2>&1
sha256sum --quiet -c /controls/perf-controls/control-inputs.sha256 > /evidence/controls-after.log 2>&1
sha256sum --quiet -c /controls/perf-controls/r4-input.sha256 > /evidence/r4-input-after.log 2>&1
printf 'R4 pairs complete; primary sources and controls also unchanged since their completed runs\n' > /evidence/completed.txt
