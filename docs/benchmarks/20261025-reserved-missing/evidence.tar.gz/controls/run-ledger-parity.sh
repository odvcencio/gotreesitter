set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/ledger-parity
mkdir -p "$scratch"
cd /baseline/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -overlay=/controls/ledger-before-overlay.json -o "$scratch/before.test" . > /evidence/before-build.log 2>&1
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -overlay=/controls/ledger-parity-v2/overlay.container.json -o "$scratch/after.test" . > /evidence/after-build.log 2>&1
for role in before after; do
 if [[ "$role" = before ]]; then cd /baseline/cgo_harness; else cd /candidate/cgo_harness; fi
 for language in c eds; do
  for mode in initial-only first-edit; do
   set +e
   GTS_ADMISSION_CANDIDATE=0 GTS_LEDGER_PARITY_LANGUAGE=$language GTS_LEDGER_PARITY_MODE=$mode GTS_LEDGER_PARITY_EXPECTED_COUNTERS="/controls/out/final-ledger-fleet/$role/default-$language.json" "$scratch/$role.test" -test.run '^TestLedgerDefaultFirstEditExactCV2$' -test.count=1 -test.v > "/evidence/$role-$language-$mode.log" 2>&1
   code=$?
   set -e
   printf '%s\t%s\t%s\t%s\n' "$role" "$language" "$mode" "$code" >> /evidence/status.tsv
  done
 done
done
# Complete raw guard observations with the prebuilt trace binary; no decision changes.
cd /candidate
set +e
GTS_OWNED_RECOVERY_EXPECT_BLOB_SHA256=9ad1f8d7d0f2b9aa32c61bd8295b56177caabb0ae2fb8dd4617559ee0f71fed4 GTS_OWNED_RECOVERY_GUARD_BINARY=/runtime/tmp/gotreesitter-go-ci-20261025/recovery-guard/root.test GTS_OWNED_RECOVERY_GUARD_OUT=/evidence/guard-json bash /controls/recovery-continuation/guard-trace/run.sh
code=$?
set -e
printf 'guard_json\t%s\n' "$code" >> /evidence/status.tsv
if [[ -f /evidence/guard-json/receipt.json ]]; then chmod 644 /evidence/guard-json/receipt.json; fi
cd /candidate/cgo_harness
REPRO_LANG=go REPRO_FILE=/controls/ledger-parity-v2/joined31.go.txt REPRO_CLOG=1 /runtime/tmp/gotreesitter-go-ci-20261025/doxygen-trace/cgo.test -test.run '^TestCTreeDumpDiag$' -test.count=1 -test.v > /evidence/joined31-physical-c.log 2>&1
sha256sum "$scratch/before.test" "$scratch/after.test" > /evidence/binary.sha256
printf 'exact fixture counter-sequence parity probes complete; retain every red result\n' > /evidence/completed.txt
