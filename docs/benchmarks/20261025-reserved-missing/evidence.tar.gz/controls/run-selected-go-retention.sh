set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/selected-go-retention
mkdir -p "$scratch"
cd /candidate
go build -tags gts_parsercorephase0 -overlay=/controls/selected-go-retention/overlay.json -o "$scratch/ledger" ./cmd/perfcounterledger > /evidence/ledger-build.log 2>&1
mkdir -p /evidence/ledger
for route in default candidate; do
 candidate=0
 if [[ "$route" = candidate ]]; then candidate=1; fi
 while IFS= read -r language; do
  GTS_ADMISSION_CANDIDATE=$candidate "$scratch/ledger" --child-route="$route" --langs "$language" > "/evidence/ledger/$route-$language.json"
  printf '%s\t%s\t0\n' "$route" "$language" >> /evidence/status.tsv
 done < /controls/fleet-controls/languages.txt
done
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -overlay=/controls/selected-go-retention/overlay.json -o "$scratch/cgo.test" . > /evidence/cgo-build.log 2>&1
"$scratch/cgo.test" -test.run '^Test(GoIssue490FragmentBoundaryLockedC|GoHiddenMissingSemicolonEditsMatchLockedC|IncludedRangesGoRootParity)$' -test.v -test.count=1 > /evidence/exact-c-and-ranges.log 2>&1
"$scratch/cgo.test" -test.run '^Test(Go(Compact|TokenInvariant|Unterminated|GeneratedNUL|NewMake|Cognociente|MalformedDeclaration|AssignmentTarget)|Stage6GoCompactCertification|CanonicalGoBenchmarkPreflight)' -test.v -test.count=1 > /evidence/go-cgo.log 2>&1
sha256sum "$scratch/ledger" "$scratch/cgo.test" > /evidence/binary.sha256
printf 'selected-result retention candidate correctness/counter probes complete; no timing or promotion claim\n' > /evidence/completed.txt
