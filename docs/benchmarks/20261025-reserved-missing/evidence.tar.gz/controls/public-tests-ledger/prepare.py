#!/usr/bin/env python3
"""Authenticate the small public regressions; do not build or run Go."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

CONTROL = Path(__file__).resolve().parent
PARENT = CONTROL.parent
ROOT = PARENT.parents[2]
TEST = "cgo_hidden_missing_corpus_test.go.txt"
TARGET = "cgo_harness/cgo_hidden_missing_corpus_test.go"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


source = (CONTROL / TEST).read_text()
names = re.findall(r"^func (Test\w+)\(", source, re.M)
expected_names = ["TestCHiddenMissingCorpusFreshLockedC", "TestCHiddenMissingCorpusFirstEditLockedC",
                  "TestEDSHiddenMissingCorpusFreshLockedC", "TestEDSHiddenMissingCorpusFirstEditLockedC"]
assert names == expected_names
start = source.index("parser := gts.NewParser(language)")
capture = source.index("// Counter capture is complete.")
hot = source[start:capture]
for forbidden in ("InspectGoTree", "assertLockedCTree", "COracle", "sitter.NewParser", "t.Log", "json.Marshal", ".Child("):
    assert forbidden not in hot, "forbidden work before first-edit capture: " + forbidden
assert hot.count("gts.NewParser(") == 1
assert "parser.SetAdmissionCandidateRoute(false)" in hot
assert hot.index("old.Edit(step.Edit)") < hot.index("parser.ParseIncrementalProfiled(step.Source, old)")
assert source.index("COracleLanguage(name)") > capture
assert source.index("freshParser := gts.NewParser(language)") > capture
assert source.index("hidden_missing_corpus_counters=") > capture
for forbidden in ("os.Getenv", "GTS_", "ledgerParityV2", "EXPECTED_COUNTERS", "out/final-ledger-fleet"):
    assert forbidden not in source, "private control dependency in public test: " + forbidden
assert 'if !cSection.HasError() || !goSection.HasError() {' in source

# Counter field types and JSON keys match the real ledger, with no float
# conversion or omitted-zero behavior. These are logging receipts, not ratchets.
ledger = (ROOT / "cmd/perfcounterledger/main.go").read_text()
counter_type = re.search(r"type counters struct \{\n(.*?)\n}", ledger, re.S).group(1)
test_counter_type = re.search(r"type hiddenMissingCorpusCounters struct \{\n(.*?)\n}", source, re.S).group(1)
assert counter_type == test_counter_type

manifest = json.loads((ROOT / "internal/benchfixtures/real_corpus.json").read_text())
selected = {row["language"]: row for row in manifest["entries"] if row["role"] == "sample"}
fixtures = []
for language in ("c", "eds"):
    row = selected[language]
    data = (ROOT / "internal/benchfixtures" / row["committed_path"]).read_bytes()
    assert len(data) == row["bytes"] and sha(data) == row["sha256"]
    assert row["sha256"] in source and row["session_sha256"] in source
    assert row["committed_path"] == "testdata/real/" + language
    references = {}
    for variant in ("before", "after"):
        path = PARENT / f"out/final-ledger-fleet/{variant}/default-{language}.json"
        reference = json.loads(path.read_text())
        assert len(reference) == 1
        assert reference[0]["fixture_sha256"] == row["sha256"]
        assert reference[0]["session_sha256"] == row["session_sha256"]
        references[variant] = {"path": str(path.relative_to(PARENT)), "bytes": path.stat().st_size, "sha256": sha(path.read_bytes())}
    fixtures.append({"language": language, "bytes": row["bytes"], "sha256": row["sha256"],
                     "session_sha256": row["session_sha256"], "committed_path": row["committed_path"],
                     "private_review_receipts_only": references})

for placement, candidate, controls in (("container", "/candidate", "/controls/public-tests-ledger"),
                                       ("host", str(ROOT), str(CONTROL))):
    (CONTROL / f"overlay.{placement}.json").write_text(json.dumps({"Replace": {
        candidate + "/" + TARGET: controls + "/" + TEST}}, indent=2) + "\n")
record = {
    "public_test_target": TARGET, "top_tests": names,
    "one_grammar_per_process_selectors": {
        "c": "^TestCHiddenMissingCorpus(Fresh|FirstEdit)LockedC$",
        "eds": "^TestEDSHiddenMissingCorpus(Fresh|FirstEdit)LockedC$"},
    "build_tags": "treesitter_c_parity", "new_environment_knobs": False,
    "default_route_explicit": True, "token_source_factory_used": False,
    "first_edit_counter_capture_before_any_deep_walk_C_setup_log_or_extra_Go_parse": True,
    "C_old_tree_built_after_profile": True,
    "direct_D8_full_axis_deep_digest_equality": True,
    "Go_C_structural_flags_fields_spans_points_and_digest_assertions": "existing assertLockedCTreeExactWithErrors helper",
    "EDS_first_section_error_is_an_explicit_negative_regression": True,
    "counter_type_matches_real_ledger_exactly": True,
    "counter_values_changed_or_ratchets_relaxed": False,
    "receipt_approval_or_ledger_rows_modified": False,
    "private_alternatives_modified": False,
    "builds_tests_benchmarks_run": False,
    "fixtures": fixtures,
    "test": {"bytes": (CONTROL / TEST).stat().st_size, "sha256": sha((CONTROL / TEST).read_bytes())}}
(CONTROL / "manifest.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"top_tests": names, "test_sha256": record["test"]["sha256"],
                  "static_sequence_checks_passed": True, "builds_tests_benchmarks_run": False}))
