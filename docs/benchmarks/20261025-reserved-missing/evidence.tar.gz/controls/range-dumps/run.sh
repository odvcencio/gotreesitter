#!/usr/bin/env bash
set -euo pipefail
: "${GTS_GO_RANGE_DUMP_BINARY:?select the prebuilt diagnostic cgo test binary}"
: "${GTS_GO_RANGE_DUMP_OUT:?select a private evidence directory}"
mkdir -p "$GTS_GO_RANGE_DUMP_OUT"
if [[ -e "$GTS_GO_RANGE_DUMP_OUT/run.log" || -e "$GTS_GO_RANGE_DUMP_OUT/receipt.json" || -e "$GTS_GO_RANGE_DUMP_OUT/process-status.json" ]]; then
 echo 'refusing to overwrite earlier range-dump evidence; choose a fresh output directory' >&2
 exit 2
fi
cd /candidate/cgo_harness
set +e
GTS_GO_RANGE_DUMP_RECEIPT_OUT="$GTS_GO_RANGE_DUMP_OUT/receipt.json" "$GTS_GO_RANGE_DUMP_BINARY" -test.run '^TestGoIncludedRangeFullTreeDumpsPrivate$' -test.v -test.count=1 > "$GTS_GO_RANGE_DUMP_OUT/run.log" 2>&1
status=$?
set -e
printf '{"exit_code":%d,"expected_cases":8,"strict_comparison":true,"failed_comparisons_remain_failures":true}\n' "$status" > "$GTS_GO_RANGE_DUMP_OUT/process-status.json"
exit "$status"
