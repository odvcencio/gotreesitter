set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate/cgo_harness
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/missing-trace
mkdir -p "$scratch"
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -overlay=/controls/missing-trace-overlay.json -o "$scratch/cgo.test" . > /evidence/build.log 2>&1
set +e
"$scratch/cgo.test" -test.run '^TestGoCIReservedRemainingDiffs$/^small_joined$/^production$' -test.count=1 -test.v > /evidence/trace.log 2>&1
code=$?
set -e
printf 'strict_c_trace\t%s\n' "$code" > /evidence/status.tsv
sha256sum "$scratch/cgo.test" > /evidence/binary.sha256
