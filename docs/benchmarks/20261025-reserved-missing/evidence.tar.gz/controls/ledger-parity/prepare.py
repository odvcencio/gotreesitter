#!/usr/bin/env python3
"""Prepare identities and overlays without Go builds, parsers or benchmarks."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import struct
import subprocess

CONTROL = Path(__file__).resolve().parent
PARENT = CONTROL.parent
ROOT = PARENT.parents[2]
TEST = "ledger_first_edit_parity_test.go.txt"
TARGET = "cgo_harness/ledger_default_first_edit_exact_c_private_test.go"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def dump(name: str, value: object) -> None:
    (CONTROL / name).write_text(json.dumps(value, indent=2) + "\n")


def point(data: bytes, offset: int) -> tuple[int, int]:
    prefix = data[:offset]
    return prefix.count(b"\n"), offset - prefix.rfind(b"\n") - 1


def session(initial: bytes) -> tuple[str, dict]:
    current = initial
    state = 4242
    result = hashlib.sha256()
    first = {}
    for index in range(72):
        state = (state * 1664525 + 1013904223) & 0xffffffff
        at = state % len(current) if current else 0
        old_end = new_end = at
        if index % 3 == 0:
            after = current[:at] + b"x" + current[at:]
            new_end += 1
        elif index % 3 == 1:
            old_end += int(at < len(current))
            after = current[:at] + current[old_end:]
        else:
            old_end += int(at < len(current))
            new_end += int(at < len(current))
            after = current
            if at < len(current):
                after = current[:at] + (b"y" if current[at] == ord("x") else b"x") + current[at + 1:]
        fields = (at, old_end, new_end, *point(current, at), *point(current, old_end), *point(after, new_end))
        result.update(struct.pack("<9I", *fields))
        result.update(hashlib.sha256(after).digest())
        if index == 0:
            first = {"start_byte": at, "old_end_byte": old_end, "new_end_byte": new_end,
                     "start_point": point(current, at), "old_end_point": point(current, old_end),
                     "new_end_point": point(after, new_end), "bytes": len(after), "sha256": sha(after)}
        current = after
    return result.hexdigest(), first


manifest_path = ROOT / "internal/benchfixtures/real_corpus.json"
manifest = json.loads(manifest_path.read_text())
fixtures = []
for name, expected_sha, expected_session in (
    ("c", "ccdf9a3671f4f291c653fce2ee409557cadddc893494c112ce49a1cf9c139917", "b9cefc3950abd10a96cc068ecfc6f42c591268d5c67371c8bc6b1e2258f3eb73"),
    ("eds", "e874774d9088e4605cffedaf3af14d98aa1a68f76e24748194468b5fe3300226", "980d7054da1d543ca7d179783642dc6c7280b77ab3f400ad3f0993566fef4404"),
):
    rows = [row for row in manifest["entries"] if row["language"] == name and row["role"] == "sample"]
    assert len(rows) == 1
    row = rows[0]
    source = (ROOT / "internal/benchfixtures" / row["committed_path"]).read_bytes()
    editing_session_sha, first = session(source)
    assert sha(source) == row["sha256"] == expected_sha
    assert editing_session_sha == row["session_sha256"] == expected_session
    assert len(source) == row["bytes"]
    fixtures.append({"language": name, "committed_path": row["committed_path"], "bytes": len(source),
                     "sha256": expected_sha, "session_sha256": expected_session, "first_edit": first})

for placement, target, replacement in (
    ("container", "/candidate/" + TARGET, "/controls/ledger-parity/" + TEST),
    ("host", str(ROOT / TARGET), str(CONTROL / TEST)),
):
    dump("overlay." + placement + ".json", {"Replace": {target: replacement}})
source_paths = ["cmd/perfcounterledger/main.go", "internal/benchfixtures/edit_session.go",
                "internal/benchfixtures/go_tree_digest.go", "internal/benchfixtures/deep_digest.go",
                "cgo_harness/parity_swift_condition_field_regression_test.go",
                "cgo_harness/benchmark_real_corpus_parity_test.go", "cgo_harness/parity_c_loader_cgo.go"]
dump("manifest.json", {
    "git_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "purpose": "Exact default first-edit C/EDS fleet-ledger adjudication, no counter waiver or route change",
    "build_tags": "treesitter_c_parity", "selector": "^TestLedgerDefaultFirstEditExactC$",
    "environment_one_grammar_per_process": {"GTS_LEDGER_PARITY_LANGUAGE": "c OR eds", "GTS_ADMISSION_CANDIDATE": "0", "GOMAXPROCS": "1"},
    "overlay_target": TARGET, "runtime_overlays_supplied_by_parent": True,
    "source_manifest_sha256": sha(manifest_path.read_bytes()), "fixtures": fixtures,
    "sources": {path: {"bytes": (ROOT / path).stat().st_size, "sha256": sha((ROOT / path).read_bytes())} for path in source_paths},
    "test": {"bytes": (CONTROL / TEST).stat().st_size, "sha256": sha((CONTROL / TEST).read_bytes())},
    "exact_ledger_methods": ["NewParser(language)", "ResetAdmissionCandidateCounters()", "Parse(source)", "EditingSession(source)[0]", "old.Edit(step.Edit)", "ParseIncrementalProfiled(step.Source, old)"],
    "factory_used": False, "candidate_telemetry_enabled": False,
    "independent_go_parses_before_captured_first_edit": False,
    "initial_Go_result_is_fresh": True,
    "initial_and_first_edit_full_axis_C_checks": True, "first_edit_direct_D8_full_axis_check": True,
    "individual_parity_subtests_do_not_hide_later_comparisons": True,
    "C_runtime_and_grammar_provenance": "COracleIdentity JSON emitted by each process",
    "builds_tests_benchmarks_run": False})
print(json.dumps({"fixtures": fixtures, "test_sha256": sha((CONTROL / TEST).read_bytes()), "builds_tests_benchmarks_run": False}))
