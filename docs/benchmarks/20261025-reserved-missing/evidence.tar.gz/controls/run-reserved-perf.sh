set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly -overlay=/controls/reserved-perf-overlay.json'
[[ -f /controls/out/reserved-fleet/validated-summary.json && -f /controls/out/reserved-contained-c4/completed.txt ]] || { echo 'correctness prerequisites missing' >&2; exit 2; }
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
sha256sum --quiet -c /controls/counter-controls/baseline-source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/perf-controls/control-inputs.sha256 > /evidence/controls-before.log 2>&1
go version > /evidence/toolchain.txt
git rev-parse HEAD > /evidence/base-head.txt
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE=$route bash scripts/run_randomized_benchmarks.sh --output "/evidence/primary-after-$route.txt" --baseline-root /baseline --baseline-output "/evidence/primary-before-$route.txt" --lock-path /evidence/benchmark.lock --bench-regex '^BenchmarkGraduationGoSuite$' --require-benchmarks BenchmarkGraduationGoSuite/Full,BenchmarkGraduationGoSuite/Edit,BenchmarkGraduationGoSuite/NoEdit --runs 20 --seed-start 1 --benchtime 750ms > "/evidence/primary-runner-$route.log" 2>&1
done
for language in go yaml; do
 GTS_ADMISSION_REAL_CORPUS_LANGS=$language bash scripts/run_randomized_benchmarks.sh --output "/evidence/r4-after-$language.txt" --baseline-root /baseline --baseline-output "/evidence/r4-before-$language.txt" --lock-path /evidence/benchmark.lock --bench-regex '^BenchmarkCompactGraduationR4$' --require-benchmarks BenchmarkCompactGraduationR4/legacy,BenchmarkCompactGraduationR4/compact --runs 20 --seed-start 1 --benchtime 750ms > "/evidence/r4-runner-$language.log" 2>&1
done
sha256sum --quiet -c /controls/counter-controls/baseline-source.sha256 > /evidence/source-after.log 2>&1
sha256sum --quiet -c /controls/perf-controls/control-inputs.sha256 > /evidence/controls-after.log 2>&1
printf 'all standard shuffled paired processes completed; benchstat and ratchet review still required\n' > /evidence/completed.txt
