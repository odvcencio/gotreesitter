set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/retention-scope
mkdir -p "$scratch"
cd /candidate
for variant in no-creation no-summary; do
 go build -tags gts_parsercorephase0 -overlay="/controls/retention-scope/$variant-overlay.json" -o "$scratch/$variant" ./cmd/perfcounterledger > "/evidence/$variant-build.log" 2>&1
done
for variant in before current no-creation no-summary; do
 binary="$scratch/$variant"
 if [[ "$variant" = before ]]; then binary=/runtime/tmp/gotreesitter-go-ci-20261025/reserved-counters/before-ledger; fi
 if [[ "$variant" = current ]]; then binary=/runtime/tmp/gotreesitter-go-ci-20261025/final-ledger-fleet/after-ledger; fi
 for language in c eds; do
  for trial in 1 2 3; do
   GTS_ADMISSION_CANDIDATE=0 "$binary" --child-route=default --langs "$language" > "/evidence/$variant-$language-$trial.json"
  done
 done
done
printf 'causal scope controls complete; no performance timing or promotion\n' > /evidence/completed.txt
