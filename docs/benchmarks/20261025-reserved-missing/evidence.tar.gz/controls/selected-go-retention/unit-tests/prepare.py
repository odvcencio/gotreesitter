#!/usr/bin/env python3
"""Prepare selected-result tests only; never build or run Go."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

CONTROL = Path(__file__).resolve().parent
EVIDENCE = CONTROL.parent.parent
ROOT = EVIDENCE.parents[2]
original = ROOT / "parser_hidden_missing_creation_test.go"
source = original.read_text()


def once(text: str, old: str, new: str) -> str:
    assert text.count(old) == 1, old
    return text.replace(old, new, 1)


source = once(source, "func TestHiddenMissingCreationEnablesRawErrorPropagation(t *testing.T) {",
              "func TestHiddenMissingCreationDoesNotEnableGlobalRetention(t *testing.T) {")
source = once(source,
    '\t\t\t\tif !p.retainExternalFallbackMissingFlags {\n\t\t\t\t\tt.Fatal("actual MISSING creation did not retain its hidden history")\n\t\t\t\t}\n',
    '\t\t\t\tif p.retainExternalFallbackMissingFlags {\n\t\t\t\t\tt.Fatal("speculative MISSING creation enabled parser-wide retention")\n\t\t\t\t}\n')
source = once(source,
    '\t\t\t\tif !hidden.HasError() || !root.HasError() {\n\t\t\t\t\tt.Fatal("hidden MISSING did not propagate through flattened ancestors")\n\t\t\t\t}\n\t\t\t\tif !reconcileStaleHasErrorFlagsWithMissing(root, 0, p.retainExternalFallbackMissingFlags) || !root.HasError() {\n\t\t\t\t\tt.Fatal("selected-root reconciliation erased genuine hidden MISSING")\n\t\t\t\t}\n',
    '\t\t\t\tif hidden.HasError() || root.HasError() || p.retainExternalFallbackMissingFlags {\n\t\t\t\t\tt.Fatal("unselected raw MISSING contaminated generic publication")\n\t\t\t\t}\n\t\t\t\tif reconcileStaleHasErrorFlagsWithMissing(root, 0, p.retainExternalFallbackMissingFlags) || root.HasError() {\n\t\t\t\t\tt.Fatal("unselected raw history became an accepted error claim")\n\t\t\t\t}\n')
source = once(source,
    '\t// A speculative version inserts MISSING and is then discarded. The\n\t// parser latch stays on, but it must not become a tree-wide error bit.\n',
    '\t// A speculative version inserts MISSING and is then discarded. It\n\t// must not enable parser-wide retention or mutate the clean sibling.\n')
source = once(source,
    '\tif !p.retainExternalFallbackMissingFlags {\n\t\tt.Fatal("discarded genuine MISSING did not exercise the retained latch")\n\t}\n',
    '\tif p.retainExternalFallbackMissingFlags {\n\t\tt.Fatal("discarded speculative MISSING enabled parser-wide retention")\n\t}\n')
source = once(source,
    '\t\tt.Fatal("retained latch prevented clearing an unsupported error claim")\n',
    '\t\tt.Fatal("discarded trial prevented clearing an unsupported error claim")\n')
source = once(source,
    '\tif reparsed.RootNode().HasError() || reparsed.RootNode().SExpr(lang) != before || oldRoot.SExpr(lang) != before {\n\t\tt.Fatal("a later clean reparse inherited the speculative MISSING")\n\t}\n',
    '\tif reparsed.RootNode().HasError() || reparsed.RootNode().SExpr(lang) != before || oldRoot.SExpr(lang) != before {\n\t\tt.Fatal("a later clean reparse inherited the speculative MISSING")\n\t}\n'
    '\tvar noEditErr error\n\tnoEditNil := false\n'
    '\tallocations := testing.AllocsPerRun(5, func() {\n'
    '\t\tsame, err := p.ParseIncremental(source, oldTree)\n'
    '\t\tif err != nil {\n\t\t\tnoEditErr = err\n\t\t\treturn\n\t\t}\n'
    '\t\tif same == nil {\n\t\t\tnoEditNil = true\n\t\t\treturn\n\t\t}\n'
    '\t\tsame.Release()\n\t})\n'
    '\tif noEditErr != nil || noEditNil || allocations != 0 || p.retainExternalFallbackMissingFlags {\n'
    '\t\tt.Fatalf("clean no-edit control: error=%v nil=%t allocations=%g retained=%t", noEditErr, noEditNil, allocations, p.retainExternalFallbackMissingFlags)\n\t}\n'
    '\tfor node, flag := range flags {\n'
    '\t\tif node.flags != flag || node.parent != parents[node] || node.rawShape != 0 {\n'
    '\t\t\tt.Fatal("clean no-edit reuse mutated old-tree flags, parents or raw history")\n\t\t}\n\t}\n')
(CONTROL / "parser_hidden_missing_creation_test.go.txt").write_text(source)

mapping = {
    "parser_hidden_missing_creation_test.go": "parser_hidden_missing_creation_test.go.txt",
    "parser_selected_go_missing_retention_private_test.go": "parser_selected_go_missing_retention_test.go.txt",
}
for placement, candidate, controls in (("container", "/candidate", "/controls/selected-go-retention/unit-tests"),
                                        ("host", str(ROOT), str(CONTROL))):
    result = {"Replace": {candidate + "/" + target: controls + "/" + replacement for target, replacement in mapping.items()}}
    (CONTROL / ("overlay." + placement + ".json")).write_text(json.dumps(result, indent=2) + "\n")
manifest = {
    "only_private_unit_test_controls": True,
    "base_creation_test_sha256": hashlib.sha256(original.read_bytes()).hexdigest(),
    "runtime_overlay_supplied_by_parent": "/controls/selected-go-retention/overlay.json",
    "selected_pipeline_fake_language_helper": "goCompatMemoryBudgetTestLanguage",
    "selector": "^TestHiddenMissing(CreationDoesNotEnableGlobalRetention|DiscardedTrialPreservesCleanSiblingAndOldTree|ZeroWidthAutomaticTokenDoesNotLatch|SelectedGoCompatibilityOwnsRetention|GoCompatProjectionAndEvidence|RepairedVisibleTokenDoesNotCreateEvidence)$",
    "ordinary_and_extra_missing_both_assert_materialized_Missing_and_HasError": True,
    "ordinary_and_extra_missing_both_assert_no_global_retention": True,
    "compact_configurations_preserved": ["node", "compact-full-configured", "compact-no-tree-configured"],
    "selected_Go_tests_start_retention_false_and_call_actual_pipeline": True,
    "selected_layouts": ["children", "final-refs"],
    "stale_selected_error": "May arm selected-result retention, but must clear HasError/raw-only evidence without a genuine missing token.",
    "lower_level_projection_retain_true_controls_changed": False,
    "old_tree_flags_parents_raw_refs_preserved_before_and_after_no_edit": True,
    "clean_no_edit_allocations_asserted_zero": True,
    "tracked_source_or_runtime_changed": False, "builds_tests_benchmarks_run": False,
    "files": {path.name: {"bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
              for path in CONTROL.iterdir() if path.is_file() and path.name != "manifest.json"}}
(CONTROL / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"test_overlays": len(mapping), "builds_tests_benchmarks_run": False}))
