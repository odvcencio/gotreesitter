set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
cd /candidate
sha256sum --quiet -c /controls/final-promoted-source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/out/final-promoted/binary.sha256 > /evidence/binary-before.log 2>&1
GTS_C4_FLEET_RECEIPT=1 /runtime/tmp/gotreesitter-go-ci-20261025/final-promoted/root.test -test.run '^TestParserCoreCorridorFleetTableShapeReceipt$' -test.count=1 -test.v > /evidence/fleet.log 2>&1
sha256sum --quiet -c /controls/final-promoted-source.sha256 > /evidence/source-after.log 2>&1
printf 'final saved-source 206-grammar C4 fleet receipt passed without overlays\n' > /evidence/completed.txt
