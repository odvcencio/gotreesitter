set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/reserved-contained
mkdir -p "$scratch"
cd /candidate
sha256sum --quiet -c /controls/counter-controls/baseline-source.sha256 > /evidence/source-before.log 2>&1
go test -overlay=/controls/reserved-contained-overlay.json ./grammargen -run 'Reserved|GoGrammarReserved' -count=1 -v > /evidence/grammar-reserved.log 2>&1
go test -overlay=/controls/reserved-contained-overlay.json ./grammars/runtime -run '^Test(GoMissingTurnRangeExclusionPrivate.*|BuiltinGoMissingVersionTurnsRequireExactBlobIdentity|BuiltinRuntimeProfilesStayNarrow)$' -count=1 -v > /evidence/runtime-grants.log 2>&1
go test -overlay=/controls/reserved-contained-overlay.json ./internal/parsercorephase0 -run '^TestNativeSelectedSnapshotContracts$' -count=1 -v > /evidence/native-grants.log 2>&1
go test -c -tags gts_parsercorephase0 -overlay=/controls/reserved-contained-overlay.json -o "$scratch/root.test" . > /evidence/root-build.log 2>&1
"$scratch/root.test" -test.run '^Test(MissingTurnRangeExclusionPrivate.*|HiddenMissing.*|RetainedHiddenMissingIgnoresRepairedVisibleNodes|RawErrorCostIncludesElidedMissingTerminal|Issue490GoGrammarRegression|ParserCoreCorridorTableShapeReceipt|ParserDerivedTables.*)$' -test.count=1 -test.v > /evidence/root-focused.log 2>&1
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -overlay=/controls/reserved-contained-overlay.json -o "$scratch/cgo.test" . > /evidence/cgo-build.log 2>&1
"$scratch/cgo.test" -test.run '^Test(GoIssue490FragmentBoundaryLockedC|GoCIReservedRemainingDiffs|GoHiddenMissingSemicolonEditsMatchLockedC)$' -test.count=1 -test.v > /evidence/exact-c-and-edit-transitions.log 2>&1
"$scratch/cgo.test" -test.run '^TestIncludedRangesGoRootParity$' -test.count=1 -test.v > /evidence/range-snapshots.log 2>&1
"$scratch/cgo.test" -test.run '^TestGoNextLiveArmProbe$/^$' -test.count=1 -test.v > /evidence/go-next-included-digest.log 2>&1
"$scratch/cgo.test" -test.run '^Test(Go(Compact|TokenInvariant|Unterminated|GeneratedNUL|NewMake|Cognociente|MalformedDeclaration|AssignmentTarget)|Stage6GoCompactCertification|CanonicalGoBenchmarkPreflight)' -test.count=1 -test.v > /evidence/go-cgo.log 2>&1
GTS_ADMISSION_REAL_CORPUS_LANGS=go "$scratch/cgo.test" -test.run '^TestCompactR4StructuralLockedC$' -test.count=1 -test.v > /evidence/go-r4-cgo.log 2>&1
set +e
GTS_RANGE_CONTAINMENT_CGO_BINARY="$scratch/cgo.test" GTS_RANGE_CONTAINMENT_OUT=/evidence/contained-ranges bash /controls/range-containment/run-prebuilt.sh range
code=$?
set -e
printf 'contained_strict_range_c\t%s\n' "$code" >> /evidence/status.tsv
cd /candidate
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE=$route GOTREESITTER_V1_INVARIANT_LANGUAGE=go "$scratch/root.test" -test.run '^TestV1InvariantGateR4EditSession$' -test.v -test.count=1 > "/evidence/go-invariant-$route.log" 2>&1
done
"$scratch/root.test" -test.run '^Test(CompactIncrementalExecution.*|CompactRecoveryMemoMemoryBudget|CompactAcceptanceReferenceAndRetainedArenasStayInMemoryBudget|CompactAcceptanceComparisonWorkspaceMemoryBudget|CompactAcceptanceChangedSourceKeepsRebuildBudget)$' -test.v -test.count=1 > /evidence/memory.log 2>&1
"$scratch/root.test" -test.run '^Test(DiagnosticParserCoreSummaryAcceptsExactQueryCompile|DiagnosticParserCoreSeedMatchesImmutableLegacyGolden|NativeNodeViews.*|QuiescentNativeGo.*)$' -test.v -test.count=1 > /evidence/publication-and-goldens.log 2>&1
go test -race -tags gts_parsercorephase0 -overlay=/controls/reserved-contained-overlay.json -run '^Test(NativeNodeViewsConcurrentReads|CompactIncrementalExecutionLifetime|HiddenMissing.*)$' -count=1 -v . > /evidence/race.log 2>&1
sha256sum --quiet -c /controls/counter-controls/baseline-source.sha256 > /evidence/source-after.log 2>&1
sha256sum "$scratch/root.test" "$scratch/cgo.test" > /evidence/binary.sha256
printf 'correctness safety and contained unsupported-mode rollout complete; no timing claim\n' > /evidence/completed.txt
