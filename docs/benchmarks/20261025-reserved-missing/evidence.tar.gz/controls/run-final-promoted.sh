set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/final-promoted
mkdir -p "$scratch"
cd /candidate
sha256sum --quiet -c /controls/final-promoted-source.sha256 > /evidence/source-before.log 2>&1
go test ./grammargen -run 'Reserved|GoGrammarReserved' -count=1 -v > /evidence/grammar.log 2>&1
go test ./grammars/runtime -run '^Test(GoMissingTurnRangeExclusion.*|BuiltinGoMissingVersionTurnsRequireExactBlobIdentity|BuiltinRuntimeProfilesStayNarrow)$' -count=1 -v > /evidence/runtime.log 2>&1
go test ./internal/parsercorephase0 -run '^TestNativeSelectedSnapshotContracts$' -count=1 -v > /evidence/native-contract.log 2>&1
go test -c -tags gts_parsercorephase0 -o "$scratch/root.test" . > /evidence/root-build.log 2>&1
"$scratch/root.test" -test.run '^Test(CompactRouteCampaignLifecycleRegistry|ParserCoreCorridor(Fleet)?TableShapeReceipt|MissingTurnRangeExclusion.*|HiddenMissing.*|ReservedRuntimePrefilter.*|Issue490GoGrammarRegression|DiagnosticParserCoreSummaryAcceptsExactQueryCompile|DiagnosticParserCoreSeedMatchesImmutableLegacyGolden)$' -test.count=1 -test.v > /evidence/root.log 2>&1
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o "$scratch/cgo.test" . > /evidence/cgo-build.log 2>&1
"$scratch/cgo.test" -test.run '^Test(GoIssue490FragmentBoundaryLockedC|GoHiddenMissingSemicolonEditsMatchLockedC|IncludedRangesGoRootParity)$' -test.count=1 -test.v > /evidence/exact-c-and-ranges.log 2>&1
"$scratch/cgo.test" -test.run '^TestGoNextLiveArmProbe$/^$' -test.count=1 -test.v > /evidence/go-next-pin.log 2>&1
GTS_ADMISSION_REAL_CORPUS_LANGS=go "$scratch/cgo.test" -test.run '^TestCompactR4StructuralLockedC$' -test.count=1 -test.v > /evidence/go-r4.log 2>&1
cd /candidate
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE=$route GOTREESITTER_V1_INVARIANT_LANGUAGE=go "$scratch/root.test" -test.run '^TestV1InvariantGateR4EditSession$' -test.v -test.count=1 > "/evidence/go-invariant-$route.log" 2>&1
done
sha256sum --quiet -c /controls/final-promoted-source.sha256 > /evidence/source-after.log 2>&1
sha256sum "$scratch/root.test" "$scratch/cgo.test" > /evidence/binary.sha256
printf 'final saved source checked without Go overlays; broader authenticated private-source gates retained\n' > /evidence/completed.txt
