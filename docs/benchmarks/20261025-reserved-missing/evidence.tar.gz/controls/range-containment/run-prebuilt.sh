#!/usr/bin/env bash
set -euo pipefail
if [[ $# != 1 || ( "$1" != range && "$1" != ordinary && "$1" != unit ) ]]; then
 echo 'usage: run-prebuilt.sh range|ordinary|unit' >&2
 exit 2
fi
: "${GTS_RANGE_CONTAINMENT_OUT:?select a fresh private evidence directory}"
mkdir -p "$GTS_RANGE_CONTAINMENT_OUT"
if [[ -e "$GTS_RANGE_CONTAINMENT_OUT/run.log" || -e "$GTS_RANGE_CONTAINMENT_OUT/process-status.json" ]]; then
 echo 'refusing to overwrite earlier containment evidence' >&2
 exit 2
fi
mode=$1
if [[ "$mode" = range ]]; then
 : "${GTS_RANGE_CONTAINMENT_CGO_BINARY:?select a prebuilt cgo binary with the dump test and chosen runtime overlays}"
 export GTS_GO_RANGE_DUMP_BINARY="$GTS_RANGE_CONTAINMENT_CGO_BINARY"
 export GTS_GO_RANGE_DUMP_OUT="$GTS_RANGE_CONTAINMENT_OUT"
 export GTS_GO_RANGE_EXPECT_BLOB_SHA256=9ad1f8d7d0f2b9aa32c61bd8295b56177caabb0ae2fb8dd4617559ee0f71fed4
 # Known range mismatches stay strict failures. Capture their JSON and status;
 # this command never turns a red comparison into parity or qualification.
 exec bash /controls/range-dumps/run.sh
fi
set +e
if [[ "$mode" = ordinary ]]; then
 : "${GTS_RANGE_CONTAINMENT_CGO_BINARY:?select a prebuilt cgo binary with the chosen runtime overlays}"
 cd /candidate/cgo_harness
 "$GTS_RANGE_CONTAINMENT_CGO_BINARY" -test.run '^Test(Go(Cognociente137KiBTopEditLockedC|MalformedDeclarationPrefixLockedC|AssignmentTargetEdits16SitesLockedC)|Stage6GoCompactCertification)$' -test.v -test.count=1 > "$GTS_RANGE_CONTAINMENT_OUT/run.log" 2>&1
 status=$?
else
 : "${GTS_RANGE_CONTAINMENT_ROOT_BINARY:?select the prebuilt root test binary}"
 cd /candidate
 "$GTS_RANGE_CONTAINMENT_ROOT_BINARY" -test.run '^TestMissingTurnRangeExclusionPrivate' -test.v -test.count=1 > "$GTS_RANGE_CONTAINMENT_OUT/run.log" 2>&1
 status=$?
fi
set -e
printf '{"mode":"%s","exit_code":%d,"compiled_here":false,"range_parity_claim":false}\n' "$mode" "$status" > "$GTS_RANGE_CONTAINMENT_OUT/process-status.json"
exit "$status"
