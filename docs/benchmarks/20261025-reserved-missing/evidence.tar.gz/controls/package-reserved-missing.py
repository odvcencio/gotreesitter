from pathlib import Path
import gzip, hashlib, io, json, re, subprocess, tarfile
repo=Path('/home/draco/work/gotreesitter')
root=repo/'harness_out/docker/go-ci-blockers-20261025'
pub=repo/'docs/benchmarks/20261025-reserved-missing'
base='eff701aa3962f88fbf6e8cd3b5994d7dca1d0a32'
members={}
def add(path, name):
    path=Path(path)
    if not path.is_file() or path.is_symlink(): return
    data=path.read_bytes()
    if data.startswith(b'\x7fELF') or data.startswith(b'MZ'):
        raise RuntimeError(f'executable excluded: {path}')
    assert not name.startswith('/') and '..' not in Path(name).parts
    old=members.get(name)
    assert old is None or old==data, name
    members[name]=data

dirs='baseline-eff701 c4-qualified counter-controls fleet-controls go-reserved hidden-missing issue490 ledger-parity ledger-parity-v2 missing-trace perf-controls public-tests public-tests-ledger range-containment range-diffs range-dumps reserved-assembly reserved-enrollment reserved-runtime retention-scope safety-pins selected-go-retention'.split()
for d in dirs:
    for f in (root/d).rglob('*'): add(f,'controls/'+str(f.relative_to(root)))
outputs='missing-trace reserved-candidate reserved-contained reserved-contained-c4 reserved-contained-resume reserved-counters reserved-diffs reserved-fleet reserved-generation reserved-hidden reserved-perf reserved-projection reserved-r4-perf final-promoted final-c4-fleet final-c4-fleet-sandbox final-ledger-fleet retention-scope selected-go-retention ledger-parity public-ledger-regressions recovery-guard'.split()
for d in outputs:
    terminal=root/'out'/d/'finished.json'
    assert terminal.exists(),d
    for f in (root/'out'/d).rglob('*'): add(f,'controls/'+str(f.relative_to(root)))
for f in (root/'recovery-continuation/guard-trace').rglob('*'): add(f,'controls/'+str(f.relative_to(root)))
for pattern in ['*overlay*.json','reserved*inputs.json','promoted-source-map.json','final-promoted-source.sha256']:
    for f in root.glob(pattern): add(f,'controls/'+f.name)
for d in outputs:
    if d.endswith('-sandbox'): continue
    for pre,suf in [('run-','.sh'),('worker-','.py'),('commands-','.json')]:
        f=root/(pre+d+suf)
        if f.is_file(): add(f,'controls/'+f.name)
for name in ['ea-census/frozen-r4-manifest.json','package-reserved-missing.py']:
    add(root/name,'controls/'+name)
prior=repo/'harness_out/docker/go-reuse-20261025'
add(prior/'recovery-work-main.go','prior-controls/recovery-work-main.go')
# Close over explicit source/control file references in the saved scripts and maps.
# References into /baseline and /candidate resolve from the named Git base plus the source snapshot.
for _ in range(5):
    n=len(members)
    for data in list(members.values()):
        try: s=data.decode('utf-8')
        except UnicodeDecodeError: continue
        for ref in re.findall(r'/(?:controls|prior-controls)/[A-Za-z0-9_./+\-]+',s):
            prefix,rel=ref[1:].split('/',1)
            f=(root if prefix=='controls' else prior)/rel
            if f.is_file(): add(f,prefix+'/'+rel)
        for ref in re.findall(r'/home/draco/work/gotreesitter/harness_out/[A-Za-z0-9_./+\-]+',s):
            f=Path(ref)
            if f.is_file(): add(f,'referenced/'+str(f.relative_to(repo/'harness_out')))
    if len(members)==n: break
source_map=json.loads((root/'promoted-source-map.json').read_text())
source_names={x['destination'] for x in source_map['files']}
source_names.update(['parser_go_regression_test.go','cgo_harness/hidden_missing_corpus_parity_test.go'])
source_rows=[]
for name in sorted(source_names):
    f=repo/name
    add(f,'source/'+name)
    source_rows.append({'path':name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size})
(pub/'source-identities.json').write_text(json.dumps({'base_head':base,'files':source_rows},indent=2)+'\n')
members['source/changes.patch']=subprocess.check_output(['git','diff','--binary',base,'--',*sorted(source_names)],cwd=repo)
for name in ['README.md','counter-review.md','counter-deltas.json','verification.json','source-identities.json']:
    add(pub/name,'receipt/'+name)
members['MANIFEST.json']=(json.dumps({'schema':'gts-reserved-missing-evidence/v1','base_head':base,'notes':['Files retain original contents; controls, prior-controls and source identify their replay roles.','Source patch covers tracked modifications; source/ contains complete new files as well.','Toolchains, executables, caches, private CSV/Enforce samples and unqualified performance prototypes are excluded.','Some diagnostic steps are intentionally red; finished/status/log receipts distinguish them from qualification.'], 'members':[{'path':k,'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()} for k,v in sorted(members.items())]},indent=2)+'\n').encode()
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w') as tar:
    for k,v in sorted(members.items()):
        info=tarfile.TarInfo(k); info.size=len(v); info.mode=0o644; info.mtime=0
        tar.addfile(info,io.BytesIO(v))
archive=pub/'evidence.tar.gz'
with archive.open('wb') as f:
    with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z: z.write(buf.getvalue())
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
(pub/'evidence.sha256').write_text(f'{sha}  evidence.tar.gz\n')
print(json.dumps({'members':len(members),'source_files':len(source_rows),'uncompressed_bytes':len(buf.getvalue()),'archive_bytes':archive.stat().st_size,'sha256':sha}))
