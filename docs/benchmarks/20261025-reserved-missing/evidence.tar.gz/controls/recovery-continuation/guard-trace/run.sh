#!/usr/bin/env bash
set -euo pipefail
: "${GTS_OWNED_RECOVERY_GUARD_BINARY:?select the prebuilt trace-overlay root-package test binary}"
: "${GTS_OWNED_RECOVERY_GUARD_OUT:?select a fresh private evidence directory}"
mkdir -p "$GTS_OWNED_RECOVERY_GUARD_OUT"
if [[ -e "$GTS_OWNED_RECOVERY_GUARD_OUT/run.log" || -e "$GTS_OWNED_RECOVERY_GUARD_OUT/receipt.json" || -e "$GTS_OWNED_RECOVERY_GUARD_OUT/process-status.json" ]]; then
 echo 'refusing to overwrite earlier guard-trace evidence; choose a fresh output directory' >&2
 exit 2
fi
cd /candidate
set +e
GTS_OWNED_RECOVERY_GUARD_RECEIPT_OUT="$GTS_OWNED_RECOVERY_GUARD_OUT/receipt.json" "$GTS_OWNED_RECOVERY_GUARD_BINARY" -test.run '^TestPrivateOwnedRecoveryGuardTrace(SoleSurvivor)?$' -test.v -test.count=1 > "$GTS_OWNED_RECOVERY_GUARD_OUT/run.log" 2>&1
status=$?
set -e
printf '{"exit_code":%d,"native_route_cases":3,"synthetic_handoff_probe":1,"c_parity_checked_here":false,"native_declines_remain_failures":true,"decisions_changed":false}\n' "$status" > "$GTS_OWNED_RECOVERY_GUARD_OUT/process-status.json"
exit "$status"
