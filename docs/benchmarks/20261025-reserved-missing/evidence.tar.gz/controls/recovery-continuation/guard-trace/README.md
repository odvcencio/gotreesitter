This is a separate trace-only variant. The first draft controls in the parent directory are unchanged. No engine decision changes; two hooks observe the existing EOF-only and sole-survivor publication guards.

Build with the contained 9ad artifact/runtime controls plus this `overlay.json`. Exact test selector: `^TestPrivateOwnedRecoveryGuardTrace(SoleSurvivor)?$`. The main test runs clean32, pinned joined31, and the owned-EOF positive control. Joined31 remains red while compact declines. The synthetic sole-survivor probe isolates the second policy boundary; it is not C-parity evidence.

`run.sh` consumes a prebuilt `GTS_OWNED_RECOVERY_GUARD_BINARY` and fresh `GTS_OWNED_RECOVERY_GUARD_OUT`. Set `GTS_OWNED_RECOVERY_EXPECT_BLOB_SHA256=9ad1f8d7d0f2b9aa32c61bd8295b56177caabb0ae2fb8dd4617559ee0f71fed4`. It preserves the actual exit code and refuses to overwrite evidence.

The observer uses `recoveryCondenseEntry`, `ownedRecoveryBetterVersionExists`, `RecoveryCompareVersions`, exact stack-summary candidates, real symbol policies, and source row positions. It records every version's node count, dynamic precedence, error state, cost, position, checkpoint and physical status. It records actual request before/after cursor and scanner checkpoints. It checks that counters, headers, token, ownership, and recovery turn inputs do not change during observation.

For the skip-cost gate, C's subtree total size includes padding from the absorbing stack position. The receipt records content start, stack position, total byte/row extent and padding separately. It refuses to price lexical ERROR as though no new pause/handle_error marker were needed. EOF does not execute this gate.

An important limit is explicit: C publishes a successful summary recovery before comparing the absorber. This read-only observer does not create that hypothetical fork. `AbsorbComparisonCompleteAfterSummaryFork` is therefore false when a summary fork would be created or pricing fails. Suppression by an already-existing version is sufficient evidence for the first pruning slice; a negative pre-fork comparison alone cannot justify retaining the absorber.

The named sole-survivor obligation is to prove executed owned non-EOF recovery on the selected lineage, followed by ordinary EOF acceptance, retaining that provenance across an authenticated shared-lexer rejoin. No `RecoverEOFAccepts` event should be fabricated to satisfy the current EOF-specific publication gate.
