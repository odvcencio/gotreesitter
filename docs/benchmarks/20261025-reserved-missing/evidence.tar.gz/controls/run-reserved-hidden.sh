set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/reserved-hidden
mkdir -p "$scratch"
go test -c -overlay=/controls/hidden-missing-baseline-tests-overlay.json -o "$scratch/before-root.test" . > /evidence/baseline-unit-build.log 2>&1
set +e
"$scratch/before-root.test" -test.run '^TestHiddenMissing' -test.count=1 -test.v > /evidence/baseline-unit.log 2>&1
code=$?
set -e
printf 'baseline_hidden_missing\t%s\n' "$code" >> /evidence/status.tsv
[[ "$code" = 1 ]] || { echo 'baseline did not reproduce hidden missing propagation failure' >&2; exit 1; }
go test -c -tags gts_parsercorephase0 -overlay=/controls/reserved-hidden-overlay.json -o "$scratch/after-root.test" . > /evidence/root-build.log 2>&1
"$scratch/after-root.test" -test.run '^Test(HiddenMissing.*|RawErrorCostIncludesElidedMissingTerminal)$' -test.count=1 -test.v > /evidence/candidate-unit.log 2>&1
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -overlay=/controls/reserved-hidden-overlay.json -o "$scratch/cgo.test" . > /evidence/cgo-build.log 2>&1
for mode in current full-order missing-off full-order-missing-off; do
 set +e
 GTS_GO_CI_PROTOCOL=$mode "$scratch/cgo.test" -test.run '^TestGoCIRecoveryProtocolMatrix$' -test.count=1 -test.v > "/evidence/protocol-$mode.log" 2>&1
 code=$?
 set -e
 printf 'protocol_%s\t%s\n' "$mode" "$code" >> /evidence/status.tsv
done
# Current proposal must match C before its broader Go gates run.
"$scratch/cgo.test" -test.run '^Test(GoIssue490FragmentBoundaryLockedC|GoCIReservedRemainingDiffs)$' -test.v -test.count=1 > /evidence/exact-issue490-and-diffs.log 2>&1
"$scratch/cgo.test" -test.run '^Test(Go(Compact|TokenInvariant|Unterminated|GeneratedNUL|NewMake|Cognociente|MalformedDeclaration|AssignmentTarget)|Stage6GoCompactCertification|CanonicalGoBenchmarkPreflight)' -test.v -test.count=1 > /evidence/go-cgo.log 2>&1
GTS_ADMISSION_REAL_CORPUS_LANGS=go "$scratch/cgo.test" -test.run '^TestCompactR4StructuralLockedC$' -test.v -test.count=1 > /evidence/go-r4-cgo.log 2>&1
cd /candidate
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE=$route GOTREESITTER_V1_INVARIANT_LANGUAGE=go "$scratch/after-root.test" -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v > "/evidence/go-invariant-$route.log" 2>&1
done
sha256sum "$scratch/before-root.test" "$scratch/after-root.test" "$scratch/cgo.test" > /evidence/binary.sha256
printf 'scoped correctness proposal complete; no timing or graduation claim\n' > /evidence/completed.txt
