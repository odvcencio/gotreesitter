set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
export GTS_GO_RESERVED_UPSTREAM_ARCHIVE=/candidate/harness_out/docker/single-version-stream-20261025/mac-c-grammars/go-upstream.tar.gz
export GTS_GO_RESERVED_UPSTREAM_GRAMMAR=/controls/go-reserved/upstream-grammar.json
git config --global --add safe.directory /candidate
cd /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/reserved
mkdir -p "$scratch"
go test -c -overlay=/controls/reserved-baseline-test-overlay.json -o "$scratch/before-root.test" . > /evidence/baseline-build.log 2>&1
set +e
"$scratch/before-root.test" -test.run '^TestReservedRuntimePrefilterPrivate' -test.count=1 -test.v > /evidence/baseline-runtime.log 2>&1
baseline_code=$?
set -e
printf 'baseline_runtime\t%s\n' "$baseline_code" >> /evidence/status.tsv
[[ "$baseline_code" = 1 ]] || { echo 'baseline must reproduce reserved-keyword failure' >&2; exit 1; }
python3 - <<'PROOF'
from pathlib import Path
s=Path('/evidence/baseline-runtime.log').read_text()
assert '--- FAIL: TestReservedRuntimePrefilterPrivateNextKeepsReservedNoActionKeyword' in s, 'baseline did not fail intended runtime regression'
PROOF
go test -overlay=/controls/reserved-generation-overlay.json -run '^TestReservedRuntimePrefilterPrivate' -count=1 -v . > /evidence/candidate-runtime.log 2>&1
go test -overlay=/controls/reserved-generation-overlay.json ./grammargen -run 'Reserved' -count=1 -v > /evidence/candidate-generator-tests.log 2>&1
go run -overlay=/controls/reserved-generation-overlay.json ./cmd/grammargen emit go -bin /evidence/go-reserved.bin > /evidence/generate.log 2>&1
sha256sum /evidence/go-reserved.bin > /evidence/blob.sha256
printf 'unit proof and Go blob generation complete; no C or performance qualification yet\n' > /evidence/completed.txt
