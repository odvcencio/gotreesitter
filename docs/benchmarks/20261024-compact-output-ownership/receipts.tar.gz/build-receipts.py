from pathlib import Path
import hashlib,json,tarfile,shutil
p=Path(__file__).resolve().parent
out=Path('/home/draco/work/gotreesitter/docs/benchmarks/20261024-compact-output-ownership')
assert (p/'measurements/complete.txt').exists()
assert (p/'measurements/exit.txt').read_text().strip()=='0'
assert (p/'correctness-analysis.json').exists() and (p/'performance-analysis.json').exists()
files=[]
for f in sorted(p.rglob('*')):
 if not f.is_file() or '__pycache__' in f.parts or f.name=='receipt-manifest.json':continue
 if f.name.endswith('.test') or f.name in ['baseline-ledger','candidate-ledger']:continue
 with f.open('rb') as stream:magic=stream.read(4)
 if magic==b'\x7fELF':continue
 files.append(f)
manifest={str(f.relative_to(p)):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files}
(p/'receipt-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'receipts.tar.gz','w:gz') as tar:
 for f in files+[p/'receipt-manifest.json']:tar.add(f,arcname=str(f.relative_to(p)),recursive=False)
for name in ['performance-analysis.json','retention-analysis.json','correctness-analysis.json','qualification.json','qualified-source.json']:
 shutil.copy2(p/name,out/name)
for f in (p/'measurements').glob('benchstat-*.txt'):shutil.copy2(f,out/f.name)
with tarfile.open(out/'receipts.tar.gz') as tar:
 for name,entry in manifest.items():
  data=tar.extractfile(name).read();assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
print(json.dumps({'files':len(files),'archive_bytes':(out/'receipts.tar.gz').stat().st_size,'archive_sha256':hashlib.sha256((out/'receipts.tar.gz').read_bytes()).hexdigest()}))
