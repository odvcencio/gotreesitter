from pathlib import Path
import json,re,hashlib
p=Path(__file__).resolve().parent;d=p/'qualified';langs=(p/'languages.txt').read_text().splitlines()
assert len(langs)==206 and len(set(langs))==206
assert (d/'exit.txt').read_text().strip()=='0' and (d/'correctness-complete.txt').exists()
assert (d/'progress.txt').read_text().splitlines()==langs
for lang in langs:
 row=json.loads((d/'counter-deltas'/f'{lang}.json').read_text());assert row['passed'] and not row['changes'] and not row['route_metadata_changes']
 for route in [0,1]:
  text=(d/'invariants'/f'{route}-{lang}.log').read_text();assert 'session_steps=72 no_edit_allocs=0' in text and '\nPASS\n' in text and '--- SKIP' not in text and '--- FAIL' not in text
  text=(d/'cgo'/f'{route}-{lang}.log').read_text();assert '\nPASS\n' in text and '--- SKIP' not in text and '--- FAIL' not in text
  assert sum(text.count('--- PASS: '+name+'/'+lang+' ') for name in ['TestParityFreshParse','TestParityIncrementalParse','TestParityHasNoErrors'])==3
work=json.loads((d/'work/comparison.json').read_text());assert work=={'rows':824,'changes':[],'adverse':[]}
for name in ['root.log','root-race.log','memory.log','yaml-focused-C.log']:
 text=(d/name).read_text();assert '--- FAIL' not in text and ('PASS' in text or 'ok  ' in text)
assert (p/'candidate-v2/exit.txt').read_text().strip()=='0'
for name in ['core.log','onepass.log','race.log','shadow.log','386.log','output.log']:
 text=(p/'candidate-v2'/name).read_text();assert '\nPASS\n' in text and '--- FAIL' not in text and '--- SKIP' not in text
for row in json.loads((p/'qualified-source.json').read_text())['files']:
 assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
result={'languages':206,'invariant_sessions':412,'edit_steps':29664,'no_edit_allocations':0,'standard_C_checks':1236,'whole_operation_work_rows':824,'work_changes':0,'selected_ledger_comparisons':206,'work_reuse_route_changes':0,'memory_contract_tests':len(re.findall(r'^--- PASS:',(d/'memory.log').read_text(),re.M)),'core_and_output_modes':['normal','one-pass','race','shadow','386'],'working_source_matches_qualified_overlay':True}
(p/'correctness-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
