from pathlib import Path
import re,json,statistics,subprocess,hashlib
p=Path(__file__).resolve().parent

def parse(path,start,cells):
 text=path.read_text();assert text.rstrip().endswith('# status: complete'),path
 assert '# completed runs: 20' in text
 seeds={};seed=None
 for line in text.splitlines():
  match=re.match(r'# seed: (\d+); position: (\d+)$',line)
  if match:
   seed,pos=map(int,match.groups());assert seed not in seeds;seeds[seed]={'position':pos,'rows':{},'order':[]}
  elif line.startswith('Benchmark'):
   words=line.split();name=re.sub(r'-\d+$','',words[0]);assert seed is not None and name not in seeds[seed]['rows'];assert int(words[1])>0
   assert len(words[2:])%2==0
   metrics={words[i+1]:float(words[i]) for i in range(2,len(words),2)}
   assert all(m in metrics for m in ['ns/op','B/op','allocs/op']);seeds[seed]['rows'][name]=metrics;seeds[seed]['order'].append(name)
  elif line.startswith('# workload order: '):assert line.split(': ',1)[1].split(',')==seeds[seed]['order']
 assert set(seeds)==set(range(start,start+20));assert all(len(v['rows'])==cells for v in seeds.values())
 assert len({tuple(sorted(v['rows'])) for v in seeds.values()})==1
 return seeds

specs=[('go',254001,4),('yaml',254001,4),('large',255001,2),('primary',256001,3)]
result={'baseline':'377beec2d9035ad3d9b91c58162273dffedb9ddd','scope':'detached compact output owner versus parent; internal read-only route except public primary control','suites':{},'ratchet_failures':[],'rows_per_role':0}
d=p/'measurements'
for suite,start,cells in specs:
 paths={role:d/(role+'-'+suite+'.txt') for role in ['baseline','candidate']};data={role:parse(f,start,cells) for role,f in paths.items()};summary=[]
 for seed in range(start,start+20):
  a,b=data['baseline'][seed],data['candidate'][seed];assert a['order']==b['order'];assert a['position']==1+(seed-start)%2 and b['position']==2-(seed-start)%2
  for name in a['rows']:
   x,y=a['rows'][name],b['rows'][name];assert x.keys()==y.keys()
   for metric in x.keys()-{'ns/op','B/op','allocs/op','MB/s'}:assert x[metric]==y[metric]
   if 'NoEdit' in name:assert x['B/op']==x['allocs/op']==y['B/op']==y['allocs/op']==0
 for name in data['baseline'][start]['order']:
  med={role:{metric:statistics.median(data[role][seed]['rows'][name][metric] for seed in range(start,start+20)) for metric in ['ns/op','B/op','allocs/op']} for role in data}
  ratios={metric:med['candidate'][metric]/med['baseline'][metric] if med['baseline'][metric] else (1 if med['candidate'][metric]==0 else None) for metric in med['baseline']}
  failures=[k for k,v in ratios.items() if v is None or v>1.1]
  summary.append({'benchmark':name,'medians':med,'ratios':ratios,'ratchet_failures':failures})
  if failures:result['ratchet_failures'].append({'suite':suite,'benchmark':name,'metrics':failures})
 result['suites'][suite]={'matched_orders':True,'alternating_roles':True,'seed_range':[start,start+19],'rows_per_role':20*cells,'results':summary};result['rows_per_role']+=20*cells
 with (d/('benchstat-'+suite+'.txt')).open('w') as out:subprocess.run(['/home/draco/go/bin/benchstat',paths['baseline'].name,paths['candidate'].name],cwd=d,stdout=out,check=True)
result['retention']={}
for lang in ['go','yaml']:
 rows={role:[] for role in ['baseline','candidate']}
 for seed in range(1,21):
  values={}
  for role in rows:
   f=d/'heap'/f'{role}-{lang}-{seed}.log';text=f.read_text();assert '\nPASS\n' in text and '--- FAIL' not in text
   matches=re.findall(r'RETENTION (\{.*\})',text);assert len(matches)==1
   row=json.loads(matches[0]);row['retained_delta']=row['LiveHeap']-row['BeforeHeap'];row['released_delta']=row['ReleasedHeap']-row['BeforeHeap']
   assert row['retained_delta']>0 and abs(row['released_delta'])<1048576
   rss=(d/'heap'/f'{role}-{lang}-{seed}.rss').read_text();assert re.search(r'Exit status: 0',rss)
   row['max_rss_kib']=int(re.search(r'Maximum resident set size \(kbytes\): (\d+)',rss)[1])
   values[role]=row;rows[role].append(row)
  for k in ['SourceBytes','SourceHash','Digest','Nodes','Backing','Work']:assert values['baseline'][k]==values['candidate'][k],(lang,seed,k)
 metrics=['retained_delta','released_delta','max_rss_kib','Backing','Nodes','SourceBytes']
 med={role:{k:statistics.median(row[k] for row in items) for k in metrics} for role,items in rows.items()}
 ratios={k:med['candidate'][k]/med['baseline'][k] for k in ['retained_delta','max_rss_kib']}
 result['retention'][lang]={'pairs':20,'medians':med,'ratios':ratios,'source_sha256':bytes(rows['baseline'][0]['SourceHash']).hex(),'digest':rows['baseline'][0]['Digest'],'work':rows['baseline'][0]['Work']}
 if ratios['max_rss_kib']>1.1:result['ratchet_failures'].append({'suite':'retention-'+lang,'metric':'max_rss_kib'})
 assert med['candidate']['max_rss_kib']*1024/med['candidate']['SourceBytes']<=400
(p/'performance-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'rows_per_role':result['rows_per_role'],'retention':result['retention'],'ratchet_failures':result['ratchet_failures']}))
