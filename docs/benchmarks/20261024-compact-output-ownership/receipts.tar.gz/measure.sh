set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOFLAGS='-p=1 -mod=readonly -overlay=/controls/overlay.json' GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/exit.txt; date -u +%FT%TZ > /evidence/finished.txt' EXIT
[[ -f /gate/correctness-complete.txt ]] || { echo 'qualification incomplete'; exit 2; }
date -u +%FT%TZ > /evidence/started.txt
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /baseline
if go test -overlay=/controls/liveness-overlay.json ./internal/parsercorephase0 -run '^TestSelectedStoreDoesNotRetainProducingCore$' -count=1 -v -timeout=30s > /evidence/baseline-liveness.log 2>&1; then
 echo 'baseline unexpectedly passed collection test';exit 3
fi
grep -q 'a live compact result retained its producing Core' /evidence/baseline-liveness.log
cd /candidate
go test ./internal/parsercorephase0 -run '^TestSelectedStoreDoesNotRetainProducingCore$' -count=1 -v -timeout=30s > /evidence/candidate-liveness.log 2>&1
mkdir -p /evidence/cogno
cd /candidate/cgo_harness
go test -c -overlay=/controls/cogno-overlay.json -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/cogno.test . > /evidence/cogno/build.log 2>&1
for route in production candidate; do
 for api in plain profiled; do
  for edit in insert replace delete; do
   label="$route-$api-$edit"
   if /evidence/cogno.test -test.run "^TestGoCognociente137KiBTopEditLockedC$/^$route$/^$api$/^$edit$" -test.v -test.count=1 -test.timeout=5m > "/evidence/cogno/$label.log" 2>&1; then code=0; else code=$?; fi
   printf '%s\t%s\n' "$label" "$code" >> /evidence/cogno/status.tsv
   if [[ "$edit" != delete && "$code" != 0 ]]; then exit "$code"; fi
  done
 done
done
mkdir -p /evidence/heap
for role in baseline candidate; do
 cd "/$role"
 go test -c -overlay=/controls/retention-overlay.json -tags gts_parsercorephase0 -o "/evidence/$role-heap.test" . > "/evidence/$role-heap-build.log" 2>&1
done
for lang in go yaml; do
 for seed in $(seq 1 20); do
  roles='baseline candidate'; if (( seed % 2 )); then roles='candidate baseline'; fi
  for role in $roles; do
   cd "/$role"
   GTS_COMPARE_LANGUAGE="$lang" /usr/bin/time -v -o "/evidence/heap/$role-$lang-$seed.rss" "/evidence/$role-heap.test" -test.run '^TestCompactOutputRetainedHeap$' -test.count=1 -test.v -test.timeout=5m > "/evidence/heap/$role-$lang-$seed.log" 2>&1
  done
 done
 done
cd /candidate
for lang in go yaml; do
 GOFLAGS='-p=1 -mod=readonly -overlay=/controls/perf-overlay.json' GTS_COMPARE_LANGUAGE="$lang" bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output "/evidence/baseline-$lang.txt" --output "/evidence/candidate-$lang.txt" --runs 20 --seed-start 254001 --benchtime 750ms --bench-regex '^BenchmarkSingleVersionOutput$' --lock-path /evidence/perf.lock > "/evidence/$lang-perf-driver.log" 2>&1
done
GOFLAGS='-p=1 -mod=readonly -overlay=/controls/large-perf-overlay.json' GTS_COMPARE_LANGUAGE=go bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-large.txt --output /evidence/candidate-large.txt --runs 20 --seed-start 255001 --benchtime 750ms --bench-regex '^BenchmarkSingleVersionOutput$' --lock-path /evidence/perf.lock > /evidence/large-perf-driver.log 2>&1
cp /controls/benchmark_primary_overlay.go.txt /evidence/prepare-primary.go
go run /evidence/prepare-primary.go /controls/benchmark_primary_go_suite.go.txt /evidence/primary-overlay.json /baseline /candidate > /evidence/primary-hashes.txt
python3 - <<'PYSCRIPT'
from pathlib import Path
import json
p=Path('/evidence/primary-overlay.json');d=json.loads(p.read_text());d['Replace'].update(json.loads(Path('/controls/overlay.json').read_text())['Replace']);p.write_text(json.dumps(d,indent=2)+'\n')
PYSCRIPT
GOFLAGS='-p=1 -mod=readonly -overlay=/evidence/primary-overlay.json' bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-primary.txt --output /evidence/candidate-primary.txt --runs 20 --seed-start 256001 --benchtime 750ms --bench-regex '^BenchmarkGTSSeededPrimary$' --require-benchmarks 'BenchmarkGTSSeededPrimary/BenchmarkGoParseFullDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalNoEditDFA' --lock-path /evidence/perf.lock > /evidence/primary-driver.log 2>&1
printf 'complete\n' > /evidence/complete.txt
