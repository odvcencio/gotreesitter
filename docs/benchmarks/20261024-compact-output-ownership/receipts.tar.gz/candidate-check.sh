set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOFLAGS='-p=1 -mod=readonly' GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/exit.txt' EXIT
git config --global --add safe.directory /candidate
cd /candidate
go test ./internal/parsercorephase0 -count=1 -v -timeout=6m > /evidence/core.log 2>&1
go test -tags gts_parsercorephase0_selectedstore_onepass ./internal/parsercorephase0 -run 'Test(NativeSelected|SelectedStore|SelectedCursor|SelectedBuild)' -count=1 -v -timeout=5m > /evidence/onepass.log 2>&1
go test -race ./internal/parsercorephase0 -run 'Test(NativeSelected|SelectedStore|SelectedCursor|SelectedBuild)' -count=1 -v -timeout=5m > /evidence/race.log 2>&1
go test -tags gts_eof_recovery_shadow ./internal/parsercorephase0 -run 'Test(.*EOF.*|NativeSelected|SelectedStore)' -count=1 -v -timeout=5m > /evidence/shadow.log 2>&1
GOARCH=386 CGO_ENABLED=0 go test ./internal/parsercorephase0 -run 'Test(NativeSelected|SelectedStore)' -count=1 -v -timeout=5m > /evidence/386.log 2>&1
go test -tags gts_parsercorephase0 -run '^TestSingleVersionDirectOutput' -count=1 -v -timeout=5m . > /evidence/output.log 2>&1
