set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOFLAGS='-p=1 -mod=readonly -overlay=/controls/baseline-overlay.json' GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/exit.txt' EXIT
git config --global --add safe.directory /baseline
cd /baseline
go test ./internal/parsercorephase0 -run 'Test(NativeSelected|SelectedStore|SelectedCursor|SelectedBuild)' -count=1 -v -timeout=5m > /evidence/core.log 2>&1
go test -tags gts_parsercorephase0 -run '^TestSingleVersionDirectOutput' -count=1 -v -timeout=5m . > /evidence/output.log 2>&1
