set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
finish(){
 sha256sum --quiet -c /controls/source.sha256 > /evidence/source-after.log 2>&1
 sha256sum --quiet -c /controls/v4/controls.sha256 > /evidence/controls-after.log 2>&1
 sha256sum --quiet -c /controls/v4-extended/controls.sha256 > /evidence/extended-after.log 2>&1
 sha256sum --quiet -c /controls/oracle0271/checksums.container.sha256 > /evidence/oracle-after.log 2>&1
 sha256sum --quiet -c /controls/oracle0271-module-bind-v3/checksums.container.sha256 > /evidence/binding-after.log 2>&1
 python3 /controls/oracle0271-module-bind-v3/verify-inputs.py > /evidence/staged-after.json
}
trap finish EXIT
sha256sum --quiet -c /controls/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/v4/controls.sha256 > /evidence/controls-before.log 2>&1
sha256sum --quiet -c /controls/v4-extended/controls.sha256 > /evidence/extended-before.log 2>&1
sha256sum --quiet -c /controls/oracle0271/checksums.container.sha256 > /evidence/oracle-before.log 2>&1
sha256sum --quiet -c /controls/oracle0271-module-bind-v3/checksums.container.sha256 > /evidence/binding-before.log 2>&1
python3 /controls/oracle0271-module-bind-v3/verify-inputs.py > /evidence/staged-before.json
scratch=/runtime/tmp/gotreesitter-go-auth-admission-v4-extended-20261026
mkdir -p "$scratch"
cd /baseline
go build -tags gts_parsercorephase0,gts_workcount -o "$scratch/before-work" /prior-controls/recovery-work-main.go > /evidence/before-build.log 2>&1
cd /candidate
go build -tags gts_parsercorephase0,gts_workcount -overlay=/controls/v4/overlay.runtime.json -o "$scratch/after-work" /prior-controls/recovery-work-main.go > /evidence/after-build.log 2>&1
for arm in before after; do
 for assignment in 0 1; do
  GTS_PROBE_ASSIGNMENT=$assignment "$scratch/$arm-work" > "/evidence/$arm-work-$assignment.log" 2>&1
 done
done
go test -race -c -overlay=/controls/v4-extended/overlay.tests.json -tags gts_parsercorephase0 -o "$scratch/root-race.test" . > /evidence/race-build.log 2>&1
"$scratch/root-race.test" -test.run '^Test(TrustedGoReuseShadowOriginalProducer|IdentifierAdmissionActualBoundaryCases|IdentifierAdmissionRealSources|TrustedGoReuseShadowCleanEditSession)$' -test.count=1 -test.v -test.timeout=12m > /evidence/race-go.log 2>&1
cd /candidate/cgo_harness
export GOFLAGS='-p=1 -mod=readonly -modfile=/controls/oracle0271-module-bind-v3/go.mod -overlay=/controls/v4-extended/overlay.c027.json'
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o "$scratch/cgo.test" . > /evidence/cgo-build.log 2>&1
"$scratch/cgo.test" -test.run '^TestCOracle0271HeaderAndLinkProbe$' -test.count=1 -test.v -test.timeout=2m > /evidence/runtime-probe.log 2>&1
"$scratch/cgo.test" -test.run '^TestGo(Cognociente137KiBTopEditLockedC|MalformedDeclarationPrefixLockedC|AssignmentTargetEdits16SitesLockedC)$' -test.count=1 -test.v -test.timeout=12m > /evidence/locked-c027.log 2>&1
sha256sum "$scratch/before-work" "$scratch/after-work" "$scratch/root-race.test" "$scratch/cgo.test" > /evidence/binary.sha256
