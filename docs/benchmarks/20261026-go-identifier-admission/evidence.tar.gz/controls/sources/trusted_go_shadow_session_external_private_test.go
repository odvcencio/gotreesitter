//go:build gts_parsercorephase0 || gts_workcount || gts_diag

package gotreesitter_test

import (
	gts "github.com/odvcencio/gotreesitter"
	"github.com/odvcencio/gotreesitter/grammars"
	"testing"
)

func TestTrustedGoReuseShadowCleanEditSession(t *testing.T) {
	gts.RunTrustedGoReuseShadowCleanSession(t, grammars.GoLanguage())
}
