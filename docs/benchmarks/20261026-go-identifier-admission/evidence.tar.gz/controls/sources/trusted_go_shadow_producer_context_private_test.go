//go:build gts_parsercorephase0 || gts_workcount || gts_diag

package gotreesitter

import "testing"

func TestTrustedGoShadowActualDefaultProducerContext(t *testing.T) {
	source := []byte("1+2+3")
	for _, name := range []string{"ordinary", "absent_capability", "cloned_buffer", "wrong_source_length", "language", "wrapper", "lexer_ranges", "parser_ranges", "budget", "timeout", "cancel", "work", "observer", "unowned_lexer", "recovery_probe", "forced_retry", "stack_override", "node_override", "merge_override"} {
		t.Run(name, func(t *testing.T) {
			lang := buildArithmeticLanguage()
			lang.SmallSourceReuseShadowArtifact = [32]byte{1} // generic adapter guards; registration is tested separately
			parser := NewParser(lang)
			d := parser.acquireParserDFATokenSource(source)
			defer d.Close()
			var ts TokenSource = d
			stacks := fullParseInitialMaxStacks(lang, parser.maxConflictWidth, source)
			merge := parser.resolveParseMergePerKeyCap(source, nil, 0)
			stackOverride, nodeOverride, mergeOverride := stacks, 0, 0
			switch name {
			case "absent_capability":
				lang.SmallSourceReuseShadowArtifact = [32]byte{}
			case "wrong_source_length":
				d.lexer.source = source[:len(source)-1]
			case "cloned_buffer":
				d.lexer.source = append([]byte{}, source...)
			case "language":
				d.language = buildArithmeticLanguage()
			case "wrapper":
				ts = newIncludedRangeTokenSource(d, []Range{{StartByte: 0, EndByte: uint32(len(source)), EndPoint: Point{Column: uint32(len(source))}}})
			case "lexer_ranges":
				d.lexer.includedRanges = []Range{{StartByte: 0, EndByte: uint32(len(source))}}
			case "parser_ranges":
				parser.SetIncludedRanges([]Range{{StartByte: 0, EndByte: uint32(len(source))}})
			case "budget":
				parser.SetMemoryBudgetBytes(1 << 20)
			case "timeout":
				parser.SetTimeoutMicros(100)
			case "cancel":
				flag := uint32(0)
				parser.SetCancellationFlag(&flag)
			case "work":
				parser.SetParseWorkLimits(ParseWorkLimits{NodeLimit: 1000})
			case "observer":
				parser.SetLogger(func(ParserLogType, string) {})
			case "unowned_lexer":
				ts = parser.newDFAReparseTokenSource(source)
			case "recovery_probe":
				parser.recoveryInitialOnly = true
			case "forced_retry":
				parser.forceCleanRetryPass = true
			case "stack_override":
				stackOverride++
			case "node_override":
				nodeOverride = 1
			case "merge_override":
				mergeOverride = -merge
			}
			got := parser.defaultReuseProducerSchedule(ts, source, stacks, merge, stackOverride, nodeOverride, mergeOverride, fullParseUsesDeterministicExternalConflicts(lang))
			if (got != 0) != (name == "ordinary") {
				t.Fatalf("producer schedule=%d, ordinary=%t", got, name == "ordinary")
			}
			if name == "unowned_lexer" {
				ts.(*dfaTokenSource).Close()
			}
		})
	}
}
