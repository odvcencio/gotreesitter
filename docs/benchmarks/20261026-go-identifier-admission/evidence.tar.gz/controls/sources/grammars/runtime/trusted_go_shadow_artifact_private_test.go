package grammarruntime

import (
	"crypto/sha256"
	gts "github.com/odvcencio/gotreesitter"
	"testing"
)

func TestTrustedGoReuseShadowArtifactScope(t *testing.T) {
	want := sha256.Sum256(BlobByName("go"))
	if want != mustRuntimeProfileSHA256("9ad1f8d7d0f2b9aa32c61bd8295b56177caabb0ae2fb8dd4617559ee0f71fed4") {
		t.Fatal("Go artifact changed")
	}
	exact := &gts.Language{Name: "go"}
	if !attachBuiltinLanguageRuntimeProfile("go", want, exact) || exact.SmallSourceReuseShadowArtifact != want {
		t.Fatal("exact Go artifact lacks qualification capability")
	}
	for _, name := range []string{"same-name", "stale-blob", "foreign-name"} {
		lang := &gts.Language{Name: "go"}
		switch name {
		case "same-name":
			AttachLanguageSupport("go", lang)
		case "stale-blob":
			attachBuiltinLanguageRuntimeProfile("go", sha256.Sum256([]byte("stale")), lang)
		case "foreign-name":
			attachBuiltinLanguageRuntimeProfile("yaml", want, lang)
		}
		if lang.SmallSourceReuseShadowArtifact != ([32]byte{}) {
			t.Fatalf("%s acquired artifact capability", name)
		}
	}
	for name, profile := range builtinLanguageRuntimeProfiles {
		if name != "go" && profile.smallSourceReuseShadow {
			t.Fatalf("non-Go profile%s entered qualification scope", name)
		}
	}
}
