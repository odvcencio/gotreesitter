//go:build gts_parsercorephase0 || gts_workcount || gts_diag

package gotreesitter

import (
	"bytes"
	"crypto/sha256"
	"fmt"
	"testing"
)

// Exported only by the qualification test binary; the grammar package remains
// outside the engine. This uses the exact original downstream declaration.
func RunTrustedGoReuseShadowProof(t *testing.T, language *Language) {
	var builder bytes.Buffer
	builder.WriteString("package main\n\nimport \"fmt\"\n\n")
	for i := 0; builder.Len() < 137*1024; i++ {
		fmt.Fprintf(&builder, "func f%d(a int, b int) int {\n\tx := a + b\n\tfmt.Println(\"f%d\", x)\n\treturn x\n}\n\n", i, i)
	}
	source := builder.Bytes()
	if len(source) != 140368 || fmt.Sprintf("%x", sha256.Sum256(source)) != "5434575bb249338937331c3756e10dcec34237d107f523ea315996fb6de0ef8f" || source[57] != 'x' {
		t.Fatal("original declaration source changed")
	}
	if language.SmallSourceReuseShadowArtifact == ([32]byte{}) {
		t.Fatal("exact registered Go lacks shadow capability")
	}
	point := func(input []byte, offset int) Point {
		var p Point
		for _, b := range input[:offset] {
			if b == '\n' {
				p.Row++
				p.Column = 0
			} else {
				p.Column++
			}
		}
		return p
	}
	compare := func(t *testing.T, a, b *Tree) {
		t.Helper()
		if a == nil || b == nil || a.rawParseStopReason() != b.rawParseStopReason() || !incrementalTreesStructurallyEqual(a, b, language) {
			t.Fatal("candidate differs from independent fresh Go")
		}
		type pair struct{ a, b *Node }
		stack := []pair{{a.RootNode(), b.RootNode()}}
		for len(stack) > 0 {
			q := stack[len(stack)-1]
			stack = stack[:len(stack)-1]
			if q.a.ParseState() != q.b.ParseState() || q.a.PreGotoState() != q.b.PreGotoState() || q.a.dynamicPrecedence != q.b.dynamicPrecedence {
				t.Fatalf("state/precedence differs at %s[%d..%d]", q.a.Type(language), q.a.StartByte(), q.a.EndByte())
			}
			for i := 0; i < q.a.ChildCount(); i++ {
				stack = append(stack, pair{q.a.Child(i), q.b.Child(i)})
			}
		}
	}
	for _, kind := range []string{"native-chain", "copied", "transformed-factory", "identity-wrapper", "compact-producer", "no-artifact"} {
		t.Run(kind, func(t *testing.T) {
			lang := language
			if kind == "no-artifact" {
				clone := *language
				clone.SmallSourceReuseShadowArtifact = [32]byte{}
				lang = &clone
			}
			parser := NewParser(lang)
			parser.SetAdmissionCandidateRoute(kind == "compact-producer")
			var old *Tree
			var err error
			switch kind {
			case "transformed-factory":
				old, err = parser.ParseWithTokenSourceFactory(source, func(input []byte) (TokenSource, error) {
					changed := bytes.ReplaceAll(input, []byte("+"), []byte("-"))
					return parser.newDFAReparseTokenSource(changed), nil
				})
			case "identity-wrapper":
				old, err = parser.ParseWithTokenSource(source, newIncludedRangeTokenSource(parser.newDFAReparseTokenSource(source), []Range{{StartByte: 0, EndByte: uint32(len(source)), EndPoint: point(source, len(source))}}))
			default:
				old, err = parser.Parse(source)
			}
			if err != nil || old == nil || old.RootNode().HasError() {
				t.Fatalf("old producer parse: %v", err)
			}
			defer func() { old.Release() }()
			if kind == "copied" {
				next := old.Copy()
				old.Release()
				old = next
			}
			if kind == "compact-producer" && !old.compactMaterialized {
				t.Fatal("compact negative did not actually select compact producer")
			}
			key := uint16(0)
			if old.arena != nil {
				key = old.arena.legacyReuseReads.DefaultProducerSchedule(len(source))
			}
			if (key != 0) != (kind == "native-chain") {
				t.Fatalf("producer key=%d kind=%s", key, kind)
			}
			// All edited attempts below use the same ordinary default API. This
			// deliberately crosses the old compact/custom producer boundary.
			parser.SetAdmissionCandidateRoute(false)
			seen, would := 0, 0
			trustedGoReuseShadowObserver.Lock()
			trustedGoReuseShadowObserver.call = func(event trustedGoReuseShadowEvent) {
				if event.parser != parser {
					return
				}
				seen++
				if kind != "native-chain" && event.smallMode {
					t.Error("unqualified producer entered native small schedule")
				}
				if event.wouldCertify {
					would++
					if kind != "native-chain" {
						t.Error("unqualified old producer would certify")
					}
					compare(t, event.candidate, event.fresh)
				}
			}
			trustedGoReuseShadowObserver.Unlock()
			defer func() {
				trustedGoReuseShadowObserver.Lock()
				trustedGoReuseShadowObserver.call = nil
				trustedGoReuseShadowObserver.Unlock()
			}()
			current := source
			steps := 1
			if kind == "native-chain" {
				steps = 2
			}
			for step := 0; step < steps; step++ {
				after := append([]byte(nil), current...)
				after[57] = byte('y' + step)
				edit := InputEdit{StartByte: 57, OldEndByte: 58, NewEndByte: 58, StartPoint: point(current, 57), OldEndPoint: point(current, 58), NewEndPoint: point(after, 58)}
				// Span-changing insertion forces a real verifier on the first
				// attempt, including capability-absent/custom controls.
				if step == 0 || kind == "native-chain" {
					after = append(append(append([]byte{}, current[:57]...), 'x'), current[57:]...)
					edit.OldEndByte = 57
					edit.OldEndPoint = edit.StartPoint
					edit.NewEndPoint = point(after, 58)
				}
				old.Edit(edit)
				result, _, parseErr := parser.ParseIncrementalProfiled(after, old)
				old.Release()
				old = result
				if parseErr != nil || result == nil {
					t.Fatalf("step%d: %v", step, parseErr)
				}
				if result.hasCertifiedIncrementalReuse() || !result.incrementalFreshVerified() {
					t.Fatal("shadow candidate bypassed mandatory fresh verification")
				}
				freshParser := NewParser(lang)
				freshParser.SetAdmissionCandidateRoute(false)
				fresh, parseErr := freshParser.Parse(after)
				if parseErr != nil || fresh == nil {
					t.Fatalf("fresh: %v", parseErr)
				}
				if kind == "compact-producer" {
					// This paired control must first be adjudicated against the
					// unchanged canonical strict-state test. It preserves every
					// historical state/precedence assertion against the same
					// unsupported-producer operation with capability withheld.
					baselineLanguage := *lang
					baselineLanguage.SmallSourceReuseShadowArtifact = [32]byte{}
					baselineParser := NewParser(&baselineLanguage)
					baselineParser.SetAdmissionCandidateRoute(true)
					baselineOld, baselineErr := baselineParser.Parse(source)
					if baselineErr != nil || baselineOld == nil || !baselineOld.compactMaterialized {
						t.Fatalf("capability-off compact control not selected: %v", baselineErr)
					}
					baselineParser.SetAdmissionCandidateRoute(false)
					baselineOld.Edit(edit)
					baselineResult, _, baselineErr := baselineParser.ParseIncrementalProfiled(after, baselineOld)
					baselineOld.Release()
					if baselineErr != nil || baselineResult == nil {
						t.Fatalf("capability-off cross-producer incremental: %v", baselineErr)
					}
					if result.rawParseStopReason() != fresh.rawParseStopReason() || !incrementalTreesStructurallyEqual(result, fresh, lang) {
						t.Fatal("unsupported producer public tree/stop differs from independent fresh")
					}
					compare(t, result, baselineResult)
					if result.arena != nil && result.arena.legacyReuseReads.DefaultProducerSchedule(len(after)) != 0 {
						t.Fatal("retained unsupported compact state acquired native producer receipt")
					}
					baselineResult.Release()
					t.Log("compact-old result preserves capability-off historical state plane and strict fresh public equality; no native grant")
				} else {
					compare(t, result, fresh)
				}
				fresh.Release()
				current = after
			}
			if kind == "native-chain" && (seen != 2 || would != 2) {
				t.Fatalf("actual native chain shadow events=%d would=%d want2/2", seen, would)
			}
			if kind != "native-chain" && would != 0 {
				t.Fatalf("unproved producer would certify%d times", would)
			}
			if kind != "no-artifact" && seen == 0 {
				t.Fatal("negative/positive did not reach active fresh verifier observation")
			}
			allocs := testing.AllocsPerRun(10, func() {
				next, e := parser.ParseIncremental(current, old)
				if e != nil || next == nil {
					panic("no-edit parse failed")
				}
				next.Release()
			})
			if allocs != 0 {
				t.Fatalf("noedit allocations=%g", allocs)
			}
			t.Logf("source_bytes=%d source_sha256=%x producer=%s verifier_events=%d would_certify=%d noedit_allocs=%g", len(source), sha256.Sum256(source), kind, seen, would, allocs)
		})
	}
}
