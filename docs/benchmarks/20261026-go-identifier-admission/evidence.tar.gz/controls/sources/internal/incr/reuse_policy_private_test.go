package incr

import (
	"reflect"
	"testing"
	"unsafe"
)

func privateTrustedProducerFacts() DefaultProducerFacts {
	return DefaultProducerFacts{ArtifactCapability: true, ExactDFA: true, ParserOwnedLexer: true, SourceIdentity: true, SameLanguage: true, NoRanges: true, DefaultControls: true, DefaultPolicy: true, MaxStacks: 8, MergePerKey: 6}
}
func TestPrivateTrustedDefaultProducerFactsRequireEveryIndependentGuard(t *testing.T) {
	positive := privateTrustedProducerFacts()
	if positive.ScheduleKey() != uint16(8<<8|6) {
		t.Fatal("positive exact producer schedule unavailable")
	}
	for _, tc := range []struct {
		name   string
		change func(*DefaultProducerFacts)
	}{
		{"artifact", func(f *DefaultProducerFacts) { f.ArtifactCapability = false }},
		{"exact-dfa", func(f *DefaultProducerFacts) { f.ExactDFA = false }},
		{"parser-owned-lexer", func(f *DefaultProducerFacts) { f.ParserOwnedLexer = false }},
		{"exact-source", func(f *DefaultProducerFacts) { f.SourceIdentity = false }},
		{"same-language", func(f *DefaultProducerFacts) { f.SameLanguage = false }},
		{"ranges", func(f *DefaultProducerFacts) { f.NoRanges = false }},
		{"controls", func(f *DefaultProducerFacts) { f.DefaultControls = false }},
		{"policy", func(f *DefaultProducerFacts) { f.DefaultPolicy = false }},
	} {
		t.Run(tc.name, func(t *testing.T) {
			f := positive
			tc.change(&f)
			before := f
			if f.ScheduleKey() != 0 {
				t.Fatal("missing producer fact manufactured authority")
			}
			if f != before {
				t.Fatal("policy query changed parser facts")
			}
		})
	}
	if (DefaultProducerFacts{ArtifactCapability: true, MaxStacks: 8, MergePerKey: 6}).ScheduleKey() != 0 {
		t.Fatal("artifact permission alone authenticated a producer")
	}
	if (DefaultProducerFacts{ExactDFA: true, ParserOwnedLexer: true, SourceIdentity: true, SameLanguage: true, NoRanges: true, DefaultControls: true, DefaultPolicy: true, MaxStacks: 8, MergePerKey: 6}).ScheduleKey() != 0 {
		t.Fatal("producer facts bypassed artifact gate")
	}
	for _, value := range []int{-1, 0, 256, 65535} {
		for _, field := range []string{"stacks", "merge"} {
			f := positive
			if field == "stacks" {
				f.MaxStacks = value
			} else {
				f.MergePerKey = value
			}
			if f.ScheduleKey() != 0 {
				t.Fatalf("%s=%d narrowed/truncated into schedule", field, value)
			}
		}
	}
	for _, pair := range [][2]int{{1, 1}, {255, 255}, {8, 7}, {9, 6}} {
		f := positive
		f.MaxStacks, f.MergePerKey = pair[0], pair[1]
		if f.ScheduleKey() != uint16(pair[0]<<8|pair[1]) {
			t.Fatalf("exact schedule not retained: %+v", pair)
		}
	}
}
func TestPrivateTrustedReuseBasisAndPublicationGuards(t *testing.T) {
	complete := FreshReuseBasis{DefaultOperation: true, SupportedTokenSource: true, AcceptedCleanOldResult: true, CompleteOldReads: true, TrustedOldProducer: true, CompleteOldStateProjection: true}
	if !complete.ScheduleEligible() {
		t.Fatal("complete basis declined")
	}
	for _, change := range []func(*FreshReuseBasis){func(f *FreshReuseBasis) { f.DefaultOperation = false }, func(f *FreshReuseBasis) { f.SupportedTokenSource = false }, func(f *FreshReuseBasis) { f.AcceptedCleanOldResult = false }, func(f *FreshReuseBasis) { f.CompleteOldReads = false }, func(f *FreshReuseBasis) { f.TrustedOldProducer = false }, func(f *FreshReuseBasis) { f.CompleteOldStateProjection = false }} {
		f := complete
		change(&f)
		if f.ScheduleEligible() {
			t.Fatal("incomplete reuse basis admitted")
		}
	}
	for _, clean := range []bool{false, true} {
		for _, entered := range []bool{false, true} {
			for _, dropped := range []bool{false, true} {
				if SmallFreshReusePublicationEligible(clean, entered, dropped) != (clean && !entered && !dropped) {
					t.Fatalf("publication clean=%v recovery=%v dropped=%v", clean, entered, dropped)
				}
			}
		}
	}
}
func TestPrivateTrustedProducerReceiptRevocationAndLayout(t *testing.T) {
	type priorReadsLayout struct {
		ends                                              []uint32
		sourceBytes                                       uint32
		sealed, valid, forestAttributes, committedDropped bool
		packedBits                                        uint8
		allocated                                         *int64
		budget, baseline                                  int64
	}
	if unsafe.Sizeof(Reads{}) != unsafe.Sizeof(priorReadsLayout{}) || unsafe.Offsetof(Reads{}.allocated) != unsafe.Offsetof(priorReadsLayout{}.allocated) {
		t.Fatal("producer key grew header or moved allocator owner")
	}
	if ReadsHeaderBytes() < int64(unsafe.Sizeof(Reads{})) || ReadsHeaderBytes() < 64 {
		t.Fatal("header undercharged")
	}
	if unsafe.Sizeof(uintptr(0)) == 8 && ReadsHeaderBytes() != 64 {
		t.Fatal("64-bit key failed to occupy existing padding")
	}
	const key = uint16(8<<8 | 6)
	for _, event := range []string{"reset", "invalid-reset", "abstain", "drop", "bad-origin", "reverse-span", "after-seal", "budget-growth", "budget-wide-promotion", "trim", "unknown-recertification"} {
		t.Run(event, func(t *testing.T) {
			r := NewReads(8)
			if r.DefaultProducerSchedule(8) != 0 {
				t.Fatal("new recorder guessed producer")
			}
			r.CertifyDefaultProducer(key)
			if r.DefaultProducerSchedule(8) != key || r.DefaultProducerSchedule(7) != 0 {
				t.Fatal("source-specific grant unavailable")
			}
			switch event {
			case "reset":
				r.Reset(8)
			case "invalid-reset":
				if r.Reset(-1) {
					t.Fatal("invalid source accepted")
				}
			case "abstain":
				r.Abstain()
			case "drop":
				r.CommitDroppedInput(true)
			case "bad-origin":
				r.Record(9, 9)
			case "reverse-span":
				r.Record(4, 3)
			case "after-seal":
				r.Record(0, 9)
				r.Seal()
				r.Record(1, 2)
			case "budget-growth":
				allocated := r.Bytes()
				r.BindBudget(allocated, 0, &allocated)
				r.Record(0, 9)
			case "budget-wide-promotion":
				r = NewReads(1 << 24)
				r.Record(0, 1)
				r.CertifyDefaultProducer(key)
				allocated := r.Bytes()
				r.BindBudget(allocated, 0, &allocated)
				r.Record(0, 1<<24)
			case "trim":
				r.Record(0, 9)
				r.CertifyDefaultProducer(key)
				r.TrimCapacity(0)
			case "unknown-recertification":
				r.CertifyDefaultProducer(0)
			}
			if r.defaultProducerSchedule != 0 || r.DefaultProducerSchedule(int(r.SourceBytes())) != 0 {
				t.Fatalf("%s retained producer authority", event)
			}
		})
	}
	var absent *Reads
	absent.CertifyDefaultProducer(key)
	if absent.DefaultProducerSchedule(0) != 0 || absent.Bytes() != 0 {
		t.Fatal("nil recorder manufactured authority")
	}
}
func TestPrivateTrustedProducerGrantPreservesOrdinaryHistoryAndCopyUnknown(t *testing.T) {
	r := NewReads(8)
	const key = uint16(8<<8 | 6)
	r.CertifyDefaultProducer(key)
	r.CertifyForestAttributes()
	r.Record(0, 3)
	r.Record(3, 9)
	r.Record(3, 10)
	r.Record(4, 8)
	r.CommitDroppedInput(false)
	if r.DefaultProducerSchedule(8) != key {
		t.Fatal("valid/coalesced reads erased source-context grant")
	}
	r.Seal()
	if r.DefaultProducerSchedule(8) != key || !r.CertifiedForestAttributes() {
		t.Fatal("seal changed producer/ordinary attributes")
	}
	if got, ok := r.Lookahead(3); !ok || got != 7 {
		t.Fatalf("parent history=%d/%v", got, ok)
	}
	if got, ok := r.LeafLookahead(3); !ok || got != 0 {
		t.Fatalf("leaf history=%d/%v", got, ok)
	}
	copy := NewReads(int(r.SourceBytes()))
	for i := 0; i < r.count(); i++ {
		entry := r.at(i)
		copy.Record(int(entry.start), entry.end)
	}
	copy.Seal()
	if copy.DefaultProducerSchedule(8) != 0 {
		t.Fatal("copied primitive history inherited producer authority")
	}
	for end := uint32(1); end <= 8; end++ {
		a, aok := r.Lookahead(end)
		b, bok := copy.Lookahead(end)
		if a != b || aok != bok {
			t.Fatal("copy lost ordinary read frontier")
		}
	}
	before := append([]uint32(nil), r.ends...)
	charge := r.Bytes()
	r.CertifyDefaultProducer(key)
	if !reflect.DeepEqual(r.ends, before) || r.Bytes() != charge || r.DefaultProducerSchedule(8) != key {
		t.Fatal("certification changed sealed history/charge")
	}
	r.Abstain()
	r.CertifyDefaultProducer(key)
	if r.DefaultProducerSchedule(8) != 0 {
		t.Fatal("certification revived invalid history")
	}
	if NewReads(-1) != nil {
		t.Fatal("invalid source recorder exists")
	}
}
