set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
finish(){ sha256sum --quiet -c /controls/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/controls.sha256 > /evidence/controls-before.log 2>&1
scratch=/runtime/tmp/gotreesitter-go-auth-admission-20261026
mkdir -p "$scratch"
cd /candidate
overlay=/controls/overlay.tests.json
go test -overlay="$overlay" ./internal/incr -run '^Test(IdentifierAdmission|PrivateTrusted)' -count=1 -v -timeout=3m > /evidence/internal.log 2>&1
go test -c -overlay="$overlay" -tags gts_parsercorephase0 -o "$scratch/root.test" . > /evidence/root-build.log 2>&1
"$scratch/root.test" -test.run '^TestTrustedGoReuseShadowOriginalProducer$' -test.count=1 -test.v -test.timeout=8m > /evidence/original-producers.log 2>&1
"$scratch/root.test" -test.run '^TestTrustedGoShadowActualDefaultProducerContext$' -test.count=1 -test.v -test.timeout=4m > /evidence/producer-context.log 2>&1
for api in plain profiled; do
 "$scratch/root.test" -test.run "^TestTrustedGoReuseShadowCleanEditSession$/$api$" -test.count=1 -test.v -test.timeout=10m > "/evidence/clean-$api.log" 2>&1
done
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE=$route GOTREESITTER_V1_INVARIANT_LANGUAGE=go "$scratch/root.test" -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/invariant-$route.log" 2>&1
done
cd /candidate/cgo_harness
go test -overlay="$overlay" -tags treesitter_c_parity,gts_parsercorephase0 -run '^TestGo(Cognociente137KiBTopEditLockedC|MalformedDeclarationPrefixLockedC|AssignmentTargetEdits16SitesLockedC)$' -count=1 -v -timeout=12m . > /evidence/locked-c.log 2>&1
for arm in baseline candidate; do
 cd "/$arm"
 extra=(); if [[ "$arm" == candidate ]]; then extra=(-overlay=/controls/overlay.runtime.json); fi
 go build "${extra[@]}" -tags gts_parsercorephase0 -o "$scratch/$arm-ledger" ./cmd/perfcounterledger > "/evidence/$arm-ledger-build.log" 2>&1
 for lang in go yaml; do
  for route in default candidate; do
   mode=0; if [[ "$route" == candidate ]]; then mode=1; fi
   GTS_ADMISSION_CANDIDATE=$mode "$scratch/$arm-ledger" --child-route "$route" --langs "$lang" > "/evidence/$arm-$lang-$route.json" 2> "/evidence/$arm-$lang-$route.stderr"
  done
 done
done
