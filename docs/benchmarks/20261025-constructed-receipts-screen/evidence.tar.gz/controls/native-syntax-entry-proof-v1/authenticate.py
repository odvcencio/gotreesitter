import json,hashlib,pathlib
r=pathlib.Path('/controls/native-syntax-producer-v1');m=json.loads((r/'v4/manifest.json').read_text())
for f in m['files']:
 s=pathlib.Path('/candidate')/f['target'];b=r/f['backing']
 assert (hashlib.sha256(s.read_bytes()).hexdigest() if s.exists() else None)==f['base_sha256'],f['target']
 assert hashlib.sha256(b.read_bytes()).hexdigest()==f['candidate_sha256'],f['backing']
print(json.dumps({'authenticated':len(m['files']),'base_head':m['base_head']}))
