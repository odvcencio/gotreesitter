# Private lease-positive edit integration V2

Prepared only; no compilation or runtime execution. V1 remains frozen. Compose the V4 runtime map, V1 proof map (for its regular qualification shim), and this directory's one-file map. All targets are disjoint. Keep `/controls` bound to the parent go-ci-blockers-20261025 directory.

```
go test -overlay=/evidence/native-syntax-edits-overlay.json -tags=treesitter_c_parity,gts_parsercorephase0 ./cgo_harness -run '^TestPrivateNativeSyntaxPrimary500EditsLockedC$' -count=1 -v -timeout=4m
```

The three edits are independent subtests so every Tree.Edit consumes an actual lease from the exact original primary500 bytes. There is no Go tree walk, fresh Go parse or C tree parse before capture of the edit/incremental operation. Initial no-edit checks are followed by another lease/no-SelectedStore/one-root assertion. Each edited result has its own no-edit zero-allocation check, explicit fresh-Go equality, and both Go trees face the unchanged full-axis fresh locked-C comparator. The ordinary verifier remains enabled. This is a focused three-edit integration control, not a complete editing-session, incremental-C, performance or graduation claim.
