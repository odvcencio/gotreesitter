set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/native-syntax-v5-initial-qualification-v2/controls.sha256 > /evidence/controls-after.log 2>&1; python3 /controls/native-syntax-v5-initial-qualification-v2/authenticate.py > /evidence/frozen-inputs-after.json; }
trap finish EXIT
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/native-syntax-v5-initial-qualification-v2/controls.sha256 > /evidence/controls-before.log 2>&1
python3 /controls/native-syntax-v5-initial-qualification-v2/authenticate.py > /evidence/frozen-inputs-before.json
overlay=/controls/native-syntax-v5-initial-qualification-v2/overlay.core.tests.json
go test -overlay="$overlay" -run '^TestSyntax(Receipt|PoolCensus|Producer)' -count=1 -v -timeout=4m ./internal/parsercorephase0 > /evidence/core-release.log 2>&1
go test -overlay="$overlay" -tags gts_workcount -run '^TestSyntax(Receipt|PoolCensus|Producer)' -count=1 -v -timeout=4m ./internal/parsercorephase0 > /evidence/core-workcount.log 2>&1
go test -overlay="$overlay" -tags gts_eof_recovery_shadow -run '^TestSyntax(ReceiptDiagnosticClone|ProducerDiagnosticClone)' -count=1 -v -timeout=4m ./internal/parsercorephase0 > /evidence/core-shadow-clone.log 2>&1
overlay=/controls/native-syntax-v5-initial-qualification-v2/overlay.tests.json
go test -overlay="$overlay" -tags gts_parsercorephase0,gts_workcount -run '^TestPrivateNativeSyntax(PrimaryLifetime|IneligibleContexts|ConstructedReceiptOracle|ReceiptPlanesSingleOwner|ReceiptHistoryFallback)$' -count=1 -v -timeout=4m . > /evidence/root-receipts.log 2>&1
go test -overlay="$overlay" -tags gts_parsercorephase0 -run '^TestPrivateSyntaxPoolViewAccountingDrift$' -count=1 -v -timeout=4m . > /evidence/accounting.log 2>&1
go test -overlay="$overlay" -tags gts_parsercorephase0,gts_workcount -run '^TestPrivateSyntaxActualGoEntries$' -count=1 -v -timeout=4m . > /evidence/actual-entries.log 2>&1
printf 'initial V5 core/root/accounting/strict primary activation gates terminal; no performance claim\n' > /evidence/completed.txt
