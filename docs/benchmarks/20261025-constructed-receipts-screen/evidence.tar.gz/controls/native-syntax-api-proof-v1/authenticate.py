#!/usr/bin/env python3
import argparse,hashlib,json,pathlib,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--root',default='/candidate');p.add_argument('--controls',default=str(pathlib.Path(__file__).resolve().parent.parent));a=p.parse_args()
controls=pathlib.Path(a.controls);d=controls/'native-syntax-api-proof-v1';v=controls/'native-syntax-producer-v1/v4';m=json.loads((d/'manifest.json').read_text())
for name,key in [('manifest.json','base_v4_manifest_sha256'),('overlay.tests.json','base_v4_overlay_tests_sha256')]:
 if hashlib.sha256((v/name).read_bytes()).hexdigest()!=m[key]:sys.exit('frozen V4 control drift: '+name)
subprocess.run([sys.executable,str(v/'authenticate.py'),'--root',a.root,'--controls',str(v.parent)],check=True)
for row in m['additional_files']:
 if (pathlib.Path(a.root)/row['target']).exists():sys.exit('additional overlay target unexpectedly exists: '+row['target'])
 if hashlib.sha256((controls/row['backing']).read_bytes()).hexdigest()!=row['sha256']:sys.exit('API test backing drift: '+row['backing'])
print(json.dumps({'additional_authenticated':len(m['additional_files']),'execution_claim':False}))
