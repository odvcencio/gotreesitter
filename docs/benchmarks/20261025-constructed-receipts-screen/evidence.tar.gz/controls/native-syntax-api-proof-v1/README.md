# V4-positive syntax API/query controls

Prepared tests only, composing the frozen V4 test overlay without changing any V4 input. Every positive source first proves an actual syntax lease, absent SelectedStore and exactly one allocated public view. Off arms use the existing native snapshot publisher. Query source is fixed add/sub functions; lifetime source is fixed primary-style functions, with no comments/calls/cases or source-specific runtime filters.

Five query families cover field/supertype provenance, predicates/directives/ranges/text/set-values, disabled patterns/captures, Highlighter.highlightTree on the already-published tree, and documented MISSING matcher fallback. Two lifetime families cover a surviving copy copied after original release, independent producer reuse, cold receipts, and concurrent immutable reads/queries/copies while a different tree is released and Core is reset/reused. They never race a read with releasing that same tree.

Maps include frozen V4 API helpers. commands.json contains focused and race selectors. Prepared/goformatted only; no author build/test/Docker/timing execution. Parent owns qualification, including the actual primary/R4/C/D8 controls. No promotion or speed claim.
