#!/usr/bin/env python3
import argparse,hashlib,json,pathlib,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--root',default='/candidate');p.add_argument('--controls',default=str(pathlib.Path(__file__).resolve().parents[2]));a=p.parse_args();c=pathlib.Path(a.controls);d=c/'native-syntax-api-proof-v1';v=d/'v2';m=json.loads((v/'manifest.json').read_text())
subprocess.run([sys.executable,str(d/'authenticate.py'),'--root',a.root,'--controls',str(c)],check=True)
for name,key in [('manifest.json','base_v1_manifest_sha256'),('overlay.tests.json','base_v1_overlay_sha256')]:
 if hashlib.sha256((d/name).read_bytes()).hexdigest()!=m[key]:sys.exit('frozen API V1 drift: '+name)
if hashlib.sha256((v/'lifetime_private_test.go.txt').read_bytes()).hexdigest()!=m['changed_backing_sha256']:sys.exit('API V2 backing drift')
print(json.dumps({'v2_authenticated':True,'runtime_change':False,'execution_claim':False}))
