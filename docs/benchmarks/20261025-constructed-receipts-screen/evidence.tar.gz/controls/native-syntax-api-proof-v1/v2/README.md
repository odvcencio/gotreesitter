# API control V2: compare corresponding copy phases

Test-only correction after the independent same-order diagnostic actually failed identically on both publishers: original/first-copy rootword2, ordinary second-copy rootword0, first/second certified reusefalse. V1 failed bytes and both red diagnostic branches remain frozen. No runtime source changes.

Phase1 requires actual native snapshot versus actual syntax lease before inspection, exact first-copy tree/all cold receipts, positive first-copy root word equal to each original plane, known structural read bounds and no unsupported certification. Phase2 applies ordinary Tree.Copy in both arms, requires exact corresponding tree/all cold receipts, explicit root readunknown/zero and certifiedfalse, then tests Core reset/reparse and exact shape/query output after releasing originals and first copies. The unchanged canonical Node/public shape comparator remains. Six other API/query families remain unchanged.

Prepared/goformatted only; parent executes. No performance or promotion claim.
