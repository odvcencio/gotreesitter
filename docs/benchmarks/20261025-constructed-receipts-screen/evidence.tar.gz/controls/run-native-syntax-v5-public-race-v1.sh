set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/native-syntax-v5-public-race-v1/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/native-syntax-v5-public-race-v1/controls.sha256 > /evidence/controls-before.log 2>&1
go test -race -overlay=/controls/native-syntax-v5-semantic-qualification-v1/overlay.tests.json -tags gts_parsercorephase0 -run '^TestPrivateNativeSyntax(ConstructedReceiptOracle|ReceiptPlanesSingleOwner|ReceiptHistoryFallback|ReadBindingHandoff.*|PublicationSourceBinding|CopyAfterOriginalRelease|ConcurrentReadsOtherReleasesAndReset|PublicPoolCapacityAndBudget)$' -count=1 -v -timeout=5m . > /evidence/public-race.log 2>&1
printf 'constructed receipt, authority, public copy/read/reset and capacity race controls terminal\n' > /evidence/completed.txt
