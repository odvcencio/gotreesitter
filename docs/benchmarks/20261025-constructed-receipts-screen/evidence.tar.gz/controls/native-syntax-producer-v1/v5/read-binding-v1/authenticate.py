#!/usr/bin/env python3
import argparse,hashlib,json,pathlib,sys
p=argparse.ArgumentParser();p.add_argument('--root',default='/candidate');p.add_argument('--controls',default=str(pathlib.Path(__file__).resolve().parents[3]));a=p.parse_args()
r=pathlib.Path(__file__).resolve().parent;m=json.loads((r/'manifest.json').read_text());base=pathlib.Path(a.root);controls=pathlib.Path(a.controls)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for row in m['files']:
 source=base/row['target'];actual=digest(source) if source.exists() else None
 if actual!=row['base_sha256']:sys.exit('base drift: '+row['target'])
 if digest(controls/row['backing'])!=row['sha256']:sys.exit('backing drift: '+row['backing'])
for name,want in m['maps'].items():
 if digest(r/name)!=want:sys.exit('map drift: '+name)
if digest(r.parent/'frozen-inputs.json')!=m['original_v5_frozen_inputs_sha256']:sys.exit('original V5 manifest drift')
print(json.dumps({'authenticated':len(m['files']),'status':'identities match; no execution claim'},sort_keys=True))
