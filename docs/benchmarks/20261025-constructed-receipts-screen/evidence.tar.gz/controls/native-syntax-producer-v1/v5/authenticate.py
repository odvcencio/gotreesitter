#!/usr/bin/env python3
"""Check frozen source identities only. Never builds or changes source."""
import argparse,hashlib,json,pathlib,sys
p=argparse.ArgumentParser();p.add_argument('--root',default='/candidate');p.add_argument('--controls',default=str(pathlib.Path(__file__).resolve().parent.parent));a=p.parse_args()
base=pathlib.Path(a.root);exp=pathlib.Path(a.controls);v=exp/'v5';m=json.loads((v/'manifest.json').read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for row in m['inputs']:
 source=base/row['target'];actual=digest(source) if source.exists() else None
 if actual!=row['base_sha256']:sys.exit('base source drift: '+row['target'])
 if digest(exp/row['backing'])!=row['sha256']:sys.exit('overlay drift: '+row['backing'])
for name,want in m['maps'].items():
 if digest(v/name)!=want:sys.exit('map drift: '+name)
if digest(exp/'v4/manifest.json')!=m['preserved_v4_manifest_sha256']:sys.exit('preserved V4 manifest drift')
print(json.dumps({'authenticated':len(m['inputs']),'status':'frozen identities match; no execution claim'},sort_keys=True))
