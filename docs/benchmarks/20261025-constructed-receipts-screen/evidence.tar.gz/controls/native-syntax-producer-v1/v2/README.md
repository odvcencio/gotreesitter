# V2: abandoned neutral-pool ownership correction

V1 frozen core controls passed; V1 remains unchanged. A later read-only lifetime check found that a cached backing could outlive Core only through a second live lease after ResetReleasingRetention, outside the Core memory ledger. V2 retires/drains that abandoned neutral pool under its mutex, forbids late releases from repopulating it, and conservatively includes the owner descriptor in each live lease footprint. Runtime action/output logic is unchanged.

The new regression creates two live leases, returns the first to populate the cache, drops Core retention, checks cached bytes disappear while the second tree remains correct, and proves late release cannot restore the cache. Run all original core/clone/root controls again with the V2 maps; add ^TestSyntaxProducerRetiredPoolDoesNotRetainUnchargedBacking$. No author builds or executions. Qualification belongs to parent.
