from pathlib import Path
base=Path('/home/draco/work/gotreesitter')
out=base/'harness_out/docker/go-ci-blockers-20261025/native-syntax-producer-v1/core'
def edit(name,fn):
 s=(base/'internal/parsercorephase0'/name).read_text();t=fn(s);assert t!=s,name;(out/(name+'.txt')).write_text(t)
def rep(s,a,b):
 assert s.count(a)==1,(a[:100],s.count(a));return s.replace(a,b)
def core(s):
 s=rep(s,'\tsubtrees subtreeRecordBlocks','\tsyntaxProducer *SyntaxProducer\n\tsyntaxPool *syntaxLeasePool\n\tsubtrees subtreeRecordBlocks')
 s=rep(s,'\tc.classificationPhase++\n\tc.resetGeneration++','\tc.AbortSyntaxProducer()\n\tc.classificationPhase++\n\tc.resetGeneration++')
 s=rep(s,'\tc.externalTokenScannerExact = false\n\treturn nil\n}\n\n// ResetReleasingRetention','\tc.externalTokenScannerExact = false\n\tc.resetSyntaxProducer()\n\treturn nil\n}\n\n// ResetReleasingRetention')
 s=rep(s,'\tc.selectedPool = nil\n\tc.releaseOversizedRetention()','\tc.selectedPool = nil\n\tc.releaseSyntaxRetention()\n\tc.releaseOversizedRetention()')
 s=rep(s,'\treturn SubtreeID(c.subtrees.Len()), nil\n}\n\nfunc (c *Core) addWork','\tid := SubtreeID(c.subtrees.Len())\n\tif err := c.syntaxRecordPublished(id); err != nil { return 0, err }\n\treturn id, nil\n}\n\nfunc (c *Core) addWork')
 s=rep(s,'\treturn payload, scoreDelta, order, nil\n}', '''\tif c.syntaxProducer != nil && c.syntaxProducer.active {
  if found || multiPop || fork.Present || path.recoveryDiscontinuity || c.reduceNoLookaheadContext || c.reduceConflictContext { c.syntaxUnsupported("ambiguous or reused reduction") } else {
   previous, e := c.node(path.prev); if e != nil { return 0,0,ForkOrder{},e }
   if e = c.syntaxCompletePayload(payload,previous.state,key.state,false); e != nil { return 0,0,ForkOrder{},e }
  }
 }
\treturn payload, scoreDelta, order, nil
}''')
 s=rep(s,'\tprobe, oldID := c.boundaries.probe(boundaryIdentityFromKey(key))','\tprobe, oldID := c.boundaries.probe(boundaryIdentityFromKey(key))\n\tif probe.found { c.syntaxUnsupported("canonical boundary reuse") }')
 return s
edit('core.go',core)
def owned(s):
 a='\tc.lastShiftFresh = outcome.change == condenseNew\n\tc.addWork(&c.work.Shifts, 1)'
 assert s.count(a)==2
 b='\tif e := c.syntaxCompletePayload(payload,boundary.state,targetState,boundary.actions.Len()!=1 || fork.Present || outcome.change!=condenseNew); e != nil { return Head{},e }\n'+a
 s=s.replace(a,b,1)
 start=s.index('func (c *Core) shiftDirectUncheckpointed(');before,tail=s[:start],s[start:]
 tail=rep(tail,a,'\tif e := c.syntaxCompletePayload(payload,node.state,targetState,fork.Present || outcome.change!=condenseNew); e != nil { return Head{},e }\n'+a);s=before+tail
 for method in ('shiftOrdinaryClassifiedCohortUncheckpointed','shiftExtraClassifiedCohortUncheckpointed'):
  start=s.index('func (c *Core) '+method+'(');end=s.index('\n}\n',start)+3;part=s[start:end]
  part=rep(part,'\tpayload, err := c.appendAuthenticatedTerminal(', '\tif len(boundaries)!=1 { c.syntaxUnsupported("multiple shift cohort") }\n\tpayload, err := c.appendAuthenticatedTerminal(')
  part=rep(part,'\t\tout[index] = outcome.head','\t\tif e := c.syntaxCompletePayload(payload,boundary.state,targets[index],boundary.actions.Len()!=1 || outcome.change!=condenseNew); e != nil { return nil,e }\n\t\tout[index] = outcome.head')
  s=s[:start]+part+s[end:]
 return s
edit('scheduler_owned.go',owned)
def storage(s):
 s=rep(s,'\ttotal := c.nodes.FootprintBytes() +','\ttotal := c.SyntaxProducerFootprintBytes() + c.nodes.FootprintBytes() +')
 s=rep(s,'\treturn c.nodes.FootprintBytes() +','\treturn c.SyntaxProducerFootprintBytes() + c.nodes.FootprintBytes() +')
 s=rep(s,'func (c *Core) releaseOversizedRetention() {\n\tif c == nil || c.FootprintBytes() <= coreRetentionCapBytes {\n\t\treturn\n\t}', 'func (c *Core) releaseOversizedRetention() {\n\tif c == nil || c.FootprintBytes() <= coreRetentionCapBytes {\n\t\treturn\n\t}\n\tc.releaseSyntaxRetention()')
 return s
edit('storage_bytes.go',storage)
edit('eof_recovery_shadow.go',lambda s:rep(s,'\t*shadow = *live','\t*shadow = *live\n\tshadow.syntaxProducer = nil\n\tshadow.syntaxPool = nil'))
