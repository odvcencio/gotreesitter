#!/usr/bin/env python3
"""Authenticate frozen private overlay inputs; never builds or changes source."""
import argparse,hashlib,json,pathlib,sys
p=argparse.ArgumentParser();p.add_argument('--root',default='/candidate');p.add_argument('--controls',default=str(pathlib.Path(__file__).resolve().parent.parent));a=p.parse_args()
base=pathlib.Path(a.root);controls=pathlib.Path(a.controls);manifest=json.loads((controls/'v3/manifest.json').read_text())
for row in manifest['files']:
 source=base/row['target'];backing=controls/row['backing']
 actual=hashlib.sha256(source.read_bytes()).hexdigest() if source.exists() else None
 if actual!=row['base_sha256']:sys.exit('base source drift: '+row['target'])
 if hashlib.sha256(backing.read_bytes()).hexdigest()!=row['candidate_sha256']:sys.exit('overlay backing drift: '+row['backing'])
print(json.dumps({'authenticated':len(manifest['files']),'base_head':manifest['base_head'],'status':'input identities match; no execution claim'},sort_keys=True))
