set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/native-syntax-v5-handoff-diagnostic-v1/controls.sha256 > /evidence/controls-before.log 2>&1
set +e
go test -overlay=/controls/native-syntax-v5-handoff-diagnostic-v1/overlay.tests.json -tags gts_parsercorephase0,gts_workcount -run '^TestPrivateNativeSyntaxConstructedReceiptOracle$/^1$' -count=1 -v -timeout=4m . > /evidence/handoff-diagnostic.log 2>&1
result=$?
set -e
printf '%s\n' "$result" > /evidence/test-exit.txt
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1
sha256sum --quiet -c /controls/native-syntax-v5-handoff-diagnostic-v1/controls.sha256 > /evidence/controls-after.log 2>&1
