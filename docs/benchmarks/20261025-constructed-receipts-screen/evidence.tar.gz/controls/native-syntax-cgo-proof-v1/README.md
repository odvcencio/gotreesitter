# Private primary500 C proof

Prepared only; no author compilation or execution. Compose the disjoint `Replace` map from `overlay.container.json` with the separately frozen `../native-syntax-producer-v1/v4/overlay.json`. Keep `/candidate` read-only and `/controls` pointing at the parent go-ci-blockers-20261025 directory.

Run inside the existing isolated container, one grammar per process:

```
go test -overlay=/evidence/native-syntax-cgo-overlay.json -tags=treesitter_c_parity,gts_parsercorephase0 ./cgo_harness -run '^TestPrivateNativeSyntaxPrimary500LockedC$' -count=1 -v -timeout=4m
```

The regular root `.go` shim exposes only private qualification controls. Both arms use the ordinary candidate entry; one explicitly requires the original SelectedStore publisher, and the enabled arm requires a nonempty syntax lease, no SelectedStore, and only the root view before public inspection. Every arm uses the unchanged full-axis locked-C helper. Source, Go blob/grammar and oracle identities remain guarded. No query, incremental, race, memory, timing or graduation claim follows from this focused test.
