set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/native-syntax-public-budget-v5/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/native-syntax-public-budget-v5/controls.sha256 > /evidence/controls-before.log 2>&1
go test -overlay=/controls/native-syntax-public-budget-v5/overlay.tests.json -tags gts_parsercorephase0 -run '^TestPrivateNativeSyntaxPublicPoolCapacityAndBudget$' -count=1 -v -timeout=4m . > /evidence/public-budget.log 2>&1
go test -race -overlay=/controls/native-syntax-v5-initial-qualification-v2/overlay.core.tests.json -run '^TestSyntax(Receipt|PoolCensus|Producer)' -count=1 -v -timeout=4m ./internal/parsercorephase0 > /evidence/core-race.log 2>&1
printf 'V5 draft public-path unused-capacity/census/budget proof complete; constructed-receipt activation still unresolved\n' > /evidence/completed.txt
