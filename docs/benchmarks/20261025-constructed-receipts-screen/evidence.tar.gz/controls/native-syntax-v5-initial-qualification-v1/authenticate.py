from pathlib import Path
import hashlib,json
r=Path('/controls/native-syntax-producer-v1');m=json.loads((r/'v5/frozen-inputs.json').read_text())
for f in m['inputs']:
 s=Path('/candidate')/f['target'];assert (hashlib.sha256(s.read_bytes()).hexdigest() if s.exists() else None)==f['base_sha256'],f['target']
 assert hashlib.sha256((r/f['backing']).read_bytes()).hexdigest()==f['sha256'],f['backing']
print(json.dumps({'authenticated_frozen_V5_inputs':len(m['inputs']),'execution_claim':False}))
