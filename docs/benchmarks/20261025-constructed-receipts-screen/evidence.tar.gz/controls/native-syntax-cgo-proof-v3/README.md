# Private lease-positive coordinates V3

Prepared only; no compilation or runtime execution. Compose the frozen V4 runtime map, V1 proof map for its regular qualification shim, and this directory's one-file map. V1/V2 remain unchanged. Keep `/controls` bound to the parent go-ci-blockers-20261025 directory.

```
go test -overlay=/evidence/native-syntax-coordinate-overlay.json -tags=treesitter_c_parity,gts_parsercorephase0 ./cgo_harness -run '^TestPrivateNativeSyntaxCoordinatesLockedC$' -count=1 -v -timeout=4m
```

Three small, syntactically valid Go sources cover leading whitespace, UTF-8 identifiers/literals, and CRLF plus leading trivia and UTF-8. Each must use an actual syntax lease with no SelectedStore and only one root view before any inspection. Every source then faces the unchanged exact locked-C comparator for symbols, fields, byte spans, points, flags and full deep digest. Source byte lengths/hashes, actual lease node counts and C identity/digest are logged. No fallback, skip, normalized coordinate comparison or expected divergence can satisfy the positive checks. These are prepared fresh-coordinate controls, with no execution or wider qualification claim.
