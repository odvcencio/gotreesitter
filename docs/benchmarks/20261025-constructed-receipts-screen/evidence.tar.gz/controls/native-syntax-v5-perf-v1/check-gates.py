from pathlib import Path
import json,re,hashlib
r=Path(__file__).resolve().parents[1];out=r/'out'
def check(folder,logs,expected_exit=0):
 p=out/folder;assert json.loads((p/'finished.json').read_text())['exit_code']==expected_exit,folder
 for n in ('source-before.log','source-after.log','controls-before.log','controls-after.log'):assert (p/n).read_text()=='',(folder,n)
 for n,count in logs.items():
  t=(p/n).read_text();assert len(re.findall(r'^--- PASS:',t,re.M))==count,(folder,n);assert not re.search(r'--- (FAIL|SKIP):|WARNING: DATA RACE|^FAIL\b',t,re.M),(folder,n)
 return p
check('native-syntax-v5-reads-qualification-v2',{'reads-all.log':42,'reads-race.log':9})
check('native-syntax-v5-initial-qualification-v2',{'core-release.log':16,'core-workcount.log':16,'core-shadow-clone.log':2},expected_exit=1)
check('native-syntax-public-budget-v5',{'public-budget.log':1,'core-race.log':16})
p=check('native-syntax-v5-initial-qualification-v4',{'root-receipts.log':8,'accounting.log':1,'actual-entries.log':1})
rows=[json.loads(x.split('SYNTAX_ACTUAL_ENTRY ',1)[1]) for x in (p/'actual-entries.log').read_text().splitlines() if 'SYNTAX_ACTUAL_ENTRY ' in x];assert len(rows)==4
for fixture in ('primary-500','real-r4'):
 a,b=[x for x in rows if x['fixture']==fixture];assert a['digest']==b['digest'] and a['board']==b['board'] and a['publication']['core_work']==b['publication']['core_work']
 diff={k:[v,b['work'].get(k)] for k,v in a['work'].items() if b['work'].get(k)!=v}
 if fixture=='primary-500':
  v=b['publication'];assert v['lease'] and v['constructed_cold'] and v['borrowed_cold'] and not v['original_cold_capture'] and not v['selected_store'];assert v['status']['ConstructedReceipts'];assert diff=={'table_lookups_proxy':[41515,26010]}
 else:assert not b['publication']['lease'] and b['publication']['original_cold_capture'] and not diff
p=check('native-syntax-v5-semantic-qualification-v1',{'core-reference.log':55,'focused.log':36,'go-public-api.log':3,'new-api-budget.log':8,'constructed-cgo.log':3,'go-cgo.log':10,'yaml-cgo.log':8,**{f'invariants-{lang}-{mode}.log':1 for lang in ('go','yaml') for mode in (0,1)}})
for lang in ('go','yaml'):
 for route in ('default','candidate'):
  name=f'{route}-{lang}.json';assert json.loads((p/name).read_text())==json.loads((out/'packed-snapshot-budget-final/ledger'/name).read_text())
 for mode in (0,1):assert 'session_steps=72 no_edit_allocs=0' in (p/f'invariants-{lang}-{mode}.log').read_text()
check('native-syntax-v5-public-race-v1',{'public-race.log':9})
print(json.dumps({'schema':'gts-constructed-receipt-preperf/v1','all_focused_semantic_gates_passed':True,'actual_primary500_constructed_cold':True,'original_capture_skipped_on_primary':True,'source_history_generation_bytes':8,'ordinary_actual_rows_equal':4,'R4_sessions':4,'R4_steps':288,'no_edit_allocs':0,'merges_held':True,'runtime_promoted':False,'full_fleet_qualified':False}))
