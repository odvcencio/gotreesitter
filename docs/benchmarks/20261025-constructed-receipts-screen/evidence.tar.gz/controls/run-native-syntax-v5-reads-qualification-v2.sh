set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/native-syntax-v5-reads-qualification-v2/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/native-syntax-v5-reads-qualification-v2/controls.sha256 > /evidence/controls-before.log 2>&1
overlay=/controls/native-syntax-v5-reads-qualification-v2/overlay.container.json
go test -overlay="$overlay" -run '^Test' -count=1 -v -timeout=3m ./internal/incr > /evidence/reads-all.log 2>&1
go test -race -overlay="$overlay" -run '^TestClosedReads' -count=1 -v -timeout=3m ./internal/incr > /evidence/reads-race.log 2>&1
printf 'complete internal/incr unit suite and new closed-read race families terminal; V5 integration remains unqualified\n' > /evidence/completed.txt
