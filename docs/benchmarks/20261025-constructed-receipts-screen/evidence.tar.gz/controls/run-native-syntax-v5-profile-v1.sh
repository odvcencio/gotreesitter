set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/native-syntax-v5-profile-v1/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/native-syntax-v5-profile-v1/controls.sha256 > /evidence/controls-before.log 2>&1
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/native-syntax-v5-profile-v1
mkdir -p "$scratch"
for arm in baseline candidate; do
 cd "/$arm"
 go test -c -overlay=/controls/native-syntax-v5-perf-v1/overlay.container.json -tags gts_parsercorephase0 -o "$scratch/$arm.test" . > "/evidence/$arm-build.log" 2>&1
 GTS_ADMISSION_CANDIDATE=1 GTS_BENCHMARK_SEED=31 /usr/bin/time -v "$scratch/$arm.test" -test.run '^$' -test.bench '^BenchmarkGraduationGoSuite$/^Full$' -test.benchtime=5s -test.count=1 -test.benchmem -test.cpuprofile="/evidence/$arm.cpu" -test.memprofile="/evidence/$arm.mem" > "/evidence/$arm-profile.log" 2> "/evidence/$arm-time.txt"
 go tool pprof -top -nodecount=45 "$scratch/$arm.test" "/evidence/$arm.cpu" > "/evidence/$arm-top.txt" 2>&1
 go tool pprof -top -cum -nodecount=60 "$scratch/$arm.test" "/evidence/$arm.cpu" > "/evidence/$arm-cum.txt" 2>&1
 sha256sum "$scratch/$arm.test" > "/evidence/$arm-binary.sha256"
done
cd /candidate
printf 'exact baseline/V5 profiles complete; attribution only, no randomized speed claim\n' > /evidence/completed.txt
