# Private public-path syntax capacity and budget proof

Prepared only; no compilation or runtime execution. The SAME public root test runs on V4 and V5. Compose its matching own map with the separately frozen V4/V5 full test/runtime map. No frozen runtime source is copied or changed. The two Core helper variants explicitly enumerate V5 receipt planes; the root view variants verify V5 borrowed plane aliases and count them once.

```
go test -overlay=/evidence/native-syntax-budget-v4-or-v5-overlay.json -tags=gts_parsercorephase0 . -run '^TestPrivateNativeSyntaxPublicPoolCapacityAndBudget$' -count=1 -v -timeout=4m
```

Actual ordinary public generated-Go Parse produces three asserted leases (128,2,1functions;4786/84/49bytes, all below primary500). No public walk happens before lease ownership checks. The normal admission borrow seam rebinds the returned runner/table adapter before Core operations.

The test independently enumerates raw block capacities, every producer/pool owned slice, descriptors, Symbols and fixed weak gauge. The expected census never calls the cached pool gauge, backing.retainedBytes, producer.retainedBytes or raw bufferBytes. A separate whole-view census counts actual retained page pointers, points, checkpoints and owned cold planes; V5 borrowed cold headers must alias the owning lease exactly and are not billed twice. The reported footprint is compared with this census; smaller live lease/arena charges and its immutable root remain unchanged through all unrelated lifetime actions.

A qualification-only helper enters the real fresh Core owner and invokes existing producer.reserve(1). Its test callback releases the actual larger public tree BEFORE delegating unchanged scheduler.ReserveSyntax, which recomputes current storage and adds only the new allocation delta. This bounded preflight fabricates no syntax/output and performs no new allocation. The released larger backing must be retained unused, then Reset must transfer it into Core exactly once while conserving the syntax/raw/sidecar capacity charge. Existing scheduler soft/hard methods reject equality and allow equality+1, including the smaller actual public arena as explicit additional ownership. Retirement removes Core syntax ownership; a deliberately strong test witness observes that a late unrelated release cannot refill the retired pool. The strong witness is test-owned, not a production retention or weak-GC result.

These are serial retained-capacity/budget controls, not heap/RSS, C parity, race, timing, platform, fleet or graduation evidence. Parent owns all execution and final V5 runtime authentication. Frozen V4/V5 and other controls remain unchanged.
