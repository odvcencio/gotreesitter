from pathlib import Path
import fcntl,hashlib,json,os,re,subprocess
base=Path('/Users/georgevillavicencio/.local/state/gotreesitter-compute/20261021-arm64-native-fields')
p=base/'pending-parent-storage-screen-v1';origin=base/'parent-copy-census-v1';binary=origin/'root.test'
os.environ['PATH']='/Applications/Docker.app/Contents/Resources/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin'
def digest(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def manifest(root):return {str(f.relative_to(root)):digest(f) for f in sorted(root.rglob('*.go')) if f.is_file()}
def checkout():
 w='/Users/georgevillavicencio/Projects/gotreesitter'
 return {'head':subprocess.check_output(['git','-C',w,'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',w,'status','--porcelain=v1'],text=True)}
with open(base.parent/'compute.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 assert (origin/'exit.txt').read_text().strip()=='0'
 expected=json.loads((origin/'before.json').read_text())['diagnostic_go'];before=manifest(origin/'source');user=checkout();sha=digest(binary)
 assert before==expected
 (p/'before.json').write_text(json.dumps({'diagnostic_source_go':before,'binary_sha256':sha,'checkout':user,'production_PR_head':'4de229c4b1718989917c6212f92cf74df28cf229'},sort_keys=True)+'\n')
 docker='/usr/local/bin/docker';name='gts-pending-parent-storage-screen-native-20261022-v1'
 args=[docker,'run','--platform','linux/arm64','--name',name,'--network','none','--memory','4g','--memory-swap','4g','--cpus','2','--cpuset-cpus','2,3','--pids-limit','256','-e','GOMAXPROCS=1','-e','GOMEMLIMIT=3GiB','-e','GOT_GLR_V2_PENDING_PARENTS=1','-e','GTS_PARENT_CENSUS_ROUTE=0','-v',str(origin)+':/input:ro','-v',str(origin/'source')+':/candidate:ro','-w','/candidate','golang@sha256:3b4a11519ad929d1e1d261a12cff056f0c85b735253d7d861346b9c6f8b36437','/input/root.test','-test.run=^TestRSSParentCensusGo$','-test.v','-test.count=1','-test.timeout=5m']
 (p/'command.json').write_text(json.dumps(args,indent=2)+'\n')
 with (p/'census.log').open('wb') as log:result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 inspection=json.loads(subprocess.check_output([docker,'inspect',name],text=True))[0];(p/'inspect.json').write_text(json.dumps(inspection,indent=2)+'\n');subprocess.run([docker,'rm',name],check=True,stdout=subprocess.DEVNULL)
 audit={'exit_code':result.returncode,'binary_unchanged':sha==digest(binary),'source_unchanged':before==manifest(origin/'source'),'checkout_unchanged':user==checkout(),'state':inspection['State'],'production_source_changed':False,'performance_comparison':False,'manual_GC':False}
 (p/'parent-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
 assert result.returncode==0 and not inspection['State']['OOMKilled']
 text=(p/'census.log').read_text();assert re.search(r'^PASS$',text,re.M) and 'FAIL' not in text
 rows=[json.loads(line.split('CENSUS ',1)[1]) for line in text.splitlines() if 'CENSUS ' in line]
 assert len(rows)==3
 baseline=[x for x in json.loads((origin/'census.json').read_text()) if not x['route']]
 assert [x['digest'] for x in baseline]==[x['digest'] for x in rows]
 assert all(x['source_sha256']==baseline[0]['source_sha256'] and not x['route'] and x['compact_routes']==0 for x in rows)
 assert all(audit[k] for k in ['binary_unchanged','source_unchanged','checkout_unchanged'])
 (p/'census.json').write_text(json.dumps(rows,indent=2)+'\n');(p/'exit.txt').write_text('0\n')
