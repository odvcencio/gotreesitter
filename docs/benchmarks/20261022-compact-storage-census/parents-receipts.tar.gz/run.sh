#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOMAXPROCS=1 GOWORK=off GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
cd /candidate
go version > /evidence/go-version.txt
go env GOOS GOARCH > /evidence/platform.txt
if [[ "$(go env GOARCH)" != arm64 ]]; then exit 30; fi
go test -c -tags gts_parsercorephase0 -o /evidence/root.test . > /evidence/build.log 2>&1
for route in 0 1; do
 GTS_PARENT_CENSUS_ROUTE="$route" /evidence/root.test -test.run '^TestRSSParentCensusGo$' -test.v -test.count=1 -test.timeout=5m > "/evidence/census-${route}.log" 2>&1
done
