from pathlib import Path
import fcntl,hashlib,json,os,re,shutil,subprocess
base=Path('/Users/georgevillavicencio/.local/state/gotreesitter-compute/20261021-arm64-native-fields')
p=base/'parent-copy-census-v1'
original=base/'read-history-publication-net-v1/candidate'
source=p/'source'
os.environ['PATH']='/Applications/Docker.app/Contents/Resources/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin'
def manifest(root):return {str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(root.rglob('*.go')) if f.is_file()}
def checkout():
 w='/Users/georgevillavicencio/Projects/gotreesitter'
 return {'head':subprocess.check_output(['git','-C',w,'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',w,'status','--porcelain=v1'],text=True)}
with open(base.parent/'compute.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 assert (base/'read-history-publication-net-v1/paired-perf/exit.txt').read_text().strip()=='0'
 scope=json.loads((p/'scope.json').read_text());before=manifest(original);user=checkout()
 assert before==scope['source_go'] and len(before)==3544
 for name,sha in scope['files'].items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==sha
 shutil.copytree(original,source,copy_function=os.link)
 for rel,name in scope['overlays'].items():
  f=source/rel;t=f.with_name(f.name+'.gts-tmp');t.write_bytes((p/name).read_bytes());t.replace(f)
 modified=manifest(source)
 assert sorted(k for k in before if before[k]!=modified[k])==sorted(scope['overlays'])
 (p/'before.json').write_text(json.dumps({'original_go':before,'diagnostic_go':modified,'checkout':user},sort_keys=True)+'\n')
 docker='/usr/local/bin/docker';name='gts-parent-copy-census-native-20261022-v1'
 image='golang@sha256:3b4a11519ad929d1e1d261a12cff056f0c85b735253d7d861346b9c6f8b36437'
 args=[docker,'run','--platform','linux/arm64','--name',name,'--network','none','--memory','4g','--memory-swap','4g','--cpus','2','--cpuset-cpus','2,3','--pids-limit','256','-e','GOMAXPROCS=1','-e','GOMEMLIMIT=3GiB','-e','GOCACHE=/go-build','-v',str(base/'inactive-scanner-trials-v1/go-build')+':/go-build','-v',str(source)+':/candidate:ro','-v',str(p)+':/evidence',image,'bash','/evidence/run.sh']
 (p/'command.json').write_text(json.dumps(args,indent=2)+'\n')
 with (p/'container.log').open('wb') as out:result=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT,timeout=900)
 inspection=json.loads(subprocess.check_output([docker,'inspect',name],text=True))[0]
 (p/'inspect.json').write_text(json.dumps(inspection,indent=2)+'\n')
 subprocess.run([docker,'rm',name],check=True,stdout=subprocess.DEVNULL)
 audit={'exit_code':result.returncode,'original_unchanged':before==manifest(original),'diagnostic_unchanged':modified==manifest(source),'checkout_unchanged':user==checkout(),'state':inspection['State'],'performance_comparison':False,'manual_GC':False}
 (p/'parent-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
 assert result.returncode==0 and not inspection['State']['OOMKilled']
 records=[]
 for route in [0,1]:
  text=(p/('census-%d.log'%route)).read_text();assert re.search(r'^PASS$',text,re.M) and 'FAIL' not in text
  rows=[json.loads(line.split('CENSUS ',1)[1]) for line in text.splitlines() if 'CENSUS ' in line]
  assert len(rows)==3 and [x['step'] for x in rows]==[0,1,2]
  assert all(x['route']==bool(route) and x['source_bytes']==1048591 and x['source_sha256']=='76c70b62127085d3c791ba98a24cba9f22bd343e40afb43522bbb5041cede524' for x in rows)
  records.extend(rows)
 assert len(set(x['digest'] for x in records))==1
 assert all(audit[k] for k in ['original_unchanged','diagnostic_unchanged','checkout_unchanged'])
 (p/'census.json').write_text(json.dumps(records,indent=2)+'\n');(p/'exit.txt').write_text('0\n')
