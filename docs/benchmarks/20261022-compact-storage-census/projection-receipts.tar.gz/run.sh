#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOMAXPROCS=1 GOWORK=off GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
cd /candidate
go version > /evidence/go-version.txt
go env GOOS GOARCH > /evidence/platform.txt
if [[ "$(go env GOARCH)" != arm64 ]]; then exit 30; fi
go test -c -tags gts_parsercorephase0 -o /evidence/root.test . > /evidence/build.log 2>&1
for spec in yaml:r4_owned yaml:eof8k_owned yaml:r4_ordinary go:grammargen_lr go:one_mib; do
 lang="${spec%%:*}"; case_name="${spec#*:}"
 GTS_PROJECTION_LANG="$lang" GTS_PROJECTION_CASE="$case_name" /evidence/root.test -test.run '^TestAcceptanceProjectionCensus$' -test.v -test.count=1 -test.timeout=5m > "/evidence/${lang}-${case_name}.log" 2>&1
done
