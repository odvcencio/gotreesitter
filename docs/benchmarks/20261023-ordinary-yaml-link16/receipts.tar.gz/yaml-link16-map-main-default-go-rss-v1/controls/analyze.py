from pathlib import Path
import json,re,statistics
p=Path('/evidence');roles={}
for role in ('baseline','candidate'):
 rows=[]
 for seed in range(172001,172021):
  d=json.loads((p/'rss'/f'{role}-{seed}.json').read_text());assert d['exit_code']==0 and d['manual_GC']==False
  s=(p/'rss'/f'{role}-{seed}.log').read_text();assert 'PASS' in s and 'measured_iteration_work_checked=true' in s and 'bytes=1048591' in s and 'sha256=76c70b62127085d3c791ba98a24cba9f22bd343e40afb43522bbb5041cede524' in s
  m=re.search(r'\s(\d+) B/op\s+(\d+) allocs/op',s);assert m
  rows.append({'seed':seed,'RSS_bytes':d['max_rss_bytes'],'B_op':int(m[1]),'allocs_op':int(m[2])})
 roles[role]={'rows':rows,'rss_median':statistics.median(x['RSS_bytes'] for x in rows),'rss_max':max(x['RSS_bytes'] for x in rows),'B_op_median':statistics.median(x['B_op'] for x in rows),'allocs_median':statistics.median(x['allocs_op'] for x in rows)}
ratios={k:roles['candidate'][k]/roles['baseline'][k] for k in ('rss_median','B_op_median','allocs_median')}
passed=all(x<=1.1 for x in ratios.values()) and roles['candidate']['rss_max']<=1048591*400
report={'roles':roles,'ratios':ratios,'absolute_limit':1048591*400,'passed':passed,'not_timing_evidence':True,'per_iteration_work_checked':True}
(p/'qualification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='roles'}))
if not passed:raise SystemExit('default Go memory or allocation gate failed')
