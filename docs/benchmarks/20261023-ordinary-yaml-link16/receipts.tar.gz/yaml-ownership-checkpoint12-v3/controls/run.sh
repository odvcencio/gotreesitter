set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
cd /candidate
go test ./internal/parsercorephase0 -count=1 -v -timeout=8m > /evidence/core-unit.log 2>&1
go test -tags gts_eof_recovery_shadow ./internal/parsercorephase0 -count=1 -v -timeout=8m > /evidence/core-shadow.log 2>&1
go test -race ./internal/parsercorephase0 -run '^Test(Checkpoint|EmptyCheckpoint|CoreCheckpoint|.*PrivateCopy.*)' -count=1 -v -timeout=8m > /evidence/core-race.log 2>&1
go test -c -tags gts_parsercorephase0 -o /evidence/candidate.test . > /evidence/root-build.log 2>&1
/evidence/candidate.test -test.run '^Test(DiagnosticParserCoreVersionLexerSnapshot.*|VersionLexerPairedValidation.*|FreshSnapshotPages.*|SnapshotPairFootprint.*|CompactExternalScannerCheckpoint.*|DiagnosticParserCoreElectionPreservesInvalidCheckpointDeclines|DiagnosticParserCoreCheckpointCompactLayoutsAMD64|DiagnosticParserCore.*Ownership.*|DiagnosticParserCore.*OwnedLexer.*|CompactYAMLReductionSelectionPreservesSampleWork)$' -test.count=1 -test.v -test.timeout=5m > /evidence/root-checkpoint.log 2>&1
for lang in go yaml; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /evidence/candidate.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/$lang-invariant-$route.log" 2>&1
 done
done
/evidence/candidate.test -test.run '^Test(CompactAcceptance(ChangedSourceKeepsRebuildBudget|CachedPublicationStopControl)|CompactMemoryBudgetDetectsGrowthAfterSmallPoll|CompactAcceptance.*(MemoryBudget|RetentionBound)|CompactArenaReserve.*(Budget|RetentionCap)|CompactExternalScannerCheckpointCopyMemoryBudget|CompactRecoveryMemoMemoryBudget|CompactBorrowedMaterializationProjectionMemoryBudget|G18RefSetSchedulerMemoryBudgetAccounting|RuntimeMemoryBudget.*|RuntimeMemoryHardCeilingStillStopsParse|ParseMemoryHardCeiling.*)$' -test.count=1 -test.v -test.timeout=8m > /evidence/memory.log 2>&1
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/candidate-cgo.test . > /evidence/cgo-build.log 2>&1
GTS_YAML_LARGE_PROBE=1 /evidence/candidate-cgo.test -test.run '^Test(YAMLOwnedGrammarLockedCParity|CompactYAMLDocumentStreamLockedC|YAMLRecoveredMappingQuotesLockedC|YAMLEOFRecoverWrapCompactRoute|YAMLEOFRecoverWrapUnfinishedMappingDeclinesCompact|YAMLOneBytePrintableEOFAdmissionMatchesLockedC)$' -test.count=1 -test.v -test.timeout=8m > /evidence/yaml-owned-cgo.log 2>&1
for lang in go yaml; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GTS_PARITY_MODE=exhaustive /evidence/candidate-cgo.test -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${lang}$" -test.count=1 -test.v -test.timeout=5m > "/evidence/$lang-cgo-$route.log" 2>&1
 done
done
for role in baseline candidate; do
 cd "/$role"
 go build -tags gts_parsercorephase0 -o "/evidence/$role-ledger" ./cmd/perfcounterledger > "/evidence/$role-ledger-build.log" 2>&1
 for lang in go yaml; do
  "/evidence/$role-ledger" --langs "$lang" > "/evidence/$role-$lang-ledger.json" 2> "/evidence/$role-$lang-ledger.log"
 done
done
cmp /evidence/baseline-go-ledger.json /evidence/candidate-go-ledger.json
printf 'complete\n' > /evidence/complete.txt
