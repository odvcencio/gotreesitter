set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 CGO_ENABLED=0 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
python3 /controls/source_hashes.py > /evidence/source-before.json
cd /candidate
bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-yaml.txt --output /evidence/candidate-yaml.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 169001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputYAML$' --require-benchmarks 'BenchmarkCompactThroughputYAML/r4_legacy,BenchmarkCompactThroughputYAML/eof8k_legacy,BenchmarkCompactThroughputYAML/r4_ordinary,BenchmarkCompactThroughputYAML/eof8k_ordinary,BenchmarkCompactThroughputYAML/r4_owned,BenchmarkCompactThroughputYAML/eof8k_owned' > /evidence/yaml-driver.log 2>&1
bash scripts/run_randomized_benchmarks.sh --primary-go-suite --baseline-root /baseline --baseline-output /evidence/baseline-go.txt --output /evidence/candidate-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 170001 --benchtime 750ms > /evidence/go-driver.log 2>&1
GTS_ADMISSION_CANDIDATE=1 bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-compact-go.txt --output /evidence/candidate-compact-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 171001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputGo$' --require-benchmarks 'BenchmarkCompactThroughputGo/full_dfa,BenchmarkCompactThroughputGo/single_byte_edit_dfa,BenchmarkCompactThroughputGo/no_edit_dfa,BenchmarkCompactThroughputGo/fresh_one_mib,BenchmarkCompactThroughputGo/query_compile,BenchmarkCompactThroughputGo/grammargen_lr' > /evidence/compact-go-driver.log 2>&1
python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'complete\n' > /evidence/complete.txt
