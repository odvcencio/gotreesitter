set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
cd /candidate
go version > /evidence/go-version.txt
python3 /controls/source_hashes.py > /evidence/source-before.json
go test -c -overlay=/controls/overlay.json -tags gts_parsercorephase0 -o /evidence/storage.test . > /evidence/build.log 2>&1
GTS_STORAGE_CASE=yaml /evidence/storage.test -test.run '^TestAcceptedStorageCensus$' -test.count=1 -test.v -test.timeout=5m -test.memprofile=/evidence/alloc.pprof > /evidence/storage.log 2>&1
go tool pprof -top -alloc_space /evidence/storage.test /evidence/alloc.pprof > /evidence/alloc-top.txt 2>&1
go build -gcflags='github.com/odvcencio/gotreesitter/internal/parsercorephase0=-m=2' ./internal/parsercorephase0 > /evidence/compiler-inline.log 2>&1
go tool pprof -list 'checkpointInterner.*internHash' /evidence/storage.test /evidence/alloc.pprof > /evidence/checkpoint-alloc-lines.txt 2>&1
python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'complete\n' > /evidence/complete.txt
