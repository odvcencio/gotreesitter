set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 CGO_ENABLED=0 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
python3 /controls/source_hashes.py > /evidence/source-before.json
cp /controls/rss-wrapper.go.txt /evidence/rss-wrapper.go
go build -o /evidence/rsswrap /evidence/rss-wrapper.go > /evidence/rss-wrapper-build.log 2>&1
for role in baseline candidate; do
 cd "/$role/roottest/bench"
 go test -c -overlay=/controls/overlay.json -tags gts_parsercorephase0 -o "/evidence/$role-memory.test" . > "/evidence/$role-build.log" 2>&1
done
mkdir /evidence/rss
for seed in $(seq 174001 174020); do
 if (( seed % 2 )); then roles=(baseline candidate); else roles=(candidate baseline); fi
 for role in "${roles[@]}"; do
  cd "/$role/roottest/bench"
  GTS_FRESH_MEMORY_LANG=go GTS_ADMISSION_CANDIDATE=1 /evidence/rsswrap "/evidence/rss/$role-$seed.json" "/evidence/$role-memory.test" -test.run '^$' -test.bench '^BenchmarkFreshMemory$/^go$/^1024KiB$' -test.benchtime=2x -test.count=1 -test.benchmem -test.shuffle="$seed" -test.timeout=5m > "/evidence/rss/$role-$seed.log" 2>&1
 done
done
python3 /controls/analyze.py > /evidence/analysis.log 2>&1
python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'complete\n' > /evidence/complete.txt
