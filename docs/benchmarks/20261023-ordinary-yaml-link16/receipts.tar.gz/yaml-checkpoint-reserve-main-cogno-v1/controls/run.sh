set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
python3 /controls/source_hashes.py > /evidence/source-before.json
cd /candidate/cgo_harness
go test -c -overlay=/controls/overlay.json -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/candidate-cgo.test . > /evidence/build.log 2>&1
for route in production candidate; do
 for api in plain profiled; do
  for edit in insert replace delete; do
   label="$route-$api-$edit"
   if /evidence/candidate-cgo.test -test.run "^TestGoCognociente137KiBTopEditLockedC$/^$route$/^$api$/^$edit$" -test.v -test.count=1 -test.timeout=5m > "/evidence/$label.log" 2>&1; then code=0; else code=$?; fi
   printf '%s\t%s\n' "$label" "$code" >> /evidence/status.tsv
   if [[ "$edit" != delete && "$code" != 0 ]]; then exit "$code"; fi
  done
 done
done
/evidence/candidate-cgo.test -test.run '^TestGoCognocienteDeleteLockedCTrace$' -test.v -test.count=1 -test.timeout=5m > /evidence/C-delete-trace.log 2>&1
python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'complete\n' > /evidence/complete.txt
