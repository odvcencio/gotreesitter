set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
python3 /controls/source_hashes.py > /evidence/source-before.json
cd /candidate
mkdir /evidence/invariants /evidence/cgo /evidence/ledger
while IFS= read -r lang; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /compiled/candidate.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/invariants/$route-$lang.log" 2>&1
  printf 'invariant\t%s\t%s\n' "$lang" "$route" >> /evidence/progress.tsv
 done
done < /controls/languages.txt
cd /candidate/cgo_harness
while IFS= read -r lang; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GTS_PARITY_MODE=exhaustive /compiled/candidate-cgo.test -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${lang}$" -test.count=1 -test.v -test.timeout=5m > "/evidence/cgo/$route-$lang.log" 2>&1
  printf 'C\t%s\t%s\n' "$lang" "$route" >> /evidence/progress.tsv
 done
done < /controls/languages.txt
cd /candidate
while IFS= read -r lang; do
 /compiled/baseline-ledger --langs "$lang" > "/evidence/ledger/baseline-$lang.json" 2> "/evidence/ledger/baseline-$lang.log"
 /compiled/candidate-ledger --langs "$lang" > "/evidence/ledger/candidate-$lang.json" 2> "/evidence/ledger/candidate-$lang.log"
 if [[ "$lang" = yaml ]]; then
  cmp /compiled/baseline-yaml-ledger.json "/evidence/ledger/baseline-$lang.json"
  cmp /compiled/candidate-yaml-ledger.json "/evidence/ledger/candidate-$lang.json"
 else
  cmp "/evidence/ledger/baseline-$lang.json" "/evidence/ledger/candidate-$lang.json"
 fi
 printf 'ledger\t%s\n' "$lang" >> /evidence/progress.tsv
done < /controls/languages.txt
python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'complete\n' > /evidence/complete.txt
