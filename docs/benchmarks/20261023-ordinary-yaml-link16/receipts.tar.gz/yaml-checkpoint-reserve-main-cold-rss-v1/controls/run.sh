set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
python3 /controls/source_hashes.py > /evidence/source-before.json
mkdir /evidence/census /evidence/probes
for role in baseline candidate; do
 cd "/$role"
 go test -c -overlay=/controls/overlay.json -tags gts_parsercorephase0 -o "/evidence/probes/$role-rss-root.test" . > "/evidence/probes/$role-build.log" 2>&1
 GTS_ADMISSION_CANDIDATE=1 "/evidence/probes/$role-rss-root.test" -test.run '^TestStreamedPrefix(PublicWorkCensus|AttemptCensus)$' -test.count=1 -test.v -test.timeout=5m > "/evidence/census/$role.log" 2>&1
 cd "/$role/cgo_harness"
 go test -c -overlay=/controls/overlay.json -tags treesitter_c_parity,gts_parsercorephase0 -o "/evidence/$role-cgo.test" . > "/evidence/$role-cgo-build.log" 2>&1
 "/evidence/$role-cgo.test" -test.run '^TestWarmCapacityLargeGoLockedC$' -test.count=1 -test.v -test.timeout=5m > "/evidence/$role-large-go-C.log" 2>&1
done
cp /controls/protocol/analyze-counters.py /evidence/analyze-counters.py
python3 /evidence/analyze-counters.py > /evidence/counter-analysis.log 2>&1
printf 'complete\n' > /evidence/focused-complete.txt
cp /controls/rss-wrapper.go.txt /evidence/rss-wrapper.go
go build -o /evidence/rsswrap /evidence/rss-wrapper.go > /evidence/rss-wrapper-build.log 2>&1
for role in baseline candidate; do
 cd "/$role"
 if [[ "$role" = candidate ]]; then expected=1; else expected=0; fi
 for name in go yaml_ordinary yaml_owned; do
  GTS_RSS_EXPECT_ORDINARY_COMPACT="$expected" /evidence/rsswrap "/evidence/probes/$role-standalone-$name.rss" "/evidence/probes/$role-rss-root.test" -test.run "^TestCompactLineageRSS$/^${name}$" -test.count=1 -test.v -test.timeout=5m > "/evidence/probes/$role-standalone-$name.log" 2>&1
 done
done
python3 /controls/protocol/rss/repeat_rss.py > /evidence/rss-run.log 2>&1
python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'complete\n' > /evidence/complete.txt
