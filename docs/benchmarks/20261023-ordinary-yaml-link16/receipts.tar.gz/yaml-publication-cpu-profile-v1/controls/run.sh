set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 CGO_ENABLED=0 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
python3 /controls/source_hashes.py > /evidence/source-before.json
for role in baseline candidate; do
 cd "/$role"
 go test -c -tags gts_parsercorephase0 -o "/evidence/$role.test" . > "/evidence/$role-build.log" 2>&1
 GTS_BENCHMARK_SEED=175001 "/evidence/$role.test" -test.run '^$' -test.bench '^BenchmarkCompactThroughputYAML$/^eof8k_ordinary$' -test.benchtime=3s -test.count=1 -test.benchmem -test.shuffle=175001 -test.timeout=5m -test.cpuprofile="/evidence/$role-yaml-cpu.pprof" > "/evidence/$role-yaml-cpu.log" 2>&1
 GTS_BENCHMARK_SEED=175001 "/evidence/$role.test" -test.run '^$' -test.bench '^BenchmarkCompactThroughputYAML$/^eof8k_ordinary$' -test.benchtime=100x -test.count=1 -test.benchmem -test.shuffle=175001 -test.timeout=5m -test.memprofilerate=1 -test.memprofile="/evidence/$role-yaml-alloc.pprof" > "/evidence/$role-yaml-alloc.log" 2>&1
 go tool pprof -top -nodecount=30 "/evidence/$role.test" "/evidence/$role-yaml-cpu.pprof" > "/evidence/$role-yaml-cpu-top.txt" 2>&1
 go tool pprof -top -cum -nodecount=30 "/evidence/$role.test" "/evidence/$role-yaml-cpu.pprof" > "/evidence/$role-yaml-cpu-cum.txt" 2>&1
 go tool pprof -top -alloc_objects -focus='benchmarkCompactThroughputSource' -nodecount=30 "/evidence/$role.test" "/evidence/$role-yaml-alloc.pprof" > "/evidence/$role-yaml-alloc-top.txt" 2>&1
 GTS_ADMISSION_CANDIDATE=1 GTS_BENCHMARK_SEED=175001 "/evidence/$role.test" -test.run '^$' -test.bench '^BenchmarkCompactThroughputGo$/^query_compile$' -test.benchtime=3s -test.count=1 -test.benchmem -test.shuffle=175001 -test.timeout=5m -test.cpuprofile="/evidence/$role-go-query-cpu.pprof" > "/evidence/$role-go-query-cpu.log" 2>&1
 go tool pprof -top -cum -nodecount=30 "/evidence/$role.test" "/evidence/$role-go-query-cpu.pprof" > "/evidence/$role-go-query-cpu-cum.txt" 2>&1
done
python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'complete\n' > /evidence/complete.txt
