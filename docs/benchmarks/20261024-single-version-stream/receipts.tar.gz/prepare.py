from pathlib import Path
import json,subprocess,hashlib,shutil
r=Path(__file__).resolve().parent
root=Path.cwd()
paths=set(subprocess.check_output(['git','diff','--name-only','HEAD'],text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
paths=sorted(p for p in paths if p.endswith('.go'))
replace={};manifest=[]
for name in paths:
 row={'path':name}
 for role in ['baseline','candidate']:
  if role=='baseline':
   x=subprocess.run(['git','show','HEAD:'+name],capture_output=True);data=x.stdout if x.returncode==0 else None
  else:data=(root/name).read_bytes() if (root/name).exists() else None
  target=r/role/name
  if data is None:replace['/'+role+'/'+name]='';row[role]=None
  else:
   target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
   replace['/'+role+'/'+name]='/controls/'+role+'/'+name
   row[role]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 manifest.append(row)
(r/'source-manifest.json').write_text(json.dumps({'baseline':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':manifest},indent=2)+'\n')
(r/'overlay.json').write_text(json.dumps({'Replace':replace},indent=2)+'\n')
old=root/'harness_out/docker/compact-node-views-v14'
for name in ['work.go.txt','perf.go.txt','compare-ledger.py','languages.txt']:
 shutil.copyfile(old/name,r/name)
for mode in ['work','perf']:
 d=dict(replace)
 for role in ['baseline','candidate']:d['/'+role+'/zz_compact_integration_'+mode+'_test.go']='/controls/'+mode+'.go.txt'
 (r/(mode+'-overlay.json')).write_text(json.dumps({'Replace':d},indent=2)+'\n')
