set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
unset GTS_ADMISSION_CANDIDATE GOT_PARSE_NODE_LIMIT_SCALE
trap 'printf "%s\n" "$?" > /evidence/run.exit' EXIT
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
cd /candidate
go version > /evidence/compiler.txt
cp /controls/benchmark_primary_overlay.go.txt /evidence/prepare-primary.go
go run /evidence/prepare-primary.go /controls/benchmark_primary_go_suite.go.txt /evidence/primary-overlay.json /baseline /candidate > /evidence/primary-hashes.txt
python3 - <<'INNER'
from pathlib import Path
import json
p=Path('/evidence/primary-overlay.json');d=json.loads(p.read_text());d['Replace'].update(json.loads(Path('/controls/overlay.json').read_text())['Replace']);p.write_text(json.dumps(d,indent=2)+'\n')
INNER
export GOFLAGS='-p=1 -mod=readonly -overlay=/evidence/primary-overlay.json -vet=off'
bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline.txt --output /evidence/candidate.txt --runs 20 --seed-start 265001 --benchtime 750ms --tags '' --bench-regex '^BenchmarkGTSSeededPrimary$' --require-benchmarks 'BenchmarkGTSSeededPrimary/BenchmarkGoParseFullDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalNoEditDFA' --lock-path /evidence/perf.lock > /evidence/driver.log 2>&1
gate_status=0
go run ./cmd/benchgate -base /evidence/baseline.txt -head /evidence/candidate.txt -benchmarks 'BenchmarkGTSSeededPrimary/BenchmarkGoParseFullDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalNoEditDFA' -max-ns-regression 0.08 -max-bytes-regression 0.05 -max-allocs-regression 0.05 > /evidence/gate.log 2>&1 || gate_status=$?
printf '%s\n' "$gate_status" > /evidence/gate.exit
printf 'complete\n' > /evidence/complete.txt
