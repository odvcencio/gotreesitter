package parsercorephase0

import (
	"errors"
	"reflect"
	"slices"
	"strings"
	"testing"
)

func recoveryDiscontinuityTestSet(core *Core, first, second uint16) AlternativeSet {
	var set AlternativeSet
	if !core.alternativeSetInsert(&set, packAlternativeSetMember(first, 0)) ||
		!core.alternativeSetInsert(&set, packAlternativeSetMember(second, 0)) {
		panic("recovery discontinuity test set insertion failed")
	}
	return set
}

func recoveryDiscontinuityTestRefs(t *testing.T, core *Core, first, second uint64) DropCohortRefSet {
	t.Helper()
	var refs DropCohortRefSet
	for _, sequence := range []uint64{first, second} {
		if !core.AddDropCohortRef(&refs, DropCohortRef{Owner: 7, Epoch: 3, Sequence: sequence, Branch: 0}) {
			t.Fatalf("failed to add test drop-cohort reference %d", sequence)
		}
	}
	return refs
}

func recoveryDiscontinuityTestLineage(
	t *testing.T,
	core *Core,
	owner uint32,
	head Head,
	set AlternativeSet,
	refs DropCohortRefSet,
) {
	t.Helper()
	if err := core.ApplySchedulerAtomic(func(token SchedulerTransactionToken) error {
		if err := core.RecordHeadLineageOwned(token, head, CleanPathRankSelected, 11, set, false, true, refs); err != nil {
			return err
		}
		return core.RecordHeadOwnerOwned(token, head, owner)
	}); err != nil {
		t.Fatal(err)
	}
}

func TestRecoveryDiscontinuityOwnedCopiesAndUnionsLineage(t *testing.T) {
	core := newTinyCoreWithLimits(t, Limits{MaxNodes: 128, MaxLinks: 128, MaxSubtrees: 128, MaxDerivations: 16, MaxPopPaths: 16})
	leftSeed, err := core.Seed(1, 0)
	if err != nil {
		t.Fatal(err)
	}
	rightSeed, err := core.Seed(2, 0)
	if err != nil {
		t.Fatal(err)
	}
	leftSet := recoveryDiscontinuityTestSet(core, 1, 2)
	rightSet := recoveryDiscontinuityTestSet(core, 3, 4)
	leftRefs := recoveryDiscontinuityTestRefs(t, core, 1, 2)
	rightRefs := recoveryDiscontinuityTestRefs(t, core, 3, 4)
	recoveryDiscontinuityTestLineage(t, core, 101, leftSeed, leftSet, leftRefs)
	recoveryDiscontinuityTestLineage(t, core, 102, rightSeed, rightSet, rightRefs)
	context := RecoveryDiscontinuityContext{ByteOffset: 0}
	var left, right Head
	err = core.ApplySchedulerAtomic(func(token SchedulerTransactionToken) error {
		var innerErr error
		left, innerErr = core.AppendRecoveryDiscontinuityOwned(token, leftSeed, context)
		if innerErr != nil {
			return innerErr
		}
		right, innerErr = core.AppendRecoveryDiscontinuityOwned(token, rightSeed, context)
		return innerErr
	})
	if err != nil {
		t.Fatal(err)
	}
	leftLineage, err := core.nodeLineage(left.Node)
	if err != nil {
		t.Fatal(err)
	}
	if leftLineage.owner != 0 || leftLineage.rank != CleanPathRankSelected || leftLineage.lineage != 11 {
		t.Fatalf("copied marker lineage=%+v, want owner zero and selected lineage 11", leftLineage)
	}
	if got, ok := core.AlternativeSetMembers(leftLineage.set); !ok || !slices.Equal(got, []uint32{packAlternativeSetMember(1, 0), packAlternativeSetMember(2, 0)}) {
		t.Fatalf("copied marker alternative set=%v/%t", got, ok)
	}
	if got := recoveryDiscontinuityTestRefs(t, core, 1, 2); !slices.Equal(g18Members(t, core, mustLineageRefs(t, core, leftLineage.dropCohortRefIndex)), g18Members(t, core, got)) {
		t.Fatalf("copied marker references=%+v, want %+v", mustLineageRefs(t, core, leftLineage.dropCohortRefIndex), got)
	}

	var merged Head
	err = core.ApplySchedulerAtomic(func(token SchedulerTransactionToken) error {
		var mergeErr error
		merged, mergeErr = core.MergeRecoveryDiscontinuityHeadsOwned(token, context, left, right)
		return mergeErr
	})
	if err != nil {
		t.Fatal(err)
	}
	mergedNode, err := core.node(merged.Node)
	if err != nil {
		t.Fatal(err)
	}
	if mergedNode.state != 0 || mergedNode.byteOffset != 0 || mergedNode.linkCount != 2 {
		t.Fatalf("merged marker node=%+v, want ERROR_STATE zero-width two links", mergedNode)
	}
	mergedLineage, err := core.nodeLineage(merged.Node)
	if err != nil {
		t.Fatal(err)
	}
	if mergedLineage.owner != 0 || mergedLineage.rank != CleanPathRankSelected || mergedLineage.lineage != 11 {
		t.Fatalf("merged marker lineage=%+v, want scheduler owner zero and lineage 11", mergedLineage)
	}
	gotSet, ok := core.AlternativeSetMembers(mergedLineage.set)
	if !ok || !slices.Equal(gotSet, []uint32{
		packAlternativeSetMember(1, 0), packAlternativeSetMember(2, 0),
		packAlternativeSetMember(3, 0), packAlternativeSetMember(4, 0),
	}) {
		t.Fatalf("merged marker alternative set=%v/%t", gotSet, ok)
	}
	wantRefs := recoveryDiscontinuityTestRefs(t, core, 1, 2)
	if !core.UnionDropCohortRefs(&wantRefs, rightRefs) || mustLineageRefs(t, core, mergedLineage.dropCohortRefIndex).Len() != wantRefs.Len() {
		t.Fatalf("merged marker references=%+v, want union %+v", mustLineageRefs(t, core, mergedLineage.dropCohortRefIndex), wantRefs)
	}
	if stats, statsErr := core.Stats(merged); statsErr != nil || stats.CurrentExactPaths != 2 {
		t.Fatalf("merged marker stats=%+v err=%v, want two paths", stats, statsErr)
	}
	derivations, err := core.Derivations(merged)
	if err != nil {
		t.Fatal(err)
	}
	if len(derivations) != 2 {
		t.Fatalf("merged marker derivations=%+v, want two paths", derivations)
	}
	for _, derivation := range derivations {
		if len(derivation.Payloads) != 0 || derivation.Score != 0 || derivation.HasBranchOrder {
			t.Fatalf("merged marker derivation=%+v, want no child, score, or order", derivation)
		}
	}
	work := core.Work()
	if work.PhysicalHeadMergeAttempts != 1 || work.PhysicalHeadMergeInputLinks != 1 || work.PhysicalHeadMergeSuccesses != 1 {
		t.Fatalf("marker merge telemetry=%+v, want one attempt, input link, and success", work)
	}
}

func TestErrorRegionResumeReplacesRecoveryDiscontinuity(t *testing.T) {
	tables := &fakeTable{
		actions: map[tableCell][]Action{
			{state: 1, symbol: 30}: {{Type: ActionShift, State: 2}},
			{state: 2, symbol: 31}: {{Type: ActionShift, State: 3}},
			{state: 3, symbol: 32}: {{Type: ActionShift, State: 4}},
			{state: 4, symbol: 9}:  {{Type: ActionReduce, Symbol: 20, ChildCount: 3, ProductionID: 5}},
		},
		gotos: map[tableCell]StateID{{state: 1, symbol: 20}: 5},
	}
	compact, err := New(tables, Limits{MaxDerivations: 4, MaxPopPaths: 4})
	if err != nil {
		t.Fatal(err)
	}
	head, err := compact.Seed(1, 0)
	if err != nil {
		t.Fatal(err)
	}
	head, err = compact.Shift(head, 30, 0, Token{Symbol: 30, StartByte: 0, EndByte: 1}, ForkOrder{})
	if err != nil {
		t.Fatal(err)
	}
	err = compact.ApplySchedulerAtomic(func(owner SchedulerTransactionToken) error {
		var appendErr error
		head, appendErr = compact.AppendRecoveryDiscontinuityOwned(owner, head, RecoveryDiscontinuityContext{ByteOffset: 1})
		return appendErr
	})
	if err != nil {
		t.Fatal(err)
	}
	marker := head
	regionChild, err := compact.ErrorRegionLeaf(99, 1, 2, false)
	if err != nil {
		t.Fatal(err)
	}
	head, err = compact.ErrorRegionResumeWithCost(head, 2, 1, 2, []SubtreeID{regionChild},
		func(NodeID, SubtreeID) (uint32, error) { return 7, nil })
	if err != nil {
		t.Fatal(err)
	}
	if head == marker {
		t.Fatal("error-region resume retained the recovery discontinuity marker")
	}
	if canonical, ok := compact.CanonicalBoundary(2, 2, true, 0); !ok || canonical != head {
		t.Fatalf("resumed canonical boundary=%+v/%t, want %+v", canonical, ok, head)
	}
	if cost, err := compact.RecoveryStoredErrorCost(head); err != nil || cost != 7 {
		t.Fatalf("resumed recovery cost=%d err=%v, want 7", cost, err)
	}
	if cost, err := compact.RecoveryStoredErrorCost(marker); err != nil || cost != 0 {
		t.Fatalf("marker recovery cost=%d err=%v, want zero", cost, err)
	}
	markerNode, err := compact.node(marker.Node)
	if err != nil {
		t.Fatal(err)
	}
	if markerNode.state != 0 || markerNode.byteOffset != 1 {
		t.Fatalf("source marker=%+v, want ERROR_STATE at byte 1", markerNode)
	}
	if work := compact.Work(); work.PhysicalHeadMergeAttempts != 0 ||
		work.PhysicalHeadMergeInputLinks != 0 || work.PhysicalHeadMergeSuccesses != 0 {
		t.Fatalf("single marker resume reported a physical merge: %+v", work)
	}
	paths, err := compact.Derivations(head)
	if err != nil || len(paths) != 1 || len(paths[0].Payloads) != 2 {
		t.Fatalf("resumed derivations=%+v err=%v, want one path with shift and ERROR", paths, err)
	}
	resumedError, err := compact.Subtree(paths[0].Payloads[1])
	if err != nil {
		t.Fatal(err)
	}
	if resumedError.Symbol != ErrorRegionSymbol || !resumedError.Extra ||
		resumedError.StartByte != 1 || resumedError.EndByte != 2 ||
		!slices.Equal(resumedError.Children, []SubtreeID{regionChild}) {
		t.Fatalf("resumed ERROR=%+v", resumedError)
	}

	head, err = compact.Shift(head, 31, 0, Token{Symbol: 31, StartByte: 2, EndByte: 3}, ForkOrder{})
	if err != nil {
		t.Fatal(err)
	}
	head, err = compact.Shift(head, 32, 0, Token{Symbol: 32, StartByte: 3, EndByte: 4}, ForkOrder{})
	if err != nil {
		t.Fatal(err)
	}
	frontier, err := compact.Reduce(head, 9, 0, ForkOrder{})
	if err != nil || len(frontier) != 1 {
		t.Fatalf("reduce frontier=%v err=%v", frontier, err)
	}
	state, byteOffset, err := compact.Boundary(frontier[0])
	if err != nil {
		t.Fatal(err)
	}
	if state != 5 || byteOffset != 4 {
		t.Fatalf("reduced boundary=%d@%d, want 5@4", state, byteOffset)
	}
}

func TestErrorRegionResumeReplacesMergedRecoveryDiscontinuities(t *testing.T) {
	compact := newTinyCoreWithLimits(t, Limits{MaxNodes: 64, MaxLinks: 64, MaxSubtrees: 64, MaxDerivations: 8, MaxPopPaths: 8})
	leftSeed, err := compact.Seed(1, 0)
	if err != nil {
		t.Fatal(err)
	}
	rightSeed, err := compact.Seed(2, 0)
	if err != nil {
		t.Fatal(err)
	}
	leftPayload, err := compact.appendSubtree(subtreeRecord{symbol: 10, terminal: true}, nil, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	rightPayload, err := compact.appendSubtree(subtreeRecord{symbol: 11, terminal: true}, nil, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	leftNode, err := compact.appendAdjacencyNode(7, 0, []linkRecord{{prev: leftSeed.Node, payload: leftPayload}})
	if err != nil {
		t.Fatal(err)
	}
	rightNode, err := compact.appendAdjacencyNode(7, 0, []linkRecord{{prev: rightSeed.Node, payload: rightPayload}})
	if err != nil {
		t.Fatal(err)
	}
	context := RecoveryDiscontinuityContext{ByteOffset: 0}
	var mergedMarker Head
	err = compact.ApplySchedulerAtomic(func(owner SchedulerTransactionToken) error {
		left, appendErr := compact.AppendRecoveryDiscontinuityOwned(owner, Head{Node: leftNode}, context)
		if appendErr != nil {
			return appendErr
		}
		right, appendErr := compact.AppendRecoveryDiscontinuityOwned(owner, Head{Node: rightNode}, context)
		if appendErr != nil {
			return appendErr
		}
		mergedMarker, appendErr = compact.MergeRecoveryDiscontinuityHeadsOwned(owner, context, left, right)
		return appendErr
	})
	if err != nil {
		t.Fatal(err)
	}
	regionChild, err := compact.ErrorRegionLeaf(99, 0, 1, false)
	if err != nil {
		t.Fatal(err)
	}
	resumed, err := compact.ErrorRegionResumeWithCost(mergedMarker, 7, 0, 1, []SubtreeID{regionChild},
		func(NodeID, SubtreeID) (uint32, error) { return 7, nil })
	if err != nil {
		t.Fatal(err)
	}
	resumedNode, err := compact.node(resumed.Node)
	if err != nil {
		t.Fatal(err)
	}
	links, err := compact.nodeLinks(*resumedNode)
	if err != nil {
		t.Fatal(err)
	}
	if len(links) != 1 || links[0].isRecoveryDiscontinuity() || links[0].payload == 0 || links[0].prev == mergedMarker.Node {
		t.Fatalf("resumed links=%+v, want one ERROR link over a merged predecessor", links)
	}
	paths, err := compact.Derivations(resumed)
	if err != nil || len(paths) != 2 {
		t.Fatalf("resumed derivations=%+v err=%v, want two", paths, err)
	}
	firstPayloads := make([]SubtreeID, 0, len(paths))
	for _, path := range paths {
		if len(path.Payloads) != 2 || path.Payloads[1] != links[0].payload {
			t.Fatalf("resumed derivation=%+v, want predecessor payload plus shared ERROR", path)
		}
		firstPayloads = append(firstPayloads, path.Payloads[0])
	}
	slices.Sort(firstPayloads)
	wantFirstPayloads := []SubtreeID{leftPayload, rightPayload}
	slices.Sort(wantFirstPayloads)
	if !slices.Equal(firstPayloads, wantFirstPayloads) {
		t.Fatalf("resumed predecessor payloads=%v, want %v", firstPayloads, wantFirstPayloads)
	}
	if cost, err := compact.RecoveryStoredErrorCost(resumed); err != nil || cost != 7 {
		t.Fatalf("resumed recovery cost=%d err=%v, want 7", cost, err)
	}
}

func TestErrorRegionResumeSelectsMatchingMixedMarkerState(t *testing.T) {
	compact := newTinyCoreWithLimits(t, Limits{MaxNodes: 64, MaxLinks: 64, MaxSubtrees: 64, MaxDerivations: 8, MaxPopPaths: 8})
	left, err := compact.Seed(7, 0)
	if err != nil {
		t.Fatal(err)
	}
	right, err := compact.Seed(8, 0)
	if err != nil {
		t.Fatal(err)
	}
	context := RecoveryDiscontinuityContext{ByteOffset: 0}
	var merged Head
	err = compact.ApplySchedulerAtomic(func(owner SchedulerTransactionToken) error {
		leftMarker, appendErr := compact.AppendRecoveryDiscontinuityOwned(owner, left, context)
		if appendErr != nil {
			return appendErr
		}
		rightMarker, appendErr := compact.AppendRecoveryDiscontinuityOwned(owner, right, context)
		if appendErr != nil {
			return appendErr
		}
		merged, appendErr = compact.MergeRecoveryDiscontinuityHeadsOwned(owner, context, leftMarker, rightMarker)
		return appendErr
	})
	if err != nil {
		t.Fatal(err)
	}
	child, err := compact.ErrorRegionLeaf(99, 0, 1, false)
	if err != nil {
		t.Fatal(err)
	}
	resumed, err := compact.ErrorRegionResume(merged, 7, 0, 1, []SubtreeID{child})
	if err != nil {
		t.Fatal(err)
	}
	paths, err := compact.Derivations(resumed)
	if err != nil || len(paths) != 1 || len(paths[0].Payloads) != 1 || paths[0].Payloads[0] == 0 {
		t.Fatalf("mixed-state resumed derivations=%+v err=%v, want one matching path", paths, err)
	}
	resumedNode, err := compact.node(resumed.Node)
	if err != nil {
		t.Fatal(err)
	}
	links, err := compact.nodeLinks(*resumedNode)
	if err != nil {
		t.Fatal(err)
	}
	if len(links) != 1 || links[0].prev != left.Node || links[0].prev == right.Node {
		t.Fatalf("mixed-state resumed links=%+v, want only state-7 predecessor %d", links, left.Node)
	}
}

func TestErrorRegionResumePreservesGapBeforeFirstErrorToken(t *testing.T) {
	compact := newTinyCoreWithLimits(t, Limits{MaxNodes: 32, MaxLinks: 32, MaxSubtrees: 32, MaxDerivations: 4, MaxPopPaths: 4})
	seed, err := compact.Seed(7, 0)
	if err != nil {
		t.Fatal(err)
	}
	var marker Head
	err = compact.ApplySchedulerAtomic(func(owner SchedulerTransactionToken) error {
		var appendErr error
		marker, appendErr = compact.AppendRecoveryDiscontinuityOwned(owner, seed, RecoveryDiscontinuityContext{ByteOffset: 0})
		return appendErr
	})
	if err != nil {
		t.Fatal(err)
	}
	child, err := compact.ErrorRegionLeaf(99, 1, 2, false)
	if err != nil {
		t.Fatal(err)
	}
	resumed, err := compact.ErrorRegionResume(marker, 7, 1, 2, []SubtreeID{child})
	if err != nil {
		t.Fatal(err)
	}
	state, byteOffset, err := compact.Boundary(resumed)
	if err != nil {
		t.Fatal(err)
	}
	if state != 7 || byteOffset != 2 {
		t.Fatalf("gap resume boundary=%d@%d, want 7@2", state, byteOffset)
	}
	paths, err := compact.Derivations(resumed)
	if err != nil || len(paths) != 1 || len(paths[0].Payloads) != 1 {
		t.Fatalf("gap resume derivations=%+v err=%v", paths, err)
	}
	region, err := compact.Subtree(paths[0].Payloads[0])
	if err != nil {
		t.Fatal(err)
	}
	if region.StartByte != 1 || region.EndByte != 2 || !slices.Equal(region.Children, []SubtreeID{child}) {
		t.Fatalf("gap resume ERROR=%+v", region)
	}
}

func TestRecoveryDiscontinuityReductionCompactsChildrenLikeC(t *testing.T) {
	tables := &fakeTable{
		actions: map[tableCell][]Action{
			{state: 1, symbol: 30}: {{Type: ActionShift, State: 2}},
			{state: 0, symbol: 31}: {{Type: ActionShift, State: 3}},
			{state: 3, symbol: 9}:  {{Type: ActionReduce, Symbol: 20, ChildCount: 3, ProductionID: 5}},
		},
		gotos: map[tableCell]StateID{{state: 1, symbol: 20}: 4},
		fields: map[uint16][]FieldMapEntry{5: {
			{FieldID: 1, ChildIndex: 0},
			{FieldID: 2, ChildIndex: 1},
			{FieldID: 3, ChildIndex: 2},
		}},
		aliases: map[productionKey][]Symbol{{productionID: 5, childCount: 3}: {101, 102, 103}},
	}
	compact, err := New(tables, Limits{MaxDerivations: 4, MaxPopPaths: 4})
	if err != nil {
		t.Fatal(err)
	}
	head, err := compact.Seed(1, 0)
	if err != nil {
		t.Fatal(err)
	}
	head, err = compact.Shift(head, 30, 0, Token{Symbol: 30, StartByte: 0, EndByte: 1}, ForkOrder{})
	if err != nil {
		t.Fatal(err)
	}
	err = compact.ApplySchedulerAtomic(func(owner SchedulerTransactionToken) error {
		var appendErr error
		head, appendErr = compact.AppendRecoveryDiscontinuityOwned(owner, head, RecoveryDiscontinuityContext{ByteOffset: 1})
		return appendErr
	})
	if err != nil {
		t.Fatal(err)
	}
	head, err = compact.Shift(head, 31, 0, Token{Symbol: 31, StartByte: 1, EndByte: 2}, ForkOrder{})
	if err != nil {
		t.Fatal(err)
	}
	storageBefore := compact.StorageBytes()
	frontier, err := compact.Reduce(head, 9, 0, ForkOrder{})
	if err != nil || len(frontier) != 1 {
		t.Fatalf("reduce frontier=%v err=%v", frontier, err)
	}
	paths, err := compact.Derivations(frontier[0])
	if err != nil || len(paths) != 1 || len(paths[0].Payloads) != 1 {
		t.Fatalf("reduced derivations=%v err=%v", paths, err)
	}
	parent, err := compact.Subtree(paths[0].Payloads[0])
	if err != nil {
		t.Fatal(err)
	}
	if len(parent.Children) != 2 || !reflect.DeepEqual(parent.Fields, []FieldMapEntry{
		{FieldID: 1, ChildIndex: 0},
		{FieldID: 2, ChildIndex: 1},
	}) || !slices.Equal(parent.Aliases, []Symbol{101, 102}) {
		t.Fatalf("compacted recovery parent=%+v", parent)
	}
	if len(compact.recoveryDiscontinuityReductions) != 1 ||
		compact.recoveryDiscontinuityReductions[0] != (recoveryDiscontinuityReduction{payload: paths[0].Payloads[0], popChildCount: 3}) {
		t.Fatalf("recovery reduction provenance=%+v", compact.recoveryDiscontinuityReductions)
	}
	if got := compact.StorageBytes() - storageBefore; got < coreRecoveryDiscontinuityReductionBytes {
		t.Fatalf("storage growth=%d, want at least provenance size %d", got, coreRecoveryDiscontinuityReductionBytes)
	}
	compact.metadataConstructionAuthenticated = false
	if _, err := compact.MaterializationView(paths[0].Payloads[0]); err != nil {
		t.Fatalf("validate compacted metadata: %v", err)
	}
	if err := compact.Reset(); err != nil {
		t.Fatal(err)
	}
	if len(compact.recoveryDiscontinuityReductions) != 0 {
		t.Fatalf("reset retained recovery reduction provenance: %+v", compact.recoveryDiscontinuityReductions)
	}
}

func TestRecoveryDiscontinuityRejectsUnauthenticatedContextAndOrdinaryNullableLink(t *testing.T) {
	core := newTinyCoreWithLimits(t, Limits{MaxNodes: 32, MaxLinks: 32, MaxSubtrees: 32, MaxDerivations: 8, MaxPopPaths: 8})
	seed, err := core.Seed(3, 0)
	if err != nil {
		t.Fatal(err)
	}
	for _, context := range []RecoveryDiscontinuityContext{
		{ErrorState: 1, ByteOffset: 0},
		{ByteOffset: 1},
		{ByteOffset: 0, Checkpoint: 1},
	} {
		before := core.nodes.Len()
		err := core.ApplySchedulerAtomic(func(token SchedulerTransactionToken) error {
			_, appendErr := core.AppendRecoveryDiscontinuityOwned(token, seed, context)
			return appendErr
		})
		if err == nil {
			t.Fatalf("context=%+v was accepted", context)
		}
		if core.nodes.Len() != before {
			t.Fatalf("context=%+v changed node arena after rejection", context)
		}
	}
	if _, err := core.appendAdjacencyNode(0, 0, []linkRecord{{prev: seed.Node}}); err == nil {
		t.Fatal("ordinary zero-payload link was accepted")
	}
}

func TestRecoveryGraphAggregatePreservesMarkerPrefixAndDeclinesUnequalCosts(t *testing.T) {
	core := newTinyCoreWithLimits(t, Limits{MaxNodes: 256, MaxLinks: 256, MaxSubtrees: 256, MaxChildren: 256, MaxDerivations: 16, MaxPopPaths: 16})
	seed, err := core.Seed(1, 0)
	if err != nil {
		t.Fatal(err)
	}
	cleanPayload, err := core.appendSubtree(subtreeRecord{symbol: 1, startByte: 0, endByte: 0, terminal: true}, nil, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	cleanPred, err := core.appendAdjacencyNode(2, 0, []linkRecord{{prev: seed.Node, payload: cleanPayload}})
	if err != nil {
		t.Fatal(err)
	}
	missingPayload, err := core.MissingLeaf(2, 0)
	if err != nil {
		t.Fatal(err)
	}
	missingPred, err := core.appendAdjacencyNode(3, 0, []linkRecord{{prev: seed.Node, payload: missingPayload}})
	if err != nil {
		t.Fatal(err)
	}
	context := RecoveryDiscontinuityContext{ByteOffset: 0}
	var cleanHead, missingHead Head
	err = core.ApplySchedulerAtomic(func(token SchedulerTransactionToken) error {
		var innerErr error
		cleanHead, innerErr = core.AppendRecoveryDiscontinuityOwned(token, Head{Node: cleanPred}, context)
		if innerErr != nil {
			return innerErr
		}
		missingHead, innerErr = core.AppendRecoveryDiscontinuityOwned(token, Head{Node: missingPred}, context)
		return innerErr
	})
	if err != nil {
		t.Fatal(err)
	}
	var aggregateHead Head
	err = core.ApplySchedulerAtomic(func(token SchedulerTransactionToken) error {
		var mergeErr error
		aggregateHead, mergeErr = core.MergeRecoveryDiscontinuityHeadsOwned(token, context, cleanHead, missingHead)
		return mergeErr
	})
	if err != nil {
		t.Fatal(err)
	}
	symbols := make([]SelectedSymbolPolicy, 3)
	symbols[1].Visible = true
	symbols[2].Visible = true
	aggregate, supported, err := core.RecoveryGraphAggregateForHead(aggregateHead, symbols, core)
	if err != nil {
		t.Fatal(err)
	}
	if supported {
		t.Fatal("unequal recovery path costs were reported as supported")
	}
	if aggregate.MaximumVisibleCount != 1 || aggregate.MinimumErrorCost != 0 || aggregate.MaximumErrorCost != RecoveryCostPerMissingTree+RecoveryCostPerRecovery || aggregate.StoredPrecedenceMaximum != 0 || aggregate.PathCount != 2 {
		t.Fatalf("aggregate=%+v, want visible 1, costs 0/%d, precedence 0, paths 2", aggregate, RecoveryCostPerMissingTree+RecoveryCostPerRecovery)
	}
}

func TestRecoveryGraphAggregateIgnoresUnreachableMalformedNode(t *testing.T) {
	core := newTinyCoreWithLimits(t, Limits{MaxNodes: 256, MaxLinks: 256, MaxSubtrees: 256, MaxDerivations: 8, MaxPopPaths: 8})
	seed, err := core.Seed(1, 0)
	if err != nil {
		t.Fatal(err)
	}
	unreachablePayload, err := core.appendSubtree(subtreeRecord{symbol: 1, terminal: true}, nil, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	unreachableLink := core.appendGraphLink(linkRecord{prev: seed.Node, payload: unreachablePayload})
	if _, err := core.appendNode(nodeInput{state: 7, byteOffset: 0, firstLink: uint32(unreachableLink), linkCount: 1, pathCount: 1}); err != nil {
		t.Fatal(err)
	}
	visiblePayload, err := core.appendSubtree(subtreeRecord{symbol: 1, startByte: 0, endByte: 0, terminal: true}, nil, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	visibleHead, err := core.appendAdjacencyNode(2, 0, []linkRecord{{prev: seed.Node, payload: visiblePayload}})
	if err != nil {
		t.Fatal(err)
	}
	// Corrupt only the unrelated node after the aggregate's reachable head is built.
	core.links[unreachableLink-1].payload = 0
	symbols := []SelectedSymbolPolicy{{}, {Visible: true}}
	aggregate, supported, err := core.RecoveryGraphAggregateForHead(Head{Node: visibleHead}, symbols, core)
	if err != nil || !supported || aggregate.PathCount != 1 || aggregate.MaximumVisibleCount != 1 {
		t.Fatalf("reachable aggregate=%+v supported=%t err=%v", aggregate, supported, err)
	}
}

func TestRecoveryGraphAggregateRequiresExactCostSource(t *testing.T) {
	core := newTinyCoreWithLimits(t, Limits{MaxDerivations: 4, MaxPopPaths: 4})
	seed, err := core.Seed(1, 0)
	if err != nil {
		t.Fatal(err)
	}
	if _, supported, err := core.RecoveryGraphAggregateForHead(seed, nil, nil); err == nil || supported {
		t.Fatalf("nil source result=%t err=%v, want fail closed", supported, err)
	}
	errorPayload, err := core.appendSubtree(subtreeRecord{symbol: ErrorRegionSymbol, startByte: 0, endByte: 1}, nil, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	errorHead, err := core.appendAdjacencyNode(2, 1, []linkRecord{{prev: seed.Node, payload: errorPayload}})
	if err != nil {
		t.Fatal(err)
	}
	if _, supported, err := core.RecoveryGraphAggregateForHead(Head{Node: errorHead}, nil, core); err == nil || supported {
		t.Fatalf("row-free Core source result=%t err=%v, want ERROR row-span failure", supported, err)
	}
}

func TestEOFAdmissionRejectsRecoveryDiscontinuityWithoutRecoveryVisitor(t *testing.T) {
	core := newTinyCoreWithLimits(t, Limits{MaxNodes: 32, MaxLinks: 32, MaxDerivations: 4, MaxPopPaths: 4})
	seed, err := core.Seed(1, 0)
	if err != nil {
		t.Fatal(err)
	}
	var head Head
	if err := core.ApplySchedulerAtomic(func(token SchedulerTransactionToken) error {
		var appendErr error
		head, appendErr = core.AppendRecoveryDiscontinuityOwned(token, seed, RecoveryDiscontinuityContext{ByteOffset: 0})
		return appendErr
	}); err != nil {
		t.Fatal(err)
	}
	_, err = core.VisitEOFAdmissionExactPath(head, core.AuthenticationGeneration(), nil, func(uint32, SubtreeID) error { return nil })
	if err == nil || !errors.Is(err, ErrEOFAdmissionMalformed) {
		t.Fatalf("marker EOF admission error=%v, want malformed fail-closed error", err)
	}
}

func TestRecoveryDiscontinuityMergeRollbackRestoresLineageSpill(t *testing.T) {
	core := newTinyCoreWithLimits(t, Limits{MaxNodes: 128, MaxLinks: 128, MaxSubtrees: 128, MaxDerivations: 16, MaxPopPaths: 16})
	leftSeed, err := core.Seed(1, 0)
	if err != nil {
		t.Fatal(err)
	}
	rightSeed, err := core.Seed(2, 0)
	if err != nil {
		t.Fatal(err)
	}
	recoveryDiscontinuityTestLineage(t, core, 201, leftSeed, recoveryDiscontinuityTestSet(core, 1, 2), recoveryDiscontinuityTestRefs(t, core, 1, 2))
	recoveryDiscontinuityTestLineage(t, core, 202, rightSeed, recoveryDiscontinuityTestSet(core, 3, 4), recoveryDiscontinuityTestRefs(t, core, 3, 4))
	context := RecoveryDiscontinuityContext{ByteOffset: 0}
	var left, right Head
	if err := core.ApplySchedulerAtomic(func(token SchedulerTransactionToken) error {
		var innerErr error
		left, innerErr = core.AppendRecoveryDiscontinuityOwned(token, leftSeed, context)
		if innerErr != nil {
			return innerErr
		}
		right, innerErr = core.AppendRecoveryDiscontinuityOwned(token, rightSeed, context)
		return innerErr
	}); err != nil {
		t.Fatal(err)
	}
	beforeNodes := core.nodes.Len()
	beforeLinks := len(core.links)
	beforeSpill := slices.Clone(core.alternativeSpillArena)
	beforeLineages := slices.Clone(core.nodeLineages)
	beforeWork := core.Work()
	sentinel := errors.New("recovery discontinuity rollback")
	err = core.ApplySchedulerAtomic(func(token SchedulerTransactionToken) error {
		if _, mergeErr := core.MergeRecoveryDiscontinuityHeadsOwned(token, context, left, right); mergeErr != nil {
			return mergeErr
		}
		return sentinel
	})
	if !errors.Is(err, sentinel) {
		t.Fatalf("rollback error=%v, want %v", err, sentinel)
	}
	if core.nodes.Len() != beforeNodes || len(core.links) != beforeLinks || !slices.Equal(core.alternativeSpillArena, beforeSpill) || !reflect.DeepEqual(core.nodeLineages, beforeLineages) || core.Work() != beforeWork {
		t.Fatalf("rollback changed nodes=%d/%d links=%d/%d spill=%v/%v lineages equal=%t work=%+v/%+v", core.nodes.Len(), beforeNodes, len(core.links), beforeLinks, core.alternativeSpillArena, beforeSpill, reflect.DeepEqual(core.nodeLineages, beforeLineages), core.Work(), beforeWork)
	}
}

func TestRecoveryDiscontinuityMergeRejectsDifferentStoredCostsBeforeMutation(t *testing.T) {
	core := newTinyCoreWithLimits(t, Limits{MaxNodes: 64, MaxLinks: 64, MaxDerivations: 8, MaxPopPaths: 8})
	leftSeed, err := core.Seed(1, 0)
	if err != nil {
		t.Fatal(err)
	}
	rightSeed, err := core.Seed(2, 0)
	if err != nil {
		t.Fatal(err)
	}
	core.mutateTestLineage(int(leftSeed.Node-1), func(r *nodeLineageRecord) { r.storedErrorCost = 7 })
	core.mutateTestLineage(int(rightSeed.Node-1), func(r *nodeLineageRecord) { r.storedErrorCost = 8 })
	var left, right Head
	context := RecoveryDiscontinuityContext{ByteOffset: 0}
	if err := core.ApplySchedulerAtomic(func(owner SchedulerTransactionToken) error {
		var appendErr error
		left, appendErr = core.AppendRecoveryDiscontinuityOwned(owner, leftSeed, context)
		if appendErr != nil {
			return appendErr
		}
		right, appendErr = core.AppendRecoveryDiscontinuityOwned(owner, rightSeed, context)
		return appendErr
	}); err != nil {
		t.Fatal(err)
	}
	leftCost, err := core.RecoveryStoredErrorCost(left)
	if err != nil || leftCost != 7 {
		t.Fatalf("left marker stored cost=%d err=%v, want 7", leftCost, err)
	}
	rightCost, err := core.RecoveryStoredErrorCost(right)
	if err != nil || rightCost != 8 {
		t.Fatalf("right marker stored cost=%d err=%v, want 8", rightCost, err)
	}
	beforeNodes, beforeLinks, beforeWork := core.nodes.Len(), len(core.links), core.Work()
	err = core.ApplySchedulerAtomic(func(owner SchedulerTransactionToken) error {
		_, mergeErr := core.MergeRecoveryDiscontinuityHeadsOwned(owner, context, left, right)
		return mergeErr
	})
	if err == nil {
		t.Fatal("different stored costs unexpectedly merged")
	}
	if core.nodes.Len() != beforeNodes || len(core.links) != beforeLinks || core.Work() != beforeWork {
		t.Fatalf("rejected merge mutated graph or telemetry: nodes=%d/%d links=%d/%d work=%+v/%+v", core.nodes.Len(), beforeNodes, len(core.links), beforeLinks, core.Work(), beforeWork)
	}
}

func TestRecordHeadStoredErrorCostRequiresFreshSpeculationPublication(t *testing.T) {
	core := newTinyCoreWithLimits(t, Limits{MaxNodes: 64, MaxLinks: 64, MaxDerivations: 8, MaxPopPaths: 8})
	seed, err := core.Seed(1, 0)
	if err != nil {
		t.Fatal(err)
	}
	core.mutateTestLineage(int(seed.Node-1), func(r *nodeLineageRecord) { r.storedErrorCost = 7 })
	if err := core.ApplySchedulerAtomic(func(owner SchedulerTransactionToken) error {
		if err := core.RecordHeadStoredErrorCostOwned(owner, seed, 7); err != nil {
			return err
		}
		return core.RecordHeadStoredErrorCostOwned(owner, seed, 8)
	}); err == nil || !strings.Contains(err.Error(), "published node") {
		t.Fatalf("published node rewrite error=%v", err)
	}
	if got, err := core.RecoveryStoredErrorCost(seed); err != nil || got != 7 {
		t.Fatalf("published node cost=%d err=%v, want 7", got, err)
	}
	err = core.ApplySchedulerAtomic(func(outer SchedulerTransactionToken) error {
		return core.ApplySchedulerSpeculation(outer, func(inner SchedulerTransactionToken) (bool, error) {
			return false, core.RecordHeadStoredErrorCostOwned(inner, seed, 8)
		})
	})
	if err == nil || !strings.Contains(err.Error(), "published node") {
		t.Fatalf("speculative published node rewrite error=%v", err)
	}

	var fresh Head
	err = core.ApplySchedulerAtomic(func(outer SchedulerTransactionToken) error {
		return core.ApplySchedulerSpeculation(outer, func(inner SchedulerTransactionToken) (bool, error) {
			var appendErr error
			fresh, appendErr = core.AppendRecoveryDiscontinuityOwned(inner, seed, RecoveryDiscontinuityContext{ByteOffset: 0})
			if appendErr != nil {
				return false, appendErr
			}
			if appendErr = core.RecordHeadStoredErrorCostOwned(inner, fresh, 9); appendErr != nil {
				return false, appendErr
			}
			return true, nil
		})
	})
	if err != nil {
		t.Fatalf("fresh speculative publication err=%v", err)
	}
	if got, err := core.RecoveryStoredErrorCost(fresh); err != nil || got != 9 {
		t.Fatalf("fresh node cost=%d err=%v, want 9", got, err)
	}
}
