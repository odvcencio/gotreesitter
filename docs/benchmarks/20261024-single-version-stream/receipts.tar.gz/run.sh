set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOFLAGS='-p=1 -mod=readonly -overlay=/controls/overlay.json'
trap 'printf "%s\n" "$?" > /evidence/run.exit' EXIT
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
go test ./internal/parsercorephase0 -run '^Test(SingleVersion|DirectReduction)' -count=1 -v -timeout=8m > /evidence/core.log 2>&1
go test -c -tags gts_parsercorephase0 -o /evidence/final.test . > /evidence/build.log 2>&1
/evidence/final.test -test.run '^Test(ParserCoreCorridor|SingleVersionDirectOutput|NativeNodeViews)' -test.count=1 -test.v -test.timeout=8m > /evidence/focused.log 2>&1
printf 'complete\n' > /evidence/focused-complete.txt
