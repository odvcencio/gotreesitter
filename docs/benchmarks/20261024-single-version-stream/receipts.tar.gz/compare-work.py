from pathlib import Path
import json
p=Path('/evidence/work'); rows={}
for role in ['baseline','candidate']:
 rows[role]={}
 for f in p.glob(role+'-*.log'):
  for line in f.read_text().splitlines():
   if line.startswith('WORK '):
    r=json.loads(line[5:]); key=(r['Language'],r['Route'],r['Phase']); assert key not in rows[role]; rows[role][key]=r['Counts']
assert set(rows['baseline'])==set(rows['candidate']) and len(rows['baseline'])==8
changes=[]
for key,a in rows['baseline'].items():
 for metric,before in a.items():
  after=rows['candidate'][key][metric]
  if before!=after:changes.append(dict(case=key,metric=metric,before=before,after=after))
adverse=[r for r in changes if r['after']>r['before']]
out=dict(rows=8,changes=changes,adverse=adverse)
(p/'comparison.json').write_text(json.dumps(out,indent=2)+'\n')
assert not adverse, adverse
