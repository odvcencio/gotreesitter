package parsercorephase0

import (
	"errors"
	"fmt"
	"reflect"
	"testing"
)

type singleVersionTestElections struct {
	core       *Core
	calls      int
	refuse     int
	advances   int
	unbound    bool
	fail, boom bool
}

func (e *singleVersionTestElections) ElectSingleVersion(Head) (Token, bool, error) {
	e.calls++
	if e.fail {
		return Token{}, false, errors.New("cancel election")
	}
	if e.boom {
		panic("election panic")
	}
	before := e.core.checkpoint
	for i := 0; i < e.advances; i++ {
		if err := e.core.BeginFrontier(); err != nil {
			return Token{}, false, err
		}
	}
	if !e.unbound {
		after, err := e.core.InternCheckpoint([]byte{byte(e.calls + 1)})
		if err != nil {
			return Token{}, false, err
		}
		if err := e.core.SetPhaseExternalTokenScannerCheckpoints(before, after); err != nil {
			return Token{}, false, err
		}
	}
	return Token{Symbol: Symbol(10 + e.calls), StartByte: uint32(1 + e.calls), EndByte: uint32(2 + e.calls), External: true}, e.calls != e.refuse, nil
}

func singleVersionStreamFixture(t *testing.T) (*Core, Head, *singleVersionTestAdapter, *singleVersionTestElections) {
	t.Helper()
	c, head, adapter := singleVersionFixture(t)
	c.EnableTerminalScannerCheckpointProvenance()
	before, err := c.InternCheckpoint([]byte{0})
	if err != nil {
		t.Fatal(err)
	}
	after, err := c.InternCheckpoint([]byte{1})
	if err != nil {
		t.Fatal(err)
	}
	if err := c.SetPhaseExternalTokenScannerCheckpoints(before, after); err != nil {
		t.Fatal(err)
	}
	for i := 1; i <= 5; i++ {
		state, symbol, parent := StateID(600+(i-1)*200), Symbol(10+i), Symbol(81+i)
		adapter.table.actions[tableCell{state: state, symbol: symbol}] = []Action{{Type: ActionReduce, Symbol: parent, ChildCount: 1}}
		adapter.table.gotos[tableCell{state: state - 100, symbol: parent}] = state + 100
		adapter.table.actions[tableCell{state: state + 100, symbol: symbol}] = []Action{{Type: ActionShift, State: state + 200}}
	}
	return c, head, adapter, &singleVersionTestElections{core: c, advances: 1}
}

func TestSingleVersionStreamMatchesTokenOperations(t *testing.T) {
	if phase0AEnabled {
		t.Skip("fresh optimization is disabled under the transaction auditor")
	}
	for _, limit := range []uint32{0, 1, 2, 3, 4, 5, 7, 9, 12, 13, 14, 40} {
		for _, refuse := range []int{0, 1, 3} {
			t.Run(fmt.Sprintf("limit=%d/refuse=%d", limit, refuse), func(t *testing.T) {
				before, oldHead, oldAdapter, oldElections := singleVersionStreamFixture(t)
				after, newHead, newAdapter, newElections := singleVersionStreamFixture(t)
				oldElections.refuse, newElections.refuse = refuse, refuse
				pub := ShiftHeadLineage{Owner: 3, PublishLineage: true, Set: NewAlternativeSetMember(2, 0), Lineage: 2, Rank: CleanPathRankSelected, SetDirty: true}
				token := Token{Symbol: 10, StartByte: 1, EndByte: 2, External: true}
				var want, got SingleVersionResult
				err := before.RunFreshSchedulerSession(func(owner SchedulerTransactionToken) error {
					want.Head = oldHead
					for want.Steps < limit {
						part, err := before.RunSingleVersionOwned(owner, want.Head, token, pub, limit-want.Steps, oldAdapter, oldAdapter)
						steps := want.Steps + part.Steps
						want, want.Steps = part, steps
						if err != nil || !want.Shifted || want.Steps == limit {
							return err
						}
						var keep bool
						token, keep, err = oldElections.ElectSingleVersion(want.Head)
						want.Shifted = false
						if err != nil || !keep {
							return err
						}
						pub.PreviousHead, pub.SetDirty = want.Head, false
					}
					return nil
				})
				if err != nil {
					t.Fatal(err)
				}
				token = Token{Symbol: 10, StartByte: 1, EndByte: 2, External: true}
				pub.PreviousHead, pub.SetDirty = Head{}, true
				err = after.RunFreshSchedulerSession(func(owner SchedulerTransactionToken) error {
					var err error
					got, err = after.RunSingleVersionStreamOwned(owner, newHead, token, pub, limit, newAdapter, newAdapter, newElections)
					return err
				})
				if err != nil {
					t.Fatal(err)
				}
				for name, pair := range map[string][2]any{
					"head": {want.Head, got.Head}, "steps": {want.Steps, got.Steps}, "shifted": {want.Shifted, got.Shifted},
					"fallback": {want.ReductionFallback, got.ReductionFallback}, "work": {before.Work(), after.Work()},
					"nodes": {before.nodes.snapshotForTest(), after.nodes.snapshotForTest()}, "links": {before.links.Values(), after.links.Values()},
					"lineage": {before.nodeLineages, after.nodeLineages}, "subtrees": {before.subtrees.snapshotForTest(), after.subtrees.snapshotForTest()},
					"children": {before.children, after.children}, "frontier": {before.frontier, after.frontier},
					"phase": {before.classificationPhase, after.classificationPhase}, "checkpoint": {before.checkpoint, after.checkpoint},
					"elections": {oldElections.calls, newElections.calls}, "before polls": {oldAdapter.before, newAdapter.before}, "after polls": {oldAdapter.after, newAdapter.after},
				} {
					if !reflect.DeepEqual(pair[0], pair[1]) {
						t.Errorf("%s differs: before=%v after=%v", name, pair[0], pair[1])
					}
				}
			})
		}
	}
}

func TestSingleVersionStreamUnboundExternalTokenStaysUnconsumed(t *testing.T) {
	if phase0AEnabled {
		t.Skip("fresh optimization disabled")
	}
	c, head, adapter, elections := singleVersionStreamFixture(t)
	elections.unbound = true
	err := c.RunFreshSchedulerSession(func(owner SchedulerTransactionToken) error {
		got, err := c.RunSingleVersionStreamOwned(owner, head, Token{Symbol: 10, StartByte: 1, EndByte: 2}, ShiftHeadLineage{Owner: 3}, 40, adapter, adapter, elections)
		if err == nil && (got.Steps != 4 || got.Shifted || elections.calls != 1 || adapter.after != 4) {
			t.Fatalf("unbound external token consumed: result=%+v elections=%d after=%d", got, elections.calls, adapter.after)
		}
		return err
	})
	if err != nil {
		t.Fatal(err)
	}
}

func TestSingleVersionStreamElectionFailurePoisonsSession(t *testing.T) {
	if phase0AEnabled {
		t.Skip("fresh optimization disabled")
	}
	for _, kind := range []string{"no frontier", "two frontiers", "error", "panic"} {
		t.Run(kind, func(t *testing.T) {
			c, head, adapter, elections := singleVersionStreamFixture(t)
			switch kind {
			case "no frontier":
				elections.advances = 0
			case "two frontiers":
				elections.advances = 2
			case "error":
				elections.fail = true
			case "panic":
				elections.boom = true
			}
			var err error
			var caught any
			func() {
				defer func() { caught = recover() }()
				err = c.RunFreshSchedulerSession(func(owner SchedulerTransactionToken) error {
					_, failure := c.RunSingleVersionStreamOwned(owner, head, Token{Symbol: 10, StartByte: 1, EndByte: 2}, ShiftHeadLineage{Owner: 3}, 40, adapter, adapter, elections)
					if failure == nil {
						t.Error("election failure was not reported")
					}
					return nil // Deliberately ignore the error; the owner must stay poisoned.
				})
			}()
			if kind == "panic" && caught == nil || kind != "panic" && err == nil {
				t.Fatalf("ignored election failure escaped: error=%v panic=%v", err, caught)
			}
			if c.nodes.Len() != 0 || c.Work() != (Work{}) {
				t.Fatal("failed election left a publishable fresh graph")
			}
		})
	}
}
