set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/ci-csharp-eff
mkdir -p "$scratch"
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -overlay=/controls/ci-followup/csharp/overlay.eff.json -o "$scratch/cgo.test" . > /evidence/build.log 2>&1
"$scratch/cgo.test" -test.run '^TestCSharpCurrentCAdjudicationPrivate$' -test.count=1 -test.v -test.timeout=10m > /evidence/csharp.log 2>&1
