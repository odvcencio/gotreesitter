set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate/cgo_harness
go test -tags treesitter_c_parity,gts_parsercorephase0 -run '^TestCSharpDispatchBlockerRoutes$' -count=1 -timeout=10m -v . > /evidence/csharp.log 2>&1
printf 'saved C-sharp diagnostic assertions pass; known C gaps unchanged\n' > /evidence/completed.txt
