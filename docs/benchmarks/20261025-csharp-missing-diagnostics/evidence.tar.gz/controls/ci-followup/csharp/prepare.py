#!/usr/bin/env python3
"""Freeze private C# all-route adjudication controls; no builds or tests."""
import hashlib
import json
from pathlib import Path
import subprocess

CONTROL = Path(__file__).resolve().parent
ROOT = CONTROL.parents[4]
EVIDENCE = CONTROL.parents[1]
BASE = "eff701aa3962f88fbf6e8cd3b5994d7dca1d0a32"
HEAD = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def dump(name, obj):
    (CONTROL / name).write_text(json.dumps(obj, indent=2) + "\n")

def write(name, data):
    path = CONTROL / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)

source_path = "cgo_harness/csharp_dispatch_blocker_receipt_test.go"
original = (ROOT / source_path).read_text()
start = original.index("\twitnesses := []csharpDispatchWitness{")
end = original.index("\n\tlanguage := grammars.CSharpLanguage()", start)
witnesses = original[start:end]
cooklang = (CONTROL.parent / "cooklang/cooklang_current_c_adjudication_v2_test.go.txt").read_text()
shape_start = cooklang.index("// Diagnostic shape control omits only HasError;")
shape = cooklang[shape_start:].replace("cooklangShapeWithoutHasError", "csharpShapeWithoutHasErrorPrivate")
body = '''//go:build cgo && treesitter_c_parity

package cgoharness

import (
    "bytes"
    "crypto/sha256"
    "encoding/json"
    "fmt"
    "os"
    "testing"

    gotreesitter "github.com/odvcencio/gotreesitter"
    "github.com/odvcencio/gotreesitter/grammars"
    "github.com/odvcencio/gotreesitter/internal/benchfixtures"
)

// Private diagnostic. Frozen Go expectations are logged; locked C remains the
// oracle. Independent route subtests run even when an earlier route differs.
func TestCSharpCurrentCAdjudicationPrivate(t *testing.T) {
    gotreesitter.ResetAdmissionCandidateCounters()
    t.Setenv("GTS_DISPATCHER_CENSUS", "1")
__WITNESSES__
    language := grammars.CSharpLanguage()
    if language.ExternalScanner == nil { t.Fatal("C# language has no registered external scanner") }
    if reusable, ok := language.ExternalScanner.(gotreesitter.IncrementalReuseExternalScanner); ok && reusable.SupportsIncrementalReuse() {
        t.Fatal("C# external scanner unexpectedly supports incremental reuse")
    }
    blob, err := os.ReadFile("../grammars/grammar_blobs/c_sharp.bin")
    if err != nil { t.Fatal(err) }
    blobSHA := fmt.Sprintf("%x", sha256.Sum256(blob))
    if blobSHA != "__BLOB_SHA__" { t.Fatalf("C# grammar blob SHA=%s", blobSHA) }
    cLanguage, err := COracleLanguage("c_sharp")
    if err != nil { t.Fatal(err) }
    identity, err := COracleIdentity("c_sharp")
    if err != nil { t.Fatal(err) }
    if identity.GrammarRepo != "https://github.com/tree-sitter/tree-sitter-c-sharp" || identity.GrammarCommit != "9150f7d56bb47f1a809fa23623f1ba1413e93fa9" {
        t.Fatalf("locked C# grammar identity=%+v", identity)
    }
    if identity.BindingVersion != COracleBindingVersion || identity.RuntimeVersion != COracleRuntimeVersion || identity.RuntimeCommit != COracleRuntimeCommit || identity.GrammarArtifactSHA256 == "" {
        t.Fatalf("C oracle identity=%+v", identity)
    }
    identityJSON, err := json.Marshal(identity)
    if err != nil { t.Fatal(err) }
    t.Logf("csharp_oracle_identity=%s grammar_lock_sha256=%s grammar_blob_sha256=%s", identityJSON, currentGrammarLockSHA256(t), blobSHA)
    for _, witness := range witnesses {
        witness := witness
        t.Run(witness.name, func(t *testing.T) {
            source := witness.src(t)
            if len(source) == 0 || source[len(source)-1] != '\\n' { source = append(source, '\\n') }
            sourceSHA := fmt.Sprintf("%x", sha256.Sum256(source))
            if sourceSHA != witness.wantSourceSHA { t.Fatalf("source SHA-256=%s, want %s", sourceSHA, witness.wantSourceSHA) }
            cTree := csharpDispatchCTree(t, cLanguage, source)
            t.Cleanup(cTree.Close)
            cDigest, err := COracleDeepDigest(cTree)
            if err != nil { t.Fatal(err) }
            if cDigest != witness.wantCDigest { t.Fatalf("locked-C digest=%s, want %s", cDigest, witness.wantCDigest) }
            for _, route := range []string{"raw", "production", "compact", "forest", "incremental"} {
                route := route
                t.Run(route, func(t *testing.T) {
                    beforeRouted, beforeFallback := gotreesitter.AdmissionCandidateCounters()
                    parser := gotreesitter.NewParser(language)
                    parser.SetAdmissionCandidateRoute(route == "compact")
                    var tree *gotreesitter.Tree
                    var parseErr error
                    var profile any
                    forestAccepted := false
                    switch route {
                    case "raw": tree, parseErr = parser.ParseNoResultCompatibilityBenchmarkOnly(source)
                    case "production", "compact": tree, parseErr = parser.Parse(source)
                    case "forest": tree, forestAccepted = parser.ParseForestExperimental(source)
                    case "incremental":
                        base := bytes.TrimSuffix(source, []byte{'\\n'})
                        oldTree, err := parser.Parse(base)
                        if err != nil || oldTree == nil { t.Fatalf("incremental base: tree=%t err=%v", oldTree != nil, err) }
                        t.Cleanup(oldTree.Release)
                        oldTree.Edit(gotreesitter.InputEdit{
                            StartByte: uint32(len(base)), OldEndByte: uint32(len(base)), NewEndByte: uint32(len(source)),
                            StartPoint: csharpDispatchPoint(base), OldEndPoint: csharpDispatchPoint(base), NewEndPoint: csharpDispatchPoint(source),
                        })
                        var incrementalProfile gotreesitter.IncrementalParseProfile
                        tree, incrementalProfile, parseErr = parser.ParseIncrementalProfiled(source, oldTree)
                        profile = incrementalProfile
                        if !incrementalProfile.ReuseUnsupported || incrementalProfile.ReuseUnsupportedReason != "external_scanner_unsupported" || incrementalProfile.OldTreeReuseRoute || incrementalProfile.ReusedSubtrees != 0 || incrementalProfile.ReusedBytes != 0 {
                            t.Errorf("incremental reuse changed: %+v", incrementalProfile)
                        }
                    }
                    if tree != nil { t.Cleanup(tree.Release) }
                    afterRouted, afterFallback := gotreesitter.AdmissionCandidateCounters()
                    expectedDigest := witness.wantGoDigest
                    expectedDiff := witness.wantRouteDiff
                    if route == "raw" { expectedDigest, expectedDiff = witness.wantRawDigest, witness.wantRawDiff }
                    row := map[string]any{
                        "witness": witness.name, "route": route, "bytes": len(source), "source_sha256": sourceSHA,
                        "c_digest": cDigest, "c_root_has_error": cTree.RootNode().HasError(), "c_root_is_error": cTree.RootNode().IsError(),
                        "old_go_digest": expectedDigest, "old_go_divergence": expectedDiff,
                        "old_compact_expectation": witness.wantCompactMode, "old_forest_expectation": witness.wantForest,
                        "actual_compact_routes": afterRouted-beforeRouted, "actual_compact_fallbacks": afterFallback-beforeFallback,
                        "fallback_reason": gotreesitter.AdmissionCandidateLastFallbackReason(), "forest_accepted": forestAccepted,
                        "incremental_profile": profile, "c_compared": false,
                    }
                    if parseErr != nil { row["status"], row["parse_error"] = "parse-error", parseErr.Error(); csharpCurrentCLogPrivate(t, row); t.Fatal(parseErr) }
                    if route == "forest" && !forestAccepted {
                        row["status"], row["tree_nil"] = "declined", tree == nil
                        csharpCurrentCLogPrivate(t, row)
                        if tree != nil { t.Error("forest declined with non-nil tree") }
                        if witness.wantForest { t.Error("formerly accepted forest route declined") }
                        return
                    }
                    if tree == nil || tree.RootNode() == nil { row["status"] = "missing-tree"; csharpCurrentCLogPrivate(t, row); t.Fatal("route returned no root") }
                    root := tree.RootNode()
                    inspection, err := benchfixtures.InspectGoTree(root, language)
                    if err != nil { row["inspection_error"] = err.Error(); csharpCurrentCLogPrivate(t, row); t.Fatal(err) }
                    shape := benchfixtures.NewDeepTreeDigest()
                    if err := csharpShapeWithoutHasErrorPrivate(shape, root, language, ""); err != nil { t.Fatal(err) }
                    shapeInspection, err := shape.Inspection()
                    if err != nil { t.Fatal(err) }
                    diff := FirstDivergenceDumpV1(root, language, cTree.RootNode())
                    flags := firstLockedCTreeFlagDivergence(root, language, cTree.RootNode(), "/"+root.Type(language))
                    exact := diff == nil && flags == nil && inspection.SHA256 == cDigest
                    row["status"], row["c_compared"] = "returned-tree", true
                    row["go_digest"], row["go_without_has_error_digest"] = inspection.SHA256, shapeInspection.SHA256
                    row["old_go_digest_matches"], row["old_expected_C_exact"] = inspection.SHA256 == expectedDigest, expectedDigest == cDigest && expectedDiff == nil
                    row["go_root_has_error"], row["go_root_is_error"] = root.HasError(), root.IsError()
                    row["go_c_first_divergence"], row["go_c_digest_equal"], row["matches_C_all_axes"] = diff, inspection.SHA256 == cDigest, exact
                    row["go_c_flag_divergence"] = nil
                    if flags != nil { row["go_c_flag_divergence"] = flags.Error() }
                    row["runtime"], row["dispatch"] = tree.ParseRuntime(), csharpDispatchPass(tree)
                    if route == "compact" { row["actual_compact_mode"] = csharpDispatchCompactMode(beforeRouted, beforeFallback, afterRouted, afterFallback) }
                    csharpCurrentCLogPrivate(t, row)
                    if !exact { t.Errorf("retained full C divergence: first=%+v flags=%v Go=%s C=%s", diff, flags, inspection.SHA256, cDigest) }
                    if route == "production" && tree.ParseRuntime().NativeRecoveredStructureAuthoritative != witness.wantNative { t.Errorf("production native authority=%t, want %t", tree.ParseRuntime().NativeRecoveredStructureAuthoritative, witness.wantNative) }
                })
            }
        })
    }
}

func csharpCurrentCLogPrivate(t *testing.T, row map[string]any) {
    t.Helper()
    raw, err := json.Marshal(row)
    if err != nil { t.Fatal(err) }
    t.Logf("csharp_current_c=%s", raw)
}

'''
blob_sha = sha((ROOT / "grammars/grammar_blobs/c_sharp.bin").read_bytes())
test = body.replace("__WITNESSES__", witnesses).replace("__BLOB_SHA__", blob_sha) + shape
test_name = "csharp_current_c_adjudication_test.go.txt"
write(test_name, test.encode())
subprocess.check_call(["gofmt", "-w", str(CONTROL / test_name)], cwd=ROOT)

changes = subprocess.check_output(["git", "diff", "--name-status", "--no-renames", BASE, HEAD, "--", "*.go", "*.bin"], cwd=ROOT, text=True)
old_map = {}
changed = {}
for line in changes.splitlines():
    status, path = line.split("\t")
    key = "/candidate/" + path
    now = (ROOT / path).read_bytes() if (ROOT / path).is_file() else None
    if status == "A":
        old_map[key] = ""
        changed[path] = {"old_absent": True, "current_sha256": sha(now)}
        continue
    assert status in ("M", "D"), (status, path)
    old = subprocess.check_output(["git", "show", BASE + ":" + path], cwd=ROOT)
    relative = "eff-files/" + path + ".source"
    write(relative, old)
    old_map[key] = "/controls/ci-followup/csharp/" + relative
    changed[path] = {"old_bytes": len(old), "old_sha256": sha(old), "current_sha256": sha(now) if now is not None else None}

probe_key = "/candidate/cgo_harness/csharp_current_c_adjudication_private_test.go"
probe_value = "/controls/ci-followup/csharp/" + test_name
for variant, mapping in (("current", {probe_key: probe_value}), ("eff", {**old_map, probe_key: probe_value})):
    dump("overlay." + variant + ".json", {"Replace": mapping})
    dump("overlay." + variant + ".host.json", {"Replace": {
        key.replace("/candidate/", str(ROOT) + "/", 1): (str(EVIDENCE) + value.removeprefix("/controls") if value else "")
        for key, value in mapping.items()}})

stable = {}
for path in (source_path, "grammars/languages.lock", "grammars/grammar_blobs/c_sharp.bin", "cgo_harness/go.mod", "cgo_harness/go.sum", "cgo_harness/parity_c_loader_cgo.go"):
    old = subprocess.check_output(["git", "show", BASE + ":" + path], cwd=ROOT)
    now = (ROOT / path).read_bytes()
    stable[path] = {"bytes": len(now), "sha256": sha(now), "unchanged_since_eff": old == now}
assert all(row["unchanged_since_eff"] for row in stable.values())
blob_path = "grammars/grammar_blobs/go.bin"
old_blob = CONTROL / "eff-files" / (blob_path + ".source")
dump("eff-runtime-bindings.json", {"required_for_exact_eff_embed_identity": True, "bindings": [{
    "source": "/controls/ci-followup/csharp/eff-files/" + blob_path + ".source", "target": "/candidate/" + blob_path,
    "read_only": True, "sha256": sha(old_blob.read_bytes())}], "note": "Embed bytes require a physical read-only bind; Go source overlay alone does not replace embedded go.bin. C# grammar blob itself is unchanged."})
dump("manifest.json", {
    "base": BASE, "current": HEAD, "changed_go_bin_paths": len(changed), "old_source_overlays": changed,
    "stable_inputs": stable, "witness_literal_verbatim_from_original": True, "production_files_modified": False,
    "selector": "^TestCSharpCurrentCAdjudicationPrivate$", "tags": "treesitter_c_parity,gts_parsercorephase0",
    "cwd": "/candidate/cgo_harness", "expected_rows_per_variant": 20,
    "full_C_mismatches_remain_test_failures": True, "forest_declines_are_not_C_compared": True,
    "old_Go_digest_mismatches_do_not_short_circuit_routes": True,
    "shape_digest_omits_only_HasError": True, "tests_builds_Docker_run": False,
    "files": {str(p.relative_to(CONTROL)): {"bytes": p.stat().st_size, "sha256": sha(p.read_bytes())}
              for p in sorted(CONTROL.rglob("*")) if p.is_file() and p.name != "manifest.json"}})
print(json.dumps({"base": BASE, "current": HEAD, "changed_go_bin_paths": len(changed), "probe_sha256": sha((CONTROL / test_name).read_bytes()), "builds_tests_run": False}))
