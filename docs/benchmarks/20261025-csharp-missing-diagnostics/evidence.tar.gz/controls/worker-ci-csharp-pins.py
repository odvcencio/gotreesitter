from pathlib import Path
import datetime,fcntl,json,subprocess
root=Path(__file__).resolve().parent
commands=json.loads((root/'commands-ci-csharp-pins.json').read_text())
with Path('/tmp/gotreesitter-compact-storage-docker.lock').open('a') as lock:
 print('CI correctness probe waiting for shared measurement lock',flush=True)
 fcntl.flock(lock,fcntl.LOCK_EX)
 print('CI correctness probe acquired shared measurement lock',flush=True)
 for task in commands:
  out=Path(task['output'])
  (out/'started.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'variant':task['variant']}))
  print('starting '+task['variant'],flush=True)
  try:
   with (out/'container.log').open('w') as log:r=subprocess.run(task['args'],stdout=log,stderr=subprocess.STDOUT,timeout=900)
   code=r.returncode
  except subprocess.TimeoutExpired:
   name=task['args'][task['args'].index('--name')+1]
   subprocess.run(['docker','stop','--time','10',name],capture_output=True)
   code=124
  (out/'finished.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':code}))
  print('finished '+task['variant']+' exit='+str(code),flush=True)
 print('all correctness probes terminal; no performance run requested',flush=True)
