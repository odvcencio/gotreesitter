set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
gofmt -d /controls/dependency.go.txt > /evidence/format-diff.txt
[[ ! -s /evidence/format-diff.txt ]]
for role in candidate; do
 cd "/$role/cgo_harness"
 go test -c -overlay=/controls/overlay.json -tags treesitter_c_parity,gts_parsercorephase0 -o "/evidence/$role-cgo.test" . > "/evidence/$role-build.log" 2>&1
 "/evidence/$role-cgo.test" -test.run '^Test(NumericRunProofABI|GoNumericRunProjectionLockedC|GoTokenInvariantLookaheadNumeric(Repair|Reuse)LockedC|ReleaseTokenInvariantGoNumericLookaheadLockedC)$' -test.v -test.count=1 -test.timeout=5m > "/evidence/$role-C.log" 2>&1
done
cd /candidate
go test -overlay=/controls/overlay.json ./internal/incr -run '^Test(SingleFrontierEvidenceRequiresClosedTrace|ASCIIDigitTextEditProjectionBoundary|LengthNeutralScannerEdit|TokenEditProjection|TokenReadBound)' -v -count=1 > /evidence/incr-unit.log 2>&1
cd /candidate
go test -c -overlay=/controls/overlay.json -tags gts_parsercorephase0 -o /evidence/candidate.test . > /evidence/root-build.log 2>&1
/evidence/candidate.test -test.run '^Test(SingleFrontierTreeProvenanceResets|TestRecoveryMemoTelemetryPreservesAMD64HotLayouts|MissingNodeDependencyLayoutAndOwnership|FullParseNodeCapacity.*|StructuralDensityNodeCap.*|.*Arena.*Hint.*|.*Arena.*Capacity.*)$' -test.count=1 -test.v -test.timeout=5m > /evidence/arena-unit.log 2>&1
for lang in go yaml; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /evidence/candidate.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/$lang-invariant-$route.log" 2>&1
 done
done
/evidence/candidate.test -test.run '^Test(CompactAcceptance(ChangedSourceKeepsRebuildBudget|CachedPublicationStopControl)|CompactMemoryBudgetDetectsGrowthAfterSmallPoll|CompactAcceptance.*(MemoryBudget|RetentionBound)|CompactArenaReserve.*(Budget|RetentionCap)|CompactExternalScannerCheckpointCopyMemoryBudget|CompactRecoveryMemoMemoryBudget|CompactBorrowedMaterializationProjectionMemoryBudget|G18RefSetSchedulerMemoryBudgetAccounting|RuntimeMemoryBudget.*|RuntimeMemoryHardCeilingStillStopsParse|ParseMemoryHardCeiling.*)$' -test.count=1 -test.v -test.timeout=8m > /evidence/memory.log 2>&1
for role in baseline candidate; do
 cd "/$role"
 go build -overlay=/controls/overlay.json -tags gts_parsercorephase0 -o "/evidence/$role-ledger" ./cmd/perfcounterledger > "/evidence/$role-ledger-build.log" 2>&1
 for lang in go yaml; do
  "/evidence/$role-ledger" --langs "$lang" > "/evidence/$role-$lang-ledger.json" 2> "/evidence/$role-$lang-ledger.log"
 done
done
for lang in go yaml; do cmp "/evidence/baseline-$lang-ledger.json" "/evidence/candidate-$lang-ledger.json"; done
printf 'complete\n' > /evidence/complete.txt
