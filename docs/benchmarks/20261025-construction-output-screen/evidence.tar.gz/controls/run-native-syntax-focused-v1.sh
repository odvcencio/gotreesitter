set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/native-syntax-focused-v1/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/native-syntax-focused-v1/controls.sha256 > /evidence/controls-before.log 2>&1
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/native-syntax-focused-v1
mkdir -p "$scratch"
overlay=/controls/native-syntax-entry-proof-v1/overlay.container.json
go test -overlay="$overlay" -tags gts_parsercorephase0 -run '^Test(Native|Selected)' -count=1 -v -timeout=4m ./internal/parsercorephase0 > /evidence/core-reference.log 2>&1
go test -c -overlay="$overlay" -tags gts_parsercorephase0 -o "$scratch/root.test" . > /evidence/root-build.log 2>&1
"$scratch/root.test" -test.run '^Test(NativeNodeViews(ConcurrentReads|SameWidthReparseWithoutEdit|FreshVerificationReadsRecords|SparseQueryKeepsOutputCompact|LeadingTrivia|RecycledMetadataDetachesResult|TypeArgumentsPreserveEditAndCopy)|NativeProjection(UnusedSourceMapIsReleased|AliasReceiptRejectsChangedPublication|ReceiptPassMatchesReference)|QuiescentNative(GoPublicationMatchesReference|GoRecoveryKeepsReferencePublisher|HiddenDirectFieldPunctuation|HiddenExtras|UnsupportedFieldsKeepReferencePublisher)|CompactAcceptance.*|RuntimeMemory.*|ParseMemory.*)$' -test.count=1 -test.v -test.timeout=5m > /evidence/focused.log 2>&1
"$scratch/root.test" -test.run '^Test(NativeNodeViewsPublicAPI|NativeNodeViewsPublicParseEdit|NativeNodeViewsExtraRootFraming)$/^go$' -test.count=1 -test.v -test.timeout=3m > /evidence/go-public-api.log 2>&1
for language in go yaml; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE=$route GOTREESITTER_V1_INVARIANT_LANGUAGE=$language "$scratch/root.test" -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=3m > "/evidence/invariants-$language-$route.log" 2>&1
 done
done
go build -overlay=/controls/native-syntax-producer-v1/v4/overlay.json -tags gts_parsercorephase0 -o "$scratch/ledger" ./cmd/perfcounterledger > /evidence/ledger-build.log 2>&1
for language in go yaml; do
 for route in default candidate; do
  mode=0; if [[ "$route" = candidate ]]; then mode=1; fi
  GTS_ADMISSION_CANDIDATE=$mode "$scratch/ledger" --child-route "$route" --langs "$language" > "/evidence/$route-$language.json" 2> "/evidence/$route-$language.stderr"
 done
done
sha256sum "$scratch/root.test" "$scratch/ledger" > /evidence/binary.sha256
printf 'focused existing API memory D8 and actual counter rows complete; not full fleet qualification\n' > /evidence/completed.txt
