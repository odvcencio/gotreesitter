set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/native-syntax-core-qualification-v1/controls.sha256 > /evidence/controls-before.log 2>&1
overlay=/controls/native-syntax-producer-v1/overlay.core.tests.json
selector='^TestSyntaxProducer(AuthenticOutputAndSealWithoutReplay|LeaseResetMultipleTreesAndPool|DeclinesAmbiguityAndSharedRaw|BudgetErrorPanicAndMutationFailClosed)$'
go test -overlay="$overlay" -run "$selector" -count=1 -v -timeout=3m ./internal/parsercorephase0 > /evidence/core-release.log 2>&1
go test -overlay="$overlay" -tags gts_workcount -run "$selector" -count=1 -v -timeout=3m ./internal/parsercorephase0 > /evidence/core-workcount.log 2>&1
go test -overlay="$overlay" -tags gts_workcount,gts_eof_recovery_shadow -run '^TestSyntaxProducerDiagnosticCloneDetachesDraft$' -count=1 -v -timeout=3m ./internal/parsercorephase0 > /evidence/core-shadow-clone.log 2>&1
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1
sha256sum --quiet -c /controls/native-syntax-core-qualification-v1/controls.sha256 > /evidence/controls-after.log 2>&1
printf 'focused construction-time syntax core gates terminal; inspect complete selection before claiming pass\n' > /evidence/completed.txt
