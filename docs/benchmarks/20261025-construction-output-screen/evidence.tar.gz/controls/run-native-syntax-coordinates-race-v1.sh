set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/native-syntax-coordinates-race-v1/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/native-syntax-coordinates-race-v1/controls.sha256 > /evidence/controls-before.log 2>&1
cd /candidate/cgo_harness
go test -overlay=/controls/native-syntax-coordinates-race-v1/overlay.container.json -tags treesitter_c_parity,gts_parsercorephase0 -run '^TestPrivateNativeSyntaxCoordinatesLockedC$' -count=1 -v -timeout=4m . > /evidence/coordinates-cgo.log 2>&1
cd /candidate
go test -race -overlay=/controls/native-syntax-producer-v1/v4/overlay.core.tests.json -run '^TestSyntaxProducer' -count=1 -v -timeout=4m ./internal/parsercorephase0 > /evidence/core-race.log 2>&1
go test -race -overlay=/controls/native-syntax-api-proof-v1/overlay.tests.json -tags gts_parsercorephase0 -run '^TestPrivateNativeSyntaxConcurrentReadsOtherReleasesAndReset$' -count=1 -v -timeout=5m . > /evidence/public-concurrent-race.log 2>&1
printf 'coordinate and independent core/concurrent race checks complete; copy receipt mismatch remains unresolved\n' > /evidence/completed.txt
