# Private ordinary Go R4 decline audit

Prepared only; no compilation or runtime execution. Merge the disjoint map here with the frozen V4 full test map `../native-syntax-producer-v1/v4/overlay.tests.json`. Keep `/controls` bound to the parent go-ci-blockers-20261025 directory.

```
go test -overlay=/evidence/native-syntax-r4-audit-overlay.json -tags=gts_parsercorephase0 . -run '^TestPrivateNativeSyntaxR4DeclineAudit$' -count=1 -v -timeout=4m
```

The first source is the original committed2047-byte R4 fixture SHA b37389f6dbac4e417f19db04909783b0264dfec4e3c93774f0557c3e91b8f6c5. The test constructs the second solely with standard go/scanner ScanComments, masks each comment byte to a space except LF, and authenticates all seven spans and masked SHA1a277b38915f687cda407bc8af99dacf6845acf0095fe098b4abe91d02a2d1c7. No token string contents are masked. Expected spans/hash were prepared independently from the frozen source; the executable standard scanner must reproduce them exactly.

Both cases use ordinary candidate public Parse. Before public inspection, the diagnostic logs actual lease/SelectedStore state and the sole cached runner's producer status. Original must decline the syntax producer for exactly `extra replay-position scope`; masked need not activate and logs its actual next result. Both must return clean, accepted full-input roots; their independent tree digests are logged after status capture. The masked fixture is separate diagnostic input, never a replacement R4 source or a real-R4 speed qualification. No runtime changes or measured-result claims are made.
