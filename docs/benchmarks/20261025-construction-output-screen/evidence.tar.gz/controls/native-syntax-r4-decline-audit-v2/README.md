# Private ordinary Go R4 decline audit V2

Prepared only; no compilation or runtime execution. V1 source and its import-cycle failure remain frozen. V2 uses package gotreesitter_test: public Parser/grammars plus unchanged PrivateSyntaxEnabledForTest/PrivateSyntaxEntryInfoForTest exports from native-syntax-entry-proof-v1. This removes the internal-test import cycle without changing runtime semantics, fixtures or required results.

Merge the frozen V4 full test map with this directory's map. The V2 map includes the unchanged entry-proof helper target plus the new external test. Do not include V1's audit test map. Keep `/controls` bound to the parent go-ci-blockers-20261025 directory.

```
go test -overlay=/evidence/native-syntax-r4-audit-v2-overlay.json -tags=gts_parsercorephase0 . -run '^TestPrivateNativeSyntaxR4DeclineAudit$' -count=1 -v -timeout=4m
```

The original2047B real R4 SHA b37389f6dbac4e417f19db04909783b0264dfec4e3c93774f0557c3e91b8f6c5 and standard-scanner comment-masked2047B diagnostic SHA1a277b38915f687cda407bc8af99dacf6845acf0095fe098b4abe91d02a2d1c7 remain pinned. The seven token.COMMENT spans, all LF positions and byte lengths remain unchanged. Status/lease/SelectedStore are captured before public tree inspection. Original must decline for exactly `extra replay-position scope`; transformed need not activate. Both roots must be clean, accepted, cover input through EOF and yield logged deep digests. The transformed fixture is never real-R4 speed evidence. No engine, verifier, runtime, source fixture or profiling controls changed; no V2 execution claim.
