from pathlib import Path
import json,re,hashlib,sys
root=Path(__file__).resolve().parents[1]
out=root/'out'
def check(folder,selectors):
 p=out/folder
 assert json.loads((p/'finished.json').read_text())['exit_code']==0,folder
 assert (p/'completed.txt').is_file(),folder
 for name in ('source-before.log','source-after.log','controls-before.log','controls-after.log'):assert (p/name).read_text()=='',(folder,name)
 for name,expected in selectors.items():
  text=(p/name).read_text()
  assert len(re.findall(r'^--- PASS:',text,re.M))==expected,(folder,name,'wrong selection')
  assert not re.search(r'--- (FAIL|SKIP):|WARNING: DATA RACE|^FAIL\b|panic:',text,re.M),(folder,name)
 return p
p=check('native-syntax-v4-qualification-v1',{'core-release.log':8,'core-workcount.log':8,'core-shadow-clone.log':1,'root.log':2,'accounting.log':1,'actual-entries.log':1})
rows=[json.loads(line.split('SYNTAX_ACTUAL_ENTRY ',1)[1]) for line in (p/'actual-entries.log').read_text().splitlines() if 'SYNTAX_ACTUAL_ENTRY ' in line]
assert len(rows)==4
for fixture in ('primary-500','real-r4'):
 a,b=[r for r in rows if r['fixture']==fixture]
 assert not a['enabled'] and b['enabled'] and a['digest']==b['digest']
 assert a['board']==b['board'] and a['publication']['core_work']==b['publication']['core_work']
 diff={k:[v,b['work'].get(k)] for k,v in a['work'].items() if b['work'].get(k)!=v}
 if fixture=='primary-500':
  assert b['source_bytes']==19294 and b['source_sha256']=='2e0f9d4676549c8560cebc3c53877932f921ab9d77c88518227f3018573af4b7'
  assert b['publication']['lease'] and not b['publication']['selected_store']
  assert b['publication']['status']['Transferred'] and b['publication']['status']['PublicNodes']==11004
  assert diff=={'table_lookups_proxy':[41515,26010]},diff
 else:assert not b['publication']['lease'] and b['publication']['selected_store'] and b['publication']['status']['Reason']=='extra replay-position scope' and not diff
p=check('native-syntax-focused-v1',{'core-reference.log':55,'focused.log':36,'go-public-api.log':3,**{f'invariants-{lang}-{route}.log':1 for lang in ('go','yaml') for route in (0,1)}})
for lang in ('go','yaml'):
 for route in ('default','candidate'):
  name=f'{route}-{lang}.json';assert json.loads((p/name).read_text())==json.loads((out/'packed-snapshot-budget-final/ledger'/name).read_text()),name
 for route in (0,1):assert 'session_steps=72 no_edit_allocs=0' in (p/f'invariants-{lang}-{route}.log').read_text()
p=check('native-syntax-cgo-qualification-v2',{'primary-cgo.log':1,'primary-edits-cgo.log':1,'go-cgo.log':10,'yaml-cgo.log':8})
assert 'actual_lease=true lease_nodes=11004' in (p/'primary-cgo.log').read_text()
s=(p/'primary-edits-cgo.log').read_text();assert s.count('initial_lease=true')==3 and s.count('no_edit_allocs=0')==3
check('native-syntax-coordinates-race-v1',{'coordinates-cgo.log':1,'core-race.log':8,'public-concurrent-race.log':1})
check('native-syntax-api-qualification-v2',{'api-query-workcount.log':7,'public-race.log':2})
p=out/'native-syntax-copy-probe-v1';assert (p/'test-exit.txt').read_text().strip()=='1'
s=(p/'copy-diagnostic.log').read_text();r=[json.loads(line.split('COPY_RECEIPT_DIAGNOSTIC ',1)[1]) for line in s.splitlines() if 'COPY_RECEIPT_DIAGNOSTIC ' in line];assert len(r)==2
for x in r:
 x.pop('mode');assert x['first_copy_root_word']==2 and x['second_copy_root_word']==0 and not x['second_copy_has_certified_reuse']
assert r[0]==r[1]
assert hashlib.sha256((root/'native-syntax-producer-v1/v4/overlay.json').read_bytes()).hexdigest()=='8ccbf9e6bd1a56c1f2e082a3ae60885a08996a1fb854f9e292f413f4282211a6'
print(json.dumps({'schema':'gts-construction-output-preperf/v1','primary500_activated':True,'actual_core_work_and_board_unchanged':True,'table_lookup_proxy':[41515,26010],'ordinary_ledger_rows_equal':4,'R4_invariant_sessions':4,'R4_edit_steps':288,'lease_positive_edit_cases':3,'lease_positive_coordinate_cases':3,'no_edit_allocs':0,'Go_C_families':10,'YAML_C_families':8,'core_race_families':8,'public_race_families':2,'api_query_families':7,'inherited_copy_abstention_explicitly_reproduced':True,'full_fleet_qualified':False,'graduation_claim':False,'runtime_promoted':False,'merges_held':True},sort_keys=True))
