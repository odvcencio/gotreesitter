set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/native-syntax-cgo-qualification-v1/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/native-syntax-cgo-qualification-v1/controls.sha256 > /evidence/controls-before.log 2>&1
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/native-syntax-cgo-qualification-v1
mkdir -p "$scratch"
cd /candidate/cgo_harness
overlay=/controls/native-syntax-cgo-qualification-v1/overlay.container.json
go test -c -overlay="$overlay" -tags treesitter_c_parity,gts_parsercorephase0 -o "$scratch/cgo.test" . > /evidence/cgo-build.log 2>&1
"$scratch/cgo.test" -test.run '^TestPrivateNativeSyntaxPrimary500LockedC$' -test.count=1 -test.v -test.timeout=4m > /evidence/primary-cgo.log 2>&1
"$scratch/cgo.test" -test.run '^Test(GoGroupedBindingSeparatorsLockedC|GoGroupedConstSeparatorEditsMatchLockedC|GoIssue490FragmentBoundaryLockedC|GoHiddenMissingSemicolonEditsMatchLockedC|Stage6GoCompactCertification|GoCompactIncrementalExecutionParity|GoCompactNestedReuse.*|GoNestedGenericSelectionLockedC)$' -test.count=1 -test.v -test.timeout=5m > /evidence/go-cgo.log 2>&1
GTS_ADMISSION_CANDIDATE=1 "$scratch/cgo.test" -test.run '^Test(CompactYAMLVersionOwnershipCOracle|CompactYAMLDocumentStreamLockedC|YAMLRecoveredMappingQuotesLockedC|YAMLOwnedGrammarLockedCParity|YAMLEOFRecoverWrapCompactRoute|YAMLEOFRecoverWrapUnfinishedMappingDeclinesCompact|YAMLOneBytePrintableEOFAdmissionMatchesLockedC|YAMLResultCompatibilityErrorsLockedC)$' -test.count=1 -test.v -test.timeout=5m > /evidence/yaml-cgo.log 2>&1
sha256sum "$scratch/cgo.test" > /evidence/binary.sha256
printf 'lease-positive primary500 and existing Go/YAML C families complete; not full fleet qualification\n' > /evidence/completed.txt
