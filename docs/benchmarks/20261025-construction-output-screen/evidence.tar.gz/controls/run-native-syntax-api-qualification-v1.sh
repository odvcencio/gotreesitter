set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/native-syntax-api-qualification-v1/controls.sha256 > /evidence/controls-after.log 2>&1; python3 /controls/native-syntax-api-proof-v1/authenticate.py --root /candidate --controls /controls > /evidence/input-authentication-after.json; }
trap finish EXIT
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/native-syntax-api-qualification-v1/controls.sha256 > /evidence/controls-before.log 2>&1
python3 /controls/native-syntax-api-proof-v1/authenticate.py --root /candidate --controls /controls > /evidence/input-authentication-before.json
overlay=/controls/native-syntax-api-proof-v1/overlay.tests.json
go test -overlay="$overlay" -tags gts_parsercorephase0,gts_workcount -run '^TestPrivateNativeSyntax(Query|CopyAfterOriginalRelease|ConcurrentReadsOtherReleasesAndReset)' -count=1 -v -timeout=4m . > /evidence/api-query-workcount.log 2>&1
go test -race -overlay=/controls/native-syntax-producer-v1/v4/overlay.core.tests.json -run '^TestSyntaxProducer' -count=1 -v -timeout=4m ./internal/parsercorephase0 > /evidence/core-race.log 2>&1
go test -race -overlay="$overlay" -tags gts_parsercorephase0 -run '^TestPrivateNativeSyntax(CopyAfterOriginalRelease|ConcurrentReadsOtherReleasesAndReset)$' -count=1 -v -timeout=5m . > /evidence/public-race.log 2>&1
printf 'lease-positive query API and core/public race gates terminal\n' > /evidence/completed.txt
