set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/native-syntax-root-qualification-v1/controls.sha256 > /evidence/controls-before.log 2>&1
python3 /controls/native-syntax-producer-v1/authenticate.py --root /candidate --controls /controls/native-syntax-producer-v1 > /evidence/input-authentication-before.json
go test -overlay=/controls/native-syntax-producer-v1/overlay.tests.json -tags gts_parsercorephase0 -run '^TestPrivateNativeSyntax(PrimaryLifetime|IneligibleContexts)$' -count=1 -v -timeout=4m . > /evidence/root.log 2>&1
python3 /controls/native-syntax-producer-v1/authenticate.py --root /candidate --controls /controls/native-syntax-producer-v1 > /evidence/input-authentication-after.json
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1
sha256sum --quiet -c /controls/native-syntax-root-qualification-v1/controls.sha256 > /evidence/controls-after.log 2>&1
printf 'root lifetime/eligibility controls terminal; real primary/R4 qualification still required\n' > /evidence/completed.txt
