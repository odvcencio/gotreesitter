set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
finish(){ cd /candidate; sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1; sha256sum --quiet -c /controls/native-syntax-r4-audit-v2/controls.sha256 > /evidence/controls-after.log 2>&1; }
trap finish EXIT
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/native-syntax-r4-audit-v2/controls.sha256 > /evidence/controls-before.log 2>&1
go test -overlay=/controls/native-syntax-r4-audit-v2/overlay.audit.json -tags gts_parsercorephase0 -run '^TestPrivateNativeSyntaxR4DeclineAudit$' -count=1 -v -timeout=4m . > /evidence/r4-decline-audit.log 2>&1
printf 'original and masked R4 diagnostic complete; masks are a distinct diagnostic fixture\n' > /evidence/completed.txt
