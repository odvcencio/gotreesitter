set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
trap 'printf "%s\n" "$?" > /evidence/before.exit' EXIT
git config --global --add safe.directory /candidate
cd /candidate
go test -tags gts_parsercorephase0 -run '^Test(TokenInvariant|GoTokenInvariant|IncrementalLeaf|LengthNeutral)' -count=1 -v . > /evidence/before-root.log 2>&1
cd cgo_harness
go test -tags treesitter_c_parity,gts_parsercorephase0 -run '^Test(GoTokenInvariantLookahead|ReleaseTokenInvariantGoNumeric)' -count=1 -v . > /evidence/before-cgo.log 2>&1
