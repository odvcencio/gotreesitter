set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
trap 'printf "%s\n" "$?" > /evidence/after.exit' EXIT
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
cd /candidate
go test ./internal/incr -count=1 -v > /evidence/after-incr.log 2>&1
go test -c -tags gts_parsercorephase0 -o /runtime/tmp/gotreesitter-go-edit-original/after.test . > /evidence/after-build.log 2>&1
/runtime/tmp/gotreesitter-go-edit-original/after.test -test.run '^Test(TokenInvariant|GoTokenInvariant|IncrementalLeaf|LengthNeutral)' -test.count=1 -test.v > /evidence/after-root.log 2>&1
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /runtime/tmp/gotreesitter-go-edit-original/after-cgo.test . > /evidence/after-cgo-build.log 2>&1
/runtime/tmp/gotreesitter-go-edit-original/after-cgo.test -test.run '^Test(GoTokenInvariantLookahead|ReleaseTokenInvariantGoNumeric)' -test.count=1 -test.v > /evidence/after-focused-cgo.log 2>&1
for role in baseline candidate; do
 cd /$role
 go build -overlay=/controls/baseline-overlay.json -o /runtime/tmp/gotreesitter-go-edit-original/$role-ledger ./cmd/perfcounterledger > /evidence/$role-ledger-build.log 2>&1
 go test -c -overlay=/controls/work-overlay.json -tags gts_parsercorephase0,gts_workcount -o /runtime/tmp/gotreesitter-go-edit-original/$role-work.test . > /evidence/$role-work-build.log 2>&1
done
mkdir -p /evidence/invariants /evidence/cgo /evidence/work /evidence/ledger /evidence/counter-deltas
while IFS= read -r lang; do
 cd /candidate
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /runtime/tmp/gotreesitter-go-edit-original/after.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > /evidence/invariants/$route-$lang.log 2>&1
 done
 cd /candidate/cgo_harness
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GTS_PARITY_MODE=exhaustive /runtime/tmp/gotreesitter-go-edit-original/after-cgo.test -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${lang}$" -test.count=1 -test.v -test.timeout=5m > /evidence/cgo/$route-$lang.log 2>&1
 done
 for role in baseline candidate; do
  cd /$role
  GTS_WORK_LANGUAGE="$lang" /runtime/tmp/gotreesitter-go-edit-original/$role-work.test -test.run '^TestDirectReductionWork$' -test.count=1 -test.timeout=5m > /evidence/work/$role-$lang.log 2>&1
  /runtime/tmp/gotreesitter-go-edit-original/$role-ledger --langs "$lang" > /evidence/ledger/$role-$lang.json 2> /evidence/ledger/$role-$lang.log
 done
 python3 /controls/compare-ledger.py /evidence/ledger/baseline-$lang.json /evidence/ledger/candidate-$lang.json /evidence/counter-deltas/$lang.json > /evidence/counter-deltas/$lang.log
 printf '%s\n' "$lang" >> /evidence/gate-progress.txt
done < /controls/languages.txt
cd /candidate
go test -race ./internal/incr -count=1 > /evidence/after-incr-race.log 2>&1
go test -race -tags gts_parsercorephase0 -run '^Test(TokenInvariant|GoTokenInvariant|IncrementalLeaf|LengthNeutral)' -count=1 . > /evidence/after-race.log 2>&1
go run ./cmd/v1layout > /evidence/after-layout.log 2>&1
printf 'complete\n' > /evidence/gate-complete.txt
