### Perf Definitive Outcome

- outcome: `DEFINITIVE_LOSS`
- reason: regression gate failed

| benchmark | metric | base | head | delta |
| --- | --- | ---: | ---: | ---: |
| BenchmarkGoParseFullDFA | ns/op | 5828276 | 5912633 | +1.45% |
| BenchmarkGoParseFullDFA | B/op | 1167 | 1167 | +0.00% |
| BenchmarkGoParseFullDFA | allocs/op | 6.0000 | 6.0000 | +0.00% |
| BenchmarkGoParseIncrementalSingleByteEditDFA | ns/op | 115228 | 127457 | +10.61% |
| BenchmarkGoParseIncrementalSingleByteEditDFA | B/op | 394.00 | 395.00 | +0.25% |
| BenchmarkGoParseIncrementalSingleByteEditDFA | allocs/op | 5.0000 | 5.0000 | +0.00% |
| BenchmarkGoParseIncrementalNoEditDFA | ns/op | 5.5915 | 5.2075 | -6.87% |
| BenchmarkGoParseIncrementalNoEditDFA | B/op | 0 | 0 | +0.00% |
| BenchmarkGoParseIncrementalNoEditDFA | allocs/op | 0 | 0 | +0.00% |

