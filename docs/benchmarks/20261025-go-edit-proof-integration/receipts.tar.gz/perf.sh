set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
unset GTS_ADMISSION_CANDIDATE GOT_PARSE_NODE_LIMIT_SCALE GOT_STATS
trap 'printf "%s\n" "$?" > /evidence/perf.exit' EXIT
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
test -f /evidence/gate-complete.txt
test "$(cat /evidence/after.exit)" = 0
cd /candidate
python3 /controls/compare-work.py
/runtime/tmp/gotreesitter-go-edit-original/after.test -test.run '^TestPrimitiveProofModeSetRetainsBounds$' -test.count=1 -test.v > /evidence/after-mode-bounds.log 2>&1
/runtime/tmp/gotreesitter-go-edit-original/after.test -test.run '^Test(CompactAcceptance(ChangedSourceKeepsRebuildBudget|CachedPublicationStopControl)|CompactMemoryBudgetDetectsGrowthAfterSmallPoll|CompactAcceptance.*(MemoryBudget|RetentionBound)|CompactArenaReserve.*(Budget|RetentionCap)|CompactExternalScannerCheckpointCopyMemoryBudget|CompactRecoveryMemoMemoryBudget|CompactBorrowedMaterializationProjectionMemoryBudget|G18RefSetSchedulerMemoryBudgetAccounting|RuntimeMemoryBudget.*|RuntimeMemoryHardCeilingStillStopsParse|ParseMemoryHardCeiling.*)$' -test.count=1 -test.v -test.timeout=8m > /evidence/after-memory.log 2>&1
mkdir -p /evidence/perf
go version > /evidence/perf/compiler.txt
cp /controls/benchmark_primary_overlay.go.txt /evidence/perf/prepare-primary.go
go run /evidence/perf/prepare-primary.go /controls/benchmark_primary_go_suite.go.txt /evidence/perf/primary-overlay.json /baseline /candidate > /evidence/perf/primary-hashes.txt
python3 - <<'INNER'
from pathlib import Path
import json
p=Path('/evidence/perf/primary-overlay.json');d=json.loads(p.read_text());d['Replace'].update(json.loads(Path('/controls/baseline-overlay.json').read_text())['Replace']);p.write_text(json.dumps(d,indent=2)+'\n')
INNER
# Go 1.22 vet reads the physical source instead of the source overlay. Native
# CI still vets both revisions; local correctness uses Go 1.26.6 separately.
export GOFLAGS='-p=1 -mod=readonly -overlay=/evidence/perf/primary-overlay.json -vet=off'
bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/perf/baseline.txt --output /evidence/perf/candidate.txt --runs 20 --seed-start 1 --benchtime 750ms --tags '' --bench-regex '^BenchmarkGTSSeededPrimary$' --require-benchmarks 'BenchmarkGTSSeededPrimary/BenchmarkGoParseFullDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalNoEditDFA' --lock-path /evidence/perf.lock > /evidence/perf/driver.log 2>&1
gate_status=0
go run ./cmd/benchgate -base /evidence/perf/baseline.txt -head /evidence/perf/candidate.txt -benchmarks 'BenchmarkGTSSeededPrimary/BenchmarkGoParseFullDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalNoEditDFA' -max-ns-regression 0.08 -max-bytes-regression 0.05 -max-allocs-regression 0.05 > /evidence/perf/gate.log 2>&1 || gate_status=$?
printf '%s\n' "$gate_status" > /evidence/perf/gate.exit
for role in baseline candidate; do
 cd /$role
 go test -c -o /runtime/tmp/gotreesitter-go-edit-original/$role-perf.test . > /evidence/perf/$role-build.log 2>&1
 GOT_BENCH_FUNC_COUNT=5000 /usr/bin/time -v /runtime/tmp/gotreesitter-go-edit-original/$role-perf.test -test.run '^$' -test.bench '^BenchmarkGoParseFullDFA$' -test.benchtime 3x -test.count 1 > /evidence/perf/$role-rss.log 2> /evidence/perf/$role-rss.txt
done
cd /candidate
bash scripts/run_go_edit_attribution.sh /baseline /evidence/attribution /runtime/tmp/gotreesitter-go-edit-original/baseline-perf.test /runtime/tmp/gotreesitter-go-edit-original/candidate-perf.test > /evidence/attribution-driver.log 2>&1
printf 'complete\n' > /evidence/perf-complete.txt
