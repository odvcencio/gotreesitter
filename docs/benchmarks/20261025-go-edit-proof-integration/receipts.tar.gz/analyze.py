from pathlib import Path
import json, re, statistics, subprocess, sys

root = Path(__file__).resolve().parent
directory = Path(sys.argv[1]) if len(sys.argv) > 1 else root / 'qualified'

def samples(path):
    text = path.read_text()
    assert text.rstrip().endswith('# status: complete'), path
    assert '# completed runs: 20' in text, path
    rows = {}
    seed = None
    stats = {}
    for line in text.splitlines():
        match = re.match(r'# seed: (\d+); position: (\d+)$', line)
        if match:
            seed, position = map(int, match.groups())
            assert seed not in rows
            rows[seed] = {'position': position, 'order': [], 'metrics': {}}
        if line.startswith('STATS edits='):
            stats[seed] = {k: int(v) for k, v in re.findall(r'(\w+)=(\d+)', line)}
        if not re.match(r'^Benchmark\S+\s+[1-9]\d*\s+', line):
            continue
        words = line.split()
        name = re.sub(r'-\d+$', '', words[0]).removeprefix('BenchmarkGTSSeededPrimary/')
        assert name not in rows[seed]['metrics']
        values = {words[i+1]: float(words[i]) for i in range(2, len(words), 2)}
        assert {'ns/op', 'B/op', 'allocs/op'} <= values.keys()
        rows[seed]['order'].append(name)
        rows[seed]['metrics'][name] = values
    assert set(rows) == set(range(1, 21))
    return rows, stats

def compare(base_path, head_path):
    base, _ = samples(base_path)
    head, _ = samples(head_path)
    for seed in base:
        assert base[seed]['order'] == head[seed]['order']
        assert base[seed]['position'] == 1+(seed-1)%2
        assert head[seed]['position'] == 2-(seed-1)%2
    result = []
    for name in base[1]['order']:
        row = {'benchmark': name, 'metrics': {}}
        for metric in ('ns/op', 'B/op', 'allocs/op'):
            before = statistics.median(base[s]['metrics'][name][metric] for s in base)
            after = statistics.median(head[s]['metrics'][name][metric] for s in head)
            row['metrics'][metric] = {'before': before, 'after': after, 'percent': (after/before-1)*100 if before else (0 if after == 0 else None)}
        if 'NoEdit' in name:
            for data in (base, head):
                assert all(data[s]['metrics'][name]['B/op'] == data[s]['metrics'][name]['allocs/op'] == 0 for s in data)
        result.append(row)
    return result

out = {'performance': compare(directory/'perf/baseline.txt', directory/'perf/candidate.txt')}
for label, path in [('baseline', directory/'attribution/base-stats.txt'), ('candidate', directory/'attribution/head-stats.txt')]:
    rows, stats = samples(path)
    assert set(stats) == set(range(1, 21))
    measures = {}
    for key in ('edit_ns', 'reuse_ns', 'parse_ns', 'reused_subtrees', 'reused_bytes', 'new_nodes'):
        values = [d[key]/d['edits'] for d in stats.values()]
        measures[key] = {'median': statistics.median(values), 'min': min(values), 'max': max(values)}
    out[label+'_attribution'] = measures
(directory/'analysis.json').write_text(json.dumps(out, indent=2)+'\n')
with (directory/'benchstat.txt').open('w') as output:
    subprocess.run(['/home/draco/go/bin/benchstat', 'baseline.txt', 'candidate.txt'], cwd=directory/'perf', stdout=output, check=True)
print(json.dumps(out, indent=2))
