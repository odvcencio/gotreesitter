set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly -overlay=/controls/baseline-overlay.json'
trap 'printf "%s\n" "$?" > /evidence/before-c.exit' EXIT
git config --global --add safe.directory /baseline
cd /baseline/cgo_harness
go test -tags treesitter_c_parity,gts_parsercorephase0 -run '^Test(GoTokenInvariantLookahead|ReleaseTokenInvariantGoNumeric)' -count=1 -v . > /evidence/before-cgo126.log 2>&1
