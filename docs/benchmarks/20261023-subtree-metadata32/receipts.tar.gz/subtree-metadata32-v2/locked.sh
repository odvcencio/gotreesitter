set -u
date -u +'%Y-%m-%dT%H:%M:%S.%NZ' > /evidence/workload-started.txt
bash /evidence/focused.sh
result=$?
printf '%s\n' "$result" > /evidence/exit-code.txt
date -u +'%Y-%m-%dT%H:%M:%S.%NZ' > /evidence/workload-finished.txt
exit "$result"
