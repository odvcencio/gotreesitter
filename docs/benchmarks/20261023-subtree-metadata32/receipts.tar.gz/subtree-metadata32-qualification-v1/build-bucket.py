from pathlib import Path
import collections,gzip,hashlib,io,json,subprocess,tarfile,shutil
repo=Path('/home/draco/work/gotreesitter');run=repo/'harness_out/docker/subtree-metadata32-qualification-v1';p=run/'out';focused=repo/'harness_out/docker/subtree-metadata32-v2'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert (p/'complete.txt').exists() and (p/'workload-exit-code.txt').read_text().strip()=='0'
assert json.loads((p/'source-before.json').read_text())==json.loads((p/'source-after-final.json').read_text())
counts=dict(collections.Counter(x.split('\t')[0] for x in (p/'progress.tsv').read_text().splitlines()));assert counts=={'invariant':412,'C':412,'ledger':206}
for f in (p/'counter-deltas').glob('*.json'):
 d=json.loads(f.read_text());assert d['passed'] and not d['changes'] and not d['route_metadata_changes']
for name in ['invariants','cgo']:
 logs=list((p/name).glob('*.log'));assert len(logs)==412
 for f in logs: assert '--- FAIL:' not in f.read_text() and f.read_text().rstrip().endswith('PASS')
perf=json.loads((p/'independent-analysis.json').read_text());assert perf['valid_rows_per_role']==300 and not perf['ratchet_failures'] and perf['all_timed_work_and_route_metrics_exact']
rss=json.loads((p/'rss-matched/audit.json').read_text());assert rss['candidate_safety_pass'] and len(rss['matched'])==120 and len(rss['initial'])==6
audit=json.loads((p/'container-audit.json').read_text());assert audit['state']['ExitCode']==0 and not audit['state']['OOMKilled']
review=json.loads((p/'source-review.json').read_text());patch=(p/'source.patch').read_bytes();assert sha(patch)==review['patch_sha256']
for change in review['source_changes']: assert sha((repo/change['path']).read_bytes())==change['after']
for row in (p/'cogno/status.tsv').read_text().splitlines():
 name,code=row.split('\t');s=(p/'cogno'/(name+'.log')).read_text();assert 'D8 incremental/fresh Go and incremental/fresh C agree independently:' in s
 if name.endswith('-delete'): assert code=='1' and 'Path:/source_file/function_declaration[2]/block[4]/ERROR[1] Category:shape GoValue:children=1 CValue:children=2' in s
 else: assert code=='0'
for role in ['baseline','candidate']:assert (p/(role+'-large-go-C.log')).read_text().count('warmed 1 MiB Go: exact symbols, fields, spans, points, flags, and deep digest')==6
entries={}
for root in [run,focused]:
 for f in sorted(root.rglob('*')):
  if not f.is_file() or f.suffix not in {'.json','.log','.txt','.tsv','.rss','.py','.sh','.go','.patch','.pprof'}:continue
  if any(x in f.name for x in ['private','inspect','buckley']):continue
  entries[root.name+'/'+str(f.relative_to(root))]=f.read_bytes()
manifest={n:{'bytes':len(b),'sha256':sha(b)} for n,b in entries.items()};entries['members.json']=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
out=repo/'docs/benchmarks/20261023-subtree-metadata32';out.mkdir(exist_ok=True);archive=out/'receipts.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for n,b in sorted(entries.items()):
    i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;tar.addfile(i,io.BytesIO(b))
with tarfile.open(archive) as tar:
 assert len(tar.getmembers())==len(entries)
 for m in tar.getmembers():
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  if m.name!='members.json':assert sha(tar.extractfile(m).read())==manifest[m.name]['sha256']
receipt={'status':'Not adopted: smaller hot records do not establish faster parsing; source preserved only as a reproducible experiment','source':review,'hot_record_bytes':{'before':44,'after':32,'sparse_descriptor_bytes':16},'fleet':{**counts,'standard_C_checks':1236,'edit_steps':29664,'no_edit_allocations':0,'memory_checks':20},'strict_counter_changes':[],'performance':perf,'cold_RSS':{k:v for k,v in rss.items() if k not in ['matched','initial']},'Cogno':{'report_comment_id':6311551850,'D8_checks':12,'clean_C_checks':8,'unchanged_malformed_delete_C_failures':4},'limitations':['No significant throughput improvement','Large Go allocated bytes +2.98%, p=0.007','Compared with held native-record runtime, not main','No Mac or native Windows qualification','Existing four malformed-delete C differences unchanged'],'profile_attribution':{'kind':'CPU samples, not paired throughput evidence; cumulative shares overlap','go_reductions_percent':20.06,'go_publication_percent':27.97,'yaml_reductions_percent':18.22,'yaml_publication_stream_percent':16.71},'archive':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':sha(archive.read_bytes())}}
(out/'qualification.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n');(out/'source.patch.gz').write_bytes(gzip.compress(patch,mtime=0))
for suite in ['go','compact-go','yaml']:shutil.copyfile(p/('benchstat-'+suite+'.txt'),out/('benchstat-'+suite+'.txt'))
for name in ['go-cpu-top.txt','yaml-cpu-top.txt']:shutil.copyfile(p/name,out/name)
(run/'artifact-verification.json').write_text(json.dumps({'archive_members_verified':len(entries),'all_hashes_match':True,'source_patch_sha256':sha(patch),'archive':receipt['archive']},indent=2)+'\n')
print(json.dumps(receipt['archive']))
