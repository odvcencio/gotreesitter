set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/dense-hybrid-qualification-v1
mkdir -p "$scratch"
cd /candidate
sha256sum --quiet -c /controls/dense-root-qualification/saved-source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/dense-hybrid-qualification-v1/controls.sha256 > /evidence/controls-before.log 2>&1
overlay=/controls/dense-hybrid-qualification-v1/overlay.container.json
go test -overlay="$overlay" -tags gts_workcount -run '^TestDense(Hybrid|LR)' -count=1 -v ./internal/parsercorephase0 > /evidence/core.log 2>&1
go test -c -overlay="$overlay" -tags gts_workcount,gts_parsercorephase0 -o "$scratch/root.test" . > /evidence/root-build.log 2>&1
"$scratch/root.test" -test.run '^Test(DenseHybridBatchOrdinaryEntries|DenseLRPrivateWarmScratchLifetime|DenseLRPrivateCancellationReleasesScratch)$' -test.count=1 -test.v > /evidence/lifetime.log 2>&1
for mode in off on; do
 GTS_DENSE_PRIVATE_CONTROL=$mode "$scratch/root.test" -test.run '^TestGoEntryWorkProbe$' -test.v -test.count=1 > "/evidence/entry-$mode.log" 2>&1
done
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE=$route GOTREESITTER_V1_INVARIANT_LANGUAGE=go "$scratch/root.test" -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=3m > "/evidence/invariants-go-$route.log" 2>&1
done
"$scratch/root.test" -test.run '^Test(CompactAcceptanceReferenceAndRetainedArenasStayInMemoryBudget|CompactAcceptanceComparisonWorkspaceMemoryBudget|CompactAcceptanceComparisonWorkspaceRetentionBound|RuntimeMemory.*|ParseMemory.*)$' -test.v -test.count=1 > /evidence/memory.log 2>&1
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -overlay="$overlay" -o "$scratch/cgo.test" . > /evidence/cgo-build.log 2>&1
"$scratch/cgo.test" -test.run '^Test(DensePrivateGoSourcesLockedC|GoGroupedBindingSeparatorsLockedC|GoGroupedConstSeparatorEditsMatchLockedC|GoIssue490FragmentBoundaryLockedC|GoHiddenMissingSemicolonEditsMatchLockedC|Stage6GoCompactCertification|GoCompactIncrementalExecutionParity|GoCompactNestedReuse.*)$' -test.count=1 -test.v -test.timeout=5m > /evidence/go-cgo.log 2>&1
cd /candidate
sha256sum --quiet -c /controls/dense-root-qualification/saved-source.sha256 > /evidence/source-after.log 2>&1
sha256sum --quiet -c /controls/dense-hybrid-qualification-v1/controls.sha256 > /evidence/controls-after.log 2>&1
sha256sum "$scratch/root.test" "$scratch/cgo.test" > /evidence/binary.sha256
printf 'private dense integration focused qualification completed; analyze counters and coverage before timing\n' > /evidence/completed.txt
