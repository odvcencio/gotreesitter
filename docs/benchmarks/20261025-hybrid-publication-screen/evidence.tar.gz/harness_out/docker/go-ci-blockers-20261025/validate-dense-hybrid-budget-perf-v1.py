from pathlib import Path
from collections import Counter
import hashlib,json,re,statistics,subprocess
root=Path(__file__).resolve().parent
out=root/'out/dense-hybrid-budget-perf-v1'
assert json.loads((out/'finished.json').read_text())['exit_code']==0
assert (out/'completed.txt').is_file()
for name in ['source-before.log','source-after.log','controls-before.log','controls-after.log']:
 assert (out/name).read_text()==''
reports={}
for series,stem,wanted in [
 ('go-r4','r4', ['BenchmarkCompactGraduationR4/legacy','BenchmarkCompactGraduationR4/compact']),
 ('yaml-r4','yaml', ['BenchmarkCompactGraduationR4/legacy','BenchmarkCompactGraduationR4/compact']),
 ('go-primary','primary',['BenchmarkGraduationGoSuite/Full','BenchmarkGraduationGoSuite/Edit','BenchmarkGraduationGoSuite/NoEdit'])]:
 prefix={'r4':'r4-{}-go.txt','yaml':'r4-{}-yaml.txt','primary':'primary-{}.txt'}[stem]
 samples={};orders={}
 for arm in ['before','after']:
  f=out/prefix.format(arm);text=f.read_text()
  assert text.rstrip().endswith('# status: complete'),f
  assert not re.search(r'^FAIL|--- (FAIL|SKIP):|panic:',text,re.M),f
  assert list(map(int,re.findall(r'^# completed seed: (\d+);',text,re.M)))==list(range(1,21)),f
  order=re.findall(r'^# workload order: (.*)',text,re.M)
  assert len(order)==20 and all(set(x.split(','))==set(wanted) for x in order),f
  orders[arm]=order
  by_name={x:[] for x in wanted}
  positions=re.findall(r'^# seed: (\d+); position: (\d+)',text,re.M)
  assert len(positions)==20
  for seed,pos in positions:
   expected=(1 if int(seed)%2 else 2) if arm=='before' else (2 if int(seed)%2 else 1)
   assert int(pos)==expected,(f,seed,pos)
  for line in text.splitlines():
   if not line.startswith('Benchmark'):continue
   name=line.split()[0];assert name in by_name,(f,name)
   n=re.search(r'\s(\d+)\s+([0-9.]+) ns/op',line);assert n and int(n[1])>0,(f,line)
   metrics={unit:float(value) for value,unit in re.findall(r'([0-9.]+) (ns/op|B/op|allocs/op|compact-routes/op|compact-fallbacks/op)',line)}
   assert {'ns/op','B/op','allocs/op'}<=metrics.keys()
   if series!='go-primary':
    assert metrics['compact-fallbacks/op']==0
    assert metrics['compact-routes/op']==(1 if name.endswith('/compact') else 0)
   elif name.endswith('/NoEdit'):assert metrics['B/op']==metrics['allocs/op']==0
   by_name[name].append(metrics)
  assert all(len(v)==20 for v in by_name.values()),(f,Counter({k:len(v) for k,v in by_name.items()}))
  samples[arm]=by_name
 assert orders['before']==orders['after']
 result={}
 for name in wanted:
  result[name]={}
  for metric in ['ns/op','B/op','allocs/op']:
   before=statistics.median(x[metric] for x in samples['before'][name]);after=statistics.median(x[metric] for x in samples['after'][name])
   result[name][metric]={'before':before,'after':after,'change_percent':None if before==0 else (after/before-1)*100}
 before=out/prefix.format('before');after=out/prefix.format('after')
 r=subprocess.run(['/home/draco/go/bin/benchstat',str(before),str(after)],capture_output=True,text=True)
 assert r.returncode==0,r.stderr
 (out/f'benchstat-{series}.txt').write_text(r.stdout+r.stderr)
 reports[series]=result
summary={'schema':'gts-dense-hybrid-budget-perf/v1','pairs':60,'processes':120,'seeds':list(range(1,21)),
 'benchtime':'750ms','GOMAXPROCS':1,'count_per_process':1,'route_fallbacks':0,'no_edit_allocations':0,
 'all_source_and_control_guards_passed':True,'results':reports,'private_prototype_promoted':False,'graduation_claim':False,'merges_held':True}
(out/'validated-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
