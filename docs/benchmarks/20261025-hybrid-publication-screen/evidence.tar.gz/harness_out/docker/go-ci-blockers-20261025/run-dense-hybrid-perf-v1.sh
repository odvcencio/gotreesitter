set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly -overlay=/controls/dense-hybrid-perf-v1/overlay.container.json'
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
python3 - <<'CHECK'
from pathlib import Path
import json
assert Path('/controls/out/dense-hybrid-qualification-v1/completed.txt').is_file()
r=json.loads(Path('/controls/out/dense-hybrid-qualification-v1/differential-summary.json').read_text())
assert r['receipt_differences']==[]
assert all(x['name']=='GraphLinkAdditionsProxy' and x['after']<x['before'] for x in r['differences'])
print('focused C/D8 and V3 memory/lifetime qualification present; private architecture experiment only')
CHECK
cd /candidate
sha256sum --quiet -c /controls/dense-root-qualification/saved-source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/dense-hybrid-perf-v1/controls.sha256 > /evidence/controls-before.log 2>&1
go version > /evidence/toolchain.txt
GTS_ADMISSION_REAL_CORPUS_LANGS=go bash scripts/run_randomized_benchmarks.sh --output /evidence/r4-after-go.txt --baseline-root /baseline --baseline-output /evidence/r4-before-go.txt --lock-path /evidence/benchmark.lock --bench-regex '^BenchmarkCompactGraduationR4$' --require-benchmarks BenchmarkCompactGraduationR4/legacy,BenchmarkCompactGraduationR4/compact --runs 20 --seed-start 1 --benchtime 750ms > /evidence/r4-runner-go.log 2>&1
GTS_ADMISSION_CANDIDATE=1 bash scripts/run_randomized_benchmarks.sh --output /evidence/primary-after.txt --baseline-root /baseline --baseline-output /evidence/primary-before.txt --lock-path /evidence/benchmark.lock --bench-regex '^BenchmarkGraduationGoSuite$' --require-benchmarks BenchmarkGraduationGoSuite/Full,BenchmarkGraduationGoSuite/Edit,BenchmarkGraduationGoSuite/NoEdit --runs 20 --seed-start 1 --benchtime 750ms > /evidence/primary-runner.log 2>&1
sha256sum --quiet -c /controls/dense-root-qualification/saved-source.sha256 > /evidence/source-after.log 2>&1
sha256sum --quiet -c /controls/dense-hybrid-perf-v1/controls.sha256 > /evidence/controls-after.log 2>&1
printf 'all40 shuffled pairs complete; private preliminary architecture comparison, no graduation claim\n' > /evidence/completed.txt
