#!/usr/bin/env bash
set -euo pipefail
# Parent executes inside the serialized qualification container. No execution
# was performed by the overlay author. Existing C/D8/memory controls are reused.
overlay=/controls/dense-hybrid-batch-v1/overlay.container.json
cd /candidate
# Hybrid-specific and inherited payload/history/ownership/budget proofs.
go test -overlay "$overlay" ./internal/parsercorephase0 -run '^TestDense(Hybrid|LR)' -count=1
# Actual ordinary primary + registered real R4 entry; full output/work/provenance.
go test -overlay "$overlay" -tags gts_workcount . -run '^TestDenseHybridBatchOrdinaryEntries$' -count=1 -v
# Warm retained-scratch and cancellation lifetime, zero allocation regression.
go test -overlay "$overlay" . -run '^TestDenseLRPrivate(WarmScratchLifetime|CancellationReleasesScratch)$' -count=1 -v
