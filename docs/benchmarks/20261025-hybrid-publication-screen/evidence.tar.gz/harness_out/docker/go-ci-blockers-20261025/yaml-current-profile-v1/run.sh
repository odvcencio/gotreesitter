set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-yaml-current-profile-v1
mkdir -p "$scratch"
cd /candidate
sha256sum --quiet -c /controls/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/controls.sha256 > /evidence/controls-before.log 2>&1
python3 /controls/verify.py --source-only > /evidence/input-authentication.json
go version > /evidence/toolchain.txt
go test -c -tags gts_parsercorephase0 -o "$scratch/root.test" . > /evidence/build.log 2>&1
sha256sum "$scratch/root.test" > /evidence/binary.sha256
GTS_ADMISSION_REAL_CORPUS_LANGS=yaml "$scratch/root.test" -test.run '^$' -test.bench '^BenchmarkAdmissionR4Compact$' -test.benchtime=4s -test.count=1 -test.benchmem -test.cpuprofile=/evidence/yaml.cpu.pprof -test.timeout=90s > /evidence/cpu.log 2>&1
GTS_ADMISSION_REAL_CORPUS_LANGS=yaml "$scratch/root.test" -test.run '^$' -test.bench '^BenchmarkAdmissionR4Compact$' -test.benchtime=1s -test.count=1 -test.benchmem -test.memprofilerate=1 -test.memprofile=/evidence/yaml.mem.pprof -test.timeout=90s > /evidence/allocation.log 2>&1
go tool pprof -top -nodecount=55 "$scratch/root.test" /evidence/yaml.cpu.pprof > /evidence/cpu-top.txt
go tool pprof -top -cum -nodecount=55 "$scratch/root.test" /evidence/yaml.cpu.pprof > /evidence/cpu-cum.txt
go tool pprof -alloc_objects -top -nodecount=55 "$scratch/root.test" /evidence/yaml.mem.pprof > /evidence/alloc-objects-top.txt
go tool pprof -alloc_objects -top -cum -nodecount=55 "$scratch/root.test" /evidence/yaml.mem.pprof > /evidence/alloc-objects-cum.txt
go tool pprof -alloc_space -top -nodecount=55 "$scratch/root.test" /evidence/yaml.mem.pprof > /evidence/alloc-space-top.txt
sha256sum --quiet -c /controls/source.sha256 > /evidence/source-after.log 2>&1
sha256sum --quiet -c /controls/controls.sha256 > /evidence/controls-after.log 2>&1
python3 /controls/verify.py --results /evidence > /evidence/profile-verification.json
printf 'ordinary YAML R4 attribution complete; profiler-perturbed timings are not comparison evidence\n' > /evidence/completed.txt
