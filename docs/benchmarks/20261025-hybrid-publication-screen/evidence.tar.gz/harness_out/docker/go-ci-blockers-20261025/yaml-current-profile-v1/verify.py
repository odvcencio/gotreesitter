#!/usr/bin/env python3
"""Authenticate current ordinary YAML inputs and reject incomplete profile runs."""
from pathlib import Path
import argparse,hashlib,json,re
p=argparse.ArgumentParser();p.add_argument('--source-only',action='store_true');p.add_argument('--results',type=Path)
a=p.parse_args();root=Path('/candidate')
manifest=json.loads((root/'internal/benchfixtures/real_corpus.json').read_text())
rows=[x for x in manifest['entries'] if x['language']=='yaml' and x['role']=='sample' and x['committed_path']]
assert len(rows)==1
row=rows[0];source=(root/'internal/benchfixtures'/row['committed_path']).read_bytes()
expected='5aa2c70bccfe73254f13eca40476c3f88f522c6a47aea499f9d672dbc5aae8c4'
assert row['bytes']==len(source)==1998 and row['sha256']==hashlib.sha256(source).hexdigest()==expected
assert row['session_sha256']=='df67b9f253a997043dbad449241774b38721ac88b37f1192cabb06a84ba43f87'
blob=(root/'grammars/grammar_blobs/yaml.bin').read_bytes()
assert hashlib.sha256(blob).hexdigest()=='9ac37a326be7a4f4297efa6e43ba00317c5959e7b4909c9262043d408f284b30'
out={'source_bytes':len(source),'source_sha256':expected,'session_sha256':row['session_sha256'],
     'yaml_blob_sha256':hashlib.sha256(blob).hexdigest(),
     'benchmark':'BenchmarkAdmissionR4Compact','tags':'gts_parsercorephase0',
     'ordinary_candidate':True,'experimental_node_views':False,'ownership_activation':False,
     'limits':'Attribution includes initialization/calibration/warm calls; not timing comparison or graduation evidence.'}
if not a.source_only:
 assert a.results is not None
 for name in ['source-before.log','source-after.log','controls-before.log','controls-after.log','build.log']:
  assert (a.results/name).read_bytes()==b'',name
 out['benchmark_results']={}
 for name in ['cpu.log','allocation.log']:
  text=(a.results/name).read_text()
  assert not re.search(r'(?m)^(?:--- SKIP:|--- FAIL:|FAIL|panic:)',text)
  assert text.rstrip().endswith('PASS')
  rows=[x.split() for x in text.splitlines() if x.startswith('BenchmarkAdmissionR4Compact')]
  assert len(rows)==1
  fields=rows[0];assert fields[0]=='BenchmarkAdmissionR4Compact'
  assert float(fields[fields.index('compact-routes/op')-1])==1
  assert float(fields[fields.index('compact-fallbacks/op')-1])==0
  out['benchmark_results'][name]={'iterations':int(fields[1]),'routes_per_op':1,'fallbacks_per_op':0,
   'bytes_per_op':int(fields[fields.index('B/op')-1]),'allocs_per_op':int(fields[fields.index('allocs/op')-1])}
 for name in ['yaml.cpu.pprof','yaml.mem.pprof']:
  data=(a.results/name).read_bytes();assert len(data)>0;out[name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
print(json.dumps(out,indent=2))
