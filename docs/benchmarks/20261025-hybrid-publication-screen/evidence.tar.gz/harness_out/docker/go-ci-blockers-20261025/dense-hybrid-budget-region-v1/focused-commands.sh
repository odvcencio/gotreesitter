#!/usr/bin/env bash
set -euo pipefail
# Parent executes only after the current final gate releases the shared lock.
# This file was syntax checked; no build/test/Docker execution by author.
overlay=/controls/dense-hybrid-budget-region-v1/overlay.container.json
cd /candidate
# Exact corrected census at every existing check: growth, current/retired
# packed+small pages, aliases, unused capacity, thresholds, callback mutation,
# dynamic-provider fallback and panic/error/cancellation lifetime.
go test -overlay "$overlay" -tags gts_parsercorephase0 . -run '^(TestDensePromotionBudgetRegion|TestPackedSnapshotBudget)' -count=1 -v
# Actual primary/R4 entry includes full output/work/provenance differential,
# and proves region diagnostics ran rather than silently abstaining.
go test -overlay "$overlay" -tags gts_workcount . -run '^TestDensePromotionBudgetRegionOrdinaryEntries$' -count=1 -v
# Frozen hybrid controls: root reuses its existing strict C/D8/memory commands.
go test -overlay "$overlay" ./internal/parsercorephase0 -run '^TestDense(Hybrid|LR)' -count=1
go test -overlay "$overlay" . -run '^TestDenseLRPrivate(WarmScratchLifetime|CancellationReleasesScratch)$' -count=1 -v
