set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/dense-hybrid-budget-qualification-v1/controls.sha256 > /evidence/inherited-controls-before.log 2>&1
sha256sum --quiet -c /controls/dense-hybrid-yaml-attribution-v1/controls.sha256 > /evidence/controls-before.log 2>&1
go test -overlay=/controls/dense-hybrid-yaml-attribution-v1/overlay.container.json -tags gts_workcount,gts_parsercorephase0 -run '^TestDenseHybridYAMLAttribution$' -count=1 -v -timeout=3m . > /evidence/yaml-attribution.log 2>&1
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1
sha256sum --quiet -c /controls/dense-hybrid-yaml-attribution-v1/controls.sha256 > /evidence/controls-after.log 2>&1
