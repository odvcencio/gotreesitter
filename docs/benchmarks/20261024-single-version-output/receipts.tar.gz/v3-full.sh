set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOFLAGS='-p=1 -mod=readonly -overlay=/controls/v3-overlay.json' GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/exit.txt; date -u +%FT%TZ > /evidence/finished.txt' EXIT
[[ -f /qualification/complete.txt ]] || { echo 'qualification incomplete' > /evidence/blocked.txt; exit 2; }
date -u +%FT%TZ > /evidence/started.txt
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
go test -tags gts_parsercorephase0a,gts_eof_recovery_shadow ./internal/parsercorephase0 -count=1 -timeout=6m > /evidence/core-shadow.log 2>&1
for lang in go yaml; do
 GTS_COMPARE_LANGUAGE="$lang" go test -overlay=/controls/v3-census-overlay.json -tags gts_parsercorephase0 -run '^TestSingleVersionCensus$' -count=1 -v . > "/evidence/$lang-census.log" 2>&1
 if [[ "$lang" == go ]]; then fixture=grammargen_lr_parse; else fixture=eof8k_parse; fi
 GTS_COMPARE_LANGUAGE="$lang" GTS_BENCHMARK_SEED=1 go test -tags gts_parsercorephase0 -run '^$' -bench "^BenchmarkSingleVersionOutput$/^$fixture$" -benchtime=8s -count=1 -cpuprofile "/evidence/$lang.cpu" -o /evidence/profile.test . > "/evidence/$lang-profile.log" 2>&1
 go tool pprof -top -nodecount=45 /evidence/profile.test "/evidence/$lang.cpu" > "/evidence/$lang-profile-top.txt" 2>&1
done
cd /candidate/cgo_harness
go test -overlay=/controls/v3-large-overlay.json -tags treesitter_c_parity,gts_parsercorephase0 -run '^TestWarmCapacityLargeGoLockedC$' -v -count=1 -timeout=5m . > /evidence/large-Go-C.log 2>&1
mkdir /evidence/cogno
go test -c -overlay=/controls/v3-cogno-overlay.json -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/cogno.test . > /evidence/cogno/build.log 2>&1
for route in production candidate; do
 for api in plain profiled; do
  for edit in insert replace delete; do
   label="$route-$api-$edit"
   if /evidence/cogno.test -test.run "^TestGoCognociente137KiBTopEditLockedC$/^$route$/^$api$/^$edit$" -test.v -test.count=1 -test.timeout=5m > "/evidence/cogno/$label.log" 2>&1; then code=0; else code=$?; fi
   printf '%s\t%s\n' "$label" "$code" >> /evidence/cogno/status.tsv
   if [[ "$edit" != delete && "$code" != 0 ]]; then exit "$code"; fi
  done
 done
done
cd /candidate
for lang in go yaml; do
 GOFLAGS='-p=1 -mod=readonly -overlay=/controls/v3-public-overlay.json' GTS_COMPARE_LANGUAGE="$lang" bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output "/evidence/baseline-$lang.txt" --output "/evidence/public-$lang.txt" --runs 20 --seed-start 248001 --benchtime 750ms --bench-regex '^BenchmarkSingleVersionOutput$' --lock-path /evidence/perf.lock > "/evidence/$lang-perf-driver.log" 2>&1
done
GOFLAGS='-p=1 -mod=readonly -overlay=/controls/v3-large-perf-overlay.json' GTS_COMPARE_LANGUAGE=go bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-direct-large.txt --output /evidence/candidate-direct-large.txt --lock-path /evidence/perf.lock --runs 20 --seed-start 252001 --benchtime 750ms --bench-regex '^BenchmarkSingleVersionOutput$' > /evidence/direct-large-driver.log 2>&1
cp /controls/benchmark_primary_overlay.go.txt /evidence/prepare-primary.go
go run /evidence/prepare-primary.go /controls/benchmark_primary_go_suite.go.txt /evidence/primary-overlay.json /baseline /candidate > /evidence/primary-hashes.txt
python3 - <<'PY'
from pathlib import Path
import json
p=Path('/evidence/primary-overlay.json');d=json.loads(p.read_text());d['Replace'].update(json.loads(Path('/controls/v3-overlay.json').read_text())['Replace']);p.write_text(json.dumps(d,indent=2)+'\n')
PY
GOFLAGS='-p=1 -mod=readonly -overlay=/evidence/primary-overlay.json' bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-primary.txt --output /evidence/candidate-primary.txt --runs 20 --seed-start 249001 --benchtime 750ms --bench-regex '^BenchmarkGTSSeededPrimary$' --require-benchmarks 'BenchmarkGTSSeededPrimary/BenchmarkGoParseFullDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalNoEditDFA' --lock-path /evidence/perf.lock > /evidence/primary-driver.log 2>&1
GOFLAGS='-p=1 -mod=readonly -overlay=/controls/v3-throughput-overlay.json' GTS_ADMISSION_CANDIDATE=1 bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-compact-primary.txt --output /evidence/candidate-compact-primary.txt --lock-path /evidence/perf.lock --runs 20 --seed-start 250001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputGo$' --require-benchmarks 'BenchmarkCompactThroughputGo/full_dfa,BenchmarkCompactThroughputGo/single_byte_edit_dfa,BenchmarkCompactThroughputGo/no_edit_dfa,BenchmarkCompactThroughputGo/fresh_one_mib,BenchmarkCompactThroughputGo/query_compile,BenchmarkCompactThroughputGo/grammargen_lr' > /evidence/compact-primary-driver.log 2>&1
GOFLAGS='-p=1 -mod=readonly -overlay=/controls/v3-overlay.json' bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-yaml-route.txt --output /evidence/candidate-yaml-route.txt --lock-path /evidence/perf.lock --runs 20 --seed-start 251001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputYAML$' > /evidence/yaml-route-driver.log 2>&1
for role in baseline candidate; do
 cd "/$role"
 go test -c -overlay=/controls/v3-throughput-overlay.json -tags gts_parsercorephase0 -o "/evidence/$role-rss.test" . > "/evidence/$role-rss-build.log" 2>&1
 GTS_ADMISSION_CANDIDATE=1 GTS_BENCHMARK_SEED=1 /usr/bin/time -v -o "/evidence/$role-one-mib-rss.txt" "/evidence/$role-rss.test" -test.run '^$' -test.bench '^BenchmarkCompactThroughputGo$/^fresh_one_mib$' -test.benchtime=1x -test.count=1 -test.benchmem > "/evidence/$role-one-mib-rss.log" 2>&1
done
printf 'complete\n' > /evidence/complete.txt
