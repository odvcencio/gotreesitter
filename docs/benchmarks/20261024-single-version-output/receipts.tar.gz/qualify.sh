set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOFLAGS='-p=1 -mod=readonly -overlay=/controls/source-overlay.json' GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/exit.txt; date -u +%FT%TZ > /evidence/finished.txt' EXIT
date -u +%FT%TZ > /evidence/started.txt
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
for role in baseline candidate; do
 cd "/$role"
 go test ./internal/parsercorephase0 -count=1 -timeout=6m > "/evidence/$role-core.log" 2>&1
 go test -c -tags gts_parsercorephase0 -o "/evidence/$role.test" . > "/evidence/$role-build.log" 2>&1
 "/evidence/$role.test" -test.run '^Test(SingleVersion.*|ParserCoreFreshFull.*|.*Corridor.*|CompactReuseDependency.*|CompactLegacyRead.*|NativeProjection.*)$' -test.count=1 -test.v -test.timeout=8m > "/evidence/$role-root.log" 2>&1
 go test -c -overlay=/controls/work-overlay.json -tags gts_parsercorephase0,gts_workcount -o "/evidence/$role-work.test" . > "/evidence/$role-work-build.log" 2>&1
 cd "/$role/cgo_harness"
 go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o "/evidence/$role-cgo.test" . > "/evidence/$role-cgo-build.log" 2>&1
 for lang in go yaml; do
  GTS_ADMISSION_CANDIDATE=1 GTS_PARITY_MODE=exhaustive "/evidence/$role-cgo.test" -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${lang}$" -test.count=1 -test.v -test.timeout=5m > "/evidence/$role-C-$lang.log" 2>&1
  cd "/$role"
  GTS_ADMISSION_CANDIDATE=1 GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" "/evidence/$role.test" -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/$role-invariant-$lang.log" 2>&1
  GTS_WORK_LANGUAGE="$lang" "/evidence/$role-work.test" -test.run '^TestDirectReductionWork$' -test.count=1 -test.v -test.timeout=5m > "/evidence/$role-work-$lang.log" 2>&1
  cd "/$role/cgo_harness"
 done
done
python3 - <<'PY'
from pathlib import Path
import json
p=Path('/evidence');d={}
for role in ['baseline','candidate']:
 d[role]={}
 for lang in ['go','yaml']:
  for line in (p/(role+'-work-'+lang+'.log')).read_text().splitlines():
   if line.startswith('WORK '):
    r=json.loads(line[5:]);d[role][(r['Language'],r['Route'],r['Phase'])]=r['Counts']
assert len(d['baseline'])==8 and d['baseline']==d['candidate'],d
(p/'work-gate.json').write_text(json.dumps({'rows':8,'changes':[]},indent=2)+'\n')
PY
cd /candidate
for lang in go yaml; do
 GTS_COMPARE_LANGUAGE="$lang" bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output "/evidence/baseline-$lang.txt" --output "/evidence/compact-$lang.txt" --runs 20 --seed-start 244001 --benchtime 750ms --bench-regex '^BenchmarkSingleVersionOutput$' --lock-path /evidence/perf.lock > "/evidence/$lang-perf-driver.log" 2>&1
done
printf 'complete\n' > /evidence/complete.txt
