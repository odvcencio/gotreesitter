set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOFLAGS='-p=1 -mod=readonly' GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/final-exit.txt' EXIT
cd /candidate
git config --global --add safe.directory /candidate
go test ./internal/parsercorephase0 -run 'Test(NativeSelectedOutput|SingleVersion|DirectReduction)' -count=1 -v -timeout=5m > /evidence/final-core.log 2>&1
go test -tags gts_parsercorephase0 -run '^TestSingleVersion' -count=1 -v -timeout=5m . > /evidence/final-root.log 2>&1
go test -tags gts_no_parsercorephase0 -run '^TestNodeLayoutSizeBudget$' -count=1 -timeout=5m . > /evidence/final-no-core-build.log 2>&1
