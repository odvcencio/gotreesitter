from pathlib import Path
import json,re,hashlib,subprocess
p=Path(__file__).resolve().parent;q=p/'v3-full'
assert (q/'complete.txt').exists() and (q/'resume-exit.txt').read_text().strip()=='0'
assert (q/'final-exit.txt').read_text().strip()=='0'
statuses=[line.split('\t') for line in (q/'cogno/status.tsv').read_text().splitlines()];assert len(statuses)==12
for label,status in statuses:
 text=(q/'cogno'/(label+'.log')).read_text();assert 'D8 incremental/fresh Go and incremental/fresh C agree independently' in text
 if label.endswith('-delete'):assert status=='1' and 'Category:shape GoValue:children=1 CValue:children=2' in text
 else:assert status=='0' and '\nPASS\n' in text
large=(q/'large-Go-C.log').read_text();assert large.count('warmed 1 MiB Go: exact symbols, fields, spans, points, flags, and deep digest')==6 and '\nPASS\n' in large
rss={}
for role in ['baseline','candidate']:
 text=(q/(role+'-one-mib-rss.txt')).read_text();m=re.search(r'Maximum resident set size \(kbytes\): (\d+)',text);assert m and 'Exit status: 0' in text;rss[role]=int(m[1])
source=json.loads((p/'qualified-source.json').read_text())
for row in source['files']:assert hashlib.sha256(Path(row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
result={'baseline':'64e22ad72e99a817d6e75c1e6ccd849ede4ec6ef','candidate':'source manifest; Buckley commit follows','scope':'branch-relative qualification; all merges held','runtime_files_match_frozen':True,'correctness':json.loads((p/'correctness-analysis.json').read_text())['v3'],'cognociente':{'report':'https://github.com/odvcencio/gotreesitter/issues/454#issuecomment-6311551850','independent_D8_agreements':12,'clean_C_agreements':8,'known_delete_C_shape_failures':4,'fixed':False},'large_Go_C_checks':6,'large_Go_source_sha256':'76c70b62127085d3c791ba98a24cba9f22bd343e40afb43522bbb5041cede524','large_Go_RSS_smoke_KiB':rss,'RSS_limit':'one bounded process per role, not a 20-pair RSS ratchet or graduation receipt','direct_output_scope':'internal read-only SelectedStore; clean supported output; not public Node/incremental contract or final D4 SoA','no_native_C_speed_or_ARM64_claim':True,'main_merge':False,'graduation':False}
(p/'qualification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
