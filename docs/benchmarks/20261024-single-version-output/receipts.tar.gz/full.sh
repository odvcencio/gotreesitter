set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOFLAGS='-p=1 -mod=readonly -overlay=/controls/full-overlay.json' GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/exit.txt; date -u +%FT%TZ > /evidence/finished.txt' EXIT
[[ -f /qualification/complete.txt ]] || { echo 'first qualification incomplete' > /evidence/blocked.txt; exit 2; }
date -u +%FT%TZ > /evidence/started.txt
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
go test ./internal/parsercorephase0 -run 'Test(NativeSelectedOutput|SingleVersion|DirectReduction)' -count=1 -v -timeout=5m > /evidence/new-core.log 2>&1
for lang in go yaml; do
 if [[ "$lang" == go ]]; then fixture=grammargen_lr_parse; else fixture=eof8k_parse; fi
 GTS_COMPARE_LANGUAGE="$lang" GTS_BENCHMARK_SEED=1 go test -tags gts_parsercorephase0 -run '^$' -bench "^BenchmarkSingleVersionOutput$/^$fixture$" -benchtime=8s -count=1 -cpuprofile "/evidence/$lang.cpu" -o /evidence/profile.test . > "/evidence/$lang-profile.log" 2>&1
 go tool pprof -top -nodecount=45 /evidence/profile.test "/evidence/$lang.cpu" > "/evidence/$lang-profile-top.txt" 2>&1
done
go test -race ./internal/parsercorephase0 -count=1 -timeout=8m > /evidence/core-race.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -count=1 -timeout=6m > /evidence/core-386.log 2>&1
go test -tags gts_parsercorephase0a,gts_eof_recovery_shadow ./internal/parsercorephase0 -count=1 -timeout=6m > /evidence/core-shadow.log 2>&1
go test -race -tags gts_parsercorephase0 -run '^Test(SingleVersion.*|NativeProjection.*|CompactReuseDependency.*|CompactLegacyRead.*)$' -count=1 -timeout=8m . > /evidence/root-race.log 2>&1
/qualification/candidate.test -test.run '^Test(CompactAcceptance(ChangedSourceKeepsRebuildBudget|CachedPublicationStopControl)|CompactMemoryBudgetDetectsGrowthAfterSmallPoll|CompactAcceptance.*(MemoryBudget|RetentionBound)|CompactArenaReserve.*(Budget|RetentionCap)|CompactExternalScannerCheckpointCopyMemoryBudget|CompactRecoveryMemoMemoryBudget|CompactBorrowedMaterializationProjectionMemoryBudget|G18RefSetSchedulerMemoryBudgetAccounting|RuntimeMemoryBudget.*|RuntimeMemoryHardCeilingStillStopsParse|ParseMemoryHardCeiling.*)$' -test.count=1 -test.v -test.timeout=8m > /evidence/memory.log 2>&1
for role in baseline candidate; do
 cd "/$role"
 go build -tags gts_parsercorephase0 -o "/evidence/$role-ledger" ./cmd/perfcounterledger > "/evidence/$role-ledger-build.log" 2>&1
done
mkdir -p /evidence/invariants /evidence/cgo /evidence/work /evidence/ledger /evidence/counter-deltas
while IFS= read -r lang; do
 cd /candidate
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /qualification/candidate.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/invariants/$route-$lang.log" 2>&1
 done
 cd /candidate/cgo_harness
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GTS_PARITY_MODE=exhaustive /qualification/candidate-cgo.test -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${lang}$" -test.count=1 -test.v -test.timeout=5m > "/evidence/cgo/$route-$lang.log" 2>&1
 done
 for role in baseline candidate; do
  cd "/$role"
  GTS_WORK_LANGUAGE="$lang" "/qualification/$role-work.test" -test.run '^TestDirectReductionWork$' -test.count=1 -test.timeout=5m > "/evidence/work/$role-$lang.log" 2>&1
 done
 /evidence/baseline-ledger --langs "$lang" > "/evidence/ledger/baseline-$lang.json" 2> "/evidence/ledger/baseline-$lang.log"
 /evidence/candidate-ledger --langs "$lang" > "/evidence/ledger/candidate-$lang.json" 2> "/evidence/ledger/candidate-$lang.log"
 python3 /controls/compare-ledger.py "/evidence/ledger/baseline-$lang.json" "/evidence/ledger/candidate-$lang.json" "/evidence/counter-deltas/$lang.json" > "/evidence/counter-deltas/$lang.log"
 printf '%s\n' "$lang" >> /evidence/progress.txt
done < /controls/languages.txt
python3 /controls/compare-work.py > /evidence/work-comparison.log
cd /candidate/cgo_harness
GTS_YAML_LARGE_PROBE=1 /qualification/candidate-cgo.test -test.run '^Test(YAMLOwnedGrammarLockedCParity|CompactYAMLDocumentStreamLockedC|YAMLRecoveredMappingQuotesLockedC|YAMLEOFRecoverWrapCompactRoute|YAMLEOFRecoverWrapUnfinishedMappingDeclinesCompact|YAMLOneBytePrintableEOFAdmissionMatchesLockedC)$' -test.count=1 -test.v -test.timeout=8m > /evidence/yaml-focused-C.log 2>&1
go test -overlay=/controls/large-overlay.json -tags treesitter_c_parity,gts_parsercorephase0 -run '^TestWarmCapacityLargeGoLockedC$' -v -count=1 -timeout=5m . > /evidence/large-Go-C.log 2>&1
mkdir /evidence/cogno
go test -c -overlay=/controls/cogno-overlay.json -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/cogno.test . > /evidence/cogno/build.log 2>&1
for route in production candidate; do
 for api in plain profiled; do
  for edit in insert replace delete; do
   label="$route-$api-$edit"
   if /evidence/cogno.test -test.run "^TestGoCognociente137KiBTopEditLockedC$/^$route$/^$api$/^$edit$" -test.v -test.count=1 -test.timeout=5m > "/evidence/cogno/$label.log" 2>&1; then code=0; else code=$?; fi
   printf '%s\t%s\n' "$label" "$code" >> /evidence/cogno/status.tsv
   if [[ "$edit" != delete && "$code" != 0 ]]; then exit "$code"; fi
  done
 done
done
cd /candidate
for lang in go yaml; do
 GOFLAGS='-p=1 -mod=readonly -overlay=/controls/public-overlay.json' GTS_COMPARE_LANGUAGE="$lang" bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output "/evidence/baseline-$lang.txt" --output "/evidence/public-$lang.txt" --runs 20 --seed-start 245001 --benchtime 750ms --bench-regex '^BenchmarkSingleVersionOutput$' --lock-path /evidence/perf.lock > "/evidence/$lang-perf-driver.log" 2>&1
done
cp /controls/benchmark_primary_overlay.go.txt /evidence/prepare-primary.go
go run /evidence/prepare-primary.go /controls/benchmark_primary_go_suite.go.txt /evidence/primary-overlay.json /baseline /candidate > /evidence/primary-hashes.txt
python3 - <<'PY'
from pathlib import Path
import json
p=Path('/evidence/primary-overlay.json');d=json.loads(p.read_text());d['Replace'].update(json.loads(Path('/controls/full-overlay.json').read_text())['Replace']);p.write_text(json.dumps(d,indent=2)+'\n')
PY
GOFLAGS='-p=1 -mod=readonly -overlay=/evidence/primary-overlay.json' bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-primary.txt --output /evidence/candidate-primary.txt --runs 20 --seed-start 246001 --benchtime 750ms --bench-regex '^BenchmarkGTSSeededPrimary$' --require-benchmarks 'BenchmarkGTSSeededPrimary/BenchmarkGoParseFullDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalNoEditDFA' --lock-path /evidence/perf.lock > /evidence/primary-driver.log 2>&1
printf 'complete\n' > /evidence/complete.txt
