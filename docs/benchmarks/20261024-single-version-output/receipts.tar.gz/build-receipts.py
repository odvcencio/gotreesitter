from pathlib import Path
import hashlib,json,tarfile
p=Path(__file__).resolve().parent
out=Path('/home/draco/work/gotreesitter/docs/benchmarks/20261024-single-version-output')
assert (p/'v3-full/complete.txt').exists()
assert (p/'v3-full/resume-exit.txt').read_text().strip()=='0'
assert (p/'performance-analysis.json').exists()
files=[]
for f in sorted(p.rglob('*')):
 if not f.is_file() or '__pycache__' in f.parts:continue
 if f.name.endswith('.test') or f.name in ['baseline-ledger','candidate-ledger']:continue
 if f.name in ['receipt-manifest.json']:continue
 if f.stat().st_size and f.read_bytes()[:4]==b'\x7fELF':continue
 files.append(f)
manifest={str(f.relative_to(p)):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in files}
(p/'receipt-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'receipts.tar.gz','w:gz') as tar:
 for f in files+[p/'receipt-manifest.json']:tar.add(f,arcname=str(f.relative_to(p)),recursive=False)
for name in ['performance-analysis.json','correctness-analysis.json','qualification.json','qualified-source.json']:
 (out/name).write_bytes((p/name).read_bytes())
for f in (p/'v3-full').glob('benchstat-v3-*.txt'):(out/f.name).write_bytes(f.read_bytes())
for f in (p/'v3').glob('benchstat-v3-*.txt'):(out/f.name).write_bytes(f.read_bytes())
print(json.dumps({'files':len(files),'archive_bytes':(out/'receipts.tar.gz').stat().st_size,'archive_sha256':hashlib.sha256((out/'receipts.tar.gz').read_bytes()).hexdigest()}))
