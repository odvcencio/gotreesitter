Compact parsing currently pays for wide graph storage, duplicate publication buffers, and hidden nodes that never reach the public tree. This draft installs the measured runtime snapshot that narrows graph/checkpoint storage, admits the ordinary-YAML ownership path, and streams native publication for supported projections. Publication now fuses projection, replay progress, and raw byte-coverage validation into one traversal. Unsupported field projections and actual recovery keep their reference publisher. Field/alias identity, scanner checkpoints, rollback, and memory accounting remain checked.

### Direct reduction experiment: not promoted

Buckley committed the [direct-reduction screen and native C comparison](https://github.com/odvcencio/gotreesitter/blob/64e22ad72e99a817d6e75c1e6ccd849ede4ec6ef/docs/benchmarks/20261024-direct-reduction-screen/README.md) at `64e22ad72e99a817d6e75c1e6ccd849ede4ec6ef`. The six-file runtime prototype is removed: its 20-pair gains—Go full DFA 6.03%, 1 MiB 3.41%, real Go files under 2%, ordinary YAML 2.46–2.98%—do not meet the requested larger architectural target. All 824 complete-operation counter rows and 206 selected ledgers are unchanged; 412 invariant sessions, 1,236 standard C checks, focused races/386 and 20 memory contracts pass. No new RSS or platform qualification is claimed for this unpromoted patch.

Twenty Go-C-C-Go cycles per language measure the archived candidate at 2.929–2.937× native C parse time on two real Go files and 1.984–2.076× on YAML R4/EOF8k. Native C runs parsing and cursor traversal without per-node cgo calls. This is a diagnostic against locked C 0.25.1, not the standalone-static graduation protocol or a claim about the restored runtime. Disjoint profiles identify construction/publication and output representation as the combined target; no larger speedup is claimed.

The known Cognociente malformed-delete failure also reproduces in 31 bytes: Go emits one error run for `:=`, whereas C emits `:` then `=`. Four reduced C checks remain failed. No ledger exception, allowlist change, runtime promotion or main merge is authorized by this bucket.


The foundational native-record runtime at `154bac17b2ef3511237f5ec74943a04058532dd6` is byte-identical to the qualified `native-record-receipts-v2` snapshot across all 3,559 Go files and module files. See the [source-equivalence receipt](docs/benchmarks/20261023-native-record-receipts/runtime-source.md). Current head adds qualified fused publication and the native receipt change described below. The page-reservation and 32-byte subtree experiments remain archived patches and are not installed.

### Latest qualified runtime change

Buckley committed and pushed one-pass native reuse receipt publication at `6d6ead01873d54d8cda839947e04b387474190ca`. Native publication now saves each original symbol when its incoming field slot is consumed, then combines alias authentication, geometry checks, and lookahead publication in one arena-ordered walk. Exact address and slot checks reject duplicate, reordered, or foreign records before exposing the tree. Receipt words are addressed directly instead of searching arena slabs for every node. This removes four full record scans from the normal native receipt path without adding persistent storage; the generic publisher keeps its duplicate-projection checks.

The [pinned qualification](https://github.com/odvcencio/gotreesitter/blob/6fe1f7c1a05af777223024d96d960007f8bd7fd3/docs/benchmarks/20261023-native-receipt-publication/README.md) compares against fused publication at `aced544fc3027e33e5486631846fd232ec10f406`. Twenty matched, alternating pairs on Linux amd64 establish:

| Workload | Before | After | Parse-time change |
| --- | ---: | ---: | ---: |
| Compact Go fresh 1 MiB | 850.8 ms | 785.4 ms | **−7.68%, p<.001** |
| Compact Go LR | 117.6 ms | 112.9 ms | **−4.02%, p=.028** |

Other timing comparisons, including all YAML cases, remain inconclusive. Primary Go edit has a **+7.29% median** (p=.081), compact no-edit +4.85% (p=.337), and ordinary YAML EOF +1.18% (p=.414). The complete tables retain these directional regressions. No allocation comparison establishes a change, no-edit reparses stay at 0 B/op and 0 allocations, and all 10% median ratchets pass. This qualifies the large-Go/LR improvement, not a YAML or main-based speed claim.

Buckley committed and pushed the completed **Linux ARM64 qualification on Mac** at `6fe1f7c1a05af777223024d96d960007f8bd7fd3`. It authenticates the same baseline and candidate source as amd64, including all 3,566 candidate Go files at the runtime commit. Twenty matched, alternating pairs per suite establish:

| Linux ARM64 workload | Before | After | Parse-time change |
| --- | ---: | ---: | ---: |
| Compact Go fresh 1 MiB | 1.171 s | 1.139 s | **−2.74%, p=.024** |
| Compact Go query source | 17.89 ms | 17.27 ms | **−3.46%, p=.001** |
| Compact Go LR source | 184.2 ms | 177.2 ms | **−3.80%, p=.003** |

Other ARM64 timing comparisons, including all YAML and the primary Go trio, remain inconclusive. Directional increases remain in the complete tables: primary Go edit +0.21%, compact edit +0.06%, ordinary YAML R4 +0.24% / EOF +0.13%, and legacy YAML R4 +0.79% / EOF +0.52%. No allocation comparison establishes a change; no-edit remains 0 B/op and 0 allocations. All timed work/routing metrics are exact and all 10% median ratchets pass.

Before ARM64 timing, core/receipt-storage units, 42 focused root tests, four Go/YAML invariant sessions / 288 edit steps, 20 memory checks, and exact Go/YAML ledgers pass. All 300 rows per role, controls, source overlays, and audit receipts are preserved in the pinned qualification. Source hashes stay unchanged; the container exits zero without OOM and is removed after audit. ARM64 does not rerun locked-C, race, 386, or RSS checks; the separate source-identical amd64 evidence follows. This is Linux ARM64 in Docker, not native Darwin, and establishes no YAML throughput gain.

On Linux amd64, all **206 work/reuse/routing ledgers are exact**: Go R4 public nodes 893→893, large Go 593,457→593,457, YAML R4 232→232, and EOF 925→925. No counter exception is required. The candidate passes 412 invariant sessions / 29,664 edit steps, 1,236 standard C checks, 12 large-Go C comparisons, YAML ownership/EOF probes, 20 memory checks, core/root races, actual 386 execution, and receipt-storage units/race/386 checks. All 126 cold-RSS probes pass; median changes are Go +0.35%, ordinary YAML +0.29%, and owned YAML +0.09%. Source hashes remain identical at completion and the container exits zero without OOM.

The latest Cognociente comment was rechecked: its exact witness still has 12 independent incremental/fresh agreements, eight clean C agreements, and the same four unresolved malformed-delete shape failures. This is not its full Windows matrix. Native Windows and Darwin qualification remain outstanding for this change. All existing merge and graduation holds remain.

### Earlier qualified fused publication

Buckley committed and pushed fused native publication at `b1da13a57d0e60ff8e25b79a7667f3538abd49df`. It replaces four traversal arrays with one frame stack, checks raw byte coverage during the existing walk, and avoids filling full materialization views for nonterminal nodes that do not need them. Ownership, replay, fields, aliases, scanner provenance, stop controls, and memory accounting remain checked.

The [complete pinned evidence](https://github.com/odvcencio/gotreesitter/blob/2cfe957d717cb34169677ab516d836fa37db04fb/docs/benchmarks/20261023-native-fused-publication/README.md) compares with frozen native-record-receipts-v2, not main or C. Twenty matched, alternating pairs on **Linux ARM64 in Mac Docker** establish these parse-time improvements:

| Workload | Before | After | Change |
| --- | ---: | ---: | ---: |
| Compact Go full DFA | 17.21 ms | 16.29 ms | −5.35%, p=.030 |
| Compact Go fresh 1 MiB | 1.178 s | 1.129 s | −4.12%, p=.003 |
| Compact Go query source | 17.72 ms | 16.97 ms | −4.24%, p=.001 |
| Ordinary YAML R4 | 383.5 µs | 367.5 µs | −4.17%, p<.001 |
| Ordinary YAML 8 KiB EOF | 1.434 ms | 1.369 ms | −4.54%, p<.001 |

Owned-lexer YAML improves 2.48–2.53% on ARM64; ARM64 LR and edit timings remain inconclusive. The initial Linux amd64 timing batch is inconclusive and remains archived in full. One separately declared confirmation batch on unchanged source, with 20 new matched pairs per suite, establishes:

| Linux amd64 confirmation workload | Before | After | Change |
| --- | ---: | ---: | ---: |
| Compact Go full DFA | 10.040 ms | 9.803 ms | −2.36%, p=.017 |
| Compact Go fresh 1 MiB | 848.6 ms | 804.8 ms | −5.16%, p=.001 |
| Compact Go query source | 10.97 ms | 10.72 ms | −2.26%, p=.001 |
| Compact Go LR source | 115.3 ms | 113.4 ms | −1.63%, p=.017 |
| Ordinary YAML R4 | 237.8 µs | 229.9 µs | −3.34%, p=.024 |
| Ordinary YAML 8 KiB EOF | 881.8 µs | 860.9 µs | −2.37%, p=.007 |

The Linux confirmation's primary Go trio, compact edit cases, owned YAML, and legacy controls remain inconclusive. Fresh 1 MiB Go allocations fall 875→848 (−3.09%, p=.039). LR allocated bytes rise **0.48% on both architectures**, with unchanged LR allocation counts; all median ratchets pass. Every timed work/route metric remains exact. The confirmation authenticates and reuses the completed source-identical correctness and counter receipts before timing, checks source hashes again on completion, and exits zero without OOM. Initial and confirmation samples remain separate. The full tables retain every directional change and control.

All **206 work/reuse/routing ledgers remain exact**. Go R4 public nodes stay 893→893; large Go 593,457→593,457; YAML R4 232→232 and EOF 925→925. No-edit reparses remain 0 B/op and 0 allocations. Linux passes 412 invariant sessions / 29,664 edit steps, 1,236 standard C checks, 12 large-Go C comparisons, YAML ownership/EOF probes, 20 memory checks, focused races, actual 386 execution, and all 126 cold-RSS probes. ARM64 adds core/publication units, four Go/YAML invariant sessions, 20 memory checks, and exact Go/YAML ledgers. Both platforms authenticate identical effective source and unchanged completion hashes, exit zero, and report no OOM. ARM64 is not native Darwin qualification.

### Earlier runtime evidence

The latest [buffer-removal qualification](docs/benchmarks/20261023-native-record-receipts/README.md) compares against the preceding [native-publication prototype](docs/benchmarks/20261023-quiescent-native-publication/README.md), not main. It passes 412 invariant sessions / 29,664 edit steps, 1,236 standard locked-C checks, 12 large-Go C checks, 20 memory checks, focused race checks, actual 386 execution, and adversarial receipt tests. No-edit allocations stay zero. All 206 before/after ledgers and every timed work/reuse/route metric remain exact.

| Public-node work | Before | After | Comparison |
| --- | ---: | ---: | --- |
| Go candidate full, R4 | 1,251 | 893 | native publication |
| Go candidate full, 1 MiB | 903,086 | 593,457 | native publication |
| Go candidate full, R4 | 893 | 893 | buffer removal |
| Go candidate full, 1 MiB | 593,457 | 593,457 | buffer removal |
| Go forced legacy, 1 MiB | 993,391 | 993,391 | both deltas |

Native publication decreases 58 candidate-full node rows; every edit, reuse and default row is unchanged in that comparison. [Complete changed rows](docs/benchmarks/20261023-quiescent-native-publication/qualification.json) and the [earlier ordinary-YAML counter comparison](docs/benchmarks/20261023-ordinary-yaml-link16/README.md) retain the cumulative history. No counter exception is added here.

Buffer removal completes 20 shuffled, matched, alternating pairs per suite using the repository runner, GOMAXPROCS=1, count=1, 750 ms and benchmem. Compact full DFA falls from 819,960 to 429,568 B/op and 71 to 36 allocations. LR falls from 3,715,744 to 2,675,360 B/op; its time improves 4.08% (p=.030). Other timing changes are inconclusive under substantial unrelated host load, including primary Go full +7.20% and ordinary YAML EOF +2.95%. This establishes an allocation improvement, not a general throughput gain. All 300 rows per role are retained.

Twenty matched cold-RSS pairs per fixture give Go −2.81%, ordinary YAML −1.19%, and owned YAML −1.04%; all 126 cold probes pass the 400-byte/source-byte ceiling. Cold results do not clear the warmed forced-legacy Go RSS failure.

### Merge and graduation holds

The combined runtime has not passed main-based throughput and allocation qualification. Earlier Go LR/large-file allocation regressions and ordinary-YAML throughput gaps remain. The existing warmed forced-legacy Go absolute RSS failure remains. Native Windows and macOS have not qualified this snapshot. Latest-head CI remains required before merging. Keep this PR draft; no language graduates here.

The exact Go witness from the [latest Cognociente report](https://github.com/odvcencio/gotreesitter/issues/454#issuecomment-6311551850) still passes all 12 independent incremental/fresh checks and eight clean C comparisons. Four malformed-delete C shape failures remain at `/source_file/function_declaration[2]/block[4]/ERROR[1]`: Go has one child, C has two. They are unresolved correctness failures, not exemptions. PR #1509 retains its warmed-RSS hold; #1511's separate counter exception is unapproved.

Refs #454. Runtime and evidence commits use Buckley.


The [page-reservation bucket](docs/benchmarks/20261023-native-page-reservation/README.md), committed through Buckley at `6eb1ffdbd425a0e5d877743b7f2def4cd16d2105`, completes its separate comparison: large-Go allocations 888→345 (−61.15%), LR allocations 1,807→1,759, all 206 ledgers exact, and all 126 cold-RSS probes within their ceilings. Twenty paired runs establish no significant timing improvement. This four-file experiment remains an archived patch; it is not installed in this draft's runtime.


The [32-byte subtree experiment](docs/benchmarks/20261023-subtree-metadata32/README.md), archived through Buckley at `362db75a2240d9094e15af2f215e5ece020cbf93`, is **not adopted**. Hot records shrink 44→32 bytes, but 20 paired runs establish no timing improvement; large-Go allocated bytes rise 2.98% (p=.007). All 206 counter/routing ledgers stay exact, 412 invariant sessions and 1,236 standard C checks pass, and all 126 cold-RSS probes pass. Its full source patch and profiles are retained in the evidence bucket; none of its runtime changes remain installed. The profiles identify reduction construction and publication as the next architectural targets. Existing merge and graduation holds remain unchanged.


The [reduction construction bucket](https://github.com/odvcencio/gotreesitter/blob/2cfe957d717cb34169677ab516d836fa37db04fb/docs/benchmarks/20261023-reduction-pop-construction/README.md) is **not adopted**. Direct unary construction and removal of repeated child-geometry reads pass all 206 strict ledgers, 412 invariant sessions, 1,236 standard C checks, focused races, memory checks, and 126 cold-RSS probes. Twenty paired runs establish no throughput or allocation improvement. Its three-file source patch and complete evidence are archived; no reduction-prototype source is installed in this PR.


The [native construction bucket](https://github.com/odvcencio/gotreesitter/blob/3d55d3fd7c85954249a8ec944a5025cb86733cf7/docs/benchmarks/20261023-native-construction/README.md), committed through Buckley, is **not promoted**: its Go LR gain of 4.45% comes with a primary Go full regression of 6.52% and no established YAML gain. The separate [frontier publication bucket](https://github.com/odvcencio/gotreesitter/blob/aced544fc3027e33e5486631846fd232ec10f406/docs/benchmarks/20261023-native-frontier-publication/README.md) is also **not promoted**: ordinary YAML EOF improves 1.51%, but compact-Go timing remains inconclusive and Go allocation costs rise. Both preserve complete source patches, twenty-pair measurements, exact 206-language ledgers, and full correctness/memory evidence. The installed receipt change is qualified directly against the preceding fused runtime; these two experiments remain archived patches.

