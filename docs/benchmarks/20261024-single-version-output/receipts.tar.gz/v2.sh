set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOFLAGS='-p=1 -mod=readonly -overlay=/controls/v2-overlay.json' GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/exit.txt; date -u +%FT%TZ > /evidence/finished.txt' EXIT
date -u +%FT%TZ > /evidence/started.txt
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
go test ./internal/parsercorephase0 -count=1 -v -timeout=6m > /evidence/core.log 2>&1
go test -race ./internal/parsercorephase0 -run 'Test(SingleVersion|DirectReduction|NativeSelectedOutput|.*Checkpoint.*)' -count=1 -timeout=6m > /evidence/core-race.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -run 'Test(SingleVersion|DirectReduction|NativeSelectedOutput)' -count=1 -timeout=6m > /evidence/core-386.log 2>&1
go test -c -tags gts_parsercorephase0 -o /evidence/candidate.test . > /evidence/build.log 2>&1
/evidence/candidate.test -test.run '^Test(SingleVersion.*|ParserCoreFreshFull.*|.*Corridor.*|CompactReuseDependency.*|CompactLegacyRead.*|NativeProjection.*)$' -test.count=1 -test.v -test.timeout=8m > /evidence/root.log 2>&1
go test -race -tags gts_parsercorephase0 -run '^Test(SingleVersion.*|NativeProjection.*|CompactReuseDependency.*)$' -count=1 -timeout=8m . > /evidence/root-race.log 2>&1
/evidence/candidate.test -test.run '^Test(CompactAcceptance(ChangedSourceKeepsRebuildBudget|CachedPublicationStopControl)|CompactMemoryBudgetDetectsGrowthAfterSmallPoll|CompactAcceptance.*(MemoryBudget|RetentionBound)|CompactArenaReserve.*(Budget|RetentionCap)|CompactExternalScannerCheckpointCopyMemoryBudget|CompactRecoveryMemoMemoryBudget|CompactBorrowedMaterializationProjectionMemoryBudget|G18RefSetSchedulerMemoryBudgetAccounting|RuntimeMemoryBudget.*|RuntimeMemoryHardCeilingStillStopsParse|ParseMemoryHardCeiling.*)$' -test.count=1 -test.v -test.timeout=8m > /evidence/memory.log 2>&1
for role in baseline candidate; do
 cd "/$role"
 go test -c -overlay=/controls/v2-work-overlay.json -tags gts_parsercorephase0,gts_workcount -o "/evidence/$role-work.test" . > "/evidence/$role-work-build.log" 2>&1
 go build -tags gts_parsercorephase0 -o "/evidence/$role-ledger" ./cmd/perfcounterledger > "/evidence/$role-ledger-build.log" 2>&1
done
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/candidate-cgo.test . > /evidence/cgo-build.log 2>&1
mkdir -p /evidence/invariants /evidence/cgo /evidence/work /evidence/ledger /evidence/counter-deltas
while IFS= read -r lang; do
 cd /candidate
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /evidence/candidate.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/invariants/$route-$lang.log" 2>&1
 done
 cd /candidate/cgo_harness
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GTS_PARITY_MODE=exhaustive /evidence/candidate-cgo.test -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${lang}$" -test.count=1 -test.v -test.timeout=5m > "/evidence/cgo/$route-$lang.log" 2>&1
 done
 for role in baseline candidate; do
  cd "/$role"
  GTS_WORK_LANGUAGE="$lang" "/evidence/$role-work.test" -test.run '^TestDirectReductionWork$' -test.count=1 -test.timeout=5m > "/evidence/work/$role-$lang.log" 2>&1
 done
 /evidence/baseline-ledger --langs "$lang" > "/evidence/ledger/baseline-$lang.json" 2> "/evidence/ledger/baseline-$lang.log"
 /evidence/candidate-ledger --langs "$lang" > "/evidence/ledger/candidate-$lang.json" 2> "/evidence/ledger/candidate-$lang.log"
 python3 /controls/compare-ledger.py "/evidence/ledger/baseline-$lang.json" "/evidence/ledger/candidate-$lang.json" "/evidence/counter-deltas/$lang.json" > "/evidence/counter-deltas/$lang.log"
 printf '%s\n' "$lang" >> /evidence/progress.txt
done < /controls/languages.txt
python3 /controls/compare-work.py > /evidence/work-comparison.log
cd /candidate/cgo_harness
GTS_YAML_LARGE_PROBE=1 /evidence/candidate-cgo.test -test.run '^Test(YAMLOwnedGrammarLockedCParity|CompactYAMLDocumentStreamLockedC|YAMLRecoveredMappingQuotesLockedC|YAMLEOFRecoverWrapCompactRoute|YAMLEOFRecoverWrapUnfinishedMappingDeclinesCompact|YAMLOneBytePrintableEOFAdmissionMatchesLockedC)$' -test.count=1 -test.v -test.timeout=8m > /evidence/yaml-focused-C.log 2>&1
printf 'complete\n' > /evidence/correctness-complete.txt
cd /candidate
for lang in go yaml; do
 GTS_COMPARE_LANGUAGE="$lang" bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output "/evidence/baseline-$lang.txt" --output "/evidence/compact-$lang.txt" --runs 20 --seed-start 247001 --benchtime 750ms --bench-regex '^BenchmarkSingleVersionOutput$' --lock-path /evidence/perf.lock > "/evidence/$lang-perf-driver.log" 2>&1
done
printf 'complete\n' > /evidence/complete.txt
