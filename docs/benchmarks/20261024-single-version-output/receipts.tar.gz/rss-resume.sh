set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOFLAGS='-p=1 -mod=readonly -overlay=/controls/v3-overlay.json' GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/resume-exit.txt; date -u +%FT%TZ > /evidence/resume-finished.txt' EXIT
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
/usr/bin/time --version > /evidence/time-version.txt
for role in baseline candidate; do
 cd "/$role"
 if [[ "$role" == candidate ]]; then
  go test -c -overlay=/controls/v3-throughput-overlay.json -tags gts_parsercorephase0 -o /evidence/candidate-rss.test . > /evidence/candidate-rss-build.log 2>&1
 fi
 GTS_ADMISSION_CANDIDATE=1 GTS_BENCHMARK_SEED=1 /usr/bin/time -v -o "/evidence/$role-one-mib-rss.txt" "/evidence/$role-rss.test" -test.run '^$' -test.bench '^BenchmarkCompactThroughputGo$/^fresh_one_mib$' -test.benchtime=1x -test.count=1 -test.benchmem > "/evidence/$role-one-mib-rss.log" 2>&1
done
printf 'complete\n' > /evidence/complete.txt
