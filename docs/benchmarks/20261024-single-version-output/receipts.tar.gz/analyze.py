from pathlib import Path
import re,json,statistics,subprocess,hashlib
p=Path(__file__).resolve().parent

def parse(path,start,cells):
 text=path.read_text();assert text.rstrip().endswith('# status: complete'),path
 assert '# completed runs: 20' in text
 seeds={};seed=None
 for line in text.splitlines():
  match=re.match(r'# seed: (\d+); position: (\d+)$',line)
  if match:
   seed,pos=map(int,match.groups());assert seed not in seeds;seeds[seed]={'position':pos,'rows':{},'order':[]}
  elif line.startswith('Benchmark'):
   words=line.split();name=re.sub(r'-\d+$','',words[0]);assert seed is not None and name not in seeds[seed]['rows'];assert int(words[1])>0
   assert len(words[2:])%2==0
   metrics={words[i+1]:float(words[i]) for i in range(2,len(words),2)}
   assert all(m in metrics for m in ['ns/op','B/op','allocs/op']);seeds[seed]['rows'][name]=metrics;seeds[seed]['order'].append(name)
  elif line.startswith('# workload order: '):assert line.split(': ',1)[1].split(',')==seeds[seed]['order']
 assert set(seeds)==set(range(start,start+20));assert all(len(v['rows'])==cells for v in seeds.values())
 assert len({tuple(sorted(v['rows'])) for v in seeds.values()})==1
 return seeds

specs=[
 ('v1-direct-go','qualified','baseline-go','compact-go',244001,4,'public tree versus read-only compact result'),
 ('v1-direct-yaml','qualified','baseline-yaml','compact-yaml',244001,4,'public tree versus read-only compact result'),
 ('v1-public-go','full','baseline-go','public-go',245001,4,'public tree versus public tree'),
 ('v1-public-yaml','full','baseline-yaml','public-yaml',245001,4,'public tree versus public tree'),
 ('v1-primary','full','baseline-primary','candidate-primary',246001,3,'default public Go route'),
 ('v3-direct-go','v3','baseline-go','compact-go',247001,4,'public tree versus read-only compact result'),
 ('v3-direct-yaml','v3','baseline-yaml','compact-yaml',247001,4,'public tree versus read-only compact result'),
 ('v3-public-go','v3-full','baseline-go','public-go',248001,4,'public tree versus public tree'),
 ('v3-public-yaml','v3-full','baseline-yaml','public-yaml',248001,4,'public tree versus public tree'),
 ('v3-direct-large','v3-full','baseline-direct-large','candidate-direct-large',252001,2,'public tree versus read-only compact result, generated one MiB'),
 ('v3-primary','v3-full','baseline-primary','candidate-primary',249001,3,'default public Go route'),
 ('v3-compact-primary','v3-full','baseline-compact-primary','candidate-compact-primary',250001,6,'public Parser.Parse with compact enabled'),
 ('v3-yaml-routes','v3-full','baseline-yaml-route','candidate-yaml-route',251001,6,'public Parser.Parse; legacy, ordinary compact, diagnostic ownership'),
]
result={'baseline':'64e22ad72e99a817d6e75c1e6ccd849ede4ec6ef','scope':'stacked PR1512, not main or C qualification','suites':{},'ratchet_failures':[],'rows_per_role':0}
for suite,folder,base,candidate,start,cells,contract in specs:
 paths={'baseline':p/folder/(base+'.txt'),'candidate':p/folder/(candidate+'.txt')};data={k:parse(v,start,cells) for k,v in paths.items()};summary=[]
 for seed in range(start,start+20):
  b,c=data['baseline'][seed],data['candidate'][seed];assert b['order']==c['order'];assert b['position']==1+(seed-start)%2 and c['position']==2-(seed-start)%2
  for name in b['rows']:
   x,y=b['rows'][name],c['rows'][name];assert x.keys()==y.keys()
   for metric in x.keys()-{'ns/op','B/op','allocs/op','MB/s'}:assert y[metric]==x[metric],(suite,seed,name,metric,x[metric],y[metric])
   if 'no_edit' in name or 'NoEdit' in name:assert x['B/op']==x['allocs/op']==y['B/op']==y['allocs/op']==0
 for name in data['baseline'][start]['order']:
  med={r:{m:statistics.median(data[r][s]['rows'][name][m] for s in range(start,start+20)) for m in ['ns/op','B/op','allocs/op']} for r in data}
  ratios={m:med['candidate'][m]/med['baseline'][m] if med['baseline'][m] else (1 if med['candidate'][m]==0 else None) for m in med['baseline']};fail=[m for m,v in ratios.items() if v is None or v>1.1]
  summary.append({'benchmark':name,'medians':med,'ratios':ratios,'ratchet_failures':fail})
  if fail:result['ratchet_failures'].append({'suite':suite,'benchmark':name,'metrics':fail})
 result['suites'][suite]={'contract':contract,'matched_orders':True,'alternating_roles':True,'seed_range':[start,start+19],'rows_per_role':20*cells,'sha256':{r:hashlib.sha256(f.read_bytes()).hexdigest() for r,f in paths.items()},'results':summary};result['rows_per_role']+=20*cells
 with (p/folder/f'benchstat-{suite}.txt').open('w') as out:subprocess.run(['/home/draco/go/bin/benchstat',paths['baseline'].name,paths['candidate'].name],cwd=p/folder,stdout=out,check=True)
(p/'performance-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'rows_per_role':result['rows_per_role'],'ratchet_failures':result['ratchet_failures']}))
