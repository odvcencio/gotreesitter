from pathlib import Path
import subprocess,json,hashlib,shutil
p=Path('harness_out/docker/single-version-output-v1');repo=Path.cwd();(p/'frozen').mkdir(exist_ok=True);(p/'qualified').mkdir(exist_ok=True)
tracked=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines();new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines();paths=[s for s in tracked+new if s.endswith('.go')]
replacements={};manifest={}
for name in paths:
 key=name.replace('/','__');body=(repo/name).read_bytes();f=p/'frozen'/('candidate-'+key);f.write_bytes(body);replacements['/candidate/'+name]='/controls/frozen/'+f.name
 manifest[name]={'candidate':hashlib.sha256(body).hexdigest()}
 if name in tracked:
  body=subprocess.check_output(['git','show','HEAD:'+name]);f=p/'frozen'/('baseline-'+key);f.write_bytes(body);replacements['/baseline/'+name]='/controls/frozen/'+f.name;manifest[name]['baseline']=hashlib.sha256(body).hexdigest()
 else:replacements['/baseline/'+name]=''
for role in ['baseline','candidate']:
 replacements['/'+role+'/zz_single_version_perf_test.go']='/controls/perf.go.txt'
 replacements['/'+role+'/zz_single_version_mode_test.go']='/controls/'+('baseline-stub.go.txt' if role=='baseline' else 'candidate-mode.go.txt')
(p/'source-overlay.json').write_text(json.dumps({'Replace':replacements},indent=2)+'\n');(p/'source-manifest.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':manifest},indent=2)+'\n')
work=dict(replacements)
for role in ['baseline','candidate']:work['/'+role+'/zz_direct_work_test.go']='/controls/work.go.txt'
(p/'work-overlay.json').write_text(json.dumps({'Replace':work},indent=2)+'\n')
for name in ['work.go.txt','compare-work.py','languages.txt','cgo-overlay.json']:
 shutil.copyfile(Path('harness_out/docker/direct-reduction-v1')/name,p/name)
args=json.loads((p/'command-v3.json').read_text());args=[s.replace('gts-single-version-focus-v3','gts-single-version-qualification-v1').replace('/single-version-output-v1/out:','/single-version-output-v1/qualified:').replace('/controls/focus-v3.sh','/controls/qualify.sh') for s in args];(p/'qualify-command.json').write_text(json.dumps(args,indent=2)+'\n')
