from pathlib import Path
import json,re,hashlib
p=Path(__file__).resolve().parent
langs=(p/'languages.txt').read_text().splitlines();assert len(langs)==206 and len(set(langs))==206
results={}
for rev,folder in [('v1','full'),('v3','v3')]:
 d=p/folder
 assert (d/'exit.txt').read_text().strip()=='0'
 assert (d/'complete.txt').exists()
 assert (d/'progress.txt').read_text().splitlines()==langs
 for lang in langs:
  ledger=json.loads((d/'counter-deltas'/f'{lang}.json').read_text());assert ledger['passed'] and not ledger['changes'] and not ledger['route_metadata_changes']
  for route in [0,1]:
   text=(d/'invariants'/f'{route}-{lang}.log').read_text();assert 'session_steps=72 no_edit_allocs=0' in text and '\nPASS\n' in text and '--- SKIP' not in text and '--- FAIL' not in text
   text=(d/'cgo'/f'{route}-{lang}.log').read_text();assert '\nPASS\n' in text and '--- SKIP' not in text and '--- FAIL' not in text
   assert sum(text.count('--- PASS: '+n+'/'+lang+' ') for n in ['TestParityFreshParse','TestParityIncrementalParse','TestParityHasNoErrors'])==3
 work=json.loads((d/'work/comparison.json').read_text());assert work=={'rows':824,'changes':[],'adverse':[]}
 memory=(d/'memory.log').read_text();assert '--- FAIL' not in memory;memory_tests=len(re.findall(r'^--- PASS:',memory,re.M))
 results[rev]={'languages':206,'invariant_sessions':412,'edit_steps':29664,'no_edit_allocations':0,'standard_C_checks':1236,'whole_operation_work_rows':824,'work_changes':0,'selected_ledger_comparisons':206,'work_reuse_route_changes':0,'memory_contract_tests':memory_tests}
(p/'correctness-analysis.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results))
