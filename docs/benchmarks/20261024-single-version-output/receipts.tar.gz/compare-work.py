from pathlib import Path
import json
p=Path('/evidence/work');rows={}
for role in ['baseline','candidate']:
 rows[role]={}
 for f in sorted(p.glob(role+'-*.log')):
  for s in f.read_text().splitlines():
   if not s.startswith('WORK '):continue
   r=json.loads(s[5:]);k=(r['Language'],r['Route'],r['Phase']);assert k not in rows[role];rows[role][k]=r['Counts']
assert set(rows['baseline'])==set(rows['candidate']) and len(rows['baseline'])==824
changes=[]
for k,a in rows['baseline'].items():
 for metric,old in a.items():
  new=rows['candidate'][k][metric]
  if old!=new:changes.append(dict(case=k,metric=metric,before=old,after=new))
report=dict(rows=824,changes=changes,adverse=[r for r in changes if r['after']>r['before']]);(p/'comparison.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
assert not report['adverse'], 'complete-operation work increased; timing held'
(p/'complete.txt').write_text('complete\n')
