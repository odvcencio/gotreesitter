set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOFLAGS='-p=1 -mod=readonly' GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/focus-exit.txt' EXIT
git config --global --add safe.directory /candidate
cd /candidate
go test ./internal/parsercorephase0 -run 'TestDirectReduction' -count=1 -timeout=5m > /evidence/core-focus.log 2>&1
go test -c -o /evidence/candidate.test . > /evidence/root-build.log 2>&1
/evidence/candidate.test -test.run '^Test(ParserCoreFreshFull.*|.*Corridor.*|CompactReuseDependency.*|CompactLegacyRead.*|NativeProjection.*)$' -test.count=1 -test.v -test.timeout=7m > /evidence/root-focus.log 2>&1
for lang in go yaml; do
 GTS_ADMISSION_CANDIDATE=1 GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /evidence/candidate.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/invariant-$lang.log" 2>&1
done
