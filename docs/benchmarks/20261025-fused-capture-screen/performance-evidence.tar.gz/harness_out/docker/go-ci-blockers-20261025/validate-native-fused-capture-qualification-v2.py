from pathlib import Path
import json,re
root=Path(__file__).resolve().parent
out=root/'out/native-fused-capture-qualification-v2'
assert json.loads((out/'finished.json').read_text())['exit_code']==0
assert (out/'completed.txt').is_file()
want={'core.log':59,'focused.log':39,'go-public-api.log':3,'yaml-fallback.log':1,'go-cgo.log':10,'yaml-cgo.log':8,'direct-output-Go.log':1,'direct-output-YAML.log':1}
for lang in ['foam','hyprlang','pkl','smithy']:want[f'quiescent-{lang}.log']=1
for name,n in want.items():
 t=(out/name).read_text()
 assert not re.search(r'--- (FAIL|SKIP):|panic:|fatal error:',t),name
 assert len(re.findall(r'^--- PASS:',t,re.M))==n,(name,n)
focused=(out/'focused.log').read_text()
for case in ['r4','canonical','type-retag','case-boundaries','root-extras','padding']:
 assert re.search(r'^    --- PASS: TestNativeFusedCaptureDifferentialGo/'+re.escape(case)+r' ',focused,re.M),case
for lang in ['go','yaml']:
 for route in ['0','1']:
  t=(out/f'invariants-{lang}-{route}.log').read_text()
  assert f'language={lang}' in t and 'session_steps=72 no_edit_allocs=0' in t
  assert re.search(r'^--- PASS: TestV1InvariantGateR4EditSession ',t,re.M)
  assert not re.search(r'--- (FAIL|SKIP):',t)
for name in ['source-before.log','source-after.log','controls-before.log','controls-after.log']:assert (out/name).read_text()==''
for lang in ['go','yaml']:
 for route in ['default','candidate']:
  n=f'{route}-{lang}.json'
  assert json.loads((out/n).read_text())==json.loads((root/'out/packed-snapshot-budget-final/ledger'/n).read_text()),n
  assert (out/f'{route}-{lang}.stderr').read_text()==''
expected={'schema':'gts-native-fused-capture-qualification/v1','source_variant':'native-fused-capture-v1/v3','failed':0,'skipped':0,'top_level_passes':want,'fused_receipt_differential_cases':6,'Go_and_YAML_C_D8_passed':True,'invariant_sessions':4,'edit_steps':288,'no_edit_allocations':0,'ordinary_actual_counter_rows_unchanged':4,'prototype_promoted':False,'performance_claim':False,'merges_held':True}
assert json.loads((out/'validated-summary.json').read_text())==expected
print(json.dumps(expected,indent=2))
