set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly -overlay=/controls/native-fused-capture-perf-v1/overlay.container.json'
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
python3 - <<'CHECK'
from pathlib import Path
import json
r=json.loads(Path('/controls/out/native-fused-capture-qualification-v2/validated-summary.json').read_text())
assert r['Go_and_YAML_C_D8_passed'] and r['ordinary_actual_counter_rows_unchanged']==4
assert r['fused_receipt_differential_cases']==6 and r['failed']==r['skipped']==0
print('independent fused publication exact receipt/replay/lifetime/C/D8/work gate passed; no dense hybrid included')
CHECK
cd /candidate
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
(cd /controls/native-fused-capture-v1
sha256sum --quiet -c controls.sha256
cd v2
sha256sum --quiet -c SHA256SUMS
cd ../v3
sha256sum --quiet -c SHA256SUMS) > /evidence/producer-controls-before.log 2>&1
sha256sum --quiet -c /controls/native-fused-capture-perf-v1/controls.sha256 > /evidence/controls-before.log 2>&1
go version > /evidence/toolchain.txt
GTS_ADMISSION_REAL_CORPUS_LANGS=go bash scripts/run_randomized_benchmarks.sh --output /evidence/r4-after-go.txt --baseline-root /baseline --baseline-output /evidence/r4-before-go.txt --lock-path /evidence/benchmark.lock --bench-regex '^BenchmarkCompactGraduationR4$' --require-benchmarks BenchmarkCompactGraduationR4/legacy,BenchmarkCompactGraduationR4/compact --runs 20 --seed-start 1 --benchtime 750ms > /evidence/r4-runner-go.log 2>&1
GTS_ADMISSION_REAL_CORPUS_LANGS=yaml bash scripts/run_randomized_benchmarks.sh --output /evidence/r4-after-yaml.txt --baseline-root /baseline --baseline-output /evidence/r4-before-yaml.txt --lock-path /evidence/benchmark.lock --bench-regex '^BenchmarkCompactGraduationR4$' --require-benchmarks BenchmarkCompactGraduationR4/legacy,BenchmarkCompactGraduationR4/compact --runs 20 --seed-start 1 --benchtime 750ms > /evidence/r4-runner-yaml.log 2>&1
GTS_ADMISSION_CANDIDATE=1 bash scripts/run_randomized_benchmarks.sh --output /evidence/primary-after.txt --baseline-root /baseline --baseline-output /evidence/primary-before.txt --lock-path /evidence/benchmark.lock --bench-regex '^BenchmarkGraduationGoSuite$' --require-benchmarks BenchmarkGraduationGoSuite/Full,BenchmarkGraduationGoSuite/Edit,BenchmarkGraduationGoSuite/NoEdit --runs 20 --seed-start 1 --benchtime 750ms > /evidence/primary-runner.log 2>&1
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1
(cd /controls/native-fused-capture-v1
sha256sum --quiet -c controls.sha256
cd v2
sha256sum --quiet -c SHA256SUMS
cd ../v3
sha256sum --quiet -c SHA256SUMS) > /evidence/producer-controls-after.log 2>&1
sha256sum --quiet -c /controls/native-fused-capture-perf-v1/controls.sha256 > /evidence/controls-after.log 2>&1
printf 'all60 shuffled pairs complete; private preliminary architecture comparison, no graduation claim\n' > /evidence/completed.txt
