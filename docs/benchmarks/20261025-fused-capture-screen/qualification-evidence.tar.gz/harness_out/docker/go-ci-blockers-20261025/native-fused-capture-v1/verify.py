#!/usr/bin/env python3
"""Authenticate frozen controls and actual canonical runtime before execution."""
import argparse,hashlib,json,pathlib
p=argparse.ArgumentParser();p.add_argument('--checkout',default='/candidate');p.add_argument('--controls',default=str(pathlib.Path(__file__).resolve().parent));a=p.parse_args()
root=pathlib.Path(a.controls);checkout=pathlib.Path(a.checkout)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for line in (root/'controls.sha256').read_text().splitlines():
 digest,name=line.split('  ',1);assert sha(root/name)==digest,name
m=json.loads((root/'source-identities.json').read_text())
for name,digest in m['source_files'].items():assert sha(checkout/name)==digest,name
for row in m['overlays']:
 assert sha(root/row['overlay'])==row['overlay_sha256'],row['overlay']
 target=checkout/row['target']
 if row['original_sha256'] is None:assert not target.exists(),row['target']
 else:assert sha(target)==row['original_sha256'],row['target']
print(json.dumps({'controls':'PASS','canonical_source':'PASS','runtime_files':len(m['source_files']),'overlay_files':len(m['overlays']),'status':'unbuilt/unrun controls; verification is identity only'}))
