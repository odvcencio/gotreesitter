set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOFLAGS='-p=1 -mod=readonly -overlay=/controls/pool-history-overlay.json'
trap 'printf "%s\n" "$?" > /evidence/pool-history.exit' EXIT
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
for role in baseline candidate; do
 cd /$role
 go test -c -tags gts_parsercorephase0 -o /evidence/$role-pool-history.test . > /evidence/$role-pool-history-build.log 2>&1
 set +e
 /evidence/$role-pool-history.test -test.run '^TestSQLRetainedParentHistoryProbe$' -test.v -test.count=1 -test.timeout=3m > /evidence/$role-pool-history.log 2>&1
 code=$?
 set -e
 printf '%s\n' "$code" > /evidence/$role-pool-history.exit
done
printf 'complete\n' > /evidence/pool-history-complete.txt
