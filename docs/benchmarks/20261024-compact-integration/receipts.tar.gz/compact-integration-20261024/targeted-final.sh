set -euo pipefail
cd /candidate/cgo_harness
for group in go yaml javascript; do
 case $group in
 go) pattern='^TestGoNewMakeResidualParity$';;
 yaml) pattern='^Test(YAMLOwnedGrammarLockedCParity|CompactYAMLDocumentStreamLockedC|YAMLRecoveredMappingQuotesLockedC|YAMLEOFRecoverWrapCompactRoute|YAMLEOFRecoverWrapUnfinishedMappingDeclinesCompact|YAMLOneBytePrintableEOFAdmissionMatchesLockedC)$';;
 javascript) pattern='^Test(CompactT3JavaScriptRecoveryProfileCharacterization|CompactT3JavaScriptRecoveryRouteSeedOracleParity|CompactJavaScriptS5RecoveryMutationDifferential)$';;
 esac
 GTS_YAML_LARGE_PROBE=1 /evidence/final-cgo.test -test.run "$pattern" -test.count=1 -test.v -test.timeout=8m > /evidence/final-cgo-$group.log 2>&1
 printf '%s\n' "$?" > /evidence/final-cgo-$group.exit
done

# One-language pool-history diagnostic; record both statuses independently.
cd /candidate
for role in baseline candidate; do
 set +e
 /evidence/$role-work.test -test.run '^TestSQLIncrementalScannerCertification$' -test.count=2 -test.v -test.timeout=5m > /evidence/sql-history-$role.log 2>&1
 code=$?
 set -e
 printf '%s\n' "$code" > /evidence/sql-history-$role.exit
done
