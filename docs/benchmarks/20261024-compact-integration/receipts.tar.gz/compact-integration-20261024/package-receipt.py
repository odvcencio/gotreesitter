from pathlib import Path
import hashlib,json,shutil,tarfile
p=Path(__file__).resolve().parent
v=p/'v2'
root=p.parents[2]
out=root/'docs/benchmarks/20261024-compact-integration'
assert (v/'perf-complete.txt').exists() and (v/'perf.exit').read_text().strip()=='0' and (v/'run.exit').read_text().strip()=='0'
a=json.loads((p/'performance-analysis.json').read_text());b=json.loads((v/'performance-analysis.json').read_text())
result={'baseline':a['baseline'],'scope':'final Go normalizer and inherited unchanged YAML path; candidate route enabled; YAML eager publication','suites':{'go':b['suites']['go'],'yaml':a['suites']['yaml'],'primary':b['suites']['primary']},'rows_per_role':380,'ratchet_failures':[]}
for name,suite in result['suites'].items():
 for row in suite['results']:
  if row['ratchet_failures']:result['ratchet_failures'].append({'suite':name,'benchmark':row['benchmark'],'metrics':row['ratchet_failures']})
assert not result['ratchet_failures']
(out/'performance-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
a=json.loads((p/'retention-analysis.json').read_text());b=json.loads((v/'retention-analysis.json').read_text())
retention={'scope':a['scope'],'results':{**{k:r for k,r in a['results'].items() if k.startswith('yaml-')},**b['results']},'ratchet_failures':[]}
assert not a['ratchet_failures'] and not b['ratchet_failures']
(out/'retention-analysis.json').write_text(json.dumps(retention,indent=2)+'\n')
for source,name in [(p/'final-qualification.json','qualification.json'),(p/'relocation-audit.json','relocation-audit.json'),(v/'source-manifest.json','source-manifest.json'),(p/'benchstat-yaml.txt','benchstat-yaml.txt'),(v/'benchstat-go.txt','benchstat-go.txt'),(v/'benchstat-primary.txt','benchstat-primary.txt')]:shutil.copyfile(source,out/name)
archive=out/'receipts.tar.gz';files=[]
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
 for f in sorted(p.rglob('*')):
  if not f.is_file() or f.is_symlink() or f.name.endswith('.lock') or '__pycache__' in f.parts:continue
  with f.open('rb') as stream:prefix=stream.read(4)
  if prefix==b'\x7fELF':continue
  tar.add(f,arcname='compact-integration-20261024/'+str(f.relative_to(p)),recursive=False)
  files.append({'path':str(f.relative_to(p)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
with tarfile.open(archive) as tar:
 for row in files:
  data=tar.extractfile('compact-integration-20261024/'+row['path']).read()
  assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
groups={}
for row in files:
 group=row['path'].split('/')[0] if '/' in row['path'] else 'root controls and logs'
 groups[group]=groups.get(group,0)+1
manifest={'archive':'receipts.tar.gz','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'file_count':len(files),'groups':groups,'verification':'Every archived file was read back and compared with its original SHA-256 before publication.'}
(out/'receipt-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='files'}))
