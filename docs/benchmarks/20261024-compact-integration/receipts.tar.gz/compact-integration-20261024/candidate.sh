set -uo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOFLAGS='-p=1 -mod=readonly'
cd /candidate
go test ./internal/parsercorephase0 -count=1 -timeout=8m > /evidence/core.log 2>&1 || exit
go test -c -tags gts_parsercorephase0 -o /evidence/candidate.test . > /evidence/candidate-build.log 2>&1 || exit
for group in synthetic go yaml javascript; do
 case $group in
 synthetic) pattern='^Test(FinalizeCompactReturnedTreeForParsePreservesCompletedTreeUnderPresetCancellation|CompactRuntimePool.*|DiagnosticParserCoreClassifiedBoundaryAndReductionPlanShape)$';;
 go) pattern='^TestAdmissionGenericConflictFamilyNoDivergence$';;
 yaml) pattern='^TestAdmissionCandidateYAMLZeroWidthDepth$';;
 javascript) pattern='^TestCompactRouteAdjudicatesFalseCleanWitnesses$/^js_log_2$';;
 esac
 /evidence/candidate.test -test.run "$pattern" -test.count=1 -test.v -test.timeout=5m > /evidence/candidate-$group.log 2>&1
 echo "$?" > /evidence/candidate-$group.exit
done

go run ./cmd/v1layout > /evidence/layout.log 2>&1
printf '%s\n' "$?" > /evidence/layout.exit
