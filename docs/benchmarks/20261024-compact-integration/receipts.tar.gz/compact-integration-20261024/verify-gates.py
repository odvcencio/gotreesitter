from pathlib import Path
import hashlib,json,re
p=Path(__file__).resolve().parent
langs=(p/'languages.txt').read_text().splitlines()
assert len(langs)==len(set(langs))==206
assert (p/'gate-progress.txt').read_text().splitlines()==langs
assert (p/'gate-complete.txt').read_text().strip()=='complete'
assert (p/'gate.exit').read_text().strip()=='0'
sessions=steps=c_checks=0
for language in langs:
 for route in [0,1]:
  text=(p/'invariants'/f'{route}-{language}.log').read_text()
  assert text.rstrip().endswith('PASS') and '--- FAIL' not in text
  rows=re.findall(r'language=(\S+) fixture=(r4|grammar-smoke) sample_bytes=(\d+) session_steps=(\d+) no_edit_allocs=(\S+)',text)
  assert len(rows)==1 and rows[0][0]==language and float(rows[0][4])==0
  assert rows[0][1]==('grammar-smoke' if language in ['csv','enforce'] else 'r4')
  sessions+=1;steps+=int(rows[0][3])
  text=(p/'cgo'/f'{route}-{language}.log').read_text()
  assert text.rstrip().endswith('PASS') and '--- FAIL' not in text
  assert len(re.findall(r'^--- PASS: TestParity',text,re.M))==3
  c_checks+=3
 for role in ['baseline','candidate']:
  text=(p/'work'/f'{role}-{language}.log').read_text()
  assert text.rstrip().endswith('PASS') and '--- FAIL' not in text
 delta=json.loads((p/'counter-deltas'/f'{language}.json').read_text())
 assert delta['passed'] and not delta['changes'] and not delta['route_metadata_changes']
work=json.loads((p/'work/comparison.json').read_text())
assert work['rows']==824 and not work['changes'] and not work['adverse']
for name in ['final-focused','final-memory','final-cgo-go','final-cgo-yaml','final-cgo-javascript','sql-history-baseline','sql-history-candidate']:
 text=(p/(name+'.log')).read_text()
 assert text.rstrip().endswith('PASS') and '--- FAIL' not in text,name
for name in ['final-core','final-core-race','final-race','no-core']:
 text=(p/(name+'.log')).read_text()
 assert text.startswith('ok ') and 'FAIL' not in text,name
assert '756/756 root Go files, 12 API tag sets' in (p/'final-layout.log').read_text()
assert 'counter ledger passed: 412 rows, 206 languages' in (p/'checked-ledger.log').read_text()
m=json.loads((p/'source-manifest.json').read_text())
for row in m['files']:
 for role in ['baseline','candidate']:
  if row[role] is not None:
   assert hashlib.sha256((p/role/row['path']).read_bytes()).hexdigest()==row[role]['sha256']
result={'baseline':m['baseline'],'invariant_sessions':sessions,'edit_steps':steps,'no_edit_allocations':0,'standard_C_checks':c_checks,'work_rows_per_role':824,'counter_changes':0,'selected_ledgers':206,'root_files':756,'API_tag_sets':12,'memory_contract_tests':len(re.findall(r'^--- PASS:',(p/'final-memory.log').read_text(),re.M)),'SQL_history_runs_per_role':2,'known_unresolved':'Broader CI SQL memory ceiling failure is not reproduced by the one-language checks; Cognociente malformed-delete C mismatch remains open.'}
(p/'qualification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
