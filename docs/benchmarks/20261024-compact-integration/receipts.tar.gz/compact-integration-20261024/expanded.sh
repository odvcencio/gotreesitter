set -uo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOFLAGS='-p=1 -mod=readonly'
cd /candidate
git config --global --add safe.directory /candidate
go build -o /evidence/candidate-ledger ./cmd/perfcounterledger > /evidence/ledger-build.log 2>&1 || exit
/evidence/candidate-ledger --langs yaml > /evidence/yaml-ledger.json 2>/evidence/yaml-ledger.log
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/candidate-cgo.test . > /evidence/cgo-build.log 2>&1 || exit
for group in go yaml javascript; do
 case $group in
 go) pattern='^TestGoNewMakeResidualParity$';;
 yaml) pattern='^Test(YAMLOwnedGrammarLockedCParity|CompactYAMLDocumentStreamLockedC|YAMLRecoveredMappingQuotesLockedC|YAMLEOFRecoverWrapCompactRoute|YAMLEOFRecoverWrapUnfinishedMappingDeclinesCompact|YAMLOneBytePrintableEOFAdmissionMatchesLockedC)$';;
 javascript) pattern='^Test(CompactT3JavaScriptRecoveryProfileCharacterization|CompactT3JavaScriptRecoveryRouteSeedOracleParity|CompactJavaScriptS5RecoveryMutationDifferential)$';;
 esac
 GTS_YAML_LARGE_PROBE=1 /evidence/candidate-cgo.test -test.run "$pattern" -test.count=1 -test.v -test.timeout=8m > /evidence/cgo-$group.log 2>&1
 printf '%s\n' "$?" > /evidence/cgo-$group.exit
done
