from pathlib import Path
import re,json,statistics,subprocess,hashlib
p=Path(__file__).resolve().parent

def parse(path,start,cells):
 text=path.read_text();assert text.rstrip().endswith('# status: complete'),path
 assert '# completed runs: 20' in text
 seeds={};seed=None
 for line in text.splitlines():
  match=re.match(r'# seed: (\d+); position: (\d+)$',line)
  if match:
   seed,pos=map(int,match.groups());assert seed not in seeds;seeds[seed]={'position':pos,'rows':{},'order':[]}
  elif line.startswith('Benchmark'):
   words=line.split();name=re.sub(r'-\d+$','',words[0]);assert seed is not None and name not in seeds[seed]['rows'];assert int(words[1])>0
   assert len(words[2:])%2==0
   metrics={words[i+1]:float(words[i]) for i in range(2,len(words),2)}
   assert all(m in metrics for m in ['ns/op','B/op','allocs/op']);seeds[seed]['rows'][name]=metrics;seeds[seed]['order'].append(name)
  elif line.startswith('# workload order: '):assert line.split(': ',1)[1].split(',')==seeds[seed]['order']
 assert set(seeds)==set(range(start,start+20));assert all(len(v['rows'])==cells for v in seeds.values())
 assert len({tuple(sorted(v['rows'])) for v in seeds.values()})==1
 return seeds

specs=[('go',260001,8),('yaml',260001,8),('primary',261001,3)]
result={'baseline':'6e9460228d50a113233fe081cfe05ffe50379f1e','scope':'compact integration corrections versus previous public-view bucket; ordinary YAML output','suites':{},'ratchet_failures':[],'rows_per_role':0}
d=p
for suite,start,cells in specs:
 paths={role:d/(role+'-perf-'+suite+'.txt') for role in ['baseline','candidate']};data={role:parse(f,start,cells) for role,f in paths.items()};summary=[]
 for seed in range(start,start+20):
  a,b=data['baseline'][seed],data['candidate'][seed];assert a['order']==b['order'];assert a['position']==1+(seed-start)%2 and b['position']==2-(seed-start)%2
  for name in a['rows']:
   x,y=a['rows'][name],b['rows'][name];assert x.keys()==y.keys()
   for metric in x.keys()-{'ns/op','B/op','allocs/op','MB/s'}:assert x[metric]==y[metric]
   if 'NoEdit' in name:assert x['B/op']==x['allocs/op']==y['B/op']==y['allocs/op']==0
 for name in data['baseline'][start]['order']:
  med={role:{metric:statistics.median(data[role][seed]['rows'][name][metric] for seed in range(start,start+20)) for metric in ['ns/op','B/op','allocs/op']} for role in data}
  ratios={metric:med['candidate'][metric]/med['baseline'][metric] if med['baseline'][metric] else (1 if med['candidate'][metric]==0 else None) for metric in med['baseline']}
  failures=[k for k,v in ratios.items() if v is None or v>1.1]
  summary.append({'benchmark':name,'medians':med,'ratios':ratios,'ratchet_failures':failures})
  if failures:result['ratchet_failures'].append({'suite':suite,'benchmark':name,'metrics':failures})
 result['suites'][suite]={'matched_orders':True,'alternating_roles':True,'seed_range':[start,start+19],'rows_per_role':20*cells,'results':summary};result['rows_per_role']+=20*cells
 with (d/('benchstat-'+suite+'.txt')).open('w') as out:subprocess.run(['/home/draco/go/bin/benchstat',paths['baseline'].name,paths['candidate'].name],cwd=d,stdout=out,check=True)
(p/'performance-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'rows_per_role':result['rows_per_role'],'ratchet_failures':result['ratchet_failures']}))
