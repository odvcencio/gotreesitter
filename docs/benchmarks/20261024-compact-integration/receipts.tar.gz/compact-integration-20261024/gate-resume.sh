set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off
export GOFLAGS='-p=1 -mod=readonly -overlay=/controls/overlay.json'
trap 'printf "%s\n" "$?" > /evidence/gate.exit' EXIT
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/final-cgo.test . > /evidence/final-cgo-build.log 2>&1
mkdir -p /evidence/invariants /evidence/cgo /evidence/work /evidence/ledger /evidence/counter-deltas
while IFS= read -r lang; do
 cd /candidate
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /evidence/final.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > /evidence/invariants/$route-$lang.log 2>&1
 done
 cd /candidate/cgo_harness
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GTS_PARITY_MODE=exhaustive /evidence/final-cgo.test -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${lang}$" -test.count=1 -test.v -test.timeout=5m > /evidence/cgo/$route-$lang.log 2>&1
 done
 for role in baseline candidate; do
  cd /$role
  GTS_WORK_LANGUAGE="$lang" /evidence/$role-work.test -test.run '^TestDirectReductionWork$' -test.count=1 -test.timeout=5m > /evidence/work/$role-$lang.log 2>&1
  /evidence/$role-ledger --langs "$lang" > /evidence/ledger/$role-$lang.json 2> /evidence/ledger/$role-$lang.log
 done
 python3 /controls/compare-ledger.py /evidence/ledger/baseline-$lang.json /evidence/ledger/candidate-$lang.json /evidence/counter-deltas/$lang.json > /evidence/counter-deltas/$lang.log
 printf '%s\n' "$lang" >> /evidence/gate-progress.txt
done < /controls/languages.txt
cd /candidate
/evidence/candidate-ledger > /evidence/checked-ledger.log 2>&1
go test -race ./internal/parsercorephase0 -run '^Test(DirectReduction|SingleVersion|NativeProjection|NativeSelected|SelectedStore)' -count=1 -timeout=8m > /evidence/final-core-race.log 2>&1
go test -race -tags gts_parsercorephase0 -run '^Test(NativeNodeViews|NodeViewArena|CompactRuntimePool)' -count=1 -timeout=8m . > /evidence/final-race.log 2>&1
go run ./cmd/v1layout > /evidence/final-layout.log 2>&1
go test -tags gts_no_parsercorephase0 -run '^TestNodeViewArena' -count=1 -timeout=5m . > /evidence/no-core.log 2>&1
printf 'complete\n' > /evidence/gate-complete.txt
