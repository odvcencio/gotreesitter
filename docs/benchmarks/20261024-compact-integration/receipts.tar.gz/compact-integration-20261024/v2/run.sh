set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOFLAGS='-p=1 -mod=readonly -overlay=/controls/overlay.json'
trap 'printf "%s\n" "$?" > /evidence/run.exit' EXIT
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
cd /candidate
go test ./internal/parsercorephase0 -count=1 -timeout=8m > /evidence/core.log 2>&1
go test -c -tags gts_parsercorephase0 -o /evidence/final.test . > /evidence/build.log 2>&1
/evidence/final.test -test.run '^Test(NativeNodeViews|AdmissionGenericConflictFamilyNoDivergence)' -test.count=1 -test.v -test.timeout=8m > /evidence/focused.log 2>&1
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE=go /evidence/final.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > /evidence/invariant-$route.log 2>&1
done
go test -c -overlay=/controls/work-overlay.json -tags gts_parsercorephase0,gts_workcount -o /evidence/candidate-work.test . > /evidence/work-build.log 2>&1
go build -o /evidence/candidate-ledger ./cmd/perfcounterledger > /evidence/ledger-build.log 2>&1
mkdir -p /evidence/work
for role in baseline candidate; do
 binary=/evidence/$role-work.test; ledger=/evidence/$role-ledger
 if [[ $role == baseline ]]; then binary=/prior/baseline-work.test; ledger=/prior/baseline-ledger; fi
 GTS_WORK_LANGUAGE=go "$binary" -test.run '^TestDirectReductionWork$' -test.count=1 -test.timeout=5m > /evidence/work/$role-go.log 2>&1
 "$ledger" --langs go > /evidence/ledger-$role.json 2>/evidence/ledger-$role.log
done
python3 /controls/compare-ledger.py /evidence/ledger-baseline.json /evidence/ledger-candidate.json /evidence/counter-deltas.json > /evidence/counter-deltas.log
python3 /controls/compare-work.py
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/cgo.test . > /evidence/cgo-build.log 2>&1
/evidence/cgo.test -test.run '^TestGoNewMakeResidualParity$' -test.count=1 -test.v -test.timeout=8m > /evidence/cgo-builtins.log 2>&1
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE="$route" GTS_PARITY_MODE=exhaustive /evidence/cgo.test -test.run '^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^go$' -test.count=1 -test.v -test.timeout=5m > /evidence/cgo-$route.log 2>&1
done
cd /candidate
go test -race -tags gts_parsercorephase0 -run '^TestNativeNodeViewsTypeArgumentsPreserveEditAndCopy$' -count=1 -timeout=8m . > /evidence/race.log 2>&1
go run ./cmd/v1layout > /evidence/layout.log 2>&1
printf 'complete\n' > /evidence/gate-complete.txt
bash /controls/perf.sh
