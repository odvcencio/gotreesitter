set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off
trap 'printf "%s\n" "$?" > /evidence/perf.exit' EXIT
[[ -f /evidence/gate-complete.txt ]] || { echo 'correctness qualification incomplete'; exit 2; }
python3 /controls/compare-work.py
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
export GOFLAGS='-p=1 -mod=readonly -overlay=/controls/perf-overlay.json'
cd /candidate
for lang in go; do
 GTS_COMPARE_LANGUAGE="$lang" bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output "/evidence/baseline-perf-$lang.txt" --output "/evidence/candidate-perf-$lang.txt" --runs 20 --seed-start 262001 --benchtime 750ms --tags gts_parsercorephase0 --bench-regex '^BenchmarkCompactPublicOutput$' --lock-path /evidence/perf.lock > "/evidence/perf-$lang-driver.log" 2>&1
done
cp /controls/benchmark_primary_overlay.go.txt /evidence/prepare-primary.go
go run /evidence/prepare-primary.go /controls/benchmark_primary_go_suite.go.txt /evidence/primary-overlay.json /baseline /candidate > /evidence/primary-hashes.txt
python3 - <<'PY'
from pathlib import Path
import json
p=Path('/evidence/primary-overlay.json');d=json.loads(p.read_text());d['Replace'].update(json.loads(Path('/controls/overlay.json').read_text())['Replace']);p.write_text(json.dumps(d,indent=2)+'\n')
PY
GOFLAGS='-p=1 -mod=readonly -overlay=/evidence/primary-overlay.json' GTS_ADMISSION_CANDIDATE=1 bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-perf-primary.txt --output /evidence/candidate-perf-primary.txt --runs 20 --seed-start 263001 --benchtime 750ms --tags gts_parsercorephase0 --bench-regex '^BenchmarkGTSSeededPrimary$' --require-benchmarks 'BenchmarkGTSSeededPrimary/BenchmarkGoParseFullDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGTSSeededPrimary/BenchmarkGoParseIncrementalNoEditDFA' --lock-path /evidence/perf.lock > /evidence/primary-driver.log 2>&1
mkdir -p /evidence/retention
for role in baseline candidate; do
 cd /$role
 go test -c -overlay=/controls/retention-overlay.json -tags gts_parsercorephase0 -o /evidence/$role-heap.test . > /evidence/retention/$role-build.log 2>&1
done
for lang in go; do
 for operation in root walk; do
  for seed in $(seq 1 20); do
   roles='baseline candidate'; if ((seed%2)); then roles='candidate baseline'; fi
   for role in $roles; do
    cd /$role
    GTS_COMPARE_LANGUAGE="$lang" GTS_VIEW_OPERATION="$operation" /usr/bin/time -v -o /evidence/retention/$role-$lang-$operation-$seed.rss /evidence/$role-heap.test -test.run '^TestCompactPublicRetainedHeap$' -test.count=1 -test.v -test.timeout=5m > /evidence/retention/$role-$lang-$operation-$seed.log 2>&1
   done
  done
 done
done
printf 'complete\n' > /evidence/perf-complete.txt
