set -uo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOFLAGS='-p=1 -mod=readonly'
cd /candidate
go test -c -tags gts_parsercorephase0 -o /evidence/baseline.test . > /evidence/baseline-build.log 2>&1 || exit
for group in synthetic go yaml javascript; do
 case $group in
 synthetic) pattern='^Test(FinalizeCompactReturnedTreeForParsePreservesCompletedTreeUnderPresetCancellation|CompactRuntimePool.*|DiagnosticParserCoreClassifiedBoundaryAndReductionPlanShape)$';;
 go) pattern='^TestAdmissionGenericConflictFamilyNoDivergence$';;
 yaml) pattern='^TestAdmissionCandidateYAMLZeroWidthDepth$';;
 javascript) pattern='^TestCompactRouteAdjudicatesFalseCleanWitnesses$/^js_log_2$';;
 esac
 /evidence/baseline.test -test.run "$pattern" -test.count=1 -test.v -test.timeout=5m > /evidence/baseline-$group.log 2>&1
 echo "$?" > /evidence/baseline-$group.exit
done
