#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOMAXPROCS=1 GOWORK=off GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
for variant in baseline candidate; do
 cd "/$variant/roottest/bench"
 for mode in plain heap; do
  args=()
  if [[ "$mode" == heap ]]; then args+=("-test.memprofile=/evidence/${variant}.heap"); fi
  /usr/bin/time -v -o "/evidence/rss-${variant}-${mode}.txt" env GTS_FRESH_MEMORY_LANG=go GTS_ADMISSION_CANDIDATE=0 "/qualified/${variant}-bench.test" -test.run '^$' -test.bench '^BenchmarkFreshMemory$/^go$/^1024KiB$' -test.benchtime=2x -test.count=1 -test.benchmem -test.shuffle=138001 -test.timeout=5m "${args[@]}" > "/evidence/${variant}-${mode}.log" 2>&1
 done
 go tool pprof -top -sample_index=inuse_space -nodecount=25 "/qualified/${variant}-bench.test" "/evidence/${variant}.heap" > "/evidence/${variant}-inuse-top.txt"
 go tool pprof -top -sample_index=alloc_space -nodecount=25 "/qualified/${variant}-bench.test" "/evidence/${variant}.heap" > "/evidence/${variant}-alloc-top.txt"
done
printf 'complete\n' > /evidence/complete.txt
