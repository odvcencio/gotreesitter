package parsercorephase0

import "errors"

// NativeProjectionConstructionSink combines child validation with copying the
// public child list. It also supports the two mutations that do not need a full
// public-node readback. The ordinary sink remains the reference implementation.
type NativeProjectionConstructionSink interface {
	EmitParent(NativeProjectionRecord, []SelectedNodeID) (SelectedNodeID, error)
	ApplyField([]SelectedNodeID, FieldID) error
	AddSupertype([]SelectedNodeID, uint32) error
}

// IncludeChild preserves source containment and left-to-right checked score
// addition. A constructing sink must call it once per child, in child order,
// before publishing the parent. The initial precedence is the raw production's
// own contribution; alias wrappers use Emit with an already complete score.
func (r *NativeProjectionRecord) IncludeChild(start, end uint32, precedence int32) error {
	if start < r.StartByte || end > r.EndByte {
		return errors.New("parser-core phase zero: native child extends outside raw parent")
	}
	var err error
	r.DynamicPrecedence, err = checkedSelectedPrecedence(r.DynamicPrecedence, precedence)
	return err
}

func nativeProjectionEmitParent(sink NativeProjectionSink, r NativeProjectionRecord, ids []SelectedNodeID) (SelectedNodeID, error) {
	for _, id := range ids {
		child, err := sink.Read(id)
		if err != nil {
			return 0, err
		}
		if err := r.IncludeChild(child.StartByte, child.EndByte, child.DynamicPrecedence); err != nil {
			return 0, err
		}
	}
	return sink.Emit(r, ids)
}

func nativeProjectionApplyField(sink NativeProjectionSink, ids []SelectedNodeID, field FieldID) error {
	// A deeper direct entry wins for the complete hidden span. Extras never
	// receive fields, and an unrelated existing field remains unchanged.
	for _, id := range ids {
		r, err := sink.Read(id)
		if err != nil {
			return err
		}
		if r.Field == field {
			return nil
		}
	}
	for _, id := range ids {
		r, err := sink.Read(id)
		if err != nil {
			return err
		}
		if r.Field != 0 || r.Extra() {
			continue
		}
		r.Field = field
		if err := sink.Rewrite(id, r); err != nil {
			return err
		}
	}
	return nil
}

func nativeProjectionAddSupertype(sink NativeProjectionSink, ids []SelectedNodeID, mask uint32) error {
	for _, id := range ids {
		r, err := sink.Read(id)
		if err != nil {
			return err
		}
		r.SupertypeMask |= mask
		if err := sink.Rewrite(id, r); err != nil {
			return err
		}
	}
	return nil
}

func (a *NativeProjectionSinkAdapter[T]) EmitParent(r NativeProjectionRecord, ids []SelectedNodeID) (SelectedNodeID, error) {
	if a.ConstructParent != nil {
		return a.ConstructParent(a.Context, r, ids)
	}
	return nativeProjectionEmitParent(a, r, ids)
}

func (a *NativeProjectionSinkAdapter[T]) ApplyField(ids []SelectedNodeID, field FieldID) error {
	if a.AssignField != nil {
		return a.AssignField(a.Context, ids, field)
	}
	return nativeProjectionApplyField(a, ids, field)
}

func (a *NativeProjectionSinkAdapter[T]) AddSupertype(ids []SelectedNodeID, mask uint32) error {
	if a.IncludeSupertype != nil {
		return a.IncludeSupertype(a.Context, ids, mask)
	}
	return nativeProjectionAddSupertype(a, ids, mask)
}
