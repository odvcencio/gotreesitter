package parsercorephase0

import (
	"math"
	"testing"
)

func TestNativeProjectionConstructionCheckedChildOrder(t *testing.T) {
	for _, tc := range []struct {
		name     string
		initial  int32
		children []int32
		want     int32
		fail     bool
	}{
		{"sum", 3, []int32{4, -2}, 5, false},
		{"positive_boundary", math.MaxInt32 - 1, []int32{1}, math.MaxInt32, false},
		{"negative_boundary", math.MinInt32 + 1, []int32{-1}, math.MinInt32, false},
		{"positive_intermediate_overflow", math.MaxInt32, []int32{1, -1}, 0, true},
		{"negative_intermediate_overflow", math.MinInt32, []int32{-1, 1}, 0, true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			r := NativeProjectionRecord{StartByte: 2, EndByte: 9, DynamicPrecedence: tc.initial}
			var err error
			for _, score := range tc.children {
				if err = r.IncludeChild(3, 8, score); err != nil {
					break
				}
			}
			if (err != nil) != tc.fail || err == nil && r.DynamicPrecedence != tc.want {
				t.Fatalf("score=%d err=%v", r.DynamicPrecedence, err)
			}
		})
	}
	for _, span := range [][2]uint32{{1, 8}, {3, 10}} {
		r := NativeProjectionRecord{StartByte: 2, EndByte: 9, DynamicPrecedence: 17}
		if err := r.IncludeChild(span[0], span[1], 3); err == nil || r.DynamicPrecedence != 17 {
			t.Fatal("out-of-parent child changed score or was accepted")
		}
	}
}

func TestNativeProjectionConstructionAdapterFallback(t *testing.T) {
	s := nativeWalkTestSink{records: []NativeProjectionRecord{
		{StartByte: 1, EndByte: 2, Field: 3, DynamicPrecedence: 5},
		{StartByte: 2, EndByte: 3, Flags: uint16(selectedNodeFlagExtra), DynamicPrecedence: -1},
		{StartByte: 3, EndByte: 4},
	}}
	a := NativeProjectionSinkAdapter[nativeWalkTestSink]{Context: &s, EmitRecord: (*nativeWalkTestSink).Emit, ReadRecord: (*nativeWalkTestSink).Read, RewriteRecord: (*nativeWalkTestSink).Rewrite}
	ids := []SelectedNodeID{1, 2, 3}
	if err := a.ApplyField(ids, 3); err != nil {
		t.Fatal(err)
	}
	if s.records[2].Field != 0 {
		t.Fatal("deeper direct field did not own its span")
	}
	if err := a.ApplyField(ids, 7); err != nil {
		t.Fatal(err)
	}
	if s.records[0].Field != 3 || s.records[1].Field != 0 || s.records[2].Field != 7 {
		t.Fatal("field assignment changed existing field or extra")
	}
	if err := a.AddSupertype(ids, 4); err != nil {
		t.Fatal(err)
	}
	r := NativeProjectionRecord{StartByte: 0, EndByte: 5, ChildCount: 3, DynamicPrecedence: 2}
	id, err := a.EmitParent(r, ids)
	if err != nil || id != 4 || s.records[3].DynamicPrecedence != 6 {
		t.Fatalf("parent %d err=%v records=%+v", id, err, s.records)
	}
	for _, r := range s.records[:3] {
		if r.SupertypeMask != 4 {
			t.Fatal("supertype missing")
		}
	}
}
