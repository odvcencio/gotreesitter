set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly' GTS_ADMISSION_CANDIDATE=0
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
sha256sum --quiet -c /controls/combined-correctness/v13/source.sha256
python3 /controls/combined-v13/verify-sources.py
sha256sum /controls/combined-v13/attribution-v18/{overlay.json,bench_test.go,transient_parents.go} > /evidence/inputs.sha256
scratch=/runtime/tmp/gts-combined-v13-attribution-v18
mkdir -p "$scratch"
for arm in baseline candidate; do
 cd "/$arm"
 go test -c -overlay=/controls/combined-v13/attribution-v18/overlay.json -tags gts_parsercorephase0 -o "$scratch/$arm.test" . > "/evidence/$arm-build.log" 2>&1
done
for seed in 1 9; do
 for arm in baseline candidate; do
  cd "/$arm"
  GTS_BENCHMARK_SEED=$seed GODEBUG=gctrace=1 "$scratch/$arm.test" -test.run '^$' -test.bench '^BenchmarkGTSAuthenticatedReuse$' -test.benchtime=750ms -test.count=1 -test.benchmem -test.shuffle="$seed" > "/evidence/$arm-$seed.log" 2>&1
 done
done
sha256sum "$scratch/"*.test > /evidence/binary.sha256
sha256sum --quiet -c /evidence/inputs.sha256
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
sha256sum --quiet -c /controls/combined-correctness/v13/source.sha256
python3 /controls/combined-v13/verify-sources.py
