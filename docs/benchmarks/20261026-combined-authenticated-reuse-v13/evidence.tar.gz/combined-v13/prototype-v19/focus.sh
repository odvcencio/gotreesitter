set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly' GTS_ADMISSION_CANDIDATE=0
git config --global --add safe.directory /candidate
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
sha256sum --quiet -c /controls/combined-correctness/v13/source.sha256
python3 /controls/combined-v13/verify-sources.py
sha256sum /controls/combined-v13/prototype-v19/{overlay.json,transient_parents.go,shared_dag_test.go} > /evidence/input.sha256
cd /candidate
go test -overlay=/controls/combined-v13/prototype-v19/overlay.json -tags gts_parsercorephase0 -run '^Test(TransientParentMaterialize|TransientParentScratch|TransientScratchCheckpoint|TransientChildScratch|.*Recover.*Cycle|AuthenticatedReuse|AuthenticatedLanguage|PrimitiveProbeIntoContract|CompactReuseDependencyPublicationOverflowSlab)' -count=1 -v -timeout=10m . > /evidence/tests.log 2>&1
go test -overlay=/controls/combined-v13/prototype-v19/overlay.json ./internal/incr -run '^Test(GroupedReadProducerAuthorityLifecycle|ReadWordPages|PagedReadHistory|Lookahead)' -count=1 -v -timeout=5m > /evidence/incr.log 2>&1
sha256sum --quiet -c /evidence/input.sha256
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
sha256sum --quiet -c /controls/combined-correctness/v13/source.sha256
python3 /controls/combined-v13/verify-sources.py
