set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly' GTS_ADMISSION_CANDIDATE=0
git config --global --add safe.directory /candidate
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
sha256sum --quiet -c /controls/combined-correctness/v13/source.sha256
python3 /controls/combined-v13/verify-sources.py
sha256sum /controls/combined-v13/prototype-v26/{overlay.json,transient_parents.go,parser_scratch.go,parser.go,identity_set.go,identity_set_test.go,shared_dag_test.go,budget_test.go,transient_children_test.go,partial_stop_test.go,lookahead.go,read_words.go,read_group_test.go} > /evidence/input.sha256
cd /candidate
go test -overlay=/controls/combined-v13/prototype-v26/overlay.json -tags gts_parsercorephase0 -run '^Test(PrototypeIdentitySet|TransientParentPartialBudgetStop|TransientParentMaterialize|TransientParentScratch|TransientScratchCheckpoint|TransientChildScratch|.*Recover.*Cycle|AuthenticatedReuse|AuthenticatedLanguage|PrimitiveProbeIntoContract|CompactReuseDependencyPublicationOverflowSlab)' -count=1 -v -timeout=10m . > /evidence/tests.log 2>&1
go test -overlay=/controls/combined-v13/prototype-v26/overlay.json ./internal/incr -run '^Test(EightPageReservation|IdentitySetCollisionsGrowthAndClearing|GroupedReadProducerAuthorityLifecycle|ReadWordPages|PagedReadHistory|Lookahead)' -count=1 -v -timeout=5m > /evidence/incr.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test -c -overlay=/controls/combined-v13/prototype-v26/overlay.json -o /evidence/incr386.test ./internal/incr > /evidence/build386.log 2>&1
/evidence/incr386.test -test.run '^TestEightPageReservationChecks32BitSliceArithmetic$' -test.count=1 -test.v > /evidence/test386.log 2>&1
sha256sum --quiet -c /evidence/input.sha256
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
sha256sum --quiet -c /controls/combined-correctness/v13/source.sha256
python3 /controls/combined-v13/verify-sources.py
