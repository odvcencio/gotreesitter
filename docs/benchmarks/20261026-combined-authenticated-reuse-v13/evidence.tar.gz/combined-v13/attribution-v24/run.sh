set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GTS_ADMISSION_CANDIDATE=0 GTS_FRESH_MEMORY_LANG=go
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
sha256sum --quiet -c /controls/combined-correctness/v13/source.sha256
sha256sum --quiet -c /controls/out-combined-v21-warm-1m/binary.sha256
python3 /controls/combined-v13/verify-sources.py
scratch=/runtime/tmp/gts-combined-v21-warm-1m
for arm in baseline candidate; do
 cd "/$arm/roottest/bench"
 GODEBUG=gctrace=1 "$scratch/$arm.test" -test.run '^$' -test.bench '^BenchmarkFreshMemory$/^go$/^1024KiB$' -test.benchtime=2x -test.count=1 -test.benchmem -test.shuffle=154001 -test.timeout=5m -test.memprofile="/evidence/$arm.pprof" -test.memprofilerate=1 > "/evidence/$arm.log" 2>&1
 go tool pprof -top -alloc_objects -nodecount=50 "$scratch/$arm.test" "/evidence/$arm.pprof" > "/evidence/$arm-objects.txt" 2>&1
 go tool pprof -top -alloc_space -nodecount=50 "$scratch/$arm.test" "/evidence/$arm.pprof" > "/evidence/$arm-space.txt" 2>&1
done
go tool pprof -top -alloc_objects -nodecount=50 -base /evidence/baseline.pprof "$scratch/candidate.test" /evidence/candidate.pprof > /evidence/diff-objects.txt 2>&1
go tool pprof -top -alloc_space -nodecount=50 -base /evidence/baseline.pprof "$scratch/candidate.test" /evidence/candidate.pprof > /evidence/diff-space.txt 2>&1
sha256sum --quiet -c /controls/out-combined-v21-warm-1m/binary.sha256
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
sha256sum --quiet -c /controls/combined-correctness/v13/source.sha256
python3 /controls/combined-v13/verify-sources.py
