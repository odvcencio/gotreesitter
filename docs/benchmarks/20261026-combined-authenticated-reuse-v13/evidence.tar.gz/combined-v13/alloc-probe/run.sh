set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly' GTS_ADMISSION_CANDIDATE=0 GTS_BENCHMARK_SEED=1
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
python3 /controls/combined-v13/verify-sources.py
scratch=/runtime/tmp/gts-combined-v13-alloc-probe
mkdir -p "$scratch"
sha256sum /controls/combined-v13/alloc-probe/{overlay.json,trace_test.go} > /evidence/controls.sha256
for arm in baseline candidate; do
 cd "/$arm"
 go test -c -overlay=/controls/combined-v13/alloc-probe/overlay.json -tags gts_parsercorephase0 -o "$scratch/$arm.test" . > "/evidence/$arm-build.log" 2>&1
 "$scratch/$arm.test" -test.run '^$' -test.bench '^BenchmarkCombinedFullAllocationTrace$' -test.benchtime=20x -test.count=1 > "/evidence/$arm-trace.log" 2>&1
 "$scratch/$arm.test" -test.run '^$' -test.bench '^BenchmarkGTSAuthenticatedReuse$/^Report137KiBFull$' -test.benchtime=10s -test.count=1 -test.memprofile="/evidence/$arm.pprof" -test.memprofilerate=1 > "/evidence/$arm-profile.log" 2>&1
 go tool pprof -top -alloc_space -nodecount=35 "$scratch/$arm.test" "/evidence/$arm.pprof" > "/evidence/$arm-alloc-space.txt"
done
sha256sum "$scratch/"*.test > /evidence/binary.sha256
sha256sum --quiet -c /evidence/controls.sha256
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
python3 /controls/combined-v13/verify-sources.py
