package gotreesitter_test

import (
	"fmt"
	"runtime"
	"testing"

	"github.com/odvcencio/gotreesitter"
	"github.com/odvcencio/gotreesitter/grammars"
)

// Diagnostic only: per-iteration accounting observes pool and GC variability.
func BenchmarkCombinedFullAllocationTrace(b *testing.B) {
	source := authenticatedBenchmarkSource(b)
	parser := gotreesitter.NewParser(grammars.GoLanguage())
	parser.SetAdmissionCandidateRoute(false)
	warm, err := parser.Parse(source)
	if err != nil || warm == nil || warm.RootNode() == nil || warm.RootNode().HasError() || warm.RootNode().EndByte() != uint32(len(source)) {
		b.Fatalf("warm parse: %v", err)
	}
	warm.Release()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		var before, after runtime.MemStats
		runtime.ReadMemStats(&before)
		tree, err := parser.Parse(source)
		if err != nil || tree == nil || tree.RootNode() == nil || tree.RootNode().HasError() || tree.RootNode().EndByte() != uint32(len(source)) {
			b.Fatalf("parse: %v", err)
		}
		tree.Release()
		runtime.ReadMemStats(&after)
		fmt.Printf("TRACE iteration=%d bytes=%d allocs=%d gc=%d\n", i, after.TotalAlloc-before.TotalAlloc, after.Mallocs-before.Mallocs, after.NumGC-before.NumGC)
	}
}
