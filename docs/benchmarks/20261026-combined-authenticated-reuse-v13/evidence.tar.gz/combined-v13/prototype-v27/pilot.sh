set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly -overlay=/controls/combined-v13/prototype-v27/overlay.json' GTS_ADMISSION_CANDIDATE=0
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
sha256sum --quiet -c /controls/combined-correctness/v13/source.sha256
python3 /controls/combined-v13/verify-sources.py
sha256sum /controls/combined-v13/prototype-v27/{overlay.json,transient_parents.go,parser_scratch.go,parser.go,identity_set.go,identity_set_test.go,shared_dag_test.go,budget_test.go,transient_children_test.go,partial_stop_test.go,lookahead.go,read_words.go,read_group_test.go} > /evidence/prototype.sha256
python3 - <<'PY'
import json
from pathlib import Path
c=json.loads(Path('/controls/out-combined-v27-counters/summary.json').read_text());assert c['languages']==206 and c['ledger_exports_byte_identical'] and c['work_and_reuse_direction_passed']
PY
cd /candidate
bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/before.txt --output /evidence/after.txt --runs 4 --seed-start 53 --benchtime 750ms --bench-regex '^BenchmarkGTSAuthenticatedReuse$' --require-benchmarks 'BenchmarkGTSAuthenticatedReuse/BenchmarkGoParseFullDFA,BenchmarkGTSAuthenticatedReuse/BenchmarkGoParseIncrementalSingleByteEditDFA,BenchmarkGTSAuthenticatedReuse/BenchmarkGoParseIncrementalNoEditDFA,BenchmarkGTSAuthenticatedReuse/Report137KiBFull,BenchmarkGTSAuthenticatedReuse/Report137KiBEdit,BenchmarkGTSAuthenticatedReuse/Report137KiBEditProfiled' --lock-path /runtime/tmp/gts-combined-v27-pilot.lock > /evidence/randomized.log 2>&1
sha256sum --quiet -c /evidence/prototype.sha256
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
sha256sum --quiet -c /controls/combined-correctness/v13/source.sha256
python3 /controls/combined-v13/verify-sources.py
