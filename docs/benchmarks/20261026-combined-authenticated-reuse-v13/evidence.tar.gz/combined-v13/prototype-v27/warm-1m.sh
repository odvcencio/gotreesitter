set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly' GTS_ADMISSION_CANDIDATE=0 GTS_FRESH_MEMORY_LANG=go
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
sha256sum --quiet -c /controls/combined-correctness/v13/source.sha256
python3 /controls/combined-v13/verify-sources.py
sha256sum /controls/combined-v13/prototype-v27/{warm-overlay.json,warm_fixture_test.go,overlay.json,transient_parents.go,parser_scratch.go,parser.go,identity_set.go,lookahead.go,read_words.go,read_group_test.go} > /evidence/input.sha256
scratch=/runtime/tmp/gts-combined-v27-warm-1m
mkdir -p "$scratch"
for arm in baseline candidate; do
 cd "/$arm/roottest/bench"
 go test -overlay=/controls/combined-v13/prototype-v27/warm-overlay.json -tags gts_parsercorephase0 -run '^TestV21FreshMemoryFixtureIdentity$' -count=1 -v > "/evidence/$arm-fixture.log" 2>&1
 go test -c -overlay=/controls/combined-v13/prototype-v27/warm-overlay.json -tags gts_parsercorephase0 -o "$scratch/$arm.test" . > "/evidence/$arm-build.log" 2>&1
done
for seed in 154001 154002 154003 154004; do
 arms=(baseline candidate); if ((seed%2==0)); then arms=(candidate baseline); fi
 for arm in "${arms[@]}"; do
  cd "/$arm/roottest/bench"
  /usr/bin/time -v -o "/evidence/$arm-$seed.time" "$scratch/$arm.test" -test.run '^$' -test.bench '^BenchmarkFreshMemory$/^go$/^1024KiB$' -test.benchtime=2x -test.count=1 -test.benchmem -test.shuffle="$seed" -test.timeout=5m > "/evidence/$arm-$seed.log" 2>&1
 done
done
sha256sum "$scratch/"*.test > /evidence/binary.sha256
sha256sum --quiet -c /evidence/input.sha256
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
sha256sum --quiet -c /controls/combined-correctness/v13/source.sha256
python3 /controls/combined-v13/verify-sources.py
