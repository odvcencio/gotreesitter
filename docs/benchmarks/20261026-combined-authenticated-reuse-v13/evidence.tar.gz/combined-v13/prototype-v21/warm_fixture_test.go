package bench_test

import (
	"crypto/sha256"
	"fmt"
	"github.com/odvcencio/gotreesitter/internal/benchfixtures"
	"testing"
)

func TestV21FreshMemoryFixtureIdentity(t *testing.T) {
	source, _, err := benchfixtures.GeneratedSource("go", 1024*1024)
	if err != nil {
		t.Fatal(err)
	}
	sum := fmt.Sprintf("%x", sha256.Sum256(source))
	if len(source) != 1048591 || sum != "76c70b62127085d3c791ba98a24cba9f22bd343e40afb43522bbb5041cede524" {
		t.Fatalf("fixture bytes=%d sha256=%s", len(source), sum)
	}
	t.Logf("bytes=%d sha256=%s", len(source), sum)
}
