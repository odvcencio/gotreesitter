set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /baseline
git config --global --add safe.directory /candidate
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
python3 /controls/combined-v13/verify-sources.py
sha256sum /controls/combined-v13/prototype-v21/{overlay.json,transient_parents.go,parser_scratch.go,parser.go,identity_set.go,identity_set_test.go,shared_dag_test.go,budget_test.go,transient_children_test.go,partial_stop_test.go,summarize-counters.py} > /evidence/prototype.sha256
scratch=/runtime/tmp/gts-combined-v21-counters
mkdir -p "$scratch" /evidence/records /evidence/diffs
for arm in baseline candidate; do
 cd "/$arm"
 extra=(-overlay=/controls/combined-v13/prototype-v21/overlay.json)
 go build "${extra[@]}" -tags gts_parsercorephase0 -o "$scratch/$arm-ledger" ./cmd/perfcounterledger
 go build "${extra[@]}" -tags gts_parsercorephase0,gts_workcount -o "$scratch/$arm-work" /prior-controls/recovery-work-main.go
 for assignment in 0 1; do GTS_PROBE_ASSIGNMENT=$assignment "$scratch/$arm-work" > "/evidence/$arm-work-$assignment.log" 2>&1; done
done
sha256sum "$scratch/"* > /evidence/binary.sha256
python3 - <<'PY' > /evidence/languages.txt
import json
names=sorted({e['language'] for e in json.load(open('/candidate/internal/benchfixtures/real_corpus.json'))['entries'] if e['role']=='sample'})
assert len(names)==206
print('\n'.join(names))
PY
fail=0
while IFS= read -r lang; do
 for route in default candidate; do
  mode=0; if [[ "$route" == candidate ]]; then mode=1; fi
  for arm in baseline candidate; do
   cd "/$arm"
   if ! GTS_ADMISSION_CANDIDATE=$mode timeout --foreground --kill-after=5s 45s "$scratch/$arm-ledger" --child-route "$route" --langs "$lang" > "/evidence/records/$lang-$route-$arm.json" 2> "/evidence/records/$lang-$route-$arm.stderr"; then echo "$lang $route $arm FAILED"; fail=1; fi
  done
  if ! cmp -s "/evidence/records/$lang-$route-baseline.json" "/evidence/records/$lang-$route-candidate.json"; then diff -u "/evidence/records/$lang-$route-baseline.json" "/evidence/records/$lang-$route-candidate.json" > "/evidence/diffs/$lang-$route.diff" || true; echo "$lang $route DIFF"; fail=1; fi
 done
 echo "$lang complete"
done < /evidence/languages.txt
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
python3 /controls/combined-v13/verify-sources.py
sha256sum --quiet -c /evidence/binary.sha256
if ((fail)); then exit 1; fi
python3 /controls/combined-v13/prototype-v21/summarize-counters.py

sha256sum --quiet -c /evidence/prototype.sha256
