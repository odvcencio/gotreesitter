import json
from pathlib import Path
p=Path('/evidence');arms={}
for arm in ('baseline','candidate'):
 rows={}
 for assignment in (0,1):
  data=[json.loads(x[5:]) for x in (p/f'{arm}-work-{assignment}.log').read_text().splitlines() if x.startswith('WORK ')]
  assert len(data)==12
  for row in data:
   key=tuple(row[k] for k in ('assignment','candidate','kind','phase'));assert key not in rows
   w=row['work'];assert w['contract']=='gts-work-count/v2' and not w['overflow']
   for name in w['outside_attempt']:
    assert w[name]==w['outside_attempt'][name]+sum(a['counters'][name] for a in w['attempts'] or [])
    for a in w['attempts'] or []: assert a['counters'][name]==sum(a[x][name] for x in ('entry_to_caps','caps_to_finalize','finalize'))
   rows[key]=row
 arms[arm]=rows
assert arms['baseline'].keys()==arms['candidate'].keys() and len(arms['baseline'])==24
changes=[]
for key,b in arms['baseline'].items():
 a=arms['candidate'][key]
 for k in ('assignment','candidate','kind','phase','has_error','end_byte'):assert a[k]==b[k]
 for name in b['work']['outside_attempt']:
  old,new=b['work'][name],a['work'][name]
  if old!=new:changes.append({'operation':key,'counter':name,'before':old,'after':new})
  if name in ('selected_nodes','selected_parent_nodes','selected_leaf_nodes'):assert new>=old,(key,name,old,new)
  else:assert new<=old,(key,name,old,new)
 for name,old in (b['selected'] or {}).items():
  new=a['selected'][name]
  if old!=new:
   assert name in ('ArenaBaselineBytes','ArenaBytesAllocated','ScratchBaselineBytes','ScratchBytesAllocated'),(key,name,old,new)
   changes.append({'operation':key,'counter':'selected.'+name,'before':old,'after':new})
(p/'summary.json').write_text(json.dumps({'languages':206,'routes_per_language':2,'ledger_exports_byte_identical':True,'operations_per_arm':24,'work_and_reuse_direction_passed':True,'changes':changes},indent=2)+'\n')
