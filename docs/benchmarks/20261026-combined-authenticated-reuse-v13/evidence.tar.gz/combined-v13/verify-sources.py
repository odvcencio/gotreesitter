import hashlib,json,subprocess
from pathlib import Path
base='e079b642fa1c11a3c9bd939d367e05598fc8162f'
root=Path('/candidate'); controls=Path('/controls/combined-v13')
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).splitlines()
assert subprocess.check_output(['git','rev-parse',base],cwd=root,text=True).strip()==base
changed=set(git('diff','--name-only',base,'--','*.go'))|set(git('ls-files','--others','--exclude-standard','*.go'))
replacements=json.loads((controls/'perf.json').read_text())['Replace']
paths={k.removeprefix('/baseline/') for k in replacements if k.startswith('/baseline/') and not k.endswith('/authenticated_reuse_benchmark_private_test.go')}
assert changed==paths,(sorted(changed-paths),sorted(paths-changed))
for f in paths:
 src=subprocess.run(['git','show',base+':'+f],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 target=replacements['/baseline/'+f]
 if src.returncode: assert target=='',f
 else: assert target and Path(target).read_bytes()==src.stdout,f
assert not git('diff','--name-only',base,'--','go.mod','go.sum','grammars/grammar_blobs','testdata/real','internal/benchfixtures/real_corpus.json')
print('exact e079 sparse baseline and unchanged non-Go inputs verified')
