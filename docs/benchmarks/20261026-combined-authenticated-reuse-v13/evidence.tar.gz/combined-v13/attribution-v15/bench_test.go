package gotreesitter_test

import (
	"bytes"
	"crypto/sha256"
	"fmt"
	"math/rand"
	"os"
	"runtime"
	"runtime/pprof"
	"strconv"
	"testing"
	"time"

	"github.com/odvcencio/gotreesitter"
	"github.com/odvcencio/gotreesitter/grammars"
)

func authenticatedBenchmarkSource(b *testing.B) []byte {
	b.Helper()
	var source bytes.Buffer
	source.WriteString("package main\n\nimport \"fmt\"\n\n")
	for i := 0; source.Len() < 137*1024; i++ {
		fmt.Fprintf(&source, "func f%d(a int, b int) int {\n\tx := a + b\n\tfmt.Println(\"f%d\", x)\n\treturn x\n}\n\n", i, i)
	}
	if source.Len() != 140368 || source.Bytes()[57] != 'x' || fmt.Sprintf("%x", sha256.Sum256(source.Bytes())) != "5434575bb249338937331c3756e10dcec34237d107f523ea315996fb6de0ef8f" {
		b.Fatal("original report fixture drifted")
	}
	return source.Bytes()
}

func diagnosticAllocSnapshot(path string) {
	file, err := os.Create(path)
	if err != nil {
		panic(err)
	}
	defer file.Close()
	if err := pprof.Lookup("allocs").WriteTo(file, 0); err != nil {
		panic(err)
	}
}

func authenticatedBenchmarkFull(b *testing.B) {
	os.Setenv("GTS_TRACE_FULL_ALLOC", "1")
	defer os.Unsetenv("GTS_TRACE_FULL_ALLOC")
	source := authenticatedBenchmarkSource(b)
	parser := gotreesitter.NewParser(grammars.GoLanguage())
	parser.SetAdmissionCandidateRoute(false)
	diagnosticAllocSnapshot(os.Getenv("GTS_DIAG_OUTPUT") + "-before.pprof")
	b.ReportAllocs()
	b.SetBytes(int64(len(source)))
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		println("FULL_ITER_BEGIN", i, "N", b.N)
		tree, err := parser.Parse(source)
		if err != nil || tree == nil || tree.RootNode().HasError() || tree.RootNode().EndByte() != uint32(len(source)) {
			b.Fatalf("fresh parse failed: %v", err)
		}
		tree.Release()
		println("FULL_ITER_END", i)
	}
	b.StopTimer()
	println("PROFILE_POST_TIMER_FORCED_GC")
	runtime.GC()
	runtime.GC()
	diagnosticAllocSnapshot(os.Getenv("GTS_DIAG_OUTPUT") + "-after.pprof")
}

// Both arms repeatedly grow and shrink the original report's identifier.
// Immutable input buffers, Tree.Edit, parsing, and old-tree release are identical.
// The first parse and final release are outside the measured operation.
func authenticatedBenchmarkEdit(b *testing.B, profiled bool) {
	source := authenticatedBenchmarkSource(b)
	grown := append(append(append([]byte{}, source[:57]...), 'x'), source[57:]...)
	inputs := [2][]byte{grown, source}
	edits := [2]gotreesitter.InputEdit{
		{StartByte: 57, OldEndByte: 57, NewEndByte: 58, StartPoint: gotreesitter.Point{Row: 5, Column: 1}, OldEndPoint: gotreesitter.Point{Row: 5, Column: 1}, NewEndPoint: gotreesitter.Point{Row: 5, Column: 2}},
		{StartByte: 57, OldEndByte: 58, NewEndByte: 57, StartPoint: gotreesitter.Point{Row: 5, Column: 1}, OldEndPoint: gotreesitter.Point{Row: 5, Column: 2}, NewEndPoint: gotreesitter.Point{Row: 5, Column: 1}},
	}
	parser := gotreesitter.NewParser(grammars.GoLanguage())
	parser.SetAdmissionCandidateRoute(false)
	tree, err := parser.Parse(source)
	if err != nil || tree == nil || tree.RootNode().HasError() {
		b.Fatalf("initial parse failed: %v", err)
	}
	var editNS, reuseNS, reparseNS int64
	var reusedBytes, newNodes uint64
	b.ReportAllocs()
	b.SetBytes(int64(len(source)))
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		index := i & 1
		if profiled {
			start := time.Now()
			tree.Edit(edits[index])
			editNS += time.Since(start).Nanoseconds()
		} else {
			tree.Edit(edits[index])
		}
		old := tree
		if profiled {
			var profile gotreesitter.IncrementalParseProfile
			tree, profile, err = parser.ParseIncrementalProfiled(inputs[index], old)
			reuseNS += profile.ReuseCursorNanos
			reparseNS += profile.ReparseNanos
			reusedBytes += profile.ReusedBytes
			newNodes += profile.NewNodesAllocated
		} else {
			tree, err = parser.ParseIncremental(inputs[index], old)
		}
		if err != nil || tree == nil || tree.RootNode().HasError() || tree.RootNode().EndByte() != uint32(len(inputs[index])) {
			b.Fatalf("edit %d failed: %v", i, err)
		}
		if tree != old {
			old.Release()
		}
	}
	b.StopTimer()
	tree.Release()
	if profiled {
		b.ReportMetric(float64(editNS)/float64(b.N), "tree-edit-ns/op")
		b.ReportMetric(float64(reuseNS)/float64(b.N), "reuse-ns/op")
		b.ReportMetric(float64(reparseNS)/float64(b.N), "reparse-ns/op")
		b.ReportMetric(float64(reusedBytes)/float64(b.N), "reused-bytes/op")
		b.ReportMetric(float64(newNodes)/float64(b.N), "new-nodes/op")
	}
}

func BenchmarkGTSAuthenticatedReuse(b *testing.B) {
	seed, err := strconv.ParseInt(os.Getenv("GTS_BENCHMARK_SEED"), 10, 64)
	if err != nil {
		b.Fatalf("GTS_BENCHMARK_SEED must contain an integer: %v", err)
	}
	cases := []struct {
		name string
		run  func(*testing.B)
	}{
		{"BenchmarkGoParseFullDFA", BenchmarkGoParseFullDFA},
		{"BenchmarkGoParseIncrementalSingleByteEditDFA", BenchmarkGoParseIncrementalSingleByteEditDFA},
		{"BenchmarkGoParseIncrementalNoEditDFA", BenchmarkGoParseIncrementalNoEditDFA},
		{"Report137KiBFull", authenticatedBenchmarkFull},
		{"Report137KiBEdit", func(b *testing.B) { authenticatedBenchmarkEdit(b, false) }},
		{"Report137KiBEditProfiled", func(b *testing.B) { authenticatedBenchmarkEdit(b, true) }},
	}
	rand.New(rand.NewSource(seed)).Shuffle(len(cases), func(i, j int) { cases[i], cases[j] = cases[j], cases[i] })
	for _, test := range cases {
		b.Run(test.name, test.run)
	}
}
