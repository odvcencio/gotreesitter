package gotreesitter

import (
	"github.com/odvcencio/gotreesitter/internal/incr"
	"unsafe"
)

type transientParentScratch struct {
	slabs             []transientParentSlab
	slabCursor        int
	allocatedBytes    int64
	nodesAllocated    uint64
	nodesMaterialized uint64
	seen              incr.IdentitySet[Node]
	frames            []transientParentFrame
}

type transientParentSlab struct {
	data []Node
	used int
}

type transientParentFrame struct {
	node    *Node
	visited bool
}

func (s *transientParentScratch) allocParent(arena *nodeArena, sym Symbol, named bool, children []*Node, productionID uint16, trackChildErrors bool) *Node {
	if s == nil {
		return newParentNodeInArenaNoLinksWithFieldSources(arena, sym, named, children, nil, nil, productionID, trackChildErrors)
	}
	if len(s.slabs) == 0 {
		capacity := max(defaultTransientParentSlabCap(), minArenaNodeCap)
		s.slabs = append(s.slabs, transientParentSlab{data: make([]Node, capacity)})
		s.allocatedBytes += nodeStructBytesForCap(capacity)
		s.slabCursor = 0
	}
	if s.slabCursor < 0 || s.slabCursor >= len(s.slabs) {
		s.slabCursor = 0
	}
	for i := s.slabCursor; ; i++ {
		if i >= len(s.slabs) {
			lastCap := len(s.slabs[len(s.slabs)-1].data)
			capacity := boundedNextSlabCap(lastCap, minArenaNodeCap, int(unsafe.Sizeof(Node{})))
			s.slabs = append(s.slabs, transientParentSlab{data: make([]Node, capacity)})
			s.allocatedBytes += nodeStructBytesForCap(capacity)
		}
		slab := &s.slabs[i]
		if slab.used >= len(slab.data) {
			continue
		}
		idx := slab.used
		slab.used++
		s.slabCursor = i
		n := &slab.data[idx]
		n.symbol = sym
		n.setNamed(named)
		n.children = children
		n.clearFieldMetadata()
		n.productionID = productionID
		n.childIndex = -1
		populateParentNodeNoLinks(n, children, trackChildErrors)
		nodeInitEquivVersion(n)
		s.nodesAllocated++
		return n
	}
}

func defaultTransientParentSlabCap() int {
	size := int(unsafe.Sizeof(Node{}))
	if size <= 0 {
		return minArenaNodeCap
	}
	capacity := fullParseArenaSlab / size
	if capacity < minArenaNodeCap {
		return minArenaNodeCap
	}
	return capacity
}

func nodeStructBytesForCap(n int) int64 {
	if n <= 0 {
		return 0
	}
	return int64(n) * int64(unsafe.Sizeof(Node{}))
}

func (s *transientParentScratch) owns(node *Node) bool {
	if s == nil || node == nil {
		return false
	}
	ptr := uintptr(unsafe.Pointer(node))
	size := unsafe.Sizeof(Node{})
	for i := range s.slabs {
		data := s.slabs[i].data
		if len(data) == 0 {
			continue
		}
		start := uintptr(unsafe.Pointer(&data[0]))
		end := start + uintptr(len(data))*size
		if ptr < start || ptr >= end {
			continue
		}
		return (ptr-start)%size == 0
	}
	return false
}

func (s *transientParentScratch) ownsActive(node *Node) bool {
	if s == nil || node == nil {
		return false
	}
	ptr := unsafe.Pointer(node)
	for i := range s.slabs {
		slab := &s.slabs[i]
		if usedArenaSliceContainsPointer(slab.data, slab.used, ptr) {
			return true
		}
	}
	return false
}

func (s *transientParentScratch) materializeEntriesUntil(entries []stackEntry, arena *nodeArena, childScratch *transientChildScratch, p *Parser) ParseStopReason {
	return s.materializeEntriesModeUntil(entries, arena, childScratch, p, false)
}

// materializeEntriesForRecycleUntil also follows raw-shape-only edges. Normal
// final-result materialization need not retain those parser-internal nodes, but
// checkpoint callers will reuse the transient slabs while parsing continues,
// so every sidecar pointer must be rebound to an arena clone first.
func (s *transientParentScratch) materializeEntriesForRecycleUntil(entries []stackEntry, arena *nodeArena, childScratch *transientChildScratch, p *Parser) ParseStopReason {
	return s.materializeEntriesModeUntil(entries, arena, childScratch, p, true)
}

func (s *transientParentScratch) materializeEntriesModeUntil(entries []stackEntry, arena *nodeArena, childScratch *transientChildScratch, p *Parser, preserveRawShapes bool) ParseStopReason {
	if s == nil || len(entries) == 0 || arena == nil {
		return ParseStopNone
	}
	defer s.clearMaterializeScratch()
	roots := make([]*Node, 0, len(entries))
	for i := range entries {
		if i&63 == 0 {
			if reason := p.resultMaterializationStopReason(arena); resultMaterializationShouldStop(reason) {
				return reason
			}
		}
		if node := stackEntryNode(entries[i]); node != nil {
			roots = append(roots, node)
		}
	}
	if reason := s.materializeNodesUntil(roots, arena, childScratch, p, preserveRawShapes); resultMaterializationShouldStop(reason) {
		return reason
	}
	for i := range entries {
		if i&63 == 0 {
			if reason := p.resultMaterializationStopReason(arena); resultMaterializationShouldStop(reason) {
				return reason
			}
		}
		node := stackEntryNode(entries[i])
		if node == nil {
			continue
		}
		if replacement := s.transientReplacement(node); replacement != nil {
			setStackEntryNode(&entries[i], replacement)
			continue
		}
		if s.seen.Contains(node) {
			setStackEntryNode(&entries[i], node)
		}
	}
	return ParseStopNone
}

func (s *transientParentScratch) materializeNodeSliceUntil(nodes []*Node, arena *nodeArena, childScratch *transientChildScratch, p *Parser) ParseStopReason {
	if s == nil || len(nodes) == 0 || arena == nil {
		return ParseStopNone
	}
	defer s.clearMaterializeScratch()
	if reason := s.materializeNodesUntil(nodes, arena, childScratch, p, false); resultMaterializationShouldStop(reason) {
		return reason
	}
	for i := range nodes {
		if i&63 == 0 {
			if reason := p.resultMaterializationStopReason(arena); resultMaterializationShouldStop(reason) {
				return reason
			}
		}
		if replacement := s.transientReplacement(nodes[i]); replacement != nil {
			nodes[i] = replacement
			continue
		}

	}
	return ParseStopNone
}

func (s *transientParentScratch) materializeNodesUntil(nodes []*Node, arena *nodeArena, childScratch *transientChildScratch, p *Parser, preserveRawShapes bool) ParseStopReason {
	if s == nil || len(nodes) == 0 || arena == nil {
		return ParseStopNone
	}
	frames := s.frames[:0]
	defer func() {
		clear(frames[:cap(frames)])
		s.frames = frames[:0]
	}()
	for i := range nodes {
		if i&63 == 0 {
			if reason := p.resultMaterializationStopReason(arena); resultMaterializationShouldStop(reason) {
				return reason
			}
		}
		if nodes[i] != nil {
			frames = append(frames, transientParentFrame{node: nodes[i]})
		}
	}
	visited := 0
	for len(frames) > 0 {
		if visited&63 == 0 {
			if reason := p.resultMaterializationStopReason(arena); resultMaterializationShouldStop(reason) {
				return reason
			}
		}
		visited++
		frame := frames[len(frames)-1]
		frames = frames[:len(frames)-1]
		n := frame.node
		if n == nil {
			continue
		}
		if frame.visited {
			if reason := s.materializeVisitedNodeUntil(n, arena, childScratch, p, preserveRawShapes); resultMaterializationShouldStop(reason) {
				return reason
			}
			continue
		}
		var rawChildren []rawShapeChild
		if preserveRawShapes {
			rawChildren = arena.rawShapeChildrenForNode(n)
		}
		if s.owns(n) {
			if n.parent != nil {
				continue
			}
			n.parent = n
		} else {
			if len(n.children) == 0 && len(rawChildren) == 0 {
				continue
			}
			if s.seen.Contains(n) {
				continue
			}
		}
		frames = append(frames, transientParentFrame{node: n, visited: true})
		for i := len(n.children) - 1; i >= 0; i-- {
			child := n.children[i]
			if child != nil {
				frames = append(frames, transientParentFrame{node: child})
			}
		}
		for i := len(rawChildren) - 1; i >= 0; i-- {
			child := stackEntryNode(rawChildren[i].packedEntry)
			if child != nil {
				frames = append(frames, transientParentFrame{node: child})
			}
		}
	}
	return ParseStopNone
}

func (s *transientParentScratch) materializeVisitedNodeUntil(n *Node, arena *nodeArena, childScratch *transientChildScratch, p *Parser, preserveRawShapes bool) ParseStopReason {
	if n == nil {
		return ParseStopNone
	}
	children := n.children
	if len(children) > 0 {
		out := children
		if childScratch != nil && childScratch.owns(children) {
			out = arena.allocNodeSliceNoClear(len(children))
			copy(out, children)
			childScratch.slicesMaterialized++
			childScratch.pointersMaterialized += uint64(len(children))
		}
		for i, child := range out {
			if i&63 == 0 {
				if reason := p.resultMaterializationStopReason(arena); resultMaterializationShouldStop(reason) {
					return reason
				}
			}
			if replacement := s.transientReplacement(child); replacement != nil {
				if replacement == n {
					return ParseStopInvariantViolation
				}
				out[i] = replacement
				continue
			}
			if s.seen.Contains(child) && child == n {
				return ParseStopInvariantViolation
			}
		}
		n.children = out
	}
	// Raw-shape sidecars preserve the grammar reduction before hidden-node
	// flattening and can therefore retain nodes that do not appear in
	// n.children. materializeNodesUntil walks those edges too; retarget them
	// before checkpoint recycling while keeping the captured per-edge shape
	// reference unchanged.
	if preserveRawShapes {
		rawChildren := arena.rawShapeChildrenForNode(n)
		for i := range rawChildren {
			child := stackEntryNode(rawChildren[i].packedEntry)
			if child == nil {
				continue
			}
			if replacement := s.transientReplacement(child); replacement != nil {
				if replacement == n {
					return ParseStopInvariantViolation
				}
				rawChildren[i].retargetNodePreservingShapeRef(replacement)
				continue
			}

		}
	}
	if !s.owns(n) {
		if !s.addSeenNode(n, p) {
			return p.noteMemoryBudgetStop(parseMemoryBudgetStopSourceScratch)
		}
		return ParseStopNone
	}

	clone := arena.allocNodeFast()
	clone.ownerArena = arena
	clone.symbol = n.symbol
	clone.children = n.children
	clone.setFieldMetadata(n.fieldIDs(), n.fieldSources())
	clone.startPoint = n.startPoint
	clone.endPoint = n.endPoint
	clone.startByte = n.startByte
	clone.endByte = n.endByte
	clone.parseState = n.parseState
	clone.preGotoState = n.preGotoState
	clone.dynamicPrecedence = n.dynamicPrecedence
	clone.rawShape = n.rawShape
	clone.productionID = n.productionID
	clone.flags = n.flags
	clone.childIndex = -1
	nodeInitEquivVersion(clone)
	arena.recordParentNodeConstructed(len(clone.children), clone.fieldIDs(), clone.fieldSources(), len(clone.fieldSources()) > 0, true, false)
	s.nodesMaterialized++
	n.parent = clone
	return ParseStopNone
}

func (s *transientParentScratch) transientReplacement(n *Node) *Node {
	if s == nil || n == nil || n.parent == nil || n.parent == n || !s.owns(n) {
		return nil
	}
	return n.parent
}

func (s *transientParentScratch) reset() {
	if s == nil {
		return
	}
	for i := range s.slabs {
		slab := &s.slabs[i]
		used := slab.used
		if used > len(slab.data) {
			used = len(slab.data)
		}
		clear(slab.data[:used])
		slab.used = 0
	}
	s.slabCursor = 0
	s.nodesAllocated = 0
	s.nodesMaterialized = 0
	s.clearMaterializeScratch()
}

func (s *transientParentScratch) usedBytes() int64 {
	if s == nil {
		return 0
	}
	var used int64
	for i := range s.slabs {
		used += nodeStructBytesForCap(s.slabs[i].used)
	}
	return used
}

func (s *transientParentScratch) recycleForParse() {
	if s == nil {
		return
	}
	nodesAllocated := s.nodesAllocated
	nodesMaterialized := s.nodesMaterialized
	s.reset()
	s.nodesAllocated = nodesAllocated
	s.nodesMaterialized = nodesMaterialized
}

// transientParentRetainedCapForSource bounds the transient parent slabs a
// parse may inherit from the pool. A parse of a large file leaves slabs sized
// for that file. A later small parse must not carry them, or the pool bills
// the large file's scratch to every small operation that follows it.
func transientParentRetainedCapForSource(sourceLen int) int {
	return max(defaultTransientParentSlabCap(), 4*parseFullArenaInitialNodeCapacity(sourceLen))
}

// trimForSource drops inherited slabs whose total capacity exceeds the bound
// for this source. The slabs are already reset, so no live node points into
// them. The next parse that needs more simply allocates.
func (s *transientParentScratch) trimForSource(sourceLen int) {
	if s != nil && s.seen.Capacity() > max(128, min(65536, 4*parseFullArenaInitialNodeCapacity(sourceLen))) {
		s.seen.Drop()
	}
	if s == nil || len(s.slabs) == 0 {
		return
	}
	totalCap := 0
	for i := range s.slabs {
		totalCap += len(s.slabs[i].data)
	}
	if totalCap <= transientParentRetainedCapForSource(sourceLen) {
		return
	}
	for i := range s.slabs {
		s.slabs[i] = transientParentSlab{}
	}
	s.slabs = nil
	s.slabCursor = 0
	s.allocatedBytes = 0
}

func (s *transientParentScratch) resetForRelease() {
	if s == nil {
		return
	}
	s.reset()
	if s.seen.Capacity() > 65536 {
		s.seen.Drop()
	}
	totalCap := 0
	for i := range s.slabs {
		totalCap += len(s.slabs[i].data)
	}
	if totalCap > maxRetainedFullSliceCap {
		for i := range s.slabs {
			s.slabs[i] = transientParentSlab{}
		}
		s.slabs = nil
		s.allocatedBytes = 0
	}
}

// The identity set stores only pointer membership and is private to this
// materialization. Charge peak overlap before replacing its backing array.
func (s *transientParentScratch) addSeenNode(n *Node, p *Parser) bool {
	if s.seen.Contains(n) {
		return true
	}
	growth := s.seen.GrowthBytes()
	if growth < 0 {
		return false
	}
	if growth > 0 {
		if p != nil && p.budgetScratch != nil {
			scratch := p.budgetScratch
			used := max(int64(0), scratch.allocatedBytes()-scratch.budgetBaselineBytes)
			if scratch.budgetBytes > 0 && (used >= scratch.budgetBytes || growth > scratch.budgetBytes-used) {
				return false
			}
		}
		if !s.seen.Grow() {
			return false
		}
	}
	s.seen.AddKnownAbsent(n)
	return true
}

func (s *transientParentScratch) clearMaterializeScratch() {
	if s == nil {
		return
	}
	s.seen.Clear()
	if cap(s.frames) > 0 {
		clear(s.frames[:cap(s.frames)])
		s.frames = s.frames[:0]
	}
}
