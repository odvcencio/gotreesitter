//go:build gts_parsercorephase0

package gotreesitter_test

import (
	"bytes"
	"fmt"
	"testing"

	gotreesitter "github.com/odvcencio/gotreesitter"
	"github.com/odvcencio/gotreesitter/grammars"
	"github.com/odvcencio/gotreesitter/internal/benchorder"
)

func BenchmarkCombinedYAML(b *testing.B) {
	sample := admissionYAMLDocumentStreamSample(b)
	fmt.Printf("YAML_FIXTURE bytes=%d sha256=5aa2c70bccfe73254f13eca40476c3f88f522c6a47aea499f9d672dbc5aae8c4 route=legacy\n", len(sample))
	at := bytes.Index(sample, []byte("minReplicas: 1"))
	if at < 0 {
		b.Fatal("missing numeric fixture")
	}
	at += len("minReplicas: ")
	changed := append([]byte(nil), sample...)
	changed[at] = '2'
	point := pointAtOffset(sample, at)
	end := pointAtOffset(sample, at+1)
	edit := gotreesitter.InputEdit{StartByte: uint32(at), OldEndByte: uint32(at + 1), NewEndByte: uint32(at + 1), StartPoint: point, OldEndPoint: end, NewEndPoint: end}
	lang := grammars.YamlLanguage()
	// Each arm proves this concrete edit against an independent fresh parse.
	check := gotreesitter.NewParser(lang)
	old, err := check.Parse(sample)
	if err != nil || old == nil {
		b.Fatalf("original: %v", err)
	}
	old.Edit(edit)
	incremental, err := check.ParseIncremental(changed, old)
	if err != nil || incremental == nil {
		b.Fatalf("incremental: %v", err)
	}
	fresh, err := gotreesitter.NewParser(lang).Parse(changed)
	if err != nil || fresh == nil {
		b.Fatalf("fresh: %v", err)
	}
	if incremental.RootNode() == nil || fresh.RootNode() == nil || fresh.RootNode().HasError() || incremental.RootNode().HasError() || fresh.ParseRuntime().StopReason != gotreesitter.ParseStopAccepted || incremental.ParseRuntime().StopReason != gotreesitter.ParseStopAccepted || fresh.RootNode().StartByte() != 0 || fresh.RootNode().EndByte() != uint32(len(changed)) || incremental.RootNode().StartByte() != 0 || !gotreesitter.YAMLBenchmarkStrictEqual(incremental, fresh, lang) || incremental.RootNode().EndByte() != uint32(len(changed)) {
		b.Fatal("YAML edit differs from fresh parse")
	}
	if incremental != old {
		old.Release()
	}
	incremental.Release()
	fresh.Release()
	cases := []benchorder.Case{
		{Label: "full", Run: func(b *testing.B) { benchmarkCompactThroughputSource(b, lang, sample, false) }},
		{Label: "edit", Run: func(b *testing.B) {
			p := gotreesitter.NewParser(lang)
			p.SetAdmissionCandidateRoute(false)
			tree, err := p.Parse(sample)
			if err != nil || tree == nil {
				b.Fatalf("initial: %v", err)
			}
			inputs := [2][]byte{changed, sample}
			beforeRoute, beforeFallback := gotreesitter.AdmissionCandidateCounters()
			b.ReportAllocs()
			b.SetBytes(int64(len(sample)))
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				tree.Edit(edit)
				previous := tree
				tree, err = p.ParseIncremental(inputs[i&1], tree)
				if err != nil || tree == nil || tree.RootNode() == nil || tree.RootNode().HasError() || tree.RootNode().EndByte() != uint32(len(sample)) {
					b.Fatalf("edit %d: %v", i, err)
				}
				if previous != tree {
					previous.Release()
				}
			}
			b.StopTimer()
			routed, fallback := gotreesitter.AdmissionCandidateCounters()
			routed -= beforeRoute
			fallback -= beforeFallback
			if routed != 0 || fallback != 0 {
				b.Fatalf("unexpected compact routing: %d/%d", routed, fallback)
			}
			b.ReportMetric(float64(routed)/float64(b.N), "compact-routes/op")
			b.ReportMetric(float64(fallback)/float64(b.N), "compact-fallbacks/op")
			tree.Release()
		}},
		{Label: "no_edit", Run: func(b *testing.B) {
			p := gotreesitter.NewParser(lang)
			p.SetAdmissionCandidateRoute(false)
			tree, err := p.Parse(sample)
			if err != nil || tree == nil {
				b.Fatalf("initial: %v", err)
			}
			beforeRoute, beforeFallback := gotreesitter.AdmissionCandidateCounters()
			b.ReportAllocs()
			b.SetBytes(int64(len(sample)))
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				previous := tree
				tree, err = p.ParseIncremental(sample, tree)
				if err != nil || tree == nil || tree.RootNode() == nil {
					b.Fatalf("no edit: %v", err)
				}
				if previous != tree {
					previous.Release()
				}
			}
			b.StopTimer()
			routed, fallback := gotreesitter.AdmissionCandidateCounters()
			routed -= beforeRoute
			fallback -= beforeFallback
			if routed != 0 || fallback != 0 {
				b.Fatalf("unexpected compact routing: %d/%d", routed, fallback)
			}
			b.ReportMetric(float64(routed)/float64(b.N), "compact-routes/op")
			b.ReportMetric(float64(fallback)/float64(b.N), "compact-fallbacks/op")
			tree.Release()
		}},
	}
	benchorder.Run(b, cases, compactThroughputSeed(b))
}
