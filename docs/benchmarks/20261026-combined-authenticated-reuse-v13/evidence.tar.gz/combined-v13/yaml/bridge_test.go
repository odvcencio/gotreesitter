//go:build gts_parsercorephase0

package gotreesitter

// YAMLBenchmarkStrictEqual is test-only; production exports no new API.
func YAMLBenchmarkStrictEqual(a, b *Tree, language *Language) bool {
	if !incrementalTreesStructurallyEqual(a, b, language) {
		return false
	}
	var equal func(*Node, *Node) bool
	equal = func(x, y *Node) bool {
		if x == nil || y == nil {
			return x == y
		}
		if x.ParseState() != y.ParseState() || x.PreGotoState() != y.PreGotoState() || x.dynamicPrecedence != y.dynamicPrecedence || x.ChildCount() != y.ChildCount() {
			return false
		}
		for i := 0; i < x.ChildCount(); i++ {
			if !equal(x.Child(i), y.Child(i)) {
				return false
			}
		}
		return true
	}
	return equal(a.RootNode(), b.RootNode())
}
