#!/usr/bin/env bash
set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly' GOMAXPROCS=1
cd /candidate
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
sha256sum --quiet -c /controls/combined-correctness/v13/source.sha256
trap 'rc=$?; sha256sum --quiet -c /controls/combined-v13/inputs.sha256 || rc=1; sha256sum --quiet -c /controls/combined-correctness/v13/source.sha256 || rc=1; exit "$rc"' EXIT
scratch=/runtime/tmp/gotreesitter-combined-correctness-v13
sha256sum -c /evidence/race-binary.sha256
sha256sum -c /evidence/root-binary.sha256
go test -race ./internal/incr -run '^TestGroupedReadProducerAuthorityLifecycle$' -count=1 -v -timeout=5m > /evidence/grouped-race.log 2>&1
"$scratch/root-race.test" -test.run '^TestCompactReuseDependencyPublicationOverflowSlab$' -test.count=1 -test.v -test.timeout=5m > /evidence/publication-race.log 2>&1
"$scratch/root.test" -test.run '^Test(LegacyReuseAliasSidecarArenaAndBudget|LegacyReuseLookaheadRespectsSidecarBudget|ArenaMemoryBudget.*|ArenaResetRetainsOverflowWithinBudget|ParserScratchMemoryBudget.*|ParserScratchBudget.*|GoCompatCleanParseUnaffectedByMemoryBudgetFix|GoCompatFramesReleasedAboveRetentionCap|CompactMemoryBudgetDetectsGrowthAfterSmallPoll|CompactArenaReserve.*(Budget|RetentionCap)|RuntimeMemoryBudget.*|RuntimeMemoryHardCeilingStillStopsParse|ParseMemoryHardCeiling.*)$' -test.count=1 -test.v -test.timeout=8m > /evidence/memory.log 2>&1
