#!/usr/bin/env bash
set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly' GOMAXPROCS=1 GTS_PARITY_C_REF_BUILD_CACHE=/c-cache
cd /candidate/cgo_harness
sha256sum --quiet -c /controls/combined-v13/inputs.sha256
sha256sum --quiet -c /controls/combined-correctness/v13/source.sha256
trap 'rc=$?; sha256sum --quiet -c /controls/combined-v13/inputs.sha256 || rc=1; sha256sum --quiet -c /controls/combined-correctness/v13/source.sha256 || rc=1; exit "$rc"' EXIT
sha256sum -c /evidence/c-fleet-binary.sha256
bin=/runtime/tmp/gotreesitter-combined-correctness-v13/c-fleet.test
GTS_ADMISSION_CANDIDATE=1 GTS_ADMISSION_REAL_CORPUS_LANGS=yaml "$bin" -test.run '^TestCompactR4StructuralLockedC$' -test.count=1 -test.v -test.timeout=8m > /evidence/yaml-r4.log 2>&1
GTS_YAML_LARGE_PROBE=1 "$bin" -test.run '^Test(YAMLOwnedGrammarLockedCParity|CompactYAMLDocumentStreamLockedC|YAMLRecoveredMappingQuotesLockedC|YAMLEOFRecoverWrapCompactRoute|YAMLEOFRecoverWrapUnfinishedMappingDeclinesCompact|YAMLOneBytePrintableEOFAdmissionMatchesLockedC|CompactYAMLVersionOwnershipCOracle)$' -test.count=1 -test.v -test.timeout=12m > /evidence/yaml-focused.log 2>&1
