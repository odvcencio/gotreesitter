from pathlib import Path
import hashlib,json
print(json.dumps({role:{str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(root.rglob('*.go'))} for role in ['baseline','candidate'] for root in [Path('/'+role)]},sort_keys=True))
