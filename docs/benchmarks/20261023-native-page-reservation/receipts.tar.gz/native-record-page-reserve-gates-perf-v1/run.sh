set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
python3 - <<'CHECK'
from pathlib import Path
import hashlib,json
p=Path('/focused-source');q=Path('/candidate')
a={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*.go')};b={str(f.relative_to(q)):hashlib.sha256(f.read_bytes()).hexdigest() for f in q.rglob('*.go')}
assert a==b
assert Path('/focused/complete.txt').exists()
assert Path('/focused/workload-exit-code.txt').read_text().strip()=='0'
hashes=json.loads(Path('/focused/source-before.json').read_text());assert hashes==json.loads(Path('/focused/source-after-final.json').read_text());assert b==hashes['candidate']
Path('/evidence/reused-cgo-source-receipt.json').write_text(json.dumps({'all_source_files_identical':True,'reused_cgo_binary_sha256':hashlib.sha256(Path('/focused/candidate-cgo.test').read_bytes()).hexdigest()},indent=2)+'\n')
CHECK
python3 /controls/source_hashes.py > /evidence/source-before.json
cd /candidate
go test -c -tags gts_parsercorephase0 -o /evidence/candidate.test . > /evidence/root-build.log 2>&1
go test -race -tags gts_parsercorephase0 -run '^Test(QuiescentNative.*|NativeProjection.*|CompactReuseDependency.*|CompactLegacyRead.*|CompactLegacyProjection.*)$' -count=1 -v -timeout=8m . > /evidence/root-race.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test -c -tags gts_parsercorephase0 -o /evidence/root-386.test . > /evidence/root-386-build.log 2>&1
/evidence/root-386.test -test.run '^Test(QuiescentNative.*|NativeProjection.*|CompactReuseDependency.*|CompactLegacyRead.*|CompactLegacyProjection.*)$' -test.count=1 -test.v -test.timeout=5m > /evidence/root-386.log 2>&1
cd /candidate/cgo_harness
GTS_YAML_LARGE_PROBE=1 /focused/candidate-cgo.test -test.run '^Test(YAMLOwnedGrammarLockedCParity|CompactYAMLDocumentStreamLockedC|YAMLRecoveredMappingQuotesLockedC|YAMLEOFRecoverWrapCompactRoute|YAMLEOFRecoverWrapUnfinishedMappingDeclinesCompact|YAMLOneBytePrintableEOFAdmissionMatchesLockedC)$' -test.count=1 -test.v -test.timeout=8m > /evidence/yaml-owned-cgo.log 2>&1
cd /candidate
for role in baseline candidate; do
 cd "/$role"
 go build -tags gts_parsercorephase0 -o "/evidence/$role-ledger" ./cmd/perfcounterledger > "/evidence/$role-ledger-build.log" 2>&1
done
cd /candidate
mkdir /evidence/invariants /evidence/cgo /evidence/ledger /evidence/counter-deltas
while IFS= read -r lang; do
 /evidence/baseline-ledger --langs "$lang" > "/evidence/ledger/baseline-$lang.json" 2> "/evidence/ledger/baseline-$lang.log"
 /evidence/candidate-ledger --langs "$lang" > "/evidence/ledger/candidate-$lang.json" 2> "/evidence/ledger/candidate-$lang.log"
 python3 /controls/compare-ledger.py "/evidence/ledger/baseline-$lang.json" "/evidence/ledger/candidate-$lang.json" "/evidence/counter-deltas/$lang.json" > "/evidence/counter-deltas/$lang.log"
 printf 'ledger\t%s\n' "$lang" >> /evidence/progress.tsv
done < /controls/languages.txt
while IFS= read -r lang; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /evidence/candidate.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/invariants/$route-$lang.log" 2>&1
  printf 'invariant\t%s\t%s\n' "$lang" "$route" >> /evidence/progress.tsv
 done
done < /controls/languages.txt
cd /candidate/cgo_harness
while IFS= read -r lang; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GTS_PARITY_MODE=exhaustive /focused/candidate-cgo.test -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${lang}$" -test.count=1 -test.v -test.timeout=5m > "/evidence/cgo/$route-$lang.log" 2>&1
  printf 'C\t%s\t%s\n' "$lang" "$route" >> /evidence/progress.tsv
 done
done < /controls/languages.txt
cd /candidate
cd /candidate/cgo_harness
mkdir /evidence/cogno
go test -c -overlay=/controls/cogno-overlay.json -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/cogno/probe.test . > /evidence/cogno/build.log 2>&1
for route in production candidate; do
 for api in plain profiled; do
  for edit in insert replace delete; do
   label="$route-$api-$edit"
   if /evidence/cogno/probe.test -test.run "^TestGoCognociente137KiBTopEditLockedC$/^$route$/^$api$/^$edit$" -test.v -test.count=1 -test.timeout=5m > "/evidence/cogno/$label.log" 2>&1; then code=0; else code=$?; fi
   printf '%s\t%s\n' "$label" "$code" >> /evidence/cogno/status.tsv
   if [[ "$edit" != delete && "$code" != 0 ]]; then exit "$code"; fi
  done
 done
done
python3 - <<'COGNO'
from pathlib import Path
p=Path('/evidence/cogno');rows=(p/'status.tsv').read_text().splitlines();assert len(rows)==12
for row in rows:
 name,code=row.split('\t');text=(p/(name+'.log')).read_text();assert 'D8 incremental/fresh Go and incremental/fresh C agree independently:' in text
 if name.endswith('-delete'):
  assert code=='1' and 'Path:/source_file/function_declaration[2]/block[4]/ERROR[1] Category:shape GoValue:children=1 CValue:children=2' in text
 else:assert code=='0' and 'independent fresh Go versus fresh C: exact symbols, fields, spans, points, flags' in text
COGNO
cd /candidate
for role in baseline candidate; do
 cd "/$role/cgo_harness"
 go test -c -overlay=/controls/cgo-overlay.json -tags treesitter_c_parity,gts_parsercorephase0 -o "/evidence/$role-large-cgo.test" . > "/evidence/$role-large-cgo-build.log" 2>&1
 "/evidence/$role-large-cgo.test" -test.run '^TestWarmCapacityLargeGoLockedC$' -test.v -test.count=1 -test.timeout=5m > "/evidence/$role-large-go-C.log" 2>&1
done
cd /candidate
printf 'correctness-and-ledger-complete\n' > /evidence/correctness-complete.txt
export CGO_ENABLED=0
bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-yaml.txt --output /evidence/candidate-yaml.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 195001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputYAML$' --require-benchmarks 'BenchmarkCompactThroughputYAML/r4_legacy,BenchmarkCompactThroughputYAML/eof8k_legacy,BenchmarkCompactThroughputYAML/r4_ordinary,BenchmarkCompactThroughputYAML/eof8k_ordinary,BenchmarkCompactThroughputYAML/r4_owned,BenchmarkCompactThroughputYAML/eof8k_owned' > /evidence/yaml-driver.log 2>&1
bash scripts/run_randomized_benchmarks.sh --primary-go-suite --baseline-root /baseline --baseline-output /evidence/baseline-go.txt --output /evidence/candidate-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 196001 --benchtime 750ms > /evidence/go-driver.log 2>&1
GOFLAGS='-p=1 -mod=readonly -buildvcs=false -overlay=/controls/benchmark-overlay.json' GTS_ADMISSION_CANDIDATE=1 bash scripts/run_randomized_benchmarks.sh --baseline-root /baseline --baseline-output /evidence/baseline-compact-go.txt --output /evidence/candidate-compact-go.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 197001 --benchtime 750ms --bench-regex '^BenchmarkCompactThroughputGo$' --require-benchmarks 'BenchmarkCompactThroughputGo/full_dfa,BenchmarkCompactThroughputGo/single_byte_edit_dfa,BenchmarkCompactThroughputGo/no_edit_dfa,BenchmarkCompactThroughputGo/fresh_one_mib,BenchmarkCompactThroughputGo/query_compile,BenchmarkCompactThroughputGo/grammargen_lr' > /evidence/compact-go-driver.log 2>&1
python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'complete\n' > /evidence/complete.txt
