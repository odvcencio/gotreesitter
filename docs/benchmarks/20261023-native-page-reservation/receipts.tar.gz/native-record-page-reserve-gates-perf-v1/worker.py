from pathlib import Path
import subprocess,json,os
p=Path(__file__).resolve().parent
def save(name,value):
 f=p/'out'/name;t=f.with_name(f.name+'.tmp');t.write_text(json.dumps(value,indent=2)+'\n');os.replace(t,f)
args=json.loads((p/'command.json').read_text());name=args[args.index('--name')+1]
with (p/'out/container.log').open('wb') as f:
 try:code=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=10800).returncode
 except subprocess.TimeoutExpired:
  code=124;subprocess.run(['docker','stop','--timeout','10',name],stdout=f,stderr=subprocess.STDOUT)
r=subprocess.run(['docker','inspect',name],capture_output=True,text=True)
if r.returncode:
 save('audit.json',{'exit_code':code,'inspect_error':r.stderr,'state_unavailable':True});raise SystemExit(1)
info=json.loads(r.stdout)[0];save('inspect.json',info);save('audit.json',{'exit_code':code,'state':info['State'],'lock_owner':'in-container flock --no-fork','durable_launcher':True})
subprocess.run(['docker','rm',name],check=True,stdout=subprocess.DEVNULL)
