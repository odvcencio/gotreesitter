from pathlib import Path
import difflib,gzip,hashlib,json,shutil,subprocess
p=Path('/home/draco/.local/state/gotreesitter-evidence/20261021-runtime-rss-architecture/compact-link-storage-v1')
proto=p/'native-record-page-reserve-v1';base=p/'native-record-receipts-v2/source';src=proto/'source'
a={str(f.relative_to(base)):f for f in base.rglob('*.go')};b={str(f.relative_to(src)):f for f in src.rglob('*.go')}
changes=[];chunks=[]
for name in sorted(a.keys()|b.keys()):
 before=a[name].read_bytes() if name in a else b'';after=b[name].read_bytes() if name in b else b''
 if before==after:continue
 changes.append({'path':name,'test':name.endswith('_test.go'),'new':name not in a,'before':hashlib.sha256(before).hexdigest(),'after':hashlib.sha256(after).hexdigest()})
 chunks.extend(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+name if name in a else '/dev/null',tofile='b/'+name if name in b else '/dev/null'))
assert len(changes)==4 and sum(not x['test'] for x in changes)==2
patch=''.join(chunks).encode();(proto/'source.patch').write_bytes(patch);(proto/'source.patch.gz').write_bytes(gzip.compress(patch,mtime=0))
subprocess.run(['git','apply','--check',str(proto/'source.patch')],cwd=base,check=True)
(proto/'source-review.json').write_text(json.dumps({'baseline':str(base),'candidate':str(src),'source_changes':changes,'new_root_production':0,'patch_sha256':hashlib.sha256(patch).hexdigest(),'patch_bytes':len(patch),'patch_applies':True},indent=2)+'\n')
d=p/'native-record-page-reserve-gates-perf-v1';assert not d.exists();d.mkdir();(d/'out').mkdir()
old=p/'native-record-receipts-gates-perf-v2'
for f in old.iterdir():
 if f.is_file():shutil.copyfile(f,d/f.name)
s=(old/'run.sh').read_text()
s=s.replace('gofmt -w /candidate/parsercore_phase0_reuse_dependency_test.go\n','')
start=s.index("python3 - <<'CHECK'");end=s.index('\nCHECK\n',start)+len('\nCHECK\n')
s=s[:start]+'''python3 - <<'CHECK'
from pathlib import Path
import hashlib,json
p=Path('/focused-source');q=Path('/candidate')
a={str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in p.rglob('*.go')};b={str(f.relative_to(q)):hashlib.sha256(f.read_bytes()).hexdigest() for f in q.rglob('*.go')}
assert a==b
assert Path('/focused/complete.txt').exists()
assert Path('/focused/workload-exit-code.txt').read_text().strip()=='0'
hashes=json.loads(Path('/focused/source-before.json').read_text());assert hashes==json.loads(Path('/focused/source-after-final.json').read_text());assert b==hashes['candidate']
Path('/evidence/reused-cgo-source-receipt.json').write_text(json.dumps({'all_source_files_identical':True,'reused_cgo_binary_sha256':hashlib.sha256(Path('/focused/candidate-cgo.test').read_bytes()).hexdigest()},indent=2)+'\\n')
CHECK
'''+s[end:]
# Memory and focused regression gates already ran on byte-identical sources.
lines=s.splitlines()
lines=[x for x in lines if not (x.startswith('/evidence/candidate.test') and ('/evidence/memory.log' in x or '/evidence/root-checkpoint.log' in x))]
s='\n'.join(lines)+'\n'
s=s.replace("^Test(QuiescentNative.*|NativeProjectionAliasReceiptRejectsChangedPublication|CompactReuseDependency.*|CompactLegacyRead.*|CompactLegacyProjection.*)$","^Test(QuiescentNative.*|NativeProjection.*|CompactReuseDependency.*|CompactLegacyRead.*|CompactLegacyProjection.*)$")
s=s.replace('190001','195001').replace('191001','196001').replace('192001','197001')
(d/'run.sh').write_text(s)
cmd=json.loads((old/'command.json').read_text());cmd.insert(2,'--detach')
for i,v in enumerate(cmd):
 if v=='gts-native-record-receipts-gates-perf-v2-20261023':cmd[i]='gts-native-record-page-reserve-gates-perf-v1-20261023'
 elif v.endswith(':/baseline:ro'):cmd[i]=str(base)+':/baseline:ro'
 elif v.endswith(':/candidate'):cmd[i]=str(src)+':/candidate:ro'
 elif v.endswith(':/controls:ro'):cmd[i]=str(d)+':/controls:ro'
 elif v.endswith(':/evidence'):cmd[i]=str(d/'out')+':/evidence'
 elif v.endswith(':/focused:ro'):cmd[i]=str(proto/'out')+':/focused:ro'
 elif v.endswith(':/focused-source:ro'):cmd[i]=str(src)+':/focused-source:ro'
(d/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
result=subprocess.check_output(cmd,text=True).strip();(d/'container-id.txt').write_text(result+'\n');print(result)
