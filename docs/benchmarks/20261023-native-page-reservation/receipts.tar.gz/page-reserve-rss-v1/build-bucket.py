from pathlib import Path
import collections,gzip,hashlib,io,json,subprocess,tarfile,shutil
repo=Path('/home/draco/work/gotreesitter')
P=Path('/home/draco/.local/state/gotreesitter-evidence/20261021-runtime-rss-architecture/compact-link-storage-v1')
focused=P/'native-record-page-reserve-v1';run=P/'native-record-page-reserve-gates-perf-v1';rssroot=repo/'harness_out/docker/page-reserve-rss-v1';g=run/'out';r=rssroot/'out'
for root in [focused/'out',g,r]:
 assert (root/'complete.txt').exists()
 assert (root/'workload-exit-code.txt').read_text().strip()=='0'
 assert json.loads((root/'source-before.json').read_text())==json.loads((root/'source-after-final.json').read_text())
counts=dict(collections.Counter(line.split('\t')[0] for line in (g/'progress.tsv').read_text().splitlines()))
assert counts=={'ledger':206,'invariant':412,'C':412}
for f in (g/'counter-deltas').glob('*.json'):
 d=json.loads(f.read_text());assert d['passed'] and not d['changes'] and not d['route_metadata_changes']
for name in ['invariants','cgo']:
 logs=list((g/name).glob('*.log'));assert len(logs)==412
 for f in logs:
  s=f.read_text();assert '--- FAIL:' not in s and s.rstrip().endswith('PASS')
for row in (g/'cogno/status.tsv').read_text().splitlines():
 name,code=row.split('\t');s=(g/'cogno'/(name+'.log')).read_text();assert 'D8 incremental/fresh Go and incremental/fresh C agree independently:' in s
 if name.endswith('-delete'):assert code=='1' and 'Path:/source_file/function_declaration[2]/block[4]/ERROR[1] Category:shape GoValue:children=1 CValue:children=2' in s
 else:assert code=='0'
for role in ['baseline','candidate']:
 assert (g/(role+'-large-go-C.log')).read_text().count('warmed 1 MiB Go: exact symbols, fields, spans, points, flags, and deep digest')==6
for name in ['performance-container-audit.json','rss-container-audit.json']:
 d=json.loads((r/name).read_text());assert d['state']['ExitCode']==0 and not d['state']['OOMKilled']
perf=json.loads((r/'independent-analysis.json').read_text());assert perf['valid_rows_per_role']==300 and not perf['ratchet_failures'] and perf['all_timed_work_and_route_metrics_exact']
rss=json.loads((r/'rss-matched/audit.json').read_text());assert rss['candidate_safety_pass'] and len(rss['matched'])==120 and len(rss['initial'])==6
review=json.loads((focused/'source-review.json').read_text());patch=(focused/'source.patch').read_bytes();digest=lambda b:hashlib.sha256(b).hexdigest();assert digest(patch)==review['patch_sha256']
subprocess.run(['git','apply','--check',str(focused/'source.patch')],cwd=P/'native-record-receipts-v2/source',check=True)
review['baseline']='native-record-receipts-v2 (identical to PR runtime at 154bac17b)';review['candidate']='native-record-page-reserve-v1'
entries={}
for root in [focused,run,rssroot]:
 selected=list(root.glob('*'))+list((root/'out').rglob('*'))+list((root/'protocol').rglob('*'))
 for f in sorted(set(selected)):
  if not f.is_file() or f.suffix not in {'.json','.log','.txt','.tsv','.rss','.py','.sh','.go','.patch','.gz'}:continue
  if any(x in f.name for x in ['private','inspect','buckley']):continue
  entries[root.name+'/'+str(f.relative_to(root))]=f.read_bytes()
manifest={n:{'bytes':len(b),'sha256':digest(b)} for n,b in entries.items()};entries['members.json']=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
out=repo/'docs/benchmarks/20261023-native-page-reservation';out.mkdir(exist_ok=True);archive=out/'receipts.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,b in sorted(entries.items()):
    info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;tar.addfile(info,io.BytesIO(b))
with tarfile.open(archive) as tar:
 assert len(tar.getmembers())==len(entries)
 for m in tar.getmembers():
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
  if m.name!='members.json':assert digest(tar.extractfile(m).read())==manifest[m.name]['sha256']
receipt={'status':'Qualified allocation reduction against the held native-record runtime; no established throughput win or graduation approval','source':review,'fleet':{**counts,'standard_C_checks':1236,'edit_steps':29664,'no_edit_allocations':0,'memory_checks':20},'strict_counter_changes':[],'performance':perf,'cold_RSS':{k:v for k,v in rss.items() if k not in ['matched','initial']},'Cogno':{'report_comment_id':6311551850,'D8_checks':12,'clean_C_checks':8,'unchanged_malformed_delete_C_failures':4,'Windows_qualified':False},'holds':['No main-based qualification of the combined runtime','No significant timing improvement','Ordinary YAML throughput gap','Earlier Go LR and large-file allocation regressions versus earlier baseline','Warmed forced-legacy Go RSS ceiling failure','Four exact malformed-delete C mismatches','No Mac or native Windows qualification'],'archive':{'bytes':archive.stat().st_size,'members':len(entries),'sha256':digest(archive.read_bytes())}}
(out/'qualification.json').write_text(json.dumps(receipt,sort_keys=True,indent=2)+'\n');(out/'source.patch.gz').write_bytes(gzip.compress(patch,mtime=0))
for suite in ['go','compact-go','yaml']:shutil.copyfile(r/('benchstat-'+suite+'.txt'),out/('benchstat-'+suite+'.txt'))
(rssroot/'artifact-verification.json').write_text(json.dumps({'archive_members_verified':len(entries),'all_hashes_match':True,'patch_applies':True,'archive':receipt['archive']},indent=2)+'\n')
print(json.dumps(receipt['archive']))
for row in perf['suites']['compact-go']['results']:
 print(row['benchmark'],row['medians'],row['ratios'])
