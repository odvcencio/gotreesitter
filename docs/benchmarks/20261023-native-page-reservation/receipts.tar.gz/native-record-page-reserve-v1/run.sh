set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
gofmt -w /candidate/parsercore_phase0_materializer.go /candidate/parsercore_selected_store_internal_test.go /candidate/internal/parsercorephase0/projection_pages.go /candidate/internal/parsercorephase0/projection_pages_test.go
python3 /controls/source_hashes.py > /evidence/source-before.json
cd /candidate
go test -race ./internal/parsercorephase0 -run '^Test(NativeProjection.*|ProjectionPages.*)$' -count=1 -v > /evidence/native-admission-unit.log 2>&1
go test -c -tags gts_parsercorephase0 -o /evidence/candidate.test . > /evidence/root-build.log 2>&1
/evidence/candidate.test -test.run '^Test(QuiescentNative.*|NativeProjection.*|CompactReuseDependency.*|CompactLegacyRead.*|CompactLegacyProjection.*)$' -test.count=1 -test.v -test.timeout=5m > /evidence/faust-field-regression.log 2>&1
/evidence/candidate.test -test.run '^Test(CompactAcceptance(ChangedSourceKeepsRebuildBudget|CachedPublicationStopControl)|CompactMemoryBudgetDetectsGrowthAfterSmallPoll|CompactAcceptance.*(MemoryBudget|RetentionBound)|CompactArenaReserve.*(Budget|RetentionCap)|CompactExternalScannerCheckpointCopyMemoryBudget|CompactRecoveryMemoMemoryBudget|CompactBorrowedMaterializationProjectionMemoryBudget|G18RefSetSchedulerMemoryBudgetAccounting|RuntimeMemoryBudget.*|RuntimeMemoryHardCeilingStillStopsParse|ParseMemoryHardCeiling.*)$' -test.count=1 -test.v -test.timeout=8m > /evidence/memory.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test ./internal/parsercorephase0 -run '^TestProjectionPages.*$' -count=1 -v > /evidence/pages-386.log 2>&1
for lang in ada faust ini go yaml foam hyprlang pkl smithy; do
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /evidence/candidate.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/$lang-invariant-$route.log" 2>&1
done
done
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o /evidence/candidate-cgo.test . > /evidence/cgo-build.log 2>&1
for lang in ada faust ini go yaml foam hyprlang pkl smithy; do
for route in 0 1; do
 GTS_ADMISSION_CANDIDATE="$route" GTS_PARITY_MODE=exhaustive /evidence/candidate-cgo.test -test.run "^(TestParityFreshParse|TestParityIncrementalParse|TestParityHasNoErrors)$/^${lang}$" -test.count=1 -test.v -test.timeout=5m > "/evidence/$lang-cgo-$route.log" 2>&1
done
done
python3 /controls/source_hashes.py > /evidence/source-after.json
cmp /evidence/source-before.json /evidence/source-after.json
printf 'complete\n' > /evidence/complete.txt
