from pathlib import Path
import os
p=Path('/home/draco/.local/state/gotreesitter-evidence/20261021-runtime-rss-architecture/compact-link-storage-v1/native-record-page-reserve-v1/source')
def put(name,text):
 f=p/name;t=f.with_name(f.name+'.tmp');t.write_text(text);os.replace(t,f)
name='internal/parsercorephase0/projection_pages.go'
s=(p/name).read_text().replace('import "unsafe"','import ("math"; "unsafe")')
s+='''
// ProjectedGrowth estimates the remaining publication slots once a substantial
// prefix has actually been emitted. Small workspaces keep their exact paging
// behavior. The estimate never changes live records and is capped at 24 MiB.
func (p *ProjectionPages[T]) ProjectedGrowth(sourceBytes int, progress uint32) (int, uint64) {
 if p.length < 16384 || p.length > math.MaxInt32 || sourceBytes <= 1 || uint64(sourceBytes) > math.MaxUint32 || progress == 0 || uint64(progress) >= uint64(sourceBytes) || uint64(progress)*16 < uint64(sourceBytes) { return 0, 0 }
 count := (uint64(p.length)*uint64(sourceBytes)+uint64(progress)-1)/uint64(progress)
 count = min((count*17+15)/16, uint64(math.MaxInt32))
 growth := p.GrowthFootprintBytes(int(count))
 const ceiling = 24 << 20
 if growth == 0 || growth > ceiling || p.FootprintBytes() > ceiling-growth { return 0, 0 }
 return int(count), growth
}

// GrowthFootprintBytes includes all reserved slots and the exact pointer table
// increase. Existing record addresses stay fixed when a new block is reserved.
func (p *ProjectionPages[T]) GrowthFootprintBytes(capacity int) uint64 {
 if capacity <= 0 || capacity > math.MaxInt32 { return 0 }
 pages := 0
 if capacity > projectionFirstSlots { pages = (capacity-projectionFirstSlots-1)/projectionPageSlots+1 }
 pageBytes := uint64(unsafe.Sizeof([projectionPageSlots]T{}))
 extraPages := uint64(max(pages-len(p.pages), 0))
 if pageBytes > 0 && extraPages > math.MaxUint64/pageBytes { return math.MaxUint64 }
 bytes := extraPages*pageBytes
 tableBytes := uint64(max(pages-cap(p.pages), 0))*uint64(unsafe.Sizeof((*[projectionPageSlots]T)(nil)))
 if tableBytes > math.MaxUint64-bytes { return math.MaxUint64 }; bytes += tableBytes
 if p.first == nil {
  first := uint64(unsafe.Sizeof([projectionFirstSlots]T{}))
  if first > math.MaxUint64-bytes { return math.MaxUint64 }; bytes += first
 }
 return bytes
}

// Grow allocates future pages together without copying any live record. The
// caller must preflight GrowthFootprintBytes against its armed memory limits.
func (p *ProjectionPages[T]) Grow(capacity int) {
 if capacity <= 0 || capacity > math.MaxInt32 || p.GrowthFootprintBytes(capacity) == math.MaxUint64 { return }
 if p.first == nil { p.first = new([projectionFirstSlots]T) }
 if capacity <= projectionFirstSlots { return }
 pages := (capacity-projectionFirstSlots-1)/projectionPageSlots+1
 if pages <= len(p.pages) { return }
 if pages > cap(p.pages) {
  table := make([]*[projectionPageSlots]T, len(p.pages), pages)
  copy(table, p.pages); p.pages = table
 }
 block := make([][projectionPageSlots]T, pages-len(p.pages))
 for i := range block { p.pages = append(p.pages, &block[i]) }
}
'''
put(name,s)
name='parsercore_phase0_materializer.go';s=(p/name).read_text()
old='scratch.sink = nativeStreamSink{arena: arena, points: &points, scratch: scratch, compact: scheduler.compact, lang: runner.lang}'
assert s.count(old)==1
s=s.replace(old,old[:-1]+', runner: runner, scheduler: scheduler, sourceBytes: len(source)}')
old='type nativeStreamSink struct {\n\tcompact *core.Core'
assert old in s;s=s.replace(old,'type nativeStreamSink struct {\n runner *parserCoreFreshFullRunner\n scheduler *diagnosticParserCoreGenericScheduler\n sourceBytes int\n reserveChecked bool\n\tcompact *core.Core')
old='\tid := core.SelectedNodeID(s.scratch.records.Len())\n\ts.scratch.records.Append(nativeStreamRecord{node: n})'
assert s.count(old)==1
s=s.replace(old,'\tif !s.reserveChecked && s.scratch.records.Len() >= 16384 && s.scratch.records.Len()&1023 == 0 { s.reserveRecords(r.EndByte) }\n'+old)
marker='func (s *nativeStreamSink) read(id core.SelectedNodeID)'
assert marker in s
s=s.replace(marker,'''// reserveRecords only adapts the internal capacity plan to the live parser's
// memory accounting. Refusing speculation leaves ordinary paging available.
func (s *nativeStreamSink) reserveRecords(progress uint32) {
 if s.sourceBytes <= 1 || uint64(progress)*16 < uint64(s.sourceBytes) { return }
 s.reserveChecked = true
 slots, additional := s.scratch.records.ProjectedGrowth(s.sourceBytes, progress)
 if slots == 0 || s.scheduler == nil || s.runner == nil { return }
 workspace := uint64(0)
 if s.scheduler.nativeProjectionScratch != s.scratch { workspace = s.scratch.retainedBytes() }
 for _, bytes := range []uint64{arenaAllocatedVolume(s.arena), workspace, s.scheduler.compact.SelectedBuildAuxiliaryBytes(), uint64(cap(s.runner.scratch.goCompatFrames))*uint64(unsafe.Sizeof(goCompatSubtreeFrame{})), uint64(cap(s.runner.scratch.linkScratch))*uint64(unsafe.Sizeof((*Node)(nil)))} {
  if bytes > math.MaxUint64-additional { return }; additional += bytes
 }
 if reason := s.scheduler.stopControlMemoryBudgetReasonWithAdditionalBytes(additional); resultMaterializationShouldStop(reason) { return }
 s.scratch.records.Grow(slots)
}

'''+marker)
put(name,s)
name='internal/parsercorephase0/projection_pages_test.go';s=(p/name).read_text()
s+='''
func TestProjectionPagesBulkReservePreservesIdentityAndAccountsCapacity(t *testing.T) {
 type record struct { pointer *int; value int }
 var p ProjectionPages[record]
 value := 17
 for i:=0; i<20000; i++ { p.Append(record{&value, i}) }
 first, edge := p.At(0), p.At(10000)
 before, length := p.FootprintBytes(), p.Len()
 slots, growth := p.ProjectedGrowth(1<<20, 1<<16)
 if slots <= length || growth == 0 { t.Fatal("missing observed reserve") }
 p.Grow(slots)
 if p.Len()!=length || p.FootprintBytes()!=before+growth || p.At(0)!=first || p.At(10000)!=edge { t.Fatal("reserve moved records or mischarged capacity") }
 for i:=length; i<slots; i++ { p.Append(record{&value,i}) }
 for i:=0; i<p.Len(); i++ { if p.At(i).value!=i || p.At(i).pointer!=&value { t.Fatalf("record %d changed",i) } }
 size:=p.FootprintBytes();p.Grow(1)
 if p.FootprintBytes()!=size { t.Fatal("smaller reserve changed capacity") }
 p.Clear()
 if *first!=(record{}) || *edge!=(record{}) { t.Fatal("clear retained record pointers") }
 for _,page:=range p.pages { for _,r:=range page { if r!=(record{}) {t.Fatal("unused bulk slot retained a pointer")} } }
 if allocations:=testing.AllocsPerRun(3,func(){ for i:=0;i<slots;i++ {p.Append(record{&value,i})};p.Clear() }); allocations!=0 {t.Fatalf("warm allocations=%v",allocations)}
}

func TestProjectionPagesReserveIsBoundedAndRequiresObservedProgress(t *testing.T) {
 var p ProjectionPages[uint64]
 for i:=0;i<16384;i++ {p.Append(uint64(i))}
 before:=p.FootprintBytes()
 for _,tc:=range []struct{ source int; progress uint32 }{{0,0},{-1,1},{1<<20,0},{1<<20,(1<<16)-1},{1<<20,1<<20},{1<<20,(1<<20)+1}} {
  if n,b:=p.ProjectedGrowth(tc.source,tc.progress);n!=0||b!=0 {t.Fatalf("invalid projection %+v => %d,%d",tc,n,b)}
 }
 if p.FootprintBytes()!=before {t.Fatal("planning allocated storage")}
 p.length=16383
 if n,b:=p.ProjectedGrowth(1<<20,1<<16);n!=0||b!=0 {t.Fatal("small workspace projected")}
 p.length=1<<30
 if n,b:=p.ProjectedGrowth(1<<20,1<<16);n!=0||b!=0 {t.Fatal("oversized projection escaped cap")}
 p.length=16384
 if allocations:=testing.AllocsPerRun(10,func(){p.ProjectedGrowth(1<<20,1<<16)});allocations!=0 {t.Fatal("planning allocated")}
}

func TestProjectionPagesBulkReserveUsesConstantAllocationCount(t *testing.T) {
 allocations:=testing.AllocsPerRun(5,func(){ var p ProjectionPages[*int];p.Grow(600000);p.Clear() })
 if allocations>3 {t.Fatalf("bulk reserve allocated per page: %v",allocations)}
}
'''
put(name,s)
name='parsercore_selected_store_internal_test.go';s=(p/name).read_text()
s+='''
func TestNativeProjectionPageReservePreflightsBothMemoryLimits(t *testing.T) {
 for _,hard:=range []bool{false,true} {t.Run(fmt.Sprint(hard),func(t *testing.T){
  fixture:=loadDiagnosticParserCoreCanonicalFixture(t,"rewrite")
  runner,err:=newParserCoreFreshFullRunner(parserCoreWarmGoScanner,parserCoreFreshFullCanonicalOptions());if err!=nil {t.Fatal(err)}
  scheduler,tokens,err:=runner.executeSchedulerOpen(fixture.Source,runner.compact,false);if tokens!=nil {defer tokens.Close()};if err!=nil {t.Fatal(err)}
  arena:=acquireNodeArena(arenaClassFull);defer arena.Release()
  var scratch nativeProjectionWorkspace
  for i:=0;i<20000;i++ {scratch.records.Append(nativeStreamRecord{})}
  sink:=nativeStreamSink{compact:scheduler.compact,arena:arena,scratch:&scratch,runner:runner,scheduler:scheduler,sourceBytes:1<<20}
  before:=scratch.records.FootprintBytes()
  if hard {scheduler.options.stopControlHardCeilingBytes=1} else {scheduler.options.stopControlMemoryBudgetBytes=1}
  sink.reserveRecords(1<<16)
  if scratch.records.FootprintBytes()!=before || !sink.reserveChecked {t.Fatal("reserve bypassed memory preflight")}
  scheduler.options.stopControlHardCeilingBytes=0;scheduler.options.stopControlMemoryBudgetBytes=0
  sink.reserveChecked=false;sink.reserveRecords(1<<16)
  if scratch.records.FootprintBytes()<=before || scratch.records.Len()!=20000 {t.Fatal("unarmed reserve changed live length or did not grow")}
  scratch.reset()
  if scratch.retainedBytes()>parserCoreMaxRetainedComparisonBytes {t.Fatal("reserve escaped retention cap")}
 })}
}
'''
put(name,s)
print('Implemented one-shot, budget-preflighted page reserve; source snapshots preserved.')
