set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/packed-snapshot-budget-v1
mkdir -p "$scratch"
cd /candidate
sha256sum --quiet -c /controls/packed-snapshot-budget-v1/source-authentication.container.sha256 > /evidence/source-before.log 2>&1
go test -c -tags gts_parsercorephase0 -overlay=/controls/packed-snapshot-budget-v1/before.container.json -o "$scratch/before.test" . > /evidence/before-build.log 2>&1
set +e
"$scratch/before.test" -test.run '^TestPackedSnapshotBudget.*Private$' -test.count=1 -test.v > /evidence/before.log 2>&1
before_status=$?
set -e
go test -c -tags gts_parsercorephase0 -overlay=/controls/packed-snapshot-budget-v1/after.container.json -o "$scratch/after.test" . > /evidence/after-build.log 2>&1
set +e
"$scratch/after.test" -test.run '^TestPackedSnapshotBudget.*Private$' -test.count=1 -test.v > /evidence/after.log 2>&1
after_status=$?
"$scratch/after.test" -test.run '^Test(CompactAcceptance.*|ParserCoreFreshFullRunner.*|RuntimeMemory.*|ParseMemory.*|SetMemoryBudgetBytesZeroDoesNotAllocateColdState|MemoryBudgetDiagnosticLatchesFirstSource)$' -test.count=1 -test.v -test.timeout=4m > /evidence/existing-memory.log 2>&1
memory_status=$?
set -e
sha256sum --quiet -c /controls/packed-snapshot-budget-v1/source-authentication.container.sha256 > /evidence/source-after.log 2>&1
sha256sum "$scratch/before.test" "$scratch/after.test" > /evidence/binary.sha256
printf '{"baseline_exit":%d,"candidate_exit":%d,"existing_memory_exit":%d}\n' "$before_status" "$after_status" "$memory_status" > /evidence/process-status.json
if (( before_status != 1 || after_status != 0 || memory_status != 0 )); then exit 1; fi
printf 'baseline defect reproduced and candidate passes focused assertions; broader qualification still required\n' > /evidence/completed.txt
