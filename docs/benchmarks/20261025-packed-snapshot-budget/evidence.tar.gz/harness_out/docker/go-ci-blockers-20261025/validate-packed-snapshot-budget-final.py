from pathlib import Path
from collections import Counter
import hashlib,json,re
root=Path(__file__).resolve().parent
out=root/'out/packed-snapshot-budget-final'
langs=(root/'fleet-controls/languages.txt').read_text().splitlines()
assert len(langs)==len(set(langs))==206
assert json.loads((out/'finished.json').read_text())['exit_code']==0
assert (out/'completed.txt').is_file()
for name in ['source-before.log','source-after.log','root-build.log','cgo-build.log','ledger-build.log']:
 assert (out/name).read_text()=='' or name not in ['source-before.log','source-after.log'],name
sessions=[]
for route in ['0','1']:
 for lang in langs:
  text=(out/'invariants'/f'{route}-{lang}.log').read_text()
  assert not re.search(r'--- (FAIL|SKIP):|^panic:|^fatal error:',text,re.M),(route,lang)
  assert len(re.findall(r'^--- PASS: TestV1InvariantGateR4EditSession ',text,re.M))==1,(route,lang)
  m=re.search(r'language=(\S+) fixture=(\S+) sample_bytes=(\d+) session_steps=(\d+) no_edit_allocs=(\d+)',text)
  assert m and m[1]==lang and m[4]=='72' and m[5]=='0',(route,lang)
  sessions.append(m[2])
assert len((out/'invariant-status.tsv').read_text().splitlines())==412
for lang in langs:
 text=(out/'cgo'/f'{lang}.log').read_text()
 assert not re.search(r'--- (FAIL|SKIP):|^panic:|^fatal error:',text,re.M),lang
 for kind in ['FreshParse','IncrementalParse','HasNoErrors']:
  assert len(re.findall(r'^    --- PASS: TestParity'+kind+'/'+re.escape(lang)+r' ',text,re.M))==1,(lang,kind)
assert len((out/'cgo-status.tsv').read_text().splitlines())==206
before=root/'out/ci-followup-final/ledger'
for route in ['default','candidate']:
 for lang in langs:
  name=f'{route}-{lang}.json'
  a=json.loads((before/name).read_text())
  b=json.loads((out/'ledger'/name).read_text())
  assert a==b,('changed actual work/reuse row',name)
  assert (out/'ledger'/f'{route}-{lang}.stderr').read_text()==''
assert len((out/'ledger-status.tsv').read_text().splitlines())==412
focused=(out/'focused.log').read_text()
assert not re.search(r'--- (FAIL|SKIP):|^panic:|^fatal error:',focused,re.M)
for name in ['TestPackedSnapshotBudgetUnpublishedCurrentStorage','TestPackedSnapshotBudgetPublishedStorageDeduplicates','TestPackedSnapshotBudgetCurrentAndRetiredPages']:
 assert re.search(r'^--- PASS: '+name+' ',focused,re.M),name
summary={
 'schema':'gts-packed-snapshot-budget-qualification/v1',
 'source_manifest_sha256':hashlib.sha256((root/'packed-snapshot-budget-final/source.sha256').read_bytes()).hexdigest(),
 'sessions':412,'edit_steps':29664,'fixture_types':dict(Counter(sessions)),
 'no_edit_allocations':0,'C_fixture_checks':618,'failed':0,'skipped':0,
 'actual_ledger_rows_compared':412,'actual_work_reuse_rows_changed':0,
 'focused_top_level_tests':len(re.findall(r'^--- PASS:',focused,re.M)),
 'memory_fix':'current packed snapshot page charged at full capacity exactly once, including unpublished slots',
 'performance_claim':False,'allowlist_changed':False,'merges_held':True
}
(out/'validated-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
