# PREPARED ONLY. Execute inside the parent-owned bounded Docker job.
# Mount canonical source read-only at /candidate and the go-ci-blockers directory
# at /controls. Use shared /runtime scratch/cache; no alternate checkout.
# Baseline is expected to fail specific packed-page accounting assertions.
set -euo pipefail
: "${GTS_PACKED_BUDGET_EVIDENCE:?select a new evidence directory}"
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build
export GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
control=/controls/packed-snapshot-budget-v1
scratch=/runtime/tmp/gotreesitter-packed-snapshot-budget-v1
mkdir -p "$scratch" "$GTS_PACKED_BUDGET_EVIDENCE"
cd /candidate
sha256sum --quiet -c "$control/source-authentication.container.sha256"
sha256sum --quiet -c "$control/controls-authentication.container.sha256"
for variant in before after; do
 go test -c -tags gts_parsercorephase0 -overlay="$control/$variant.container.json" -o "$scratch/$variant.test" . > "$GTS_PACKED_BUDGET_EVIDENCE/$variant-build.log" 2>&1
 set +e
 "$scratch/$variant.test" -test.run '^TestPackedSnapshotBudget.*Private$' -test.v -test.count=1 > "$GTS_PACKED_BUDGET_EVIDENCE/$variant.log" 2>&1
 status=$?
 set -e
 printf '%s\t%d\n' "$variant" "$status" >> "$GTS_PACKED_BUDGET_EVIDENCE/process-status.tsv"
done
sha256sum --quiet -c "$control/source-authentication.container.sha256"
sha256sum --quiet -c "$control/controls-authentication.container.sha256"
# The parent must inspect the exact failure/pass records, no empty selections,
# old-byte/reset controls and original memory suites before qualification.
