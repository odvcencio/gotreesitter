# Unpublished packed scanner-page budget proof

Prepared sparse overlays only; no build, test, Docker run, production edit, threshold change, commit or merge occurred here. The parent must execute the before/after controls before calling this a reproduced runtime defect.

`ScannerSnapshotPages.CurrentStorage` returns both current small and packed allocations, including unused/unpublished slots. The existing scheduler footprint ignores the packed result. A packed allocation can therefore remain absent from reachable published snapshots while still owned by the scheduler's page field. The candidate adds the second current identity, marks it seen through live records, and charges it only when those references have not already charged the complete allocation. It changes no page storage, snapshots, ownership checks, generation, rollback rules, budgets or polling cadence.

Use `before.container.json` and `after.container.json` from the existing network-isolated bounded Docker job. Selector: `^TestPackedSnapshotBudget.*Private$`, tags `gts_parsercorephase0`. The supplied commands build one root binary per overlay and retain both exit codes, including the expected baseline failure.

Three test families cover:

- Current packed-only, small-only negative control, and both page shapes without publishing records; exact soft/hard boundaries and dropping the current pages.
- Packed/small pairs shared by active headers, rollback copies and duplicate requests; one charge per physical allocation, old references remaining charged across page reset, and release of all scheduler owners.
- An older packed page retained by a request while a new current page is unpublished; publication must not add a second capacity charge, and rollover/reset must not overwrite older immutable data.

The controls initialize immutable synthetic records only to exercise owned storage and references. They make no claim about scanner admission, parser output, C parity or grammar throughput. Source guards pin the current accounting function, state and page definitions. Candidate reversal is byte-exact against the frozen source. The test remains private; any eventual promotion must respect the root-file budget and the repository's affected-language gates.
