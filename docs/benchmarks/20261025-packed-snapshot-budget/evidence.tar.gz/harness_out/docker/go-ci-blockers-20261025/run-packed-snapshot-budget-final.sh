set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/packed-snapshot-budget-final
mkdir -p "$scratch" /evidence/invariants /evidence/cgo /evidence/ledger
cd /candidate
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
go test ./cmd/v1layout ./cmd/perfcounterledger -count=1 > /evidence/layout-guard-tests.log 2>&1
go run ./cmd/v1layout -base origin/main > /evidence/layout.log 2>&1
go test -c -tags gts_parsercorephase0 -o "$scratch/root.test" . > /evidence/root-build.log 2>&1
"$scratch/root.test" -test.run '^Test(PackedSnapshotBudget.*|DiagnosticParserCoreVersionLexerSnapshot.*|DiagnosticParserCoreVersionLexerClone.*|VersionLexerPaired.*|CompactAcceptance.*|RuntimeMemory.*|ParseMemory.*|MemoryBudgetDiagnosticLatchesFirstSource|ParserCoreFreshFullRunner.*)$' -test.count=1 -test.v -test.timeout=4m > /evidence/focused.log 2>&1
for route in 0 1; do
 while IFS= read -r language; do
  GTS_ADMISSION_CANDIDATE=$route GOTREESITTER_V1_INVARIANT_LANGUAGE=$language "$scratch/root.test" -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=3m > "/evidence/invariants/$route-$language.log" 2>&1
  printf '%s\t%s\t0\n' "$route" "$language" >> /evidence/invariant-status.tsv
 done < /controls/fleet-controls/languages.txt
done
cd /candidate/cgo_harness
go test -c -tags treesitter_c_parity,gts_parsercorephase0 -o "$scratch/cgo.test" . > /evidence/cgo-build.log 2>&1
while IFS= read -r language; do
 GTS_ADMISSION_CANDIDATE=1 GTS_PARITY_MODE=exhaustive GTS_PARITY_COMPARE_FIELDS=1 GTS_PARITY_COMPARE_HAS_ERROR=1 GTS_PARITY_IGNORE_KNOWN_SKIPS=1 "$scratch/cgo.test" -test.run "^TestParity(FreshParse|IncrementalParse|HasNoErrors)$/^${language}$" -test.count=1 -test.v -test.timeout=3m > "/evidence/cgo/$language.log" 2>&1
 printf '%s\t0\n' "$language" >> /evidence/cgo-status.tsv
done < /controls/fleet-controls/languages.txt
cd /candidate
go build -tags gts_parsercorephase0 -o "$scratch/ledger" ./cmd/perfcounterledger > /evidence/ledger-build.log 2>&1
for route in default candidate; do
 mode=0; if [[ "$route" = candidate ]]; then mode=1; fi
 while IFS= read -r language; do
  GTS_ADMISSION_CANDIDATE=$mode "$scratch/ledger" --child-route "$route" --langs "$language" > "/evidence/ledger/$route-$language.json" 2> "/evidence/ledger/$route-$language.stderr"
  printf '%s\t%s\t0\n' "$route" "$language" >> /evidence/ledger-status.tsv
 done < /controls/fleet-controls/languages.txt
done
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1
sha256sum "$scratch/root.test" "$scratch/cgo.test" "$scratch/ledger" > /evidence/binary.sha256
printf 'saved-source correctness and counter processes complete; inspect exact coverage/equality before claiming a pass\n' > /evidence/completed.txt
