set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-before.log 2>&1
go test -race -tags gts_parsercorephase0 -run '^(TestPackedSnapshotBudget.*|TestFreshSnapshotPagesKeepStaleVersionSnapshotImmutable|TestDiagnosticParserCoreVersionLexerSnapshotRollbackRestoresImmutablePointer|TestDiagnosticParserCoreVersionLexerSnapshotResetClearsRetainedHeaderBuffers)$' -count=1 -v -timeout=4m . > /evidence/race-root.log 2>&1
go test -race -run '^TestScannerSnapshotPages.*$' -count=1 -v -timeout=3m ./internal/parsercorephase0 > /evidence/race-pages.log 2>&1
sha256sum --quiet -c /controls/packed-snapshot-budget-final/source.sha256 > /evidence/source-after.log 2>&1
