set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
go env GOOS GOARCH > /evidence/platform.txt
[[ "$(go env GOARCH)" = arm64 ]]
cd /candidate
go test -c -tags gts_parsercorephase0 -o /evidence/candidate.test . > /evidence/root-build.log 2>&1
/evidence/candidate.test -test.run '^Test(PrimitiveProofModeSetRetainsBounds|TokenInvariantPrimitive.*|TokenInvariantWhitespace.*|MissingNodeDependencyLayoutAndOwnership)$' -test.count=1 -test.v -test.timeout=5m > /evidence/arena-unit.log 2>&1
for lang in go yaml; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /evidence/candidate.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/$lang-invariant-$route.log" 2>&1
 done
done
/evidence/candidate.test -test.run '^Test(CompactAcceptance(ChangedSourceKeepsRebuildBudget|CachedPublicationStopControl)|CompactMemoryBudgetDetectsGrowthAfterSmallPoll|CompactAcceptance.*(MemoryBudget|RetentionBound)|CompactArenaReserve.*(Budget|RetentionCap)|CompactExternalScannerCheckpointCopyMemoryBudget|CompactRecoveryMemoMemoryBudget|CompactBorrowedMaterializationProjectionMemoryBudget|G18RefSetSchedulerMemoryBudgetAccounting|RuntimeMemoryBudget.*|RuntimeMemoryHardCeilingStillStopsParse|ParseMemoryHardCeiling.*)$' -test.count=1 -test.v -test.timeout=8m > /evidence/memory.log 2>&1
for role in baseline candidate; do
 cd "/$role"
 go build -tags gts_parsercorephase0 -o "/evidence/$role-ledger" ./cmd/perfcounterledger > "/evidence/$role-ledger-build.log" 2>&1
 for lang in go yaml; do
  "/evidence/$role-ledger" --langs "$lang" > "/evidence/$role-$lang-ledger.json" 2> "/evidence/$role-$lang-ledger.log"
 done
done
for lang in go yaml; do cmp "/evidence/baseline-$lang-ledger.json" "/evidence/candidate-$lang-ledger.json"; done
printf 'identical\n' > /evidence/work-gate.txt
cd /candidate
go test ./internal/incr -run '^TestProbeModeSet' -count=1 -v > /evidence/mode-unit.log 2>&1
CGO_ENABLED=1 go test -race ./internal/incr -run '^TestProbeModeSet' -count=1 -v > /evidence/mode-race.log 2>&1
CGO_ENABLED=1 go test -race -tags gts_parsercorephase0 . -run '^Test(PrimitiveProofModeSetRetainsBounds|TokenInvariantPrimitiveProof.*)$' -count=1 -v -timeout=8m > /evidence/root-race.log 2>&1
bash scripts/run_randomized_benchmarks.sh --primary-go-suite --baseline-root /baseline --baseline-output /evidence/baseline-primary.txt --output /evidence/candidate-primary.txt --lock-path /evidence/bench.lock --runs 20 --seed-start 162001 --benchtime 750ms > /evidence/primary-driver.log 2>&1
printf 'complete\n' > /evidence/complete.txt
