set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
cd /candidate
gofmt -d token_invariant_lexical_proof.go token_invariant_lexical_proof_test.go internal/incr/probe_modes.go internal/incr/probe_modes_test.go > /evidence/format-diff.txt
[[ ! -s /evidence/format-diff.txt ]]
go test ./internal/incr -run '^TestProbeModeSet' -v -count=1 > /evidence/internal-unit.log 2>&1
go test -c -tags gts_parsercorephase0 -o /evidence/installed.test . > /evidence/build.log 2>&1
/evidence/installed.test -test.run '^Test(PrimitiveProofModeSetRetainsBounds|TokenInvariantPrimitive.*|TokenInvariantWhitespace.*|MissingNodeDependencyLayoutAndOwnership)$' -test.count=1 -test.v > /evidence/root-unit.log 2>&1
for lang in go yaml; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /evidence/installed.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/$lang-invariant-$route.log" 2>&1
 done
done
go build -tags gts_parsercorephase0 -o /evidence/installed-ledger ./cmd/perfcounterledger > /evidence/ledger-build.log 2>&1
while IFS= read -r lang; do
 /evidence/installed-ledger --langs "$lang" > "/evidence/$lang-ledger.json" 2> "/evidence/$lang-ledger.log"
 cmp "/evidence/$lang-ledger.json" "/expected/ledger/baseline-$lang.json"
done < /controls/languages.txt
printf 'complete\n' > /evidence/complete.txt
