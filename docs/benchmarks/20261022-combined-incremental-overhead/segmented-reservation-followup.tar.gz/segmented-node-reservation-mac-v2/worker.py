from pathlib import Path
import json,hashlib,os,fcntl,subprocess,time
p=Path(__file__).resolve().parent
root=p.parent
out=p/'native-out';out.mkdir(exist_ok=False)
def manifest(q):
 return {str(x.relative_to(q)):hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted(q.rglob('*.go'))}
with (root.parent/'compute.lock').open('w') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 before={name:manifest(p/name) for name in ['baseline','candidate']}
 (out/'source-before.json').write_text(json.dumps(before,sort_keys=True)+'\n')
 args=['/usr/local/bin/docker','run','--name','gts-segmented-node-reservation-native-arm64-v2-20261022','--platform','linux/arm64','--network','none','--memory','4g','--memory-swap','4g','--cpus','2','--cpuset-cpus','2,3','--pids-limit','256','-e','GOMAXPROCS=1','-e','GOMEMLIMIT=3GiB','-e','CGO_ENABLED=0','-e','GOPROXY=off','-e','GOCACHE=/go-build','-e','GOMODCACHE=/go-mod','-v',str(p/'baseline')+':/baseline:ro','-v',str(p/'candidate')+':/candidate:ro','-v',str(p)+':/controls:ro','-v',str(out)+':/evidence','-v',str(root/'inactive-scanner-trials-v1/go-build')+':/go-build','-v',str(root/'locked-c-oracle-amd64-v1/go-mod')+':/go-mod:ro','golang@sha256:3b4a11519ad929d1e1d261a12cff056f0c85b735253d7d861346b9c6f8b36437','bash','/controls/native.sh']
 (out/'command.json').write_text(json.dumps(args,indent=2)+'\n')
 (p/'started.json').write_text(json.dumps({'pid':os.getpid(),'started':time.time(),'name':args[args.index('--name')+1]})+'\n')
 env=dict(os.environ);env['PATH']='/Applications/Docker.app/Contents/Resources/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin'
 with (out/'container.log').open('wb') as f:
  try:code=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=1800).returncode
  except subprocess.TimeoutExpired:
   code=124;subprocess.run(['/usr/local/bin/docker','stop','--time','10',args[args.index('--name')+1]],env=env,stdout=f,stderr=subprocess.STDOUT)
 name=args[args.index('--name')+1]
 info=json.loads(subprocess.check_output(['/usr/local/bin/docker','inspect',name],env=env,text=True))[0]
 (out/'inspect.json').write_text(json.dumps(info,indent=2)+'\n')
 after={name:manifest(p/name) for name in ['baseline','candidate']}
 (out/'source-after.json').write_text(json.dumps(after,sort_keys=True)+'\n')
 (out/'audit.json').write_text(json.dumps({'exit_code':code,'state':info['State'],'source_unchanged':before==after},indent=2)+'\n')
 subprocess.run(['/usr/local/bin/docker','rm',name],env=env,check=True,stdout=subprocess.DEVNULL)
