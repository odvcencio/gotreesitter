package gotreesitter

import (
	"testing"
	"unsafe"
)

func TestSegmentedPrimaryReservationPreservesCapacityAndRetention(t *testing.T) {
	a := newNodeArena(arenaClassFull)
	target := maxRetainedNodeCapacityForClass(arenaClassFull) + 17
	a.ensureFullParseNodeCapacity(target)
	if a.segmentedNodeSlabs == 0 {
		t.Fatal("large reservation was not split")
	}
	sum := len(a.nodes)
	for _, s := range a.nodeSlabs {
		sum += len(s.data)
	}
	if sum != target {
		t.Fatalf("reserved %d want %d", sum, target)
	}
	bytes := a.allocatedBytes
	first := a.allocNode()
	first.startByte = 17
	for i := 1; i < target; i++ {
		a.allocNode().startByte = uint32(i + 17)
	}
	if a.allocatedBytes != bytes || first.startByte != 17 || a.used != target {
		t.Fatal("reserved allocation grew or relocated nodes")
	}
	for _, s := range a.nodeSlabs {
		if nodeBytesForCap(len(s.data)) > maxOverflowSlabGrowthBytes {
			t.Fatal("unbounded chunk")
		}
	}
	a.reset()
	if len(a.nodes) != 0 || len(a.nodeSlabs) != 0 || a.segmentedNodeSlabs != 0 {
		t.Fatal("oversized primary pieces survived the old retention ceiling")
	}
	if unsafe.Sizeof(Node{}) != 104 {
		t.Fatal("public Node layout changed")
	}
}
func TestSegmentedPrimaryReservationRetainsOnlyActualOverflow(t *testing.T) {
	a := newNodeArena(arenaClassFull)
	target := maxRetainedNodeCapacityForClass(arenaClassFull) + 17
	a.ensureFullParseNodeCapacity(target)
	prefix := a.segmentedNodeSlabs
	for i := 0; i < target+1; i++ {
		a.allocNode()
	}
	if len(a.nodeSlabs) <= prefix {
		t.Fatal("missing actual overflow")
	}
	overflow := &a.nodeSlabs[prefix].data[0]
	a.reset()
	if len(a.nodes) != 0 || len(a.nodeSlabs) == 0 || &a.nodeSlabs[0].data[0] != overflow {
		t.Fatal("retention changed for actual overflow")
	}
}
