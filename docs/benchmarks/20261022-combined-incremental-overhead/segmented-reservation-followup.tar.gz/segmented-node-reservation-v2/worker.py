from pathlib import Path
import subprocess,json,fcntl,time
p=Path(__file__).resolve().parent
with open('/tmp/gotreesitter-compact-storage-docker.lock','w') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 args=json.loads((p/'command.json').read_text())
 with (p/'out/container.log').open('wb') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=600)
 name=args[args.index('--name')+1];info=json.loads(subprocess.check_output(['docker','inspect',name],text=True))[0]
 (p/'out/inspect.json').write_text(json.dumps(info,indent=2)+'\n')
 subprocess.run(['docker','rm',name],check=True,stdout=subprocess.DEVNULL)
 (p/'out/audit.json').write_text(json.dumps({'exit_code':r.returncode,'state':info['State']},indent=2)+'\n')
