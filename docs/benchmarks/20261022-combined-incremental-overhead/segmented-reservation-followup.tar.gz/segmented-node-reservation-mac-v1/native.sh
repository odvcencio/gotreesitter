set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
go env GOOS GOARCH > /evidence/platform.txt
[[ "$(go env GOARCH)" = arm64 ]]
cd /candidate
go test ./internal/nodearena -run "^TestSplitReservationExactAndBounded$" -v -count=1 > /evidence/plan-unit.log 2>&1
go test -c -tags gts_parsercorephase0 -o /evidence/candidate.test . > /evidence/root-build.log 2>&1
/evidence/candidate.test -test.run '^Test(SegmentedPrimaryReservation.*|MissingNodeDependencyLayoutAndOwnership|FullParseNodeCapacity.*|StructuralDensityNodeCap.*|.*Arena.*Hint.*|.*Arena.*Capacity.*)$' -test.count=1 -test.v -test.timeout=5m > /evidence/arena-unit.log 2>&1
for lang in go yaml; do
 for route in 0 1; do
  GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /evidence/candidate.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/$lang-invariant-$route.log" 2>&1
 done
done
/evidence/candidate.test -test.run '^Test(CompactAcceptance(ChangedSourceKeepsRebuildBudget|CachedPublicationStopControl)|CompactMemoryBudgetDetectsGrowthAfterSmallPoll|CompactAcceptance.*(MemoryBudget|RetentionBound)|CompactArenaReserve.*(Budget|RetentionCap)|CompactExternalScannerCheckpointCopyMemoryBudget|CompactRecoveryMemoMemoryBudget|CompactBorrowedMaterializationProjectionMemoryBudget|G18RefSetSchedulerMemoryBudgetAccounting|RuntimeMemoryBudget.*|RuntimeMemoryHardCeilingStillStopsParse|ParseMemoryHardCeiling.*)$' -test.count=1 -test.v -test.timeout=8m > /evidence/memory.log 2>&1
for role in baseline candidate; do
 cd "/$role"
 go build -tags gts_parsercorephase0 -o "/evidence/$role-ledger" ./cmd/perfcounterledger > "/evidence/$role-ledger-build.log" 2>&1
 for lang in go yaml; do
  "/evidence/$role-ledger" --langs "$lang" > "/evidence/$role-$lang-ledger.json" 2> "/evidence/$role-$lang-ledger.log"
 done
done
for lang in go yaml; do cmp "/evidence/baseline-$lang-ledger.json" "/evidence/candidate-$lang-ledger.json"; done
printf 'identical\n' > /evidence/work-gate.txt
cp /controls/rss-wrapper.go.txt /evidence/rss-wrapper.go
go build -o /evidence/rsswrap /evidence/rss-wrapper.go > /evidence/rss-wrapper-build.log 2>&1
for role in baseline candidate; do
 cd "/$role/roottest/bench"
 go test -c -tags gts_parsercorephase0 -o "/evidence/$role-memory.test" . > "/evidence/$role-memory-build.log" 2>&1
done
mkdir /evidence/rss
for seed in $(seq 160001 160020); do
 if (( seed % 2 )); then roles=(baseline candidate); else roles=(candidate baseline); fi
 for role in "${roles[@]}"; do
  cd "/$role/roottest/bench"
  GTS_FRESH_MEMORY_LANG=go GTS_ADMISSION_CANDIDATE=0 /evidence/rsswrap "/evidence/rss/$role-$seed.json" "/evidence/$role-memory.test" -test.run '^$' -test.bench '^BenchmarkFreshMemory$/^go$/^1024KiB$' -test.benchtime=2x -test.count=1 -test.benchmem -test.shuffle="$seed" -test.timeout=5m > "/evidence/rss/$role-$seed.log" 2>&1
 done
done
printf 'complete\n' > /evidence/complete.txt
