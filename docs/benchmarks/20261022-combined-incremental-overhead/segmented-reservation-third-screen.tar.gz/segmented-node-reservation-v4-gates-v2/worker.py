from pathlib import Path
import subprocess,json,fcntl
p=Path(__file__).resolve().parent
with open('/tmp/gotreesitter-compact-storage-docker.lock','w') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 args=json.loads((p/'command.json').read_text());name=args[args.index('--name')+1]
 with (p/'out/container.log').open('wb') as f:
  try:code=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,timeout=1800).returncode
  except subprocess.TimeoutExpired:
   code=124;subprocess.run(['docker','stop','--time','10',name],stdout=f,stderr=subprocess.STDOUT)
 info=json.loads(subprocess.check_output(['docker','inspect',name],text=True))[0]
 (p/'out/inspect.json').write_text(json.dumps(info,indent=2)+'\n')
 (p/'out/audit.json').write_text(json.dumps({'exit_code':code,'state':info['State']},indent=2)+'\n')
 subprocess.run(['docker','rm',name],check=True,stdout=subprocess.DEVNULL)
