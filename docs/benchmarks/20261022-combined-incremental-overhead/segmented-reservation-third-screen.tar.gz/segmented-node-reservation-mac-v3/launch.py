from pathlib import Path
import json,hashlib,tarfile,shutil,os,subprocess,sys
p=Path(__file__).resolve().parent;info=json.loads((p/'transfer.json').read_text())
for name,expected in info['archives'].items():
 d=(p/name).read_bytes()
 if len(d)!=expected['bytes'] or hashlib.sha256(d).hexdigest()!=expected['sha256']:raise RuntimeError('archive mismatch '+name)
base=p/'baseline';base.mkdir()
with tarfile.open(p/'baseline.tar.gz') as t:
 for m in t.getmembers():
  q=base/m.name
  if not q.resolve().is_relative_to(base.resolve()):raise RuntimeError('unsafe archive path')
  if m.issym() and not (q.parent/m.linkname).resolve().is_relative_to(base.resolve()):raise RuntimeError('unsafe symlink')
  if m.islnk() and not (base/m.linkname).resolve().is_relative_to(base.resolve()):raise RuntimeError('unsafe hardlink')
 t.extractall(base)
def overlay(root,name,expected):
 with tarfile.open(p/name) as t:
  for m in t.getmembers():
   if not m.isfile() or m.name not in expected:raise RuntimeError('unexpected overlay file')
   q=root/m.name
   if not q.resolve().is_relative_to(root.resolve()):raise RuntimeError('unsafe overlay')
   data=t.extractfile(m).read()
   if hashlib.sha256(data).hexdigest()!=expected[m.name]:raise RuntimeError('overlay hash mismatch')
   q.parent.mkdir(parents=True,exist_ok=True);temp=q.with_name(q.name+'.warm-reservation-tmp');temp.write_bytes(data);os.replace(temp,q)
overlay(base,'baseline-overlay.tar.gz',info['baseline_changes'])
candidate=p/'candidate';shutil.copytree(base,candidate,copy_function=os.link,symlinks=True)
overlay(candidate,'candidate-overlay.tar.gz',info['candidate_changes'])
with (p/'worker.log').open('wb') as log:
 worker=subprocess.Popen([sys.executable,str(p/'worker.py')],stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
(p/'launch.json').write_text(json.dumps({'pid':worker.pid,'source_validated':True})+'\n')
print(json.dumps({'pid':worker.pid,'source_validated':True}))
