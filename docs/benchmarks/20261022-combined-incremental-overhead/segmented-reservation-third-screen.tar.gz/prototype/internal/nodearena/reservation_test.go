package nodearena

import "testing"

func TestSplitReservationExactAndBounded(t *testing.T) {
	for _, width := range []int{80, 104, 128} {
		for _, total := range []int{1, 640, 64 * 1024 * 1024 / width, 64*1024*1024/width + 1, 1048591, 1500000} {
			p := SplitReservation(total, width, 64*1024*1024, 32*1024*1024, 8*1024*1024)
			sum := p.Primary
			if p.Slabs > 0 {
				remaining := total - p.Primary
				for i := 0; i < p.Slabs; i++ {
					n := p.Chunk
					if n > remaining {
						n = remaining
					}
					if n <= 0 || n*width > 8*1024*1024 {
						t.Fatal("unbounded or empty chunk")
					}
					sum += n
					remaining -= n
				}
			}
			if sum != total {
				t.Fatalf("%+v sum=%d want %d", p, sum, total)
			}
		}
	}
	if p := SplitReservation(1, 0, 1, 1, 1); p != (Reservation{}) {
		t.Fatal("invalid plan")
	}
}
