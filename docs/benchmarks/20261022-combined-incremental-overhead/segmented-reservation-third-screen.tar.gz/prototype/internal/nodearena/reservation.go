// Package nodearena supplies pointer-free allocation plans for node storage.
package nodearena

type Reservation struct{ Primary, Chunk, Slabs int }

// SplitReservation keeps ordinary reservations contiguous. An oversized
// primary is split into bounded allocations with exactly the same node count.
// Its owner must still discard all pieces under the original primary policy.
func SplitReservation(total, nodeBytes, retainedBytes, primaryBytes, chunkBytes int) Reservation {
	if total <= 0 || nodeBytes <= 0 || retainedBytes <= 0 || primaryBytes <= 0 || chunkBytes <= 0 {
		return Reservation{}
	}
	if total <= retainedBytes/nodeBytes {
		return Reservation{Primary: total}
	}
	primary := primaryBytes / nodeBytes
	chunk := chunkBytes / nodeBytes
	if primary <= 0 || chunk <= 0 || primary >= total {
		return Reservation{Primary: total}
	}
	return Reservation{Primary: primary, Chunk: chunk, Slabs: 1 + (total-primary-1)/chunk}
}
