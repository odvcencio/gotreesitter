package gotreesitter

import (
	"testing"
	"unsafe"
)

func TestSegmentedPrimaryReservationPreservesCapacityAndRetention(t *testing.T) {
	a := newNodeArena(arenaClassFull)
	target := maxRetainedNodeCapacityForClass(arenaClassFull) + 17
	a.ensureFullParseNodeCapacity(target)
	if a.segmentedNodeSlabs == 0 {
		t.Fatal("large reservation was not split")
	}
	sum := len(a.nodes)
	for _, s := range a.nodeSlabs {
		sum += len(s.data)
	}
	if sum != target {
		t.Fatalf("reserved %d want %d", sum, target)
	}
	bytes := a.allocatedBytes
	first := a.allocNode()
	first.startByte = 17
	for i := 1; i < target; i++ {
		a.allocNode().startByte = uint32(i + 17)
	}
	if a.allocatedBytes != bytes || first.startByte != 17 || a.used != target {
		t.Fatal("reserved allocation grew or relocated nodes")
	}
	for _, s := range a.nodeSlabs {
		if nodeBytesForCap(len(s.data)) > maxOverflowSlabGrowthBytes {
			t.Fatal("unbounded chunk")
		}
	}
	a.reset()
	if len(a.nodes) != 0 || len(a.nodeSlabs) != 0 || a.segmentedNodeSlabs != 0 {
		t.Fatal("oversized primary pieces survived the old retention ceiling")
	}
	if unsafe.Sizeof(Node{}) != 104 {
		t.Fatal("public Node layout changed")
	}
}
func TestSegmentedPrimaryReservationRetainsOnlyActualOverflow(t *testing.T) {
	a := newNodeArena(arenaClassFull)
	target := maxRetainedNodeCapacityForClass(arenaClassFull) + 17
	a.ensureFullParseNodeCapacity(target)
	prefix := a.segmentedNodeSlabs
	for i := 0; i < target+1; i++ {
		a.allocNode()
	}
	if len(a.nodeSlabs) <= prefix {
		t.Fatal("missing actual overflow")
	}
	if len(a.nodeSlabs[prefix].data) != nodeCapacityForClass(arenaClassFull) {
		t.Fatal("first true overflow changed growth policy")
	}
	overflow := &a.nodeSlabs[prefix].data[0]
	a.reset()
	if len(a.nodes) != 0 || len(a.nodeSlabs) == 0 || &a.nodeSlabs[0].data[0] != overflow {
		t.Fatal("retention changed for actual overflow")
	}
}

func TestSegmentedPrimaryMetadataIsLazyAndShared(t *testing.T) {
	a := newNodeArena(arenaClassFull)
	target := maxRetainedNodeCapacityForClass(arenaClassFull) + 17
	a.ensureFullParseNodeCapacity(target)
	first := a.allocNode()
	first.ownerArena = a
	var last *Node
	for i := 1; i < target; i++ {
		last = a.allocNode()
	}
	last.ownerArena = a
	before := a.allocatedBytes
	a.budgetBaselineBytes = before
	a.budgetBytes = 1
	if legacyReuseMetadataWord(first, true, false) != nil || a.allocatedBytes != before {
		t.Fatal("metadata exceeded the bound")
	}
	a.budgetBytes = 0
	for _, alias := range []bool{false, true} {
		left := legacyReuseMetadataWord(first, true, alias)
		right := legacyReuseMetadataWord(last, true, alias)
		if left == nil || right == nil || left == right {
			t.Fatal("missing or aliased metadata")
		}
		*left = 17
		*right = 23
		if *legacyReuseMetadataWord(first, false, alias) != 17 || *legacyReuseMetadataWord(last, false, alias) != 23 {
			t.Fatal("metadata moved or overlapped")
		}
		var words []uint32
		if alias {
			words = a.nodeReuseRawSymbols
		} else {
			words = a.nodeReuseLookahead
		}
		total := cap(words)
		for i := 0; i < a.segmentedNodeSlabs; i++ {
			if alias {
				total += cap(a.nodeSlabs[i].rawSymbols)
			} else {
				total += cap(a.nodeSlabs[i].reuseLookahead)
			}
		}
		if total != target {
			t.Fatalf("metadata capacity=%d want %d", total, target)
		}
	}
	if a.allocatedBytes-before != int64(target)*8 {
		t.Fatalf("metadata charge=%d want %d", a.allocatedBytes-before, int64(target)*8)
	}
	a.reset()
	if len(a.nodes) != 0 || len(a.nodeSlabs) != 0 || a.nodeReuseLookahead != nil || a.nodeReuseRawSymbols != nil {
		t.Fatal("logical primary metadata retained")
	}
}
