#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOMAXPROCS=1 GOWORK=off GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
go env GOOS GOARCH > /evidence/platform.txt
for role in baseline candidate; do
 cd "/${role}"
 go test ./internal/incr -count=1 -timeout=5m -v > "/evidence/${role}-incr.log" 2>&1
 go test -c -tags gts_parsercorephase0 -o "/evidence/${role}.test" . > "/evidence/${role}-root-build.log" 2>&1
 "/evidence/${role}.test" -test.run '^Test(CompactReuseDependency|TokenInvariant.*(Lookahead|Primitive))' -test.count=1 -test.v -test.timeout=5m > "/evidence/${role}-focused-root.log" 2>&1
 for route in 0 1; do
  for lang in go yaml; do
   GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" "/evidence/${role}.test" -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/${role}-invariant-${route}-${lang}.log" 2>&1
  done
 done
 go build -tags gts_parsercorephase0 -o "/evidence/${role}-ledger" ./cmd/perfcounterledger > "/evidence/${role}-counter-build.log" 2>&1
 "/evidence/${role}-ledger" --write --output "/evidence/${role}-ledger.json" > "/evidence/${role}-counter.log" 2>&1
done
cp /evidence/candidate.test /evidence/root.test
cd /candidate
go test -race ./internal/incr -count=1 -timeout=5m -v > /evidence/candidate-incr-race.log 2>&1
CGO_ENABLED=0 GOARCH=386 go test -c -overlay=/evidence/header-overlay.json ./internal/incr -o /evidence/incr386.test > /evidence/header-386-build.log 2>&1
printf 'complete\n' > /evidence/complete.txt
