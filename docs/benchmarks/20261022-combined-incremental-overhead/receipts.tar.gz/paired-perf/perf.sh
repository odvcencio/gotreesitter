#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOMAXPROCS=1 GOWORK=off GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
export GTS_ADMISSION_CANDIDATE=1 GOT_BENCH_FUNC_COUNT=500
go version > /evidence/go-version.txt
go env GOOS GOARCH > /evidence/platform.txt
if [[ "$(go env GOARCH)" != arm64 ]]; then exit 30; fi
cd /candidate
CGO_ENABLED=0 GOARCH=386 go test -c -overlay=/evidence/header-overlay.json ./internal/incr -o /evidence/incr386.test > /evidence/header-386-build.log 2>&1
go test -overlay=/evidence/header-overlay.json ./internal/incr -run '^Test(ReadWordPages|PagedReadHistory)' -count=1 -v -timeout=5m > /evidence/header-native.log 2>&1
for role in baseline candidate; do
 cd "/${role}"
 go test -c -tags gts_parsercorephase0 -o "/evidence/${role}.test" . > "/evidence/${role}-build.log" 2>&1
done
cd /candidate
bash /evidence/randomized-benchmarks.sh --output /evidence/go-after.txt --baseline-root /baseline --baseline-output /evidence/go-before.txt --lock-path /evidence/benchmark.lock --runs 20 --seed-start 152001 --benchtime 750ms --tags gts_parsercorephase0 --bench-regex '^BenchmarkOrderedReceiptsGo$' --require-benchmarks 'BenchmarkOrderedReceiptsGo/full_dfa,BenchmarkOrderedReceiptsGo/full_dfa_3500,BenchmarkOrderedReceiptsGo/single_byte_edit_dfa,BenchmarkOrderedReceiptsGo/no_edit_dfa,BenchmarkOrderedReceiptsGo/fresh_one_mib,BenchmarkOrderedReceiptsGo/query_compile,BenchmarkOrderedReceiptsGo/grammargen_lr' > /evidence/go-runner.log 2>&1
bash /evidence/randomized-benchmarks.sh --output /evidence/yaml-after.txt --baseline-root /baseline --baseline-output /evidence/yaml-before.txt --lock-path /evidence/benchmark.lock --runs 20 --seed-start 153001 --benchtime 750ms --tags gts_parsercorephase0 --bench-regex '^BenchmarkCompactThroughputYAML$' --require-benchmarks 'BenchmarkCompactThroughputYAML/r4_legacy,BenchmarkCompactThroughputYAML/r4_ordinary,BenchmarkCompactThroughputYAML/r4_owned,BenchmarkCompactThroughputYAML/eof8k_legacy,BenchmarkCompactThroughputYAML/eof8k_ordinary,BenchmarkCompactThroughputYAML/eof8k_owned' > /evidence/yaml-runner.log 2>&1
# Compile the memory benchmark and measurement wrapper before either runs.
cp /evidence/rss-wrapper.go.txt /evidence/rss-wrapper.go
go build -o /evidence/rsswrap /evidence/rss-wrapper.go > /evidence/rss-wrapper-build.log 2>&1
for role in baseline candidate; do
 cd "/${role}/roottest/bench"
 go test -c -tags gts_parsercorephase0 -o "/evidence/${role}-memory.test" . > "/evidence/${role}-memory-build.log" 2>&1
done
mkdir /evidence/rss
for seed in $(seq 154001 154020); do
 if (( seed % 2 )); then roles=(baseline candidate); else roles=(candidate baseline); fi
 for role in "${roles[@]}"; do
  cd "/${role}/roottest/bench"
  GTS_FRESH_MEMORY_LANG=go GTS_ADMISSION_CANDIDATE=0 /evidence/rsswrap "/evidence/rss/${role}-${seed}.json" "/evidence/${role}-memory.test" -test.run '^$' -test.bench '^BenchmarkFreshMemory$/^go$/^1024KiB$' -test.benchtime=2x -test.count=1 -test.benchmem -test.shuffle="$seed" -test.timeout=5m > "/evidence/rss/${role}-${seed}.log" 2>&1
 done
done
printf 'complete\n' > /evidence/complete.txt
