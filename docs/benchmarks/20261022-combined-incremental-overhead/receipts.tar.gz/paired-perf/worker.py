from pathlib import Path
import fcntl, hashlib, json, os, re, shutil, subprocess, statistics

base = Path('/Users/georgevillavicencio/.local/state/gotreesitter-compute/20261021-arm64-native-fields')
prototype = base / 'read-history-publication-net-v1'
lab = prototype / 'paired-perf'
original = prototype / 'baseline'
candidate_source = prototype / 'candidate'
deps = base / 'locked-c-oracle-amd64-v1'
docker = '/usr/local/bin/docker'
image = 'golang@sha256:3b4a11519ad929d1e1d261a12cff056f0c85b735253d7d861346b9c6f8b36437'
os.environ['PATH'] = '/Applications/Docker.app/Contents/Resources/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def manifest(root):
    return {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob('*.go')) if p.is_file()}

def checkout():
    path = '/Users/georgevillavicencio/Projects/gotreesitter'
    return {'head': subprocess.check_output(['git', '-C', path, 'rev-parse', 'HEAD'], text=True).strip(),
            'status': subprocess.check_output(['git', '-C', path, 'status', '--porcelain=v1'], text=True)}

def replace(path, data):
    temporary = path.with_name(path.name + '.gts-tmp')
    temporary.write_bytes(data)
    temporary.replace(path)

def run_container(phase, platform, roots, extra):
    evidence = lab / phase
    evidence.mkdir()
    for name in ['oracle.go.txt', 'cgo-overlay.json', 'header-overlay.json', 'header-layout.go.txt', 'randomized-benchmarks.sh', 'rss-wrapper.go.txt']:
        shutil.copy2(lab / name, evidence / name)
    name = 'gts-read-net-v1-' + phase + '-20261022'
    args = [docker, 'run', '--platform', platform, '--name', name, '--network', 'none',
            '--memory', '4g', '--memory-swap', '4g', '--cpus', '2', '--cpuset-cpus', '2,3', '--pids-limit', '256',
            '-e', 'GOMAXPROCS=1', '-e', 'GOMEMLIMIT=3GiB', '-v', str(roots[0]) + ':/baseline:ro',
            '-v', str(roots[1]) + ':/candidate:ro', '-v', str(lab) + ':/controls:ro',
            '-v', str(evidence) + ':/evidence'] + extra + [image, 'bash', '/controls/' + phase + '.sh']
    (evidence / 'command.json').write_text(json.dumps(args, indent=2) + '\n')
    with (evidence / 'container.log').open('wb') as log:
        result = subprocess.run(args, stdout=log, stderr=subprocess.STDOUT, timeout=7200)
    inspection = json.loads(subprocess.check_output([docker, 'inspect', name], text=True))[0]
    (evidence / 'inspect.json').write_text(json.dumps(inspection, indent=2) + '\n')
    subprocess.run([docker, 'rm', name], stdout=subprocess.DEVNULL, check=True)
    (evidence / 'exit.txt').write_text(str(result.returncode) + '\n')
    assert result.returncode == 0 and not inspection['State']['OOMKilled'], (phase, result.returncode)
    return inspection['State']

with open('/Users/georgevillavicencio/.local/state/gotreesitter-compute/compute.lock', 'a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    gate = json.loads((prototype / 'full-gates/gate-audit.json').read_text())
    assert gate['passed'] and gate['locked_C_checks'] == 1236 and gate['invariant_sessions'] == 412
    assert (prototype / 'exit.txt').read_text().strip() == '0'
    expected = json.loads((prototype / 'before.json').read_text())
    before, candidate_before, user_before = manifest(original), manifest(candidate_source), checkout()
    assert before == expected['baseline_go'] and candidate_before == expected['candidate_go']
    assert len(before) == 3541 and len(candidate_before) == 3544
    scope = json.loads((lab / 'scope.json').read_text())
    assert all(digest(lab / name) == sha for name, sha in scope['files'].items())
    (lab / 'original-before.json').write_text(json.dumps({'baseline_go': before, 'candidate_go': candidate_before,
        'checkout': user_before}, sort_keys=True) + '\n')

    c_state = run_container('cgo', 'linux/amd64', (original, candidate_source), [
        '-e', 'CGO_ENABLED=1', '-e', 'GOPROXY=off', '-e', 'GOCACHE=/go-build', '-e', 'GOMODCACHE=/go-mod',
        '-e', 'GTS_PARITY_C_REF_BUILD_CACHE=/c-cache', '-v', str(deps / 'go-build') + ':/go-build',
        '-v', str(deps / 'go-mod') + ':/go-mod', '-v', str(deps / 'c-cache') + ':/c-cache:ro'])
    outcomes = dict(line.split('\t') for line in (lab / 'cgo/status.tsv').read_text().splitlines())
    assert len(outcomes) == 24
    d8, selected = {}, {}
    known = scope['expected_known_delete_C_divergence']
    for role in ['baseline', 'candidate']:
        for route in ['production', 'candidate']:
            for api in ['plain', 'profiled']:
                for edit in ['insert', 'replace', 'delete']:
                    label = '-'.join([role, route, api, edit])
                    text = (lab / 'cgo' / (label + '.log')).read_text()
                    matches = re.findall(r'D8 incremental/fresh Go and incremental/fresh C agree independently: deep_digest=([0-9a-f]{64})', text)
                    assert len(matches) == 1 and '--- SKIP:' not in text, label
                    d8[label] = matches[0]
                    if edit == 'delete':
                        assert outcomes[label] == '1' and known in text and 'independent fresh Go versus fresh C' in text, label
                    else:
                        assert outcomes[label] == '0' and text.rstrip().endswith('PASS') and '--- FAIL:' not in text, label
                    if api == 'profiled':
                        values = re.findall(r'selected_parse reused_subtrees=(\d+) new_nodes=(\d+) reparse_ns=\d+', text)
                        assert len(values) == 1, label
                        selected[label] = [int(value) for value in values[0]]
    for label, value in d8.items():
        if label.startswith('baseline-'):
            assert value == d8['candidate-' + label[len('baseline-'):]], label
    for label, value in selected.items():
        if label.startswith('baseline-'):
            assert value == selected['candidate-' + label[len('baseline-'):]], label
    numeric = (lab / 'cgo/numeric.log').read_text()
    assert re.search(r'^PASS$', numeric, re.M) and '--- FAIL:' not in numeric and '--- SKIP:' not in numeric
    assert len(re.findall(r'replacement=\S reparse_ns=\d+ new_nodes=\d+', numeric)) == 12
    (lab / 'cgo/gate-audit.json').write_text(json.dumps({'passed_for_performance_experiment': True,
        'clean_report_C_leaves_per_variant': 8, 'report_D8_leaves_per_variant': 12, 'numeric_replacements': 12,
        'known_delete_C_failures_per_variant': 4, 'known_delete_C_gap': known,
        'delete_C_is_not_a_pass': True, 'D8_digests': d8, 'selected_profiled_counter_pairs': selected,
        'baseline_candidate_digest_and_counter_pairs_equal': True}, indent=2) + '\n')

    wrapper = (lab / 'benchmark-wrapper.go.txt').read_bytes()
    for role, source in [('baseline', original), ('candidate', candidate_source)]:
        directory = lab / role
        shutil.copytree(source, directory, copy_function=os.link)
        replace(directory / 'benchmark_admission_candidate_route_test.go', wrapper)
    b, c = manifest(lab / 'baseline'), manifest(lab / 'candidate')
    differences = sorted(key for key in set(b) | set(c) if b.get(key) != c.get(key))
    assert differences == scope['paired_go_differences'], differences
    assert len(b) == 3541 and len(c) == 3544
    assert b['benchmark_admission_candidate_route_test.go'] == c['benchmark_admission_candidate_route_test.go'] == digest(lab / 'benchmark-wrapper.go.txt')
    (lab / 'before.json').write_text(json.dumps({'source_go': before, 'prototype_go': candidate_before,
        'baseline_go': b, 'candidate_go': c, 'checkout': user_before}, sort_keys=True) + '\n')
    perf_state = run_container('perf', 'linux/arm64', (lab / 'baseline', lab / 'candidate'), [
        '-e', 'GOCACHE=/go-build', '-v', str(base / 'inactive-scanner-trials-v1/go-build') + ':/go-build'])
    rss = {}
    for role in ['baseline', 'candidate']:
        values = []
        for seed in range(154001, 154021):
            path = lab / 'perf/rss' / ('%s-%d.json' % (role, seed))
            record = json.loads(path.read_text())
            assert record['exit_code'] == 0 and record['max_rss_bytes'] > 0 and record['compiler_outside_measured_process'] and not record['manual_GC']
            text = path.with_suffix('.log').read_text()
            assert len(re.findall(r'^BenchmarkFreshMemory/go/1024KiB\s+2\s+', text, re.M)) == 1 and re.search(r'^PASS$', text, re.M) and 'FAIL' not in text
            values.append(record['max_rss_bytes'])
        rss[role] = {'max_rss_bytes': values, 'median_bytes': statistics.median(values), 'maximum_bytes': max(values),
                     'above_400_bytes_per_source_byte': sum(value > 400*1048591 for value in values)}
    rss['median_ratio'] = rss['candidate']['median_bytes'] / rss['baseline']['median_bytes']
    rss['inside_10pct_relative_ratchet'] = rss['median_ratio'] <= 1.10
    rss['absolute_400_gate_passed'] = rss['candidate']['above_400_bytes_per_source_byte'] == 0
    rss['source_bytes'] = 1048591
    rss['fixed_iterations'] = 2
    rss['route'] = 0
    rss['measurement_not_throughput_comparison'] = True
    (lab / 'rss-audit.json').write_text(json.dumps(rss, indent=2) + '\n')
    assert rss['inside_10pct_relative_ratchet'], 'new peak RSS regression'
    audit = {'exit_code': 0, 'baseline_original_unchanged': before == manifest(original),
        'candidate_original_unchanged': candidate_before == manifest(candidate_source),
        'baseline_bench_source_unchanged': b == manifest(lab / 'baseline'),
        'candidate_bench_source_unchanged': c == manifest(lab / 'candidate'), 'checkout_unchanged': user_before == checkout(),
        'cgo_state': c_state, 'perf_state': perf_state, 'platform': 'native linux/arm64 perf; emulated linux/amd64 C correctness',
        'large_file_RSS_qualified': rss['absolute_400_gate_passed'], 'RSS_median_ratio': rss['median_ratio']}
    assert all(audit[key] for key in ['baseline_original_unchanged', 'candidate_original_unchanged',
        'baseline_bench_source_unchanged', 'candidate_bench_source_unchanged', 'checkout_unchanged'])
    (lab / 'parent-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
    (lab / 'exit.txt').write_text('0\n')
