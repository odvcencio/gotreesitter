#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOMAXPROCS=1 GOWORK=off GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
go env GOOS GOARCH CGO_ENABLED > /evidence/platform.txt
for role in baseline candidate; do
 cd "/${role}/cgo_harness"
 go test -c -tags treesitter_c_parity,gts_parsercorephase0 -overlay=/evidence/cgo-overlay.json -o "/evidence/${role}.test" . > "/evidence/${role}-build.log" 2>&1
 for route in production candidate; do
  for api in plain profiled; do
   for edit in insert replace delete; do
    label="${role}-${route}-${api}-${edit}"
    if "/evidence/${role}.test" -test.run "^TestGoCognociente137KiBTopEditLockedC$/^${route}$/^${api}$/^${edit}$" -test.count=1 -test.v -test.timeout=5m > "/evidence/${label}.log" 2>&1; then
     printf '%s\t0\n' "$label" >> /evidence/status.tsv
    else
     probe_code=$?
     printf '%s\t%s\n' "$label" "$probe_code" >> /evidence/status.tsv
     if [[ "$edit" != delete ]]; then exit "$probe_code"; fi
    fi
   done
  done
 done
done
cd /candidate/cgo_harness
/evidence/candidate.test -test.run '^TestGoTokenInvariantLookaheadNumeric(Repair|Reuse)LockedC$' -test.count=1 -test.v -test.timeout=5m > /evidence/numeric.log 2>&1
printf 'complete\n' > /evidence/complete.txt
