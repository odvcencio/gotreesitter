from pathlib import Path
import hashlib,json,shutil,tarfile
p=Path('/Users/georgevillavicencio/.local/state/gotreesitter-compute/20261021-arm64-native-fields/read-history-publication-net-v1')
assert (p/'paired-perf/exit.txt').read_text().strip()=='0'
audit=json.loads((p/'paired-perf/parent-audit.json').read_text())
assert audit['exit_code']==0 and all(audit[k] for k in ['baseline_original_unchanged','candidate_original_unchanged','baseline_bench_source_unchanged','candidate_bench_source_unchanged','checkout_unchanged'])
shutil.copy2(p.parent/'ordered-receipt-v3-cgo-v1/dependency-manifest.json',p/'receipt-dependency-manifest.json')
allowed={'.json','.log','.py','.sh','.txt','.tsv','.cpu','.patch'}
dirs=['.','full-gates','full-gates/cgo','full-gates/native','paired-perf','paired-perf/cgo','paired-perf/perf','paired-perf/perf/rss']
files={}
for name in dirs:
 for f in (p/name).iterdir():
  if f.is_file() and f.suffix in allowed and f.name not in {'receipt-manifest.json','receipt-archive.json'}:
   files[str(f.relative_to(p))]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size}
assert len([f for f in files if f.startswith('paired-perf/perf/rss/') and f.endswith('.json')])==40
(p/'receipt-manifest.json').write_text(json.dumps(files,sort_keys=True,indent=2)+'\n')
f=p/'receipts.tar.gz'
assert not f.exists()
with tarfile.open(f,'w:gz') as archive:
 for name in sorted(files):archive.add(p/name,arcname=name,recursive=False)
 archive.add(p/'receipt-manifest.json',arcname='receipt-manifest.json',recursive=False)
record={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size,'manifest_members':len(files),'archive_members':len(files)+1,'qualified_source_unchanged':True,'large_file_RSS_qualified':audit['large_file_RSS_qualified']}
(p/'receipt-archive.json').write_text(json.dumps(record,sort_keys=True,indent=2)+'\n')
print(json.dumps(record))
