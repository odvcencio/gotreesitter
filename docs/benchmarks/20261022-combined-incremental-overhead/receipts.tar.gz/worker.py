from pathlib import Path
import fcntl, hashlib, json, os, shutil, subprocess, sys

base = Path('/Users/georgevillavicencio/.local/state/gotreesitter-compute/20261021-arm64-native-fields')
lab = base / 'read-history-publication-net-v1'
original = base / 'primitive-dfa-state-source-v1'
os.environ['PATH'] = '/Applications/Docker.app/Contents/Resources/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def manifest(root):
    return {str(p.relative_to(root)): digest(p) for p in sorted(root.rglob('*.go')) if p.is_file()}

def checkout():
    p = '/Users/georgevillavicencio/Projects/gotreesitter'
    return {'head': subprocess.check_output(['git', '-C', p, 'rev-parse', 'HEAD'], text=True).strip(),
            'status': subprocess.check_output(['git', '-C', p, 'status', '--porcelain=v1'], text=True)}

def replace(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.gts-tmp')
    temporary.write_bytes(data)
    temporary.replace(path)

with open('/Users/georgevillavicencio/.local/state/gotreesitter-compute/compute.lock', 'a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    assert (base / 'paged-read-history-v4/paired-perf/exit.txt').read_text().strip() == '0'
    scope = json.loads((lab / 'scope.json').read_text())
    original_before, user_before = manifest(original), checkout()
    assert original_before == scope['original_go']
    assert all(digest(lab / 'delta' / name) == sha for name, sha in scope['files'].items())
    for role in ['baseline', 'candidate']:
        directory = lab / role
        shutil.copytree(original, directory, copy_function=os.link)
        for category in ['common', 'shared', role]:
            root = lab / 'delta' / category
            for path in root.rglob('*.go'):
                replace(directory / path.relative_to(root), path.read_bytes())
        if role == 'baseline':
            for name in scope['baseline_remove']:
                (directory / name).unlink()
        assert manifest(directory) == scope[role + '_go']
    before, candidate = manifest(lab / 'baseline'), manifest(lab / 'candidate')
    assert len(before) == 3541 and len(candidate) == 3544
    (lab / 'before.json').write_text(json.dumps({'original_go': original_before, 'baseline_go': before,
        'candidate_go': candidate, 'checkout': user_before, 'main_sha': scope['main_sha']}, sort_keys=True) + '\n')
    docker = '/usr/local/bin/docker'
    name = 'gts-read-history-publication-net-qual-20261022-v1'
    image = 'golang@sha256:3b4a11519ad929d1e1d261a12cff056f0c85b735253d7d861346b9c6f8b36437'
    args = [docker, 'run', '--platform', 'linux/arm64', '--name', name, '--network', 'none', '--memory', '4g',
            '--memory-swap', '4g', '--cpus', '2', '--cpuset-cpus', '2,3', '--pids-limit', '256',
            '-e', 'GOMAXPROCS=1', '-e', 'GOMEMLIMIT=3GiB', '-e', 'GOCACHE=/go-build',
            '-v', str(base / 'inactive-scanner-trials-v1/go-build') + ':/go-build',
            '-v', str(lab / 'baseline') + ':/baseline:ro', '-v', str(lab / 'candidate') + ':/candidate:ro',
            '-v', str(lab) + ':/evidence', image, 'bash', '/evidence/qualify.sh']
    (lab / 'command.json').write_text(json.dumps(args, indent=2) + '\n')
    with (lab / 'container.log').open('wb') as log:
        result = subprocess.run(args, stdout=log, stderr=subprocess.STDOUT, timeout=3600)
    inspection = json.loads(subprocess.check_output([docker, 'inspect', name], text=True))[0]
    (lab / 'inspect.json').write_text(json.dumps(inspection, indent=2) + '\n')
    subprocess.run([docker, 'rm', name], stdout=subprocess.DEVNULL, check=True)
    audit = {'exit_code': result.returncode, 'original_unchanged': original_before == manifest(original),
        'baseline_unchanged': before == manifest(lab / 'baseline'), 'candidate_unchanged': candidate == manifest(lab / 'candidate'),
        'checkout_unchanged': user_before == checkout(), 'state': inspection['State'], 'main_sha': scope['main_sha']}
    (lab / 'parent-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
    (lab / 'exit.txt').write_text(str(result.returncode) + '\n')
    assert result.returncode == 0 and not inspection['State']['OOMKilled']
    assert all(audit[key] for key in ['original_unchanged', 'baseline_unchanged', 'candidate_unchanged', 'checkout_unchanged'])
    b = json.loads((lab / 'baseline-ledger.json').read_text())
    c = json.loads((lab / 'candidate-ledger.json').read_text())
    assert b == c and len(c['rows']) == 412
    following = lab / 'full-gates'
    (following / 'counter-equality.json').write_text(json.dumps({'passed': True, 'rows': 412, 'json_values_equal': True,
        'candidate_sha256': digest(lab / 'candidate-ledger.json'), 'baseline': scope['main_sha']}, indent=2) + '\n')
    with (following / 'worker.log').open('wb') as log:
        child = subprocess.Popen([sys.executable, str(following / 'worker.py')], stdout=log,
                                 stderr=subprocess.STDOUT, start_new_session=True)
    (following / 'launch.json').write_text(json.dumps({'pid': child.pid}, indent=2) + '\n')
