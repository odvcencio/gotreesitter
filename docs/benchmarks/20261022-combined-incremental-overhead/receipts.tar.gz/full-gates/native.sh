#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOMAXPROCS=1 GOWORK=off GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
go env GOOS GOARCH > /evidence/platform.txt
cd /candidate
for route in 0 1; do
 while IFS= read -r lang; do
  GTS_ADMISSION_CANDIDATE="$route" GOTREESITTER_V1_INVARIANT_LANGUAGE="$lang" /prototype/root.test -test.run '^TestV1InvariantGateR4EditSession$' -test.count=1 -test.v -test.timeout=5m > "/evidence/invariant-${route}-${lang}.log" 2>&1
 done < /controls/languages.txt
done
/prototype/root.test -test.run '^Test(CompactAcceptance(ChangedSourceKeepsRebuildBudget|CachedPublicationStopControl)|CompactMemoryBudgetDetectsGrowthAfterSmallPoll|CompactAcceptance.*(MemoryBudget|RetentionBound)|CompactArenaReserve.*(Budget|RetentionCap)|CompactExternalScannerCheckpointCopyMemoryBudget|CompactRecoveryMemoMemoryBudget|CompactBorrowedMaterializationProjectionMemoryBudget|G18RefSetSchedulerMemoryBudgetAccounting|RuntimeMemoryBudget.*|RuntimeMemoryHardCeilingStillStopsParse|ParseMemoryHardCeiling.*)$' -test.count=1 -test.v -test.timeout=8m > /evidence/memory-contracts.log 2>&1
go test -race -tags gts_parsercorephase0 -run '^Test(CompactReuseDependency|CompactLegacyReadHistoryPublicationDemand|CompactCanonicalNoReplayReadHistory|LegacyReuse.*(Lookahead|ReadHistory)|TokenInvariant.*(Lookahead|Primitive)|LexerReadSpan|ContextualCloseAngleProbeReadHistory)' -count=1 -timeout=8m -v . > /evidence/race.log 2>&1
printf 'complete\n' > /evidence/complete.txt
