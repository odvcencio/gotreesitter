set -euo pipefail
export PATH=/usr/local/go/bin:$PATH GOWORK=off GOMAXPROCS=1 GOFLAGS='-p=1 -mod=readonly -buildvcs=false'
go version > /evidence/go-version.txt
for role in baseline candidate; do
 cd "/$role"
 go test -c -overlay=/controls/overlay.json -tags gts_parsercorephase0 -o "/evidence/$role.test" ./roottest/bench > "/evidence/$role-build.log" 2>&1
 GTS_FRESH_MEMORY_LANG=go GTS_ADMISSION_CANDIDATE=0 GTS_MEMORY_PROFILE_DIR="/evidence/$role" "/evidence/$role.test" -test.run '^$' -test.bench '^BenchmarkFreshMemory$/^go$/^1024KiB$' -test.benchtime=2x -test.count=1 -test.benchmem -test.shuffle=1 -test.timeout=8m -test.cpuprofile="/evidence/$role.cpu.pprof" > "/evidence/$role.log" 2>&1
 go tool pprof -top -nodecount=18 -inuse_space "/evidence/$role.test" "/evidence/$role/n2-i1-live.heap.pprof" > "/evidence/$role-inuse.txt" 2>&1
 go tool pprof -top -nodecount=18 -alloc_space "/evidence/$role.test" "/evidence/$role/n2-i1-live.heap.pprof" > "/evidence/$role-alloc.txt" 2>&1
 go tool pprof -top -nodecount=18 "/evidence/$role.test" "/evidence/$role.cpu.pprof" > "/evidence/$role-cpu.txt" 2>&1
done
