from pathlib import Path
import fcntl,json,subprocess,datetime
p=Path(__file__).resolve().parent;root=p.parent;old=root/'20261021-arm64-native-fields';out=p/'out';out.mkdir(exist_ok=True)
for d in [old/'checkpoint-record-cache-20261022-v1/baseline',old/'checkpoint-record-cache-20261022-v1/candidate',old/'inactive-scanner-trials-v1/go-build',old/'locked-c-oracle-amd64-v1/go-mod']:assert d.is_dir(),d
with (root/'compute.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 (p/'started.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}))
 args=['/Applications/Docker.app/Contents/Resources/bin/docker','run','--name','gts-native-receipts-arm64-v1-20261023','--platform','linux/arm64','--network','none','--memory','4g','--memory-swap','4g','--cpus','1','--cpuset-cpus','2','--pids-limit','512','-e','GOMAXPROCS=1','-e','GOMEMLIMIT=3GiB','-e','GOPROXY=off','-e','GOCACHE=/go-build','-e','GOMODCACHE=/go-mod','-v',str(old/'checkpoint-record-cache-20261022-v1/baseline')+':/baseline:ro','-v',str(old/'checkpoint-record-cache-20261022-v1/candidate')+':/candidate:ro','-v',str(root/'20261023-native-fused-publication-v1')+':/previous:ro','-v',str(p)+':/controls:ro','-v',str(out)+':/evidence','-v',str(old/'inactive-scanner-trials-v1/go-build')+':/go-build','-v',str(old/'locked-c-oracle-amd64-v1/go-mod')+':/go-mod:ro','golang@sha256:116d58cbd88c1297624acc6e967a060012422bacf9930927e23fb719189c6f36','bash','/controls/run.sh']
 (p/'command.json').write_text(json.dumps(args,indent=2)+'\n')
 with (out/'console.log').open('w') as log:r=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT)
 (out/'exit-code.txt').write_text(str(r.returncode)+'\n')
 (out/'finished.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}))
