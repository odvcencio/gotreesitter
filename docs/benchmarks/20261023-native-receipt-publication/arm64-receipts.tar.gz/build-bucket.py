from pathlib import Path
import gzip, hashlib, io, json, shutil, subprocess, tarfile

run = Path(__file__).resolve().parent
repo = run.parents[2]
p = run / 'out'
bucket = repo / 'docs/benchmarks/20261023-native-receipt-publication'
sha = lambda b: hashlib.sha256(b).hexdigest()
assert (p / 'exit-code.txt').read_text().strip() == '0'
assert (p / 'complete.txt').exists()
assert (p / 'platform.txt').read_text().splitlines() == ['linux', 'arm64']
source = json.loads((p / 'source-before.json').read_text())
assert source == json.loads((p / 'source-after.json').read_text())
assert source == json.loads((run / 'expected-effective.json').read_text())
assert source == json.loads((run.parent / 'native-receipts-qualification-v1/out/source-before.json').read_text())
tracked = set(subprocess.check_output(['git', 'ls-files', '-z', '--', '*.go'], cwd=repo).decode().split('\0')) - {''}
assert tracked == set(source['candidate'])
assert all(sha((repo / name).read_bytes()) == digest for name, digest in source['candidate'].items())
for name in ['core-unit.log', 'incr-unit.log']:
    assert (p / name).read_text().startswith('ok  ')
for name in ['root-unit.log', 'memory.log']:
    assert (p / name).read_text().rstrip().endswith('PASS')
    assert '--- FAIL:' not in (p / name).read_text()
assert sum(line.startswith('--- PASS:') for line in (p / 'memory.log').read_text().splitlines()) == 20
invariants = list(p.glob('*-invariant-*.log'))
assert len(invariants) == 4
assert all(f.read_text().rstrip().endswith('PASS') and '--- FAIL:' not in f.read_text() for f in invariants)
assert all('session_steps=72 no_edit_allocs=0' in f.read_text() for f in invariants)
for lang in ['go', 'yaml']:
    d = json.loads((p / (lang + '-counter-delta.json')).read_text())
    assert d['passed'] and not d['changes'] and not d['route_metadata_changes']
perf = json.loads((p / 'independent-analysis.json').read_text())
assert perf['valid_rows_per_role'] == 300 and not perf['ratchet_failures'] and perf['all_timed_work_and_route_metrics_exact']
audit = json.loads((p / 'container-audit.json').read_text())
assert audit['state']['ExitCode'] == 0 and not audit['state']['OOMKilled']
cleanup = json.loads((p / 'cleanup.json').read_text())
assert cleanup['container_removed'] and cleanup['shared_caches_preserved']

entries = {}
for f in sorted(run.rglob('*')):
    if f.is_file() and f.suffix in {'.json', '.log', '.txt', '.py', '.sh', '.go', '.tsv'}:
        entries[str(f.relative_to(run))] = f.read_bytes()
for overlay in ['source-overlay.json', 'benchmark-overlay.json']:
    for replacement in json.loads((run / overlay).read_text())['Replace'].values():
        if replacement.startswith('/controls/'):
            assert replacement.removeprefix('/controls/') in entries
        elif replacement.startswith('/previous/'):
            assert replacement.removeprefix('/') in entries
        else:
            assert not replacement
manifest = {n: {'bytes': len(b), 'sha256': sha(b)} for n, b in entries.items()}
entries['members.json'] = (json.dumps(manifest, sort_keys=True, indent=2) + '\n').encode()
archive = bucket / 'arm64-receipts.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for n, b in sorted(entries.items()):
                item = tarfile.TarInfo(n); item.size = len(b); item.mode = 0o644
                tar.addfile(item, io.BytesIO(b))
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(entries)
    for item in tar.getmembers():
        assert item.isfile() and not Path(item.name).is_absolute() and '..' not in Path(item.name).parts
        if item.name != 'members.json':
            assert sha(tar.extractfile(item).read()) == manifest[item.name]['sha256']
receipt = {
    'status': 'qualified-linux-arm64',
    'runtime_commit': '6d6ead01873d54d8cda839947e04b387474190ca',
    'platform': 'Linux ARM64 in Docker on Mac; not native Darwin',
    'source': {'matches_amd64_effective_sources': True, 'matches_committed_candidate': True, 'unchanged_at_completion': True, 'file_counts': {r: len(v) for r, v in source.items()}, 'approved_transfer_sha256': json.loads((run / 'transfer-archive.json').read_text())['sha256']},
    'correctness': {'core_units': True, 'receipt_storage_units': True, 'focused_root_tests': 42, 'invariant_sessions': 4, 'edit_steps': 288, 'memory_checks': 20, 'strict_counter_languages': ['go', 'yaml'], 'strict_counter_changes': [], 'no_edit_bytes': 0, 'no_edit_allocations': 0},
    'significant_time_changes': {'fresh_one_mib_go_percent': -2.74, 'query_source_go_percent': -3.46, 'compact_go_LR_percent': -3.80},
    'directional_time_increases_percent': {'legacy_yaml_R4': 0.79, 'legacy_yaml_EOF': 0.52, 'ordinary_yaml_R4': 0.24, 'ordinary_yaml_EOF': 0.13, 'primary_go_edit': 0.21, 'compact_go_edit': 0.06},
    'performance': perf,
    'container': {'exit_code': 0, 'OOMKilled': False, 'resource_limits': audit['resource_limits'], 'removed_after_audit': True},
    'archive': {'bytes': archive.stat().st_size, 'members': len(entries), 'sha256': sha(archive.read_bytes())},
    'limitations': ['No ARM64 locked-C, race, 386, or RSS rerun; the source-identical amd64 qualification retains those checks.', 'Not native Darwin or Windows qualification.', 'Not a combined main-based or Go/C timing comparison.', 'All existing correctness, allocation, warmed-RSS, merge and graduation holds remain.'],
}
qualification = json.loads((bucket / 'qualification.json').read_text())
qualification['arm64'] = receipt
qualification['status'] = 'qualified-linux-amd64-and-linux-arm64'
qualification['decision']['status'] = qualification['status']
old = 'ARM64 qualification awaits approval of the new bundle; native Windows and Darwin remain unqualified'
new = 'Linux ARM64 qualification is complete; native Windows and Darwin remain unqualified'
for obj in [qualification, qualification['decision']]:
    obj['limitations'] = [new if x == old else x for x in obj['limitations']]
(bucket / 'qualification.json').write_text(json.dumps(qualification, sort_keys=True, indent=2) + '\n')
for suite in ['go', 'compact-go', 'yaml']:
    shutil.copyfile(p / ('benchstat-' + suite + '.txt'), bucket / ('arm64-benchstat-' + suite + '.txt'))
print(json.dumps({'archive': receipt['archive'], 'performance_rows_per_role': perf['valid_rows_per_role'], 'ratchet_failures': perf['ratchet_failures']}))
