from pathlib import Path
import json
import shlex
import subprocess

p = Path(__file__).resolve().parent
m = json.loads((p / 'transfer-review.json').read_text())
code = '''from pathlib import Path
import json
p=Path(REMOTE);out=p/'out'
summary={}
for name in ['core-unit.log','incr-unit.log','root-unit.log','memory.log','counter-gate.log','exit-code.txt','console.log']:
 f=out/name
 if f.exists():
  s=f.read_text()
  summary[name]={'bytes':f.stat().st_size,'pass':s.rstrip().endswith('PASS') or s.startswith('ok  '),'top_level_tests':sum(x.startswith('--- PASS:') for x in s.splitlines())}
  if name=='counter-gate.log': summary[name]={'passed':bool(s.strip()) and all(json.loads(x)['passed'] for x in s.splitlines()),'languages':len(s.splitlines())}
  if name in ['exit-code.txt','console.log'] or 'FAIL' in s: summary[name]['tail']=s[-500:]
summary['invariant_sessions_passed']=sum(f.read_text().rstrip().endswith('PASS') for f in out.glob('*-invariant-*.log'))
for name in ['yaml','go','compact-go']:
 f=out/('candidate-'+name+'.txt')
 if f.exists():
  s=f.read_text()
  summary[name]={'samples':sum(x.startswith('Benchmark') for x in s.splitlines()),'complete':s.rstrip().endswith('# status: complete')}
summary['complete_stages']=sorted(x.name for x in out.glob('*complete*'))
summary['worker_errors']=(p/'worker.log').read_text()[-1000:]
print(json.dumps(summary))
'''.replace('REMOTE', repr(m['destination_directory']))
r = subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', m['destination_host'], 'python3 -c ' + shlex.quote(code)], check=True, text=True, capture_output=True)
print(r.stdout)
