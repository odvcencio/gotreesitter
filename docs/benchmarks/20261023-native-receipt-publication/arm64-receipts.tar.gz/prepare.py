from pathlib import Path
import json,hashlib,shutil,tarfile,io,gzip,subprocess
p=Path(__file__).resolve().parent;repo=p.parents[2];old=repo/'harness_out/docker/native-fused-publication-mac-v1';linux=repo/'harness_out/docker/native-receipts-qualification-v1';pins=json.loads((linux/'expected-source.json').read_text());original=json.loads((old/'remote-current-inputs.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest();(p/'files').mkdir(exist_ok=True)
repl={};selected={};reused={}
for role in ['baseline','candidate']:
 for n,h in pins[role].items():
  if original[role].get(n,{}).get('sha256')==h:continue
  previous=old/'files'/(h+'.go')
  if previous.exists():
   assert sha(previous.read_bytes())==h;repl['/'+role+'/'+n]='/previous/files/'+h+'.go';reused[role+'/'+n]=h
  else:
   data=(repo/n).read_bytes() if role=='candidate' else subprocess.check_output(['git','show','HEAD:'+n],cwd=repo)
   assert sha(data)==h,n
   f=p/'files'/(h+'.go');f.write_bytes(data);repl['/'+role+'/'+n]='/controls/files/'+h+'.go';selected[role+'/'+n]={'bytes':len(data),'sha256':h}
 for n in original[role]:
  if n.endswith('.go') and n not in pins[role]:repl['/'+role+'/'+n]=''
(p/'source-overlay.json').write_text(json.dumps({'Replace':repl},indent=2)+'\n')
(p/'benchmark-overlay.json').write_text(json.dumps({'Replace':{**repl,**{f'/{role}/benchmark_admission_fresh_test.go':'/controls/benchmark-fresh.go.txt' for role in ['baseline','candidate']}}},indent=2)+'\n')
(p/'expected-effective.json').write_text(json.dumps(pins,sort_keys=True)+'\n')
for n in ['verify.py','remote-current-inputs.json','run_randomized_benchmarks.sh','compare-ledger.py','benchmark-fresh.go.txt']:shutil.copyfile(old/n,p/n)
for n in ['benchmark_primary_overlay.go.txt','benchmark_primary_go_suite.go.txt']:shutil.copyfile(linux/n,p/n)
s=(old/'run.sh').read_text().replace('209001','235001').replace('210001','237001')
s=s.replace('go test -c -tags', 'go test ./internal/incr -count=1 -timeout=3m > /evidence/incr-unit.log 2>&1\ngo test -c -tags',1)
anchor="GOFLAGS='-p=1 -mod=readonly -overlay=/controls/benchmark-overlay.json' GTS_ADMISSION_CANDIDATE=1"
primary=(linux/'run.sh').read_text();primary=primary[primary.index('cp /controls/benchmark_primary_overlay.go.txt'):primary.index("GOFLAGS='-p=1 -mod=readonly -overlay=/controls/benchmark-overlay.json' GTS_ADMISSION_CANDIDATE=1")].replace('231001','236001')
s=s.replace(anchor,primary+anchor);(p/'run.sh').write_text(s)
s=(old/'worker.py').read_text().replace('gts-native-fused-publication-arm64-v1-20261023','gts-native-receipts-arm64-v1-20261023')
s=s.replace("'-v',str(p)+':/controls:ro'", "'-v',str(root/'20261023-native-fused-publication-v1')+':/previous:ro','-v',str(p)+':/controls:ro'")
(p/'worker.py').write_text(s)
manifest={'destination_host':'georgevillavicencio@georges-macbook-pro.tail28c2e1.ts.net','destination_directory':'/Users/georgevillavicencio/.local/state/gotreesitter-compute/20261023-native-receipts-v1','purpose':'Bounded Linux ARM64 Docker qualification on the authorized Mac, using existing read-only source trees and prior source blobs','baseline_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'candidate':'seven-file native receipt publication prototype, already passed Linux correctness and 206 strict counter ledgers','selected_source':selected,'reused_previous_source':reused,'no_credentials_or_unrelated_files_selected':True,'limits':{'cpus':1,'memory':'4g','GOMEMLIMIT':'3GiB','network':'none','shared_compute_lock':True},'protocol':{'samples_per_suite':20,'benchtime':'750ms','seed_ranges':{'yaml':[235001,235020],'primary_go':[236001,236020],'compact_go':[237001,237020]},'matching_workload_order':True,'alternating_roles':True}}
(p/'transfer-review.json').write_text(json.dumps(manifest,indent=2)+'\n')
entries={str(f.relative_to(p)):f.read_bytes() for f in p.rglob('*') if f.is_file() and f.name not in ['transfer.tar.gz','transfer-archive.json','prepare.py']}
entries['transfer-members.json']=(json.dumps({n:{'bytes':len(b),'sha256':sha(b)} for n,b in entries.items()},sort_keys=True,indent=2)+'\n').encode()
archive=p/'transfer.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as t:
   for n,b in sorted(entries.items()):
    assert not Path(n).is_absolute() and '..' not in Path(n).parts
    f=tarfile.TarInfo(n);f.mode=0o644;f.size=len(b);t.addfile(f,io.BytesIO(b))
r={'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(entries),'new_source_files':len(list((p/'files').iterdir()))};(p/'transfer-archive.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
