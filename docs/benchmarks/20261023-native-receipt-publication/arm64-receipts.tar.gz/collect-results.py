from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import tarfile

p = Path(__file__).resolve().parent
m = json.loads((p / 'transfer-review.json').read_text())
code = r'''from pathlib import Path
import datetime,fcntl,gzip,hashlib,io,json,subprocess,tarfile
p=Path(REMOTE);out=p/'out';sha=lambda b:hashlib.sha256(b).hexdigest()
assert (out/'exit-code.txt').read_text().strip()=='0'
assert (out/'complete.txt').exists()
assert json.loads((out/'source-before.json').read_text())==json.loads((out/'source-after.json').read_text())
docker='/Applications/Docker.app/Contents/Resources/bin/docker'
name='gts-native-receipts-arm64-v1-20261023'
with (p.parent/'compute.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 audit=json.loads(subprocess.check_output([docker,'inspect',name],text=True))[0]
 state=audit['State'];host=audit['HostConfig']
 assert not state['Running'] and not state['OOMKilled'] and state['ExitCode']==0
 assert host['NetworkMode']=='none' and host['Memory']==4294967296 and host['MemorySwap']==4294967296 and host['NanoCpus']==1000000000 and host['CpusetCpus']=='2'
 receipt={'state':state,'image':audit['Config']['Image'],'image_id':audit['Image'],'platform':audit['Platform'],'resource_limits':{k:host[k] for k in ['NetworkMode','Memory','MemorySwap','NanoCpus','CpusetCpus','PidsLimit']},'environment':audit['Config']['Env'],'mounts':audit['Mounts']}
 (out/'container-audit.json').write_text(json.dumps(receipt,indent=2)+'\n')
 binaries={}
 for name in ['candidate.test','baseline-ledger','candidate-ledger']:
  f=out/name
  assert f.is_file()
  binaries[name]={'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())}
 (out/'binary-manifest.json').write_text(json.dumps(binaries,indent=2)+'\n')
 subprocess.run([docker,'rm','gts-native-receipts-arm64-v1-20261023'],check=True,capture_output=True)
 for name in binaries:(out/name).unlink()
 (out/'cleanup.json').write_text(json.dumps({'container_removed':True,'binaries_removed':list(binaries),'bytes_freed':sum(v['bytes'] for v in binaries.values()),'shared_caches_preserved':True,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
entries={}
for f in sorted(p.rglob('*')):
 if f.is_file() and not f.is_symlink() and f.suffix in {'.json','.log','.txt','.py','.sh','.go','.tsv'}:
  entries[str(f.relative_to(p))]=f.read_bytes()
for name in ['source-overlay.json','benchmark-overlay.json']:
 for replacement in json.loads((p/name).read_text())['Replace'].values():
  if replacement.startswith('/previous/'):
   n=replacement.removeprefix('/previous/')
   assert not Path(n).is_absolute() and '..' not in Path(n).parts
   entries['previous/'+n]=(p.parent/'20261023-native-fused-publication-v1'/n).read_bytes()
  elif replacement.startswith('/controls/'):
   assert replacement.removeprefix('/controls/') in entries
  elif replacement:
   raise AssertionError(replacement)
members={n:{'bytes':len(b),'sha256':sha(b)} for n,b in entries.items()}
entries['results-members.json']=(json.dumps(members,sort_keys=True,indent=2)+'\n').encode()
archive=p/'results.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for n,b in sorted(entries.items()):
    i=tarfile.TarInfo(n);i.size=len(b);i.mode=0o644;tar.addfile(i,io.BytesIO(b))
print(json.dumps({'bytes':archive.stat().st_size,'members':len(entries),'sha256':sha(archive.read_bytes()),'bytes_freed':sum(v['bytes'] for v in binaries.values())}))
'''.replace('REMOTE', repr(m['destination_directory']))
r = subprocess.run(['ssh', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', m['destination_host'], 'python3 -c ' + shlex.quote(code)], check=True, text=True, capture_output=True)
receipt = json.loads(r.stdout)
(p / 'results-archive.json').write_text(json.dumps(receipt, indent=2) + '\n')
subprocess.run(['scp', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=10', m['destination_host'] + ':' + m['destination_directory'] + '/results.tar.gz', str(p / 'results.tar.gz')], check=True)
archive = p / 'results.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == receipt['sha256']
with tarfile.open(archive) as tar:
    members = tar.getmembers()
    assert len(members) == receipt['members']
    manifest = json.loads(tar.extractfile('results-members.json').read())
    assert len(manifest) == len(members) - 1
    assert len({member.name for member in members}) == len(members)
    for member in members:
        assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        data = tar.extractfile(member).read()
        if member.name != 'results-members.json':
            assert len(data) == manifest[member.name]['bytes']
            assert hashlib.sha256(data).hexdigest() == manifest[member.name]['sha256']
        target = p / member.name
        if target.exists():
            assert target.read_bytes() == data, member.name
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
print(json.dumps(receipt))
