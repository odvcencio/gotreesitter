from pathlib import Path
import hashlib,json,subprocess
replacements=json.loads(Path('/controls/source-overlay.json').read_text())['Replace']
result={}
for role in ['baseline','candidate']:
 root=Path('/'+role)
 if role=='candidate':
  names=set(subprocess.check_output(['git','-c','safe.directory=/candidate','ls-files','--cached','--others','--exclude-standard','--','*.go'],cwd=root,text=True).splitlines())
 else:names={str(f.relative_to(root)) for f in root.rglob('*.go')}
 names.update(str(Path(n).relative_to(root)) for n in replacements if n.startswith(str(root)+'/'))
 result[role]={n:hashlib.sha256(Path(replacements.get(str(root/n),str(root/n))).read_bytes()).hexdigest() for n in sorted(names)}
print(json.dumps(result,sort_keys=True))
