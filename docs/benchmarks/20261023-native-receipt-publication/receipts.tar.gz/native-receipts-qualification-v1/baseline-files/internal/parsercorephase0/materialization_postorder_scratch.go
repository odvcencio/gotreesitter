package parsercorephase0

import (
	"errors"
	"math"
	"unsafe"
)

type materializationPostorderFrame struct {
	id   SubtreeID
	next uint32
	// The replay fields carry the top-down parse-state replay through the
	// same traversal. cursor is the state after the children visited so far,
	// which is the next child's pre-goto state. pre and state are this
	// subtree's own replay results; the Known flags follow the replay rules.
	cursor     StateID
	pre        StateID
	state      StateID
	preKnown   bool
	stateKnown bool
	prebuilt   bool
}

// MaterializationReplayTransition computes the parse state reached after one
// subtree is pushed from pre, and reports whether the tables held that
// transition. It mirrors the root package's replay transition, so the fused
// visit assigns the same states as the separate top-down replay.
type MaterializationReplayTransition func(pre StateID, view MaterializationReplayView) (StateID, bool, error)

// MaterializationReplayBorrowedTransition reads one temporary replay view.
// The view expires when the callback returns. Callers must not retain its
// pointer, mutate it, or mutate Core during the traversal.
type MaterializationReplayBorrowedTransition func(pre StateID, view *MaterializationReplayView) (StateID, bool, error)

// MaterializationPostorderScratch retains the transient ownership colors and
// iterative traversal stack for VisitMaterializationPostorderWithScratch.
// Callers must not use one scratch concurrently or reentrantly.
type MaterializationPostorderScratch struct {
	colors       []uint8
	frames       []materializationPostorderFrame
	nativeFrames []nativeProjectionFrame
	// view is the visit argument. It lives in the scratch so the pointer
	// visitor does not move a fresh view to the heap on every subtree.
	view       MaterializationSubtreeView
	replayView MaterializationReplayView
	inUse      bool
}

// RetainedBytes counts backing storage even after Reset clears the lengths.
// The traversal's inline state belongs to its caller's scratch allocation.
func (scratch *MaterializationPostorderScratch) RetainedBytes() uint64 {
	if scratch == nil {
		return 0
	}
	colors := uint64(cap(scratch.colors))
	frames := uint64(cap(scratch.frames))
	size := uint64(unsafe.Sizeof(materializationPostorderFrame{}))
	if frames > (math.MaxUint64-colors)/size {
		return math.MaxUint64
	}
	total := colors + frames*size
	nativeSize := uint64(unsafe.Sizeof(nativeProjectionFrame{}))
	nativeFrames := uint64(cap(scratch.nativeFrames))
	if nativeFrames > (math.MaxUint64-total)/nativeSize {
		return math.MaxUint64
	}
	return total + nativeFrames*nativeSize
}

// Reset clears traversal state while retaining the backing storage for reuse.
func (scratch *MaterializationPostorderScratch) Reset() {
	if scratch == nil {
		return
	}
	clear(scratch.colors)
	scratch.colors = scratch.colors[:0]
	if cap(scratch.frames) > 0 {
		clear(scratch.frames[:cap(scratch.frames)])
	}
	scratch.frames = scratch.frames[:0]
	if cap(scratch.nativeFrames) > 0 {
		clear(scratch.nativeFrames[:cap(scratch.nativeFrames)])
	}
	scratch.nativeFrames = scratch.nativeFrames[:0]
	scratch.view = MaterializationSubtreeView{}
	scratch.replayView = MaterializationReplayView{}
	scratch.inUse = false
}

func (scratch *MaterializationPostorderScratch) prepareOwnershipColors(subtrees int) error {
	if scratch == nil {
		return errors.New("parser-core phase zero: materialization postorder scratch is nil")
	}
	if scratch.inUse {
		return errors.New("parser-core phase zero: materialization postorder scratch is already in use")
	}
	colorCount := subtrees + 1
	if cap(scratch.colors) < colorCount {
		scratch.colors = make([]uint8, colorCount)
	} else {
		scratch.colors = scratch.colors[:colorCount]
	}
	scratch.inUse = true
	return nil
}

func (scratch *MaterializationPostorderScratch) prepare(subtrees int) error {
	if err := scratch.prepareOwnershipColors(subtrees); err != nil {
		return err
	}
	if cap(scratch.frames) < 64 {
		scratch.frames = make([]materializationPostorderFrame, 0, 64)
	} else {
		scratch.frames = scratch.frames[:0]
	}
	return nil
}

// VisitMaterializationPostorderWithScratch authenticates roots and visits each
// subtree after its children. It retains caller-owned traversal storage.
func (c *Core) VisitMaterializationPostorderWithScratch(
	roots []SubtreeID,
	poll func() error,
	scratch *MaterializationPostorderScratch,
	visit func(SubtreeID, MaterializationSubtreeView) error,
) error {
	return c.VisitMaterializationPostorderWithReplay(roots, poll, scratch, 0, nil, visit)
}

// VisitMaterializationPostorderWithReplay is VisitMaterializationPostorderWithScratch
// with the top-down parse-state replay fused into the same traversal. When
// transition is non-nil, every root starts from rootPre, each child's pre-goto
// state is the state after its previous sibling, and the visit receives each
// subtree's replay states in the view. A nil transition visits without replay.
func (c *Core) VisitMaterializationPostorderWithReplay(
	roots []SubtreeID,
	poll func() error,
	scratch *MaterializationPostorderScratch,
	rootPre StateID,
	transition MaterializationReplayTransition,
	visit func(SubtreeID, MaterializationSubtreeView) error,
) error {
	if visit == nil {
		return errors.New("parser-core phase zero: materialization requires a visitor")
	}
	return c.VisitMaterializationPostorderPrebuilt(roots, poll, scratch, rootPre, transition, nil,
		func(id SubtreeID, view *MaterializationSubtreeView) error { return visit(id, *view) })
}

// VisitMaterializationPostorderPrebuilt is VisitMaterializationPostorderWithReplay
// for a derivation the eager materializer has partly built. prebuilt reports
// whether a subtree already owns a public node. The traversal does not
// visit prebuilt subtrees or their descendants. It still traverses them to
// validate metadata and exclusive ownership across the complete accepted tree.
// The traversal advances the replay cursor so later siblings receive the
// same pre-goto state as in a full traversal. A nil prebuilt visits every subtree.
func (c *Core) VisitMaterializationPostorderPrebuilt(
	roots []SubtreeID,
	poll func() error,
	scratch *MaterializationPostorderScratch,
	rootPre StateID,
	transition MaterializationReplayTransition,
	prebuilt func(SubtreeID) bool,
	visit func(SubtreeID, *MaterializationSubtreeView) error,
) error {
	var borrowed MaterializationReplayBorrowedTransition
	if transition != nil {
		borrowed = func(pre StateID, view *MaterializationReplayView) (StateID, bool, error) {
			return transition(pre, *view)
		}
	}
	return c.VisitMaterializationPostorderPrebuiltWithBorrowedReplay(roots, poll, scratch, rootPre, borrowed, prebuilt, visit)
}

// VisitMaterializationPostorderPrebuiltWithBorrowedReplay preserves the full
// traversal and validation of VisitMaterializationPostorderPrebuilt while
// lending one scratch-owned replay view to each transition. Core must remain
// unchanged throughout the traversal. Every frame carries the already checked
// subtree ID; record storage is resolved from the fixed arena without retaining
// a record pointer in the traversal stack.
func (c *Core) VisitMaterializationPostorderPrebuiltWithBorrowedReplay(
	roots []SubtreeID,
	poll func() error,
	scratch *MaterializationPostorderScratch,
	rootPre StateID,
	transition MaterializationReplayBorrowedTransition,
	prebuilt func(SubtreeID) bool,
	visit func(SubtreeID, *MaterializationSubtreeView) error,
) error {
	if c == nil || len(roots) == 0 {
		return errors.New("parser-core phase zero: materialization requires at least one compact root")
	}
	if visit == nil {
		return errors.New("parser-core phase zero: materialization requires a visitor")
	}
	if scratch == nil {
		return errors.New("parser-core phase zero: materialization postorder scratch is nil")
	}
	if scratch.inUse {
		return errors.New("parser-core phase zero: materialization postorder scratch is already in use")
	}
	if poll == nil {
		poll = func() error { return nil }
	}
	if err := poll(); err != nil {
		return err
	}
	if err := scratch.prepare(c.subtrees.Len()); err != nil {
		return err
	}
	defer scratch.Reset()

	colors := scratch.colors
	records := c.subtrees
	var reusedOwners map[uint32]SubtreeID
	if len(c.reusedSubtrees) != 0 {
		reusedOwners = make(map[uint32]SubtreeID)
	}
	var visited, work uint64
	for _, root := range roots {
		record, err := c.subtree(root)
		if err != nil {
			return err
		}
		if colors[root] != 0 {
			return errors.New("parser-core phase zero: compact subtree has repeated public-tree ownership")
		}
		colors[root] = 1
		rootFrame := materializationPostorderFrame{id: root, prebuilt: prebuilt != nil && prebuilt(root)}
		if transition != nil {
			c.fillMaterializationReplayViewForRecord(root, record, &scratch.replayView)
			state, known, err := transition(rootPre, &scratch.replayView)
			if err != nil {
				return err
			}
			rootFrame.pre, rootFrame.cursor = rootPre, rootPre
			rootFrame.state, rootFrame.stateKnown = state, known
			rootFrame.preKnown = known && !record.extra
		}
		scratch.frames = append(scratch.frames, rootFrame)
		for len(scratch.frames) != 0 {
			work++
			if work&255 == 0 {
				if err := poll(); err != nil {
					return err
				}
			}
			top := &scratch.frames[len(scratch.frames)-1]
			record := records.At(int(top.id - 1))
			if top.next < record.childCount {
				child := c.children[record.firstChild+top.next]
				top.next++
				childRecord, err := c.subtree(child)
				if err != nil {
					return err
				}
				switch colors[child] {
				case 0:
					colors[child] = 1
					childFrame := materializationPostorderFrame{id: child,
						prebuilt: top.prebuilt || (prebuilt != nil && prebuilt(child))}
					if transition != nil {
						childPre := top.cursor
						c.fillMaterializationReplayViewForRecord(child, childRecord, &scratch.replayView)
						state, known, err := transition(childPre, &scratch.replayView)
						if err != nil {
							return err
						}
						// The replay advances the parent's cursor by the child's
						// result even when the tables held no transition.
						top.cursor = state
						childFrame.pre, childFrame.cursor = childPre, childPre
						childFrame.state, childFrame.stateKnown = state, known
						childFrame.preKnown = known && !childRecord.extra
					}
					scratch.frames = append(scratch.frames, childFrame)
					continue
				case 1:
					return errors.New("parser-core phase zero: compact subtree cycle during materialization")
				default:
					return errors.New("parser-core phase zero: compact subtree has repeated public-tree ownership")
				}
			}
			if err := c.validateMaterializationMetadata(top.id, record); err != nil {
				return err
			}
			if err := c.claimReusedOwnership(top.id, reusedOwners); err != nil {
				return err
			}
			if top.prebuilt {
				colors[top.id] = 2
				visited++
				scratch.frames = scratch.frames[:len(scratch.frames)-1]
				continue
			}
			view := &scratch.view
			c.fillMaterializationSubtreeView(top.id, record, view)
			if transition != nil {
				view.ReplayPreGotoState, view.ReplayParseState = top.pre, top.state
				view.ReplayPreGotoKnown, view.ReplayParseStateKnown = top.preKnown, top.stateKnown
			}
			if err := visit(top.id, view); err != nil {
				return err
			}
			colors[top.id] = 2
			visited++
			scratch.frames = scratch.frames[:len(scratch.frames)-1]
		}
	}
	if visited > uint64(c.subtrees.Len()) {
		return errors.New("parser-core phase zero: materialization exceeded compact subtree arena")
	}
	return poll()
}
