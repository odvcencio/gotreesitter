set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly -overlay=/controls/dense-perf-v4/overlay.container.json'
git config --global --add safe.directory /candidate
git config --global --add safe.directory /baseline
python3 - <<'CHECK'
from pathlib import Path
import json
p=Path('/controls/out/dense-root-qualification-v4')
assert (p/'completed.txt').is_file()
by={}
for mode in ['off','on']:
 for line in (p/f'entry-{mode}.log').read_text().splitlines():
  if 'ENTRY_WORK {' in line:
   row=json.loads(line.split('ENTRY_WORK ',1)[1]);by[mode,row['fixture'],row['entry'],row['candidate']]=row
assert len(by)==16
for (mode,fixture,entry,candidate),before in by.items():
 if mode!='off':continue
 after=by['on',fixture,entry,candidate]
 assert before['deep_digest']==after['deep_digest']
 assert before['work']==after['work']
 if candidate:
  a,b=before['dense_private_observations'][0],after['dense_private_observations'][0]
  assert a['SchedulerWork']==b['SchedulerWork']
  for key in ['SourceSHA256','PayloadScannerSHA256','DependencySHA256','DependenciesDisabled','Dispatches','Tokens','BranchOrder','NextSeq','ElectionIndex','CheckpointID','DenseStateReleased']:assert a[key]==b[key],key
  for key in a['CoreWork']:
   if key=='GraphLinkAdditionsProxy':assert b['CoreWork'][key]<a['CoreWork'][key]
   else:assert a['CoreWork'][key]==b['CoreWork'][key],key
print('Eight exact work/publication pairs, strict C/D8, memory and lifetime prerequisites pass')
CHECK
cd /candidate
sha256sum --quiet -c /controls/dense-root-qualification/saved-source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/dense-perf-v4/controls.sha256 > /evidence/controls-before.log 2>&1
GTS_ADMISSION_REAL_CORPUS_LANGS=go bash scripts/run_randomized_benchmarks.sh --output /evidence/r4-after-go.txt --baseline-root /baseline --baseline-output /evidence/r4-before-go.txt --lock-path /evidence/benchmark.lock --bench-regex '^BenchmarkCompactGraduationR4$' --require-benchmarks BenchmarkCompactGraduationR4/legacy,BenchmarkCompactGraduationR4/compact --runs 20 --seed-start 1 --benchtime 750ms > /evidence/r4-runner-go.log 2>&1
sha256sum --quiet -c /controls/dense-root-qualification/saved-source.sha256 > /evidence/source-after.log 2>&1
sha256sum --quiet -c /controls/dense-perf-v4/controls.sha256 > /evidence/controls-after.log 2>&1
printf 'Twenty real Go pairs complete; observer-only correction, no graduation or production claim\n' > /evidence/completed.txt
