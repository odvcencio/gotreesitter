set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
cd /candidate
sha256sum --quiet -c /controls/dense-root-qualification/saved-source.sha256 > /evidence/source-before.log 2>&1
go test -tags gts_parsercorephase0 -overlay=/controls/dense-canonical-work-v1/overlay.container.json -run '^TestPrivateDenseCanonicalGraphWork$' -count=1 -v . > /evidence/probe.log 2>&1
sha256sum --quiet -c /controls/dense-root-qualification/saved-source.sha256 > /evidence/source-after.log 2>&1
