set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/dense-memory-pins-v1
mkdir -p "$scratch"
cd /candidate
sha256sum --quiet -c /controls/dense-root-qualification/saved-source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/dense-memory-pins-v1/controls.sha256 > /evidence/controls-before.log 2>&1
go test -c -tags gts_parsercorephase0 -overlay=/controls/dense-memory-pins-v1/overlay.container.json -o "$scratch/root.test" . > /evidence/build.log 2>&1
set +e
"$scratch/root.test" -test.run '^Test(CompactAcceptance.*|ParserCoreFreshFullRunner.*|RuntimeMemory.*|ParseMemory.*|SetMemoryBudgetBytesZeroDoesNotAllocateColdState|MemoryBudgetDiagnosticLatchesFirstSource)$' -test.v -test.count=1 -test.timeout=4m > /evidence/memory-lifecycle.log 2>&1
memory_status=$?
"$scratch/root.test" -test.run '^TestGoCleanReuseGraduationBenchmarkTransitionsPrivate$' -test.v -test.count=1 -test.timeout=5m > /evidence/clean-reuse.log 2>&1
reuse_status=$?
set -e
sha256sum --quiet -c /controls/dense-root-qualification/saved-source.sha256 > /evidence/source-after.log 2>&1
sha256sum --quiet -c /controls/dense-memory-pins-v1/controls.sha256 > /evidence/controls-after.log 2>&1
sha256sum "$scratch/root.test" > /evidence/binary.sha256
printf '{"memory_exit":%d,"clean_reuse_exit":%d}\n' "$memory_status" "$reuse_status" > /evidence/process-status.json
if (( memory_status != 0 || reuse_status != 0 )); then exit 1; fi
printf 'exact graph pins and full original memory assertions passed; clean replacement reuse passed\n' > /evidence/completed.txt
