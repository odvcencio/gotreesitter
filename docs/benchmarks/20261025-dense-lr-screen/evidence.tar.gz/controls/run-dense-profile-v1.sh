set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly -overlay=/controls/dense-perf-v1/overlay.container.json'
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/dense-profile-v1
mkdir -p "$scratch"
cd /candidate
sha256sum --quiet -c /controls/dense-root-qualification/saved-source.sha256 > /evidence/source-before.log 2>&1
GTS_ADMISSION_CANDIDATE=1 go test -o "$scratch/profile.test" -tags gts_parsercorephase0 -run '^$' -bench '^BenchmarkGoParseFullDFA$' -benchtime=4s -count=1 -cpuprofile=/evidence/generated.cpu.pprof . > /evidence/generated-profile.log 2>&1
GTS_ADMISSION_REAL_CORPUS_LANGS=go go test -o "$scratch/profile.test" -tags gts_parsercorephase0 -run '^$' -bench '^BenchmarkAdmissionR4Compact$' -benchtime=4s -count=1 -cpuprofile=/evidence/r4.cpu.pprof . > /evidence/r4-profile.log 2>&1
go tool pprof -top -nodecount=35 /evidence/generated.cpu.pprof > /evidence/generated-top.txt
go tool pprof -top -cum -nodecount=35 /evidence/generated.cpu.pprof > /evidence/generated-cum.txt
go tool pprof -top -nodecount=35 /evidence/r4.cpu.pprof > /evidence/r4-top.txt
go tool pprof -top -cum -nodecount=35 /evidence/r4.cpu.pprof > /evidence/r4-cum.txt
sha256sum --quiet -c /controls/dense-root-qualification/saved-source.sha256 > /evidence/source-after.log 2>&1
printf 'CPU attribution only; fixed-order profile runs are not comparison evidence\n' > /evidence/completed.txt
