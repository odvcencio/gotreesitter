#!/usr/bin/env python3
"""Prepare private root-test overlay only. No compilation or test execution."""
from pathlib import Path
import hashlib
import json
import subprocess

p = Path(__file__).resolve().parent
root = p.parents[3]
name = "go_reuse_graduation_test.go.txt"
subprocess.check_call(["gofmt", "-w", str(p / name)], cwd=root)
def sha(data): return hashlib.sha256(data).hexdigest()
def dump(name, obj): (p / name).write_text(json.dumps(obj, indent=2) + "\n")
virtual = "zz_gts_go_reuse_graduation_private_test.go"
assert not (root / virtual).exists()
dump("overlay.container.json", {"Replace": {"/candidate/"+virtual: "/controls/go-reuse-graduation-v1/"+name}})
dump("overlay.host.json", {"Replace": {str(root/virtual): str(p/name)}})
inputs = ["incremental_invariant_gate_test.go", "internal/benchfixtures/edit_session.go", "internal/benchfixtures/go_tree_digest.go", "internal/benchfixtures/deep_digest.go", "internal/benchfixtures/real_corpus.json", "internal/benchfixtures/testdata/real/go", "grammars/grammar_blobs/go.bin", "parser.go", "parser_api.go", "incremental.go", "tree.go", "admission_switch.go", "admission_switch_candidate.go"]
dump("manifest.json", {
    "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
    "private_overlay_only": True, "source_bytes": 2047, "steps": 72, "seed": 4242,
    "source_sha256": "b37389f6dbac4e417f19db04909783b0264dfec4e3c93774f0557c3e91b8f6c5",
    "session_sha256": "071227746df0a0f7974e04b8b6f32c10151fc31adc06571d1c135743185a6dfb",
    "expected_target_rows": 146, "expected_pairs": 73,
    "no_vacuous_clean_reuse_pass": True, "no_tree_walk_before_target_profile": True,
    "each_target_replays_exact_unobserved_original_prefix": True,
    "selector": "^TestGoReuseGraduationR4SessionPrivate$", "tags": "gts_parsercorephase0",
    "build_from": "/candidate", "overlay": "/controls/go-reuse-graduation-v1/overlay.container.json",
    "execution": ["<root-test-binary>", "-test.run", "^TestGoReuseGraduationR4SessionPrivate$", "-test.count=1", "-test.v", "-test.timeout=5m"],
    "production_modified": False, "tests_builds_Docker_run": False,
    "inputs": {name: {"bytes": (root/name).stat().st_size, "sha256": sha((root/name).read_bytes())} for name in inputs},
    "files": {x.name: {"bytes": x.stat().st_size, "sha256": sha(x.read_bytes())} for x in sorted(p.iterdir()) if x.is_file() and x.name != "manifest.json"}})
print(json.dumps({"head": json.loads((p/"manifest.json").read_text())["head"], "test_sha256": sha((p/name).read_bytes()), "builds_tests_run": False}))
