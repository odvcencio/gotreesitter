set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly'
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/dense-memory-reuse-v2
mkdir -p "$scratch"
cd /candidate
sha256sum --quiet -c /controls/dense-root-qualification/saved-source.sha256 > /evidence/source-before.log 2>&1
sha256sum --quiet -c /controls/dense-memory-reuse-v2/controls.sha256 > /evidence/controls-before.log 2>&1
go test -c -tags gts_parsercorephase0 -overlay=/controls/go-reuse-graduation-v2/overlay.container.json -o "$scratch/baseline.test" . > /evidence/baseline-build.log 2>&1
set +e
"$scratch/baseline.test" -test.run '^TestGoReuseGraduationR4SessionPrivate$' -test.v -test.count=1 -test.timeout=5m > /evidence/reuse-baseline.log 2>&1
baseline_status=$?
set -e
go test -c -tags gts_parsercorephase0 -overlay=/controls/dense-memory-reuse-v2/overlay.container.json -o "$scratch/dense.test" . > /evidence/dense-build.log 2>&1
set +e
"$scratch/dense.test" -test.run '^TestGoReuseGraduationR4SessionPrivate$' -test.v -test.count=1 -test.timeout=5m > /evidence/reuse-dense.log 2>&1
dense_status=$?
"$scratch/dense.test" -test.run '^Test(CompactAcceptance.*|ParserCoreFreshFullRunner.*|RuntimeMemory.*|ParseMemory.*|SetMemoryBudgetBytesZeroDoesNotAllocateColdState|MemoryBudgetDiagnosticLatchesFirstSource)$' -test.v -test.count=1 -test.timeout=4m > /evidence/memory-lifecycle.log 2>&1
memory_status=$?
set -e
sha256sum --quiet -c /controls/dense-root-qualification/saved-source.sha256 > /evidence/source-after.log 2>&1
sha256sum --quiet -c /controls/dense-memory-reuse-v2/controls.sha256 > /evidence/controls-after.log 2>&1
sha256sum "$scratch/baseline.test" "$scratch/dense.test" > /evidence/binary.sha256
printf '{"baseline_reuse_exit":%d,"dense_reuse_exit":%d,"memory_exit":%d}\n' "$baseline_status" "$dense_status" "$memory_status" > /evidence/process-status.json
if (( baseline_status != 0 || dense_status != 0 || memory_status != 0 )); then exit 1; fi
printf 'focused memory/lifetime and explicit Go reuse processes passed; analyze coverage and counters\n' > /evidence/completed.txt
