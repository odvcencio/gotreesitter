#!/usr/bin/env python3
"""Prepare additive clean replacement controls, with no builds or tests."""
from pathlib import Path
import hashlib
import json
import subprocess

p = Path(__file__).resolve().parent
root = p.parents[3]
prior = p.parent / "go-reuse-graduation-v2/go_reuse_graduation_test.go.txt"
def sha(data): return hashlib.sha256(data).hexdigest()
assert sha(prior.read_bytes()) == "67c1526d2c7ad2a2ed6a6344e27dc16ffbd70105b443ab75230e04ed7dc771fe"
s = prior.read_text().replace("goReuseGraduation", "goCleanReuseGraduation").replace("TestGoReuseGraduationR4SessionPrivate", "TestGoCleanReuseGraduationBenchmarkTransitionsPrivate").replace("go_reuse_graduation", "go_clean_reuse_graduation")
s = s.replace('"crypto/sha256"', '"bytes"\n\t"crypto/sha256"\n\t"encoding/binary"').replace('\n\t"path/filepath"', '')
s = s.replace('b37389f6dbac4e417f19db04909783b0264dfec4e3c93774f0557c3e91b8f6c5', '2e0f9d4676549c8560cebc3c53877932f921ab9d77c88518227f3018573af4b7').replace('071227746df0a0f7974e04b8b6f32c10151fc31adc06571d1c135743185a6dfb', 'dcdd42954ccb0ada55e15fa11b8b293f005f229bdc1a3002d132d398d651feda')
a = s.index('\traw, err := os.ReadFile(')
b = s.index('\tlang := grammars.GoLanguage()', a)
s = s[:a] + '''\tsource := makeGoBenchmarkSource(500)
\tif len(source) != 19294 || fmt.Sprintf("%x", sha256.Sum256(source)) != goCleanReuseGraduationSourceSHA {
\t\tt.Fatal("500-function benchmark source identity changed")
\t}
\teditAt := bytes.Index(source, []byte("v := 0"))
\tif editAt < 0 { t.Fatal("benchmark edit marker missing") }
\teditAt += len("v := ")
\tif editAt != 35 { t.Fatalf("benchmark edit site=%d, want35", editAt) }
\tstart, end := pointAtOffset(source, editAt), pointAtOffset(source, editAt+1)
\tedit := gts.InputEdit{StartByte: uint32(editAt), OldEndByte: uint32(editAt+1), NewEndByte: uint32(editAt+1), StartPoint: start, OldEndPoint: end, NewEndPoint: end}
\tif got := goCleanReuseGraduationSessionSHA(source, edit, editAt); got != goCleanReuseGraduationSessionSHA { t.Fatalf("benchmark transition sessionSHA=%s", got) }
\tblob, err := os.ReadFile("grammars/grammar_blobs/go.bin")
\tif err != nil { t.Fatal(err) }
\tif got := fmt.Sprintf("%x", sha256.Sum256(blob)); got != goCleanReuseGraduationBlobSHA { t.Fatalf("Go grammar SHA=%s", got) }
''' + s[b:]
s = s.replace('// This private receipt checks the unchanged R4 schedule, not V4 activation.', '// This additive control uses the existing 500-function benchmark and exact\n// single-site 0<->1 replacement; it does not replace the R4 schedule or cover\n// insertion, deletion, 16 sites, C equality, performance, or full graduation.')
oldlog='\tt.Logf("go_clean_reuse_graduation_identity source_sha256=%s session_sha256=%s blob_sha256=%s bytes=%d seed=%d steps=%d", goCleanReuseGraduationSourceSHA, goCleanReuseGraduationSessionSHA, goCleanReuseGraduationBlobSHA, len(source), benchfixtures.EditSessionSeed, len(steps))'
assert oldlog in s
s=s.replace(oldlog,'\tt.Logf("go_clean_reuse_graduation_identity source_sha256=%s session_sha256=%s blob_sha256=%s bytes=%d edit_at=%d steps=72 scope=single-site-replacement-only", goCleanReuseGraduationSourceSHA, goCleanReuseGraduationSessionSHA, goCleanReuseGraduationBlobSHA, len(source), editAt)')
s=s.replace('target <= len(steps)', 'target <= 72')
s=s.replace('goCleanReuseGraduationTarget(t, lang, source, steps, target, route == 1)', 'goCleanReuseGraduationTarget(t, lang, source, edit, editAt, target, route == 1)')
s=s.replace('steps []benchfixtures.EditStep, target int', 'edit gts.InputEdit, editAt, target int')
s=s.replace('\ttree, err := parser.Parse(source)', '\tcurrent := append([]byte(nil), source...)\n\tscratch := make([]byte, len(current))\n\ttree, err := parser.Parse(current)',1)
s=s.replace('\tcurrent := source\n', '',1)
s=s.replace('\t\tstep := steps[i]\n\t\tprevious := tree\n\t\tprevious.Edit(step.Edit)\n\t\tnext, profile, err := parser.ParseIncrementalProfiled(step.Source, previous)', '\t\tnextSource := prepareEditedBenchmarkSource(current, scratch, editAt)\n\t\tprevious := tree\n\t\tprevious.Edit(edit)\n\t\tnext, profile, err := parser.ParseIncrementalProfiled(nextSource, previous)',1)
s=s.replace('\t\ttree, current, result.Profile = next, step.Source, profile', '\t\toldSource := current\n\t\ttree, current, result.Profile = next, nextSource, profile\n\t\tscratch = oldSource',1)
s=s.replace('class = []string{"insert", "delete", "replace"}[(target-1)%3]', 'class = "replace"')
s=s.replace('row["edit"] = steps[target-1].Edit','row["edit"] = edit')
s=s.replace('"profile": result.Profile, "runtime": runtime,', '"reused_subtrees": result.Profile.ReusedSubtrees, "reused_bytes": result.Profile.ReusedBytes, "new_nodes": result.Profile.NewNodesAllocated, "tokens": result.Profile.TokensConsumed, "max_stacks": result.Profile.MaxStacksSeen, "block_splices": result.Profile.BlockSpliceSteps, "old_tree_reuse_route": result.Profile.OldTreeReuseRoute, "reuse_unsupported": result.Profile.ReuseUnsupported, "reuse_unsupported_reason": result.Profile.ReuseUnsupportedReason, "stop_reason": runtime.StopReason, "compact_incremental_reuse": runtime.CompactIncrementalReuseRoute, "compact_incremental_fallback_reason": runtime.CompactIncrementalFallbackReason,')
s=s.replace('if target == 0 || !got[0].Clean || !got[1].Clean {\n\t\t\t\treturn\n\t\t\t}', 'if !got[0].Clean || !got[1].Clean { t.Errorf("benchmark control must remain clean on both routes") }\n\t\t\tif target == 0 { return }')
s=s.replace('if cleanSteps == 0 {\n\t\tt.Error("fixed 72-step R4 schedule contains no clean edited states; positive clean-step reuse graduation requirement is unproven")\n\t}', 'if cleanSteps != 72 || positiveCandidateSteps != 72 {\n\t\tt.Errorf("clean replacement coverage incomplete: clean=%d positive_candidate=%d, want72each", cleanSteps, positiveCandidateSteps)\n\t}')
# The summary's count reflects verified clean steps, never a presumed fixture.
s=s.replace('\t\t\tcleanSteps++', '\t\t\tif got[0].Clean && got[1].Clean { cleanSteps++ }')
s += '''
// Hash the same nine edit coordinates plus resulting-sourceSHA stream used by
// EditingSessionSHA256, for this separately identified benchmark transition set.
func goCleanReuseGraduationSessionSHA(source []byte, edit gts.InputEdit, at int) string {
\th := sha256.New()
\tvar fields [36]byte
\tvalues := [...]uint32{edit.StartByte, edit.OldEndByte, edit.NewEndByte, edit.StartPoint.Row, edit.StartPoint.Column, edit.OldEndPoint.Row, edit.OldEndPoint.Column, edit.NewEndPoint.Row, edit.NewEndPoint.Column}
\tfor i, v := range values { binary.LittleEndian.PutUint32(fields[i*4:], v) }
\tcurrent := append([]byte(nil), source...)
\tscratch := make([]byte, len(current))
\tfor i := 0; i < 72; i++ {
\t\tnext := prepareEditedBenchmarkSource(current, scratch, at)
\t\th.Write(fields[:])
\t\tsum := sha256.Sum256(next)
\t\th.Write(sum[:])
\t\tcurrent, scratch = next, current
\t}
\treturn fmt.Sprintf("%x", h.Sum(nil))
}
'''
# Give the constant and hash function distinct names.
s=s.replace('func goCleanReuseGraduationSessionSHA(', 'func goCleanReuseGraduationSessionDigest(').replace('got := goCleanReuseGraduationSessionSHA(source, edit, editAt)', 'got := goCleanReuseGraduationSessionDigest(source, edit, editAt)')
assert 'steps[' not in s and 'len(steps)' not in s and 'EditSessionSeed' not in s
assert '"profile": result.Profile' not in s and 'ReuseCursorNanos' not in s
name = 'go_clean_reuse_graduation_test.go.txt'
(p/name).write_text(s)
subprocess.check_call(['gofmt','-w',str(p/name)],cwd=root)
def dump(name,obj): (p/name).write_text(json.dumps(obj,indent=2)+'\n')
virtual='zz_gts_go_clean_reuse_graduation_private_test.go'
assert not (root/virtual).exists()
dump('overlay.container.json',{'Replace':{'/candidate/'+virtual:'/controls/go-clean-reuse-graduation-v1/'+name}})
dump('overlay.host.json',{'Replace':{str(root/virtual):str(p/name)}})
inputs=['benchmark_test.go','incremental_invariant_gate_test.go','internal/benchfixtures/go_tree_digest.go','internal/benchfixtures/deep_digest.go','grammars/grammar_blobs/go.bin']
dump('manifest.json',{
 'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'scope':'additive single-site replacement clean-control; not original R4 schedule or full graduation',
 'source_helper':'makeGoBenchmarkSource(500)', 'transition_helpers':['prepareEditedBenchmarkSource','pointAtOffset'],
 'source_bytes':19294,'source_sha256':'2e0f9d4676549c8560cebc3c53877932f921ab9d77c88518227f3018573af4b7',
 'edited_sha256':'63d6743bdfcf50d94242b6c85923570d38b4ed8a24b2e9b636e91526874b71cd',
 'session_sha256':'dcdd42954ccb0ada55e15fa11b8b293f005f229bdc1a3002d132d398d651feda',
 'edit_at':35,'start_point':{'row':2,'column':21},'classes':['replace'],'edited_steps':72,
 'expected_target_rows':146,'expected_pairs':73,'expected_clean_edited_pairs':72,
 'ordinary_initial_Parse_then_Profiled_incremental':True,'exact_benchmark_buffer_swap':True,
 'no_tree_walk_before_target_profile':True,'no_edit_allocations_required':0,
 'candidate_positive_and_at_least_legacy_on_both_reuse_metrics':True,
 'not_covered':['insert','delete','16-sites','C oracle equality','timing','full graduation'],
 'selector':'^TestGoCleanReuseGraduationBenchmarkTransitionsPrivate$','tags':'gts_parsercorephase0',
 'production_modified':False,'tests_builds_Docker_run':False,
 'inputs':{n:{'bytes':(root/n).stat().st_size,'sha256':sha((root/n).read_bytes())} for n in inputs},
 'files':{x.name:{'bytes':x.stat().st_size,'sha256':sha(x.read_bytes())} for x in sorted(p.iterdir()) if x.is_file() and x.name!='manifest.json'}})
print(json.dumps({'test_sha256':sha((p/name).read_bytes()),'builds_tests_run':False}))
