#!/usr/bin/env python3
"""Print an exact held-V2 Docker command. --execute explicitly acquires the shared lock."""
import argparse,fcntl,hashlib,json,pathlib,subprocess
p=argparse.ArgumentParser()
p.add_argument('--group',required=True,choices=['dense-root-qualification-v1', 'dense-memory-reuse-v1', 'dense-memory-reuse-v2', 'dense-canonical-work-v1', 'dense-memory-pins-v1', 'dense-perf-v1', 'dense-perf-v2', 'dense-profile-v1'])
for x in ['repo','module-cache','c-cache','runtime','output']:p.add_argument('--'+x,required=True,type=pathlib.Path)
p.add_argument('--cpu',required=True,type=int)
p.add_argument('--lock',type=pathlib.Path,default=pathlib.Path('/tmp/gotreesitter-compact-storage-docker.lock'))
p.add_argument('--execute',action='store_true');a=p.parse_args()
home=pathlib.Path(__file__).resolve().parent
for line in (home/'payload.sha256').read_text().splitlines():
 expected,name=line.split('  ',1);assert hashlib.sha256((home/name).read_bytes()).hexdigest()==expected,name
for x in ['repo','module_cache','c_cache','runtime']:
 v=getattr(a,x).resolve();assert v.is_dir(),v;setattr(a,x,v)
for line in (home/'controls/dense-root-qualification/saved-source.sha256').read_text().splitlines():
 expected,name=line.split('  ',1);assert hashlib.sha256((a.repo/name).read_bytes()).hexdigest()==expected,name
# Authenticate the runner too: it is outside the original Go/bin manifest.
assert (a.repo/'scripts/run_randomized_benchmarks.sh').read_bytes()==(home/'source/scripts/run_randomized_benchmarks.sh').read_bytes()
out=a.output.resolve();assert not out.exists(),'choose a new output directory; preserve original failed and successful evidence'
cmd=json.loads((home/('controls/commands-'+a.group+'.json')).read_text())[0]['args'][:]
binds={'/candidate':a.repo,'/baseline':a.repo,'/controls':home/'controls','/prior-controls':home/'controls',
       '/go-mod':a.module_cache,'/c-cache':a.c_cache,'/runtime':a.runtime,'/evidence':out,'/measurement-lock':a.lock.resolve()}
for i,arg in enumerate(cmd):
 if i and cmd[i-1]=='-v':
  src,dst,*mode=arg.split(':');assert dst in binds,dst
  cmd[i]=str(binds[dst])+':'+dst+(':'+':'.join(mode) if mode else '')
cmd[cmd.index('--cpuset-cpus')+1]=str(a.cpu)
cmd[cmd.index('--name')+1]='gts-held-dense-v2-'+hashlib.sha256(str(out).encode()).hexdigest()[:12]
print(json.dumps(cmd,indent=2))
if a.execute:
 out.mkdir(parents=True,exist_ok=False)
 with a.lock.open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  with (out/'container.log').open('w') as log:
   try:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=1300)
   except subprocess.TimeoutExpired:
    subprocess.run(['docker','stop','--time','10',cmd[cmd.index('--name')+1]],capture_output=True)
    raise SystemExit(124)
 raise SystemExit(r.returncode)
