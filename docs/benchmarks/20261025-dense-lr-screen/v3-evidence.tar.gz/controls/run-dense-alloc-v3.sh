set -euo pipefail
export TMPDIR=/runtime/tmp GOTMPDIR=/runtime/go-tmp GOCACHE=/runtime/go-build GOWORK=off GOTOOLCHAIN=local GOFLAGS='-p=1 -mod=readonly -overlay=/controls/dense-perf-v3/overlay.container.json'
git config --global --add safe.directory /candidate
scratch=/runtime/tmp/gotreesitter-go-ci-20261025/dense-alloc-v3
mkdir -p "$scratch"
cd /candidate
sha256sum --quiet -c /controls/dense-root-qualification/saved-source.sha256 > /evidence/source-before.log 2>&1
GTS_ADMISSION_REAL_CORPUS_LANGS=go go test -o "$scratch/profile.test" -tags gts_parsercorephase0 -run '^$' -bench '^BenchmarkAdmissionR4Compact$' -benchtime=2s -count=1 -memprofilerate=1 -memprofile=/evidence/r4.mem.pprof . > /evidence/profile.log 2>&1
go tool pprof -alloc_objects -top -nodecount=40 /evidence/r4.mem.pprof > /evidence/alloc-top.txt
go tool pprof -alloc_objects -top -cum -nodecount=40 /evidence/r4.mem.pprof > /evidence/alloc-cum.txt
sha256sum --quiet -c /controls/dense-root-qualification/saved-source.sha256 > /evidence/source-after.log 2>&1
printf 'allocation attribution only; profiler-perturbed timing is not performance evidence\n' > /evidence/completed.txt
