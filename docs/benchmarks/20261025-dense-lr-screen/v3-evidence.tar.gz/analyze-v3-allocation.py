#!/usr/bin/env python3
"""Read the frozen Go pprof protobuf; no Go executable or workload required."""
from pathlib import Path
import gzip,json
def varint(data,index):
 value=shift=0
 while True:
  byte=data[index];index+=1;value|=(byte&127)<<shift
  if byte<128:return value,index
  shift+=7
def message(data):
 out={};index=0
 while index<len(data):
  tag,index=varint(data,index);field,wire=tag>>3,tag&7
  if wire==0:value,index=varint(data,index)
  elif wire==2:
   length,index=varint(data,index);value=data[index:index+length];index+=length
  elif wire==1:value=data[index:index+8];index+=8
  elif wire==5:value=data[index:index+4];index+=4
  else:raise ValueError(wire)
  out.setdefault(field,[]).append(value)
 return out
def integers(items):
 out=[]
 for item in items:
  if isinstance(item,int):out.append(item);continue
  index=0
  while index<len(item):value,index=varint(item,index);out.append(value)
 return out
def analyze(home):
 profile=message(gzip.decompress((home/'controls/out/dense-alloc-v3/r4.mem.pprof').read_bytes()))
 strings=[x.decode() for x in profile[6]]
 types=[strings[message(x)[1][0]] for x in profile[1]]
 functions={message(x)[1][0]:message(x) for x in profile[5]}
 target={i for i,x in functions.items() if strings[x[2][0]].endswith('.tryDenseLRPrivate')}
 locations={message(x)[1][0]:message(x) for x in profile[4]}
 selected={i for i,x in locations.items() if any(message(line)[1][0] in target and message(line)[2][0]==357 for line in x.get(4,[]))}
 total=[0]*len(types)
 for raw in profile[2]:
  sample=message(raw)
  if integers(sample[1])[0] in selected:
   for i,value in enumerate(integers(sample[2])):total[i]+=value
 values=dict(zip(types,total))
 assert values['alloc_objects']==51451 and values['alloc_space']==3292864
 source=(home/'controls/dense-lr-v3-reentry/parsercore_dense_lr_private.go.txt').read_text().splitlines()
 assert source[356].strip()=='boundary, reduction, e := s.promoteDenseLRPrivate("core refused action: " + s.denseLR.LastRefusal())'
 return {'function':'tryDenseLRPrivate','source_line':357,'pprof_flat_location_ids':sorted(selected),
         'flat_alloc_objects':values['alloc_objects'],'flat_alloc_space_bytes':values['alloc_space'],
         'randomized_R4_delta_allocations_per_parse':23,'randomized_R4_delta_bytes_per_parse':1472,
         'exact_multiplicity':2237,'objects_match':51451==2237*23,'bytes_match':3292864==2237*1472,
         'profile_measured_benchmark_iterations':2133,
         'profile_scope':'includes setup/calibration/warm calls;2237 is not the timed-iteration count',
         'cause':'diagnostic reason concatenation at refusal is unconditional even with no observer',
         'candidate_status':'measured V3 remains rejected; no corrected variant measured in this receipt'}
if __name__=='__main__':print(json.dumps(analyze(Path(__file__).resolve().parent),indent=2))
